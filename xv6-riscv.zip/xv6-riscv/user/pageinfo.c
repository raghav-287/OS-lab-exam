#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  char *va = sbrk(4096);
  struct pageinfo info;
  int pid;
  int status;

  if ((uint64)va == (uint64)-1) {
    printf("sbrk failed\n");
    exit(1);
  }

  *va = 'x';
  if (pageinfo((uint64)va, &info) < 0) {
    printf("pageinfo failed\n");
    exit(1);
  }

  printf("Before protection:\n");
  printf("VA 0x%lx -> PPN 0x%lx Flags: P=%d W=%d U=%d\n",
         (unsigned long)((uint64)va), (unsigned long)(info.pa >> 12),
         info.present, info.writable, info.user);

  if (setreadonly((uint64)va) < 0) {
    printf("setreadonly failed\n");
    exit(1);
  }

  if (pageinfo((uint64)va, &info) < 0) {
    printf("pageinfo failed\n");
    exit(1);
  }

  printf("After setreadonly:\n");
  printf("VA 0x%lx -> PPN 0x%lx Flags: P=%d W=%d U=%d\n",
         (unsigned long)((uint64)va), (unsigned long)(info.pa >> 12),
         info.present, info.writable, info.user);

  pid = fork();
  if (pid == 0) {
    printf("Child attempting a write to the read-only page...\n");
    *va = 'y';
    exit(0);
  }

  wait(&status);
  printf("Parent: child was terminated after the protection fault.\n");
  exit(0);
}
