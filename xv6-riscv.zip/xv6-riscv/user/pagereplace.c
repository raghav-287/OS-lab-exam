#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define MAX_FRAMES 8
#define MAX_REF 32

static void
print_frames(int frames[], int count)
{
  int i;
  printf("[");
  for (i = 0; i < count; i++) {
    if (i > 0)
      printf(" ");
    if (frames[i] == -1)
      printf("-");
    else
      printf("%d", frames[i]);
  }
  printf("]");
}

static int
find_in_frames(int frames[], int used, int value)
{
  int i;
  for (i = 0; i < used; i++) {
    if (frames[i] == value)
      return i;
  }
  return -1;
}

static int
find_next_use(int refs[], int ref_count, int value, int current)
{
  int i;
  for (i = current + 1; i < ref_count; i++) {
    if (refs[i] == value)
      return i;
  }
  return ref_count + 1;
}

static void
simulate_fifo(int frame_count, int refs[], int ref_count, int *hits_out,
              int *faults_out)
{
  int frames[MAX_FRAMES];
  int used = 0;
  int pos = 0;
  int hits = 0;
  int faults = 0;
  int i;

  for (i = 0; i < MAX_FRAMES; i++)
    frames[i] = -1;

  for (i = 0; i < ref_count; i++) {
    int r = refs[i];
    int found = find_in_frames(frames, used, r);
    if (found >= 0) {
      hits++;
      printf("Ref %d: ", r);
      print_frames(frames, used);
      printf(" HIT\n");
      continue;
    }

    faults++;
    if (used < frame_count) {
      frames[used++] = r;
    } else {
      frames[pos] = r;
      pos = (pos + 1) % frame_count;
    }
    printf("Ref %d: ", r);
    print_frames(frames, frame_count);
    printf(" FAULT\n");
  }

  *hits_out = hits;
  *faults_out = faults;
  printf("FIFO with %d frames: %d faults, %d hits\n\n", frame_count, faults,
         hits);
}

static void
simulate_lru(int frame_count, int refs[], int ref_count, int *hits_out,
              int *faults_out)
{
  int frames[MAX_FRAMES];
  int lru[MAX_FRAMES];
  int used = 0;
  int hits = 0;
  int faults = 0;
  int i;

  for (i = 0; i < MAX_FRAMES; i++) {
    frames[i] = -1;
    lru[i] = 0;
  }

  for (i = 0; i < ref_count; i++) {
    int r = refs[i];
    int found = find_in_frames(frames, used, r);
    if (found >= 0) {
      hits++;
      printf("Ref %d: ", r);
      print_frames(frames, used);
      printf(" HIT\n");
      for (int j = 0; j < used; j++)
        lru[j]++;
      lru[found] = 0;
      continue;
    }

    faults++;
    if (used < frame_count) {
      frames[used] = r;
      lru[used] = 0;
      used++;
    } else {
      int evict = 0;
      int max = lru[0];
      for (int j = 1; j < used; j++) {
        if (lru[j] > max) {
          max = lru[j];
          evict = j;
        }
      }
      frames[evict] = r;
      lru[evict] = 0;
      for (int j = 0; j < used; j++)
        lru[j]++;
    }
    printf("Ref %d: ", r);
    print_frames(frames, frame_count);
    printf(" FAULT\n");
  }

  *hits_out = hits;
  *faults_out = faults;
  printf("LRU with %d frames: %d faults, %d hits\n\n", frame_count, faults,
         hits);
}

static void
simulate_optimal(int frame_count, int refs[], int ref_count, int *hits_out,
                 int *faults_out)
{
  int frames[MAX_FRAMES];
  int used = 0;
  int hits = 0;
  int faults = 0;
  int i;

  for (i = 0; i < MAX_FRAMES; i++)
    frames[i] = -1;

  for (i = 0; i < ref_count; i++) {
    int r = refs[i];
    int found = find_in_frames(frames, used, r);
    if (found >= 0) {
      hits++;
      printf("Ref %d: ", r);
      print_frames(frames, used);
      printf(" HIT\n");
      continue;
    }

    faults++;
    if (used < frame_count) {
      frames[used++] = r;
    } else {
      int evict = 0;
      int furthest = -1;
      for (int j = 0; j < used; j++) {
        int next = find_next_use(refs, ref_count, frames[j], i);
        if (next > furthest) {
          furthest = next;
          evict = j;
        }
      }
      frames[evict] = r;
    }
    printf("Ref %d: ", r);
    print_frames(frames, frame_count);
    printf(" FAULT\n");
  }

  *hits_out = hits;
  *faults_out = faults;
  printf("Optimal with %d frames: %d faults, %d hits\n\n", frame_count,
         faults, hits);
}

int
main(void)
{
  int refs[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0,
               1};
  int ref_count = 20;
  int frames[] = {3, 4, 5};
  int i;

  printf("Reference string: ");
  for (i = 0; i < ref_count; i++)
    printf("%d%c", refs[i], (i + 1 == ref_count) ? '\n' : ' ');

  printf("\n");
  for (i = 0; i < 3; i++) {
    int fifo_hits, fifo_faults;
    int lru_hits, lru_faults;
    int opt_hits, opt_faults;

    simulate_fifo(frames[i], refs, ref_count, &fifo_hits, &fifo_faults);
    simulate_lru(frames[i], refs, ref_count, &lru_hits, &lru_faults);
    simulate_optimal(frames[i], refs, ref_count, &opt_hits, &opt_faults);
    printf("Summary for %d frames: FIFO %d faults/%d hits, LRU %d faults/%d hits, Optimal %d faults/%d hits\n\n",
           frames[i], fifo_faults, fifo_hits, lru_faults, lru_hits, opt_faults,
           opt_hits);
  }

  printf("Frames | Algorithm | Faults | Hits | Hit ratio | Fault ratio\n");
  for (i = 0; i < 3; i++) {
    int f = frames[i];
    int fifo_hits, fifo_faults;
    int lru_hits, lru_faults;
    int opt_hits, opt_faults;
    int fifo_ratio, lru_ratio, opt_ratio;

    simulate_fifo(f, refs, ref_count, &fifo_hits, &fifo_faults);
    simulate_lru(f, refs, ref_count, &lru_hits, &lru_faults);
    simulate_optimal(f, refs, ref_count, &opt_hits, &opt_faults);

    fifo_ratio = (fifo_hits * 100) / ref_count;
    lru_ratio = (lru_hits * 100) / ref_count;
    opt_ratio = (opt_hits * 100) / ref_count;

    printf("%d      | FIFO      | %d     | %d    | %d%%       | %d%%\n",
           f, fifo_faults, fifo_hits, fifo_ratio, 100 - fifo_ratio);
    printf("%d      | LRU       | %d     | %d    | %d%%       | %d%%\n",
           f, lru_faults, lru_hits, lru_ratio, 100 - lru_ratio);
    printf("%d      | Optimal   | %d     | %d    | %d%%       | %d%%\n",
           f, opt_faults, opt_hits, opt_ratio, 100 - opt_ratio);
  }

  exit(0);
}
