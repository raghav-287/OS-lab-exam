
user/_pagereplace:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <print_frames>:
#define MAX_FRAMES 8
#define MAX_REF 32

static void
print_frames(int frames[], int count)
{
   0:	715d                	addi	sp,sp,-80
   2:	e486                	sd	ra,72(sp)
   4:	e0a2                	sd	s0,64(sp)
   6:	f84a                	sd	s2,48(sp)
   8:	f44e                	sd	s3,40(sp)
   a:	0880                	addi	s0,sp,80
   c:	892a                	mv	s2,a0
   e:	89ae                	mv	s3,a1
  int i;
  printf("[");
  10:	00001517          	auipc	a0,0x1
  14:	fc050513          	addi	a0,a0,-64 # fd0 <malloc+0x104>
  18:	601000ef          	jal	e18 <printf>
  for (i = 0; i < count; i++) {
  1c:	05305f63          	blez	s3,7a <print_frames+0x7a>
  20:	fc26                	sd	s1,56(sp)
  22:	f052                	sd	s4,32(sp)
  24:	ec56                	sd	s5,24(sp)
  26:	e85a                	sd	s6,16(sp)
  28:	e45e                	sd	s7,8(sp)
  2a:	4481                	li	s1,0
    if (i > 0)
      printf(" ");
    if (frames[i] == -1)
  2c:	5a7d                	li	s4,-1
      printf("-");
    else
      printf("%d", frames[i]);
  2e:	00001a97          	auipc	s5,0x1
  32:	fbaa8a93          	addi	s5,s5,-70 # fe8 <malloc+0x11c>
      printf("-");
  36:	00001b97          	auipc	s7,0x1
  3a:	faab8b93          	addi	s7,s7,-86 # fe0 <malloc+0x114>
      printf(" ");
  3e:	00001b17          	auipc	s6,0x1
  42:	f9ab0b13          	addi	s6,s6,-102 # fd8 <malloc+0x10c>
    if (frames[i] == -1)
  46:	00092583          	lw	a1,0(s2)
  4a:	01458f63          	beq	a1,s4,68 <print_frames+0x68>
      printf("%d", frames[i]);
  4e:	8556                	mv	a0,s5
  50:	5c9000ef          	jal	e18 <printf>
  for (i = 0; i < count; i++) {
  54:	2485                	addiw	s1,s1,1
  56:	0911                	addi	s2,s2,4
  58:	00998c63          	beq	s3,s1,70 <print_frames+0x70>
    if (i > 0)
  5c:	fe9055e3          	blez	s1,46 <print_frames+0x46>
      printf(" ");
  60:	855a                	mv	a0,s6
  62:	5b7000ef          	jal	e18 <printf>
  66:	b7c5                	j	46 <print_frames+0x46>
      printf("-");
  68:	855e                	mv	a0,s7
  6a:	5af000ef          	jal	e18 <printf>
  6e:	b7dd                	j	54 <print_frames+0x54>
  70:	74e2                	ld	s1,56(sp)
  72:	7a02                	ld	s4,32(sp)
  74:	6ae2                	ld	s5,24(sp)
  76:	6b42                	ld	s6,16(sp)
  78:	6ba2                	ld	s7,8(sp)
  }
  printf("]");
  7a:	00001517          	auipc	a0,0x1
  7e:	f7650513          	addi	a0,a0,-138 # ff0 <malloc+0x124>
  82:	597000ef          	jal	e18 <printf>
}
  86:	60a6                	ld	ra,72(sp)
  88:	6406                	ld	s0,64(sp)
  8a:	7942                	ld	s2,48(sp)
  8c:	79a2                	ld	s3,40(sp)
  8e:	6161                	addi	sp,sp,80
  90:	8082                	ret

0000000000000092 <simulate_fifo>:
}

static void
simulate_fifo(int frame_count, int refs[], int ref_count, int *hits_out,
              int *faults_out)
{
  92:	7135                	addi	sp,sp,-160
  94:	ed06                	sd	ra,152(sp)
  96:	e922                	sd	s0,144(sp)
  98:	fcce                	sd	s3,120(sp)
  9a:	f4d6                	sd	s5,104(sp)
  9c:	e4e6                	sd	s9,72(sp)
  9e:	1100                	addi	s0,sp,160
  a0:	89aa                	mv	s3,a0
  a2:	f6d43423          	sd	a3,-152(s0)
  a6:	f6e43023          	sd	a4,-160(s0)
  int hits = 0;
  int faults = 0;
  int i;

  for (i = 0; i < MAX_FRAMES; i++)
    frames[i] = -1;
  aa:	57fd                	li	a5,-1
  ac:	f6f42823          	sw	a5,-144(s0)
  b0:	f6f42a23          	sw	a5,-140(s0)
  b4:	f6f42c23          	sw	a5,-136(s0)
  b8:	f6f42e23          	sw	a5,-132(s0)
  bc:	f8f42023          	sw	a5,-128(s0)
  c0:	f8f42223          	sw	a5,-124(s0)
  c4:	f8f42423          	sw	a5,-120(s0)
  c8:	f8f42623          	sw	a5,-116(s0)

  for (i = 0; i < ref_count; i++) {
  cc:	10c05163          	blez	a2,1ce <simulate_fifo+0x13c>
  d0:	e526                	sd	s1,136(sp)
  d2:	e14a                	sd	s2,128(sp)
  d4:	f8d2                	sd	s4,112(sp)
  d6:	f0da                	sd	s6,96(sp)
  d8:	ecde                	sd	s7,88(sp)
  da:	e8e2                	sd	s8,80(sp)
  dc:	e0ea                	sd	s10,64(sp)
  de:	fc6e                	sd	s11,56(sp)
  e0:	892e                	mv	s2,a1
  e2:	060a                	slli	a2,a2,0x2
  e4:	00c58b33          	add	s6,a1,a2
  int faults = 0;
  e8:	4a81                	li	s5,0
  int hits = 0;
  ea:	4c81                	li	s9,0
  int pos = 0;
  ec:	4a01                	li	s4,0
  int used = 0;
  ee:	4481                	li	s1,0
      frames[used++] = r;
    } else {
      frames[pos] = r;
      pos = (pos + 1) % frame_count;
    }
    printf("Ref %d: ", r);
  f0:	00001b97          	auipc	s7,0x1
  f4:	f08b8b93          	addi	s7,s7,-248 # ff8 <malloc+0x12c>
    print_frames(frames, frame_count);
    printf(" FAULT\n");
  f8:	00001d17          	auipc	s10,0x1
  fc:	f18d0d13          	addi	s10,s10,-232 # 1010 <malloc+0x144>
  for (i = 0; i < used; i++) {
 100:	4c01                	li	s8,0
      printf(" HIT\n");
 102:	00001d97          	auipc	s11,0x1
 106:	f06d8d93          	addi	s11,s11,-250 # 1008 <malloc+0x13c>
 10a:	a0b1                	j	156 <simulate_fifo+0xc4>
    if (found >= 0) {
 10c:	0607c363          	bltz	a5,172 <simulate_fifo+0xe0>
      hits++;
 110:	2c85                	addiw	s9,s9,1
      printf("Ref %d: ", r);
 112:	855e                	mv	a0,s7
 114:	505000ef          	jal	e18 <printf>
      print_frames(frames, used);
 118:	85a6                	mv	a1,s1
 11a:	f7040513          	addi	a0,s0,-144
 11e:	ee3ff0ef          	jal	0 <print_frames>
      printf(" HIT\n");
 122:	856e                	mv	a0,s11
 124:	4f5000ef          	jal	e18 <printf>
      continue;
 128:	a025                	j	150 <simulate_fifo+0xbe>
      frames[used++] = r;
 12a:	00249793          	slli	a5,s1,0x2
 12e:	f9078793          	addi	a5,a5,-112
 132:	97a2                	add	a5,a5,s0
 134:	feb7a023          	sw	a1,-32(a5)
 138:	2485                	addiw	s1,s1,1
    printf("Ref %d: ", r);
 13a:	855e                	mv	a0,s7
 13c:	4dd000ef          	jal	e18 <printf>
    print_frames(frames, frame_count);
 140:	85ce                	mv	a1,s3
 142:	f7040513          	addi	a0,s0,-144
 146:	ebbff0ef          	jal	0 <print_frames>
    printf(" FAULT\n");
 14a:	856a                	mv	a0,s10
 14c:	4cd000ef          	jal	e18 <printf>
  for (i = 0; i < ref_count; i++) {
 150:	0911                	addi	s2,s2,4
 152:	032b0e63          	beq	s6,s2,18e <simulate_fifo+0xfc>
    int r = refs[i];
 156:	00092583          	lw	a1,0(s2)
  for (i = 0; i < used; i++) {
 15a:	00905c63          	blez	s1,172 <simulate_fifo+0xe0>
 15e:	f7040713          	addi	a4,s0,-144
 162:	87e2                	mv	a5,s8
    if (frames[i] == value)
 164:	4314                	lw	a3,0(a4)
 166:	fab683e3          	beq	a3,a1,10c <simulate_fifo+0x7a>
  for (i = 0; i < used; i++) {
 16a:	2785                	addiw	a5,a5,1
 16c:	0711                	addi	a4,a4,4
 16e:	fe979be3          	bne	a5,s1,164 <simulate_fifo+0xd2>
    faults++;
 172:	2a85                	addiw	s5,s5,1
    if (used < frame_count) {
 174:	fb34cbe3          	blt	s1,s3,12a <simulate_fifo+0x98>
      frames[pos] = r;
 178:	002a1793          	slli	a5,s4,0x2
 17c:	f9078793          	addi	a5,a5,-112
 180:	97a2                	add	a5,a5,s0
 182:	feb7a023          	sw	a1,-32(a5)
      pos = (pos + 1) % frame_count;
 186:	2a05                	addiw	s4,s4,1
 188:	033a6a3b          	remw	s4,s4,s3
 18c:	b77d                	j	13a <simulate_fifo+0xa8>
 18e:	64aa                	ld	s1,136(sp)
 190:	690a                	ld	s2,128(sp)
 192:	7a46                	ld	s4,112(sp)
 194:	7b06                	ld	s6,96(sp)
 196:	6be6                	ld	s7,88(sp)
 198:	6c46                	ld	s8,80(sp)
 19a:	6d06                	ld	s10,64(sp)
 19c:	7de2                	ld	s11,56(sp)
  }

  *hits_out = hits;
 19e:	f6843783          	ld	a5,-152(s0)
 1a2:	0197a023          	sw	s9,0(a5)
  *faults_out = faults;
 1a6:	f6043783          	ld	a5,-160(s0)
 1aa:	0157a023          	sw	s5,0(a5)
  printf("FIFO with %d frames: %d faults, %d hits\n\n", frame_count, faults,
 1ae:	86e6                	mv	a3,s9
 1b0:	8656                	mv	a2,s5
 1b2:	85ce                	mv	a1,s3
 1b4:	00001517          	auipc	a0,0x1
 1b8:	e6450513          	addi	a0,a0,-412 # 1018 <malloc+0x14c>
 1bc:	45d000ef          	jal	e18 <printf>
         hits);
}
 1c0:	60ea                	ld	ra,152(sp)
 1c2:	644a                	ld	s0,144(sp)
 1c4:	79e6                	ld	s3,120(sp)
 1c6:	7aa6                	ld	s5,104(sp)
 1c8:	6ca6                	ld	s9,72(sp)
 1ca:	610d                	addi	sp,sp,160
 1cc:	8082                	ret
  int faults = 0;
 1ce:	4a81                	li	s5,0
  int hits = 0;
 1d0:	4c81                	li	s9,0
 1d2:	b7f1                	j	19e <simulate_fifo+0x10c>

00000000000001d4 <simulate_optimal>:
}

static void
simulate_optimal(int frame_count, int refs[], int ref_count, int *hits_out,
                 int *faults_out)
{
 1d4:	7171                	addi	sp,sp,-176
 1d6:	f506                	sd	ra,168(sp)
 1d8:	f122                	sd	s0,160(sp)
 1da:	fcd6                	sd	s5,120(sp)
 1dc:	f8da                	sd	s6,112(sp)
 1de:	e8ea                	sd	s10,80(sp)
 1e0:	1900                	addi	s0,sp,176
 1e2:	8aaa                	mv	s5,a0
 1e4:	f6d43023          	sd	a3,-160(s0)
 1e8:	f4e43c23          	sd	a4,-168(s0)
  int hits = 0;
  int faults = 0;
  int i;

  for (i = 0; i < MAX_FRAMES; i++)
    frames[i] = -1;
 1ec:	57fd                	li	a5,-1
 1ee:	f6f42823          	sw	a5,-144(s0)
 1f2:	f6f42a23          	sw	a5,-140(s0)
 1f6:	f6f42c23          	sw	a5,-136(s0)
 1fa:	f6f42e23          	sw	a5,-132(s0)
 1fe:	f8f42023          	sw	a5,-128(s0)
 202:	f8f42223          	sw	a5,-124(s0)
 206:	f8f42423          	sw	a5,-120(s0)
 20a:	f8f42623          	sw	a5,-116(s0)

  for (i = 0; i < ref_count; i++) {
 20e:	0ec05363          	blez	a2,2f4 <simulate_optimal+0x120>
 212:	ed26                	sd	s1,152(sp)
 214:	e94a                	sd	s2,144(sp)
 216:	e54e                	sd	s3,136(sp)
 218:	e152                	sd	s4,128(sp)
 21a:	f4de                	sd	s7,104(sp)
 21c:	f0e2                	sd	s8,96(sp)
 21e:	ece6                	sd	s9,88(sp)
 220:	e4ee                	sd	s11,72(sp)
 222:	84b2                	mv	s1,a2
 224:	00458993          	addi	s3,a1,4
 228:	00060c9b          	sext.w	s9,a2
 22c:	4a05                	li	s4,1
  int faults = 0;
 22e:	4b01                	li	s6,0
  int hits = 0;
 230:	4d01                	li	s10,0
  int used = 0;
 232:	4901                	li	s2,0
          evict = j;
        }
      }
      frames[evict] = r;
    }
    printf("Ref %d: ", r);
 234:	00001c17          	auipc	s8,0x1
 238:	dc4c0c13          	addi	s8,s8,-572 # ff8 <malloc+0x12c>
    print_frames(frames, frame_count);
    printf(" FAULT\n");
 23c:	00001d97          	auipc	s11,0x1
 240:	dd4d8d93          	addi	s11,s11,-556 # 1010 <malloc+0x144>
  for (i = 0; i < used; i++) {
 244:	4b81                	li	s7,0
  return ref_count + 1;
 246:	0016079b          	addiw	a5,a2,1
 24a:	f6f43423          	sd	a5,-152(s0)
 24e:	a8f5                	j	34a <simulate_optimal+0x176>
    if (found >= 0) {
 250:	0c07c163          	bltz	a5,312 <simulate_optimal+0x13e>
      hits++;
 254:	2d05                	addiw	s10,s10,1
      printf("Ref %d: ", r);
 256:	8562                	mv	a0,s8
 258:	3c1000ef          	jal	e18 <printf>
      print_frames(frames, used);
 25c:	85ca                	mv	a1,s2
 25e:	f7040513          	addi	a0,s0,-144
 262:	d9fff0ef          	jal	0 <print_frames>
      printf(" HIT\n");
 266:	00001517          	auipc	a0,0x1
 26a:	da250513          	addi	a0,a0,-606 # 1008 <malloc+0x13c>
 26e:	3ab000ef          	jal	e18 <printf>
      continue;
 272:	a0f1                	j	33e <simulate_optimal+0x16a>
 274:	f7040813          	addi	a6,s0,-144
      for (int j = 0; j < used; j++) {
 278:	855e                	mv	a0,s7
      int furthest = -1;
 27a:	537d                	li	t1,-1
      int evict = 0;
 27c:	8e5e                	mv	t3,s7
  for (i = current + 1; i < ref_count; i++) {
 27e:	000a089b          	sext.w	a7,s4
 282:	a819                	j	298 <simulate_optimal+0xc4>
  return ref_count + 1;
 284:	f6843783          	ld	a5,-152(s0)
        if (next > furthest) {
 288:	00f35463          	bge	t1,a5,290 <simulate_optimal+0xbc>
          furthest = next;
 28c:	833e                	mv	t1,a5
          evict = j;
 28e:	8e2a                	mv	t3,a0
      for (int j = 0; j < used; j++) {
 290:	2505                	addiw	a0,a0,1
 292:	0811                	addi	a6,a6,4
 294:	07250763          	beq	a0,s2,302 <simulate_optimal+0x12e>
        int next = find_next_use(refs, ref_count, frames[j], i);
 298:	00082603          	lw	a2,0(a6)
  for (i = current + 1; i < ref_count; i++) {
 29c:	87c6                	mv	a5,a7
 29e:	fe98d3e3          	bge	a7,s1,284 <simulate_optimal+0xb0>
 2a2:	874e                	mv	a4,s3
    if (refs[i] == value)
 2a4:	4314                	lw	a3,0(a4)
 2a6:	fec681e3          	beq	a3,a2,288 <simulate_optimal+0xb4>
  for (i = current + 1; i < ref_count; i++) {
 2aa:	2785                	addiw	a5,a5,1
 2ac:	0711                	addi	a4,a4,4
 2ae:	fef49be3          	bne	s1,a5,2a4 <simulate_optimal+0xd0>
 2b2:	bfc9                	j	284 <simulate_optimal+0xb0>
 2b4:	64ea                	ld	s1,152(sp)
 2b6:	694a                	ld	s2,144(sp)
 2b8:	69aa                	ld	s3,136(sp)
 2ba:	6a0a                	ld	s4,128(sp)
 2bc:	7ba6                	ld	s7,104(sp)
 2be:	7c06                	ld	s8,96(sp)
 2c0:	6ce6                	ld	s9,88(sp)
 2c2:	6da6                	ld	s11,72(sp)
  }

  *hits_out = hits;
 2c4:	f6043783          	ld	a5,-160(s0)
 2c8:	01a7a023          	sw	s10,0(a5)
  *faults_out = faults;
 2cc:	f5843783          	ld	a5,-168(s0)
 2d0:	0167a023          	sw	s6,0(a5)
  printf("Optimal with %d frames: %d faults, %d hits\n\n", frame_count,
 2d4:	86ea                	mv	a3,s10
 2d6:	865a                	mv	a2,s6
 2d8:	85d6                	mv	a1,s5
 2da:	00001517          	auipc	a0,0x1
 2de:	d6e50513          	addi	a0,a0,-658 # 1048 <malloc+0x17c>
 2e2:	337000ef          	jal	e18 <printf>
         faults, hits);
}
 2e6:	70aa                	ld	ra,168(sp)
 2e8:	740a                	ld	s0,160(sp)
 2ea:	7ae6                	ld	s5,120(sp)
 2ec:	7b46                	ld	s6,112(sp)
 2ee:	6d46                	ld	s10,80(sp)
 2f0:	614d                	addi	sp,sp,176
 2f2:	8082                	ret
  int faults = 0;
 2f4:	4b01                	li	s6,0
  int hits = 0;
 2f6:	4d01                	li	s10,0
 2f8:	b7f1                	j	2c4 <simulate_optimal+0xf0>
    faults++;
 2fa:	2b05                	addiw	s6,s6,1
      int evict = 0;
 2fc:	4e01                	li	t3,0
    if (used < frame_count) {
 2fe:	01594d63          	blt	s2,s5,318 <simulate_optimal+0x144>
      frames[evict] = r;
 302:	002e1793          	slli	a5,t3,0x2
 306:	f9078793          	addi	a5,a5,-112
 30a:	97a2                	add	a5,a5,s0
 30c:	feb7a023          	sw	a1,-32(a5)
 310:	a821                	j	328 <simulate_optimal+0x154>
    faults++;
 312:	2b05                	addiw	s6,s6,1
    if (used < frame_count) {
 314:	f75950e3          	bge	s2,s5,274 <simulate_optimal+0xa0>
      frames[used++] = r;
 318:	00291793          	slli	a5,s2,0x2
 31c:	f9078793          	addi	a5,a5,-112
 320:	97a2                	add	a5,a5,s0
 322:	feb7a023          	sw	a1,-32(a5)
 326:	2905                	addiw	s2,s2,1
    printf("Ref %d: ", r);
 328:	8562                	mv	a0,s8
 32a:	2ef000ef          	jal	e18 <printf>
    print_frames(frames, frame_count);
 32e:	85d6                	mv	a1,s5
 330:	f7040513          	addi	a0,s0,-144
 334:	ccdff0ef          	jal	0 <print_frames>
    printf(" FAULT\n");
 338:	856e                	mv	a0,s11
 33a:	2df000ef          	jal	e18 <printf>
  for (i = 0; i < ref_count; i++) {
 33e:	001a079b          	addiw	a5,s4,1
 342:	0991                	addi	s3,s3,4
 344:	f74c88e3          	beq	s9,s4,2b4 <simulate_optimal+0xe0>
 348:	8a3e                	mv	s4,a5
    int r = refs[i];
 34a:	ffc9a583          	lw	a1,-4(s3)
  for (i = 0; i < used; i++) {
 34e:	fb2056e3          	blez	s2,2fa <simulate_optimal+0x126>
 352:	f7040713          	addi	a4,s0,-144
 356:	87de                	mv	a5,s7
    if (frames[i] == value)
 358:	4314                	lw	a3,0(a4)
 35a:	eeb68be3          	beq	a3,a1,250 <simulate_optimal+0x7c>
  for (i = 0; i < used; i++) {
 35e:	2785                	addiw	a5,a5,1
 360:	0711                	addi	a4,a4,4
 362:	ff279be3          	bne	a5,s2,358 <simulate_optimal+0x184>
 366:	b775                	j	312 <simulate_optimal+0x13e>

0000000000000368 <simulate_lru>:
{
 368:	7131                	addi	sp,sp,-192
 36a:	fd06                	sd	ra,184(sp)
 36c:	f922                	sd	s0,176(sp)
 36e:	e952                	sd	s4,144(sp)
 370:	e556                	sd	s5,136(sp)
 372:	f0ea                	sd	s10,96(sp)
 374:	0180                	addi	s0,sp,192
 376:	8a2a                	mv	s4,a0
 378:	f4d43423          	sd	a3,-184(s0)
 37c:	f4e43023          	sd	a4,-192(s0)
  for (i = 0; i < MAX_FRAMES; i++) {
 380:	f9040513          	addi	a0,s0,-112
{
 384:	f5040713          	addi	a4,s0,-176
 388:	f7040793          	addi	a5,s0,-144
    frames[i] = -1;
 38c:	56fd                	li	a3,-1
 38e:	c394                	sw	a3,0(a5)
    lru[i] = 0;
 390:	00072023          	sw	zero,0(a4)
  for (i = 0; i < MAX_FRAMES; i++) {
 394:	0791                	addi	a5,a5,4
 396:	0711                	addi	a4,a4,4
 398:	fea79be3          	bne	a5,a0,38e <simulate_lru+0x26>
  for (i = 0; i < ref_count; i++) {
 39c:	12c05d63          	blez	a2,4d6 <simulate_lru+0x16e>
 3a0:	f526                	sd	s1,168(sp)
 3a2:	f14a                	sd	s2,160(sp)
 3a4:	ed4e                	sd	s3,152(sp)
 3a6:	e15a                	sd	s6,128(sp)
 3a8:	fcde                	sd	s7,120(sp)
 3aa:	f8e2                	sd	s8,112(sp)
 3ac:	f4e6                	sd	s9,104(sp)
 3ae:	ecee                	sd	s11,88(sp)
 3b0:	89ae                	mv	s3,a1
 3b2:	060a                	slli	a2,a2,0x2
 3b4:	00c58b33          	add	s6,a1,a2
  int faults = 0;
 3b8:	4a81                	li	s5,0
  int hits = 0;
 3ba:	4d01                	li	s10,0
  int used = 0;
 3bc:	4901                	li	s2,0
    printf("Ref %d: ", r);
 3be:	00001c17          	auipc	s8,0x1
 3c2:	c3ac0c13          	addi	s8,s8,-966 # ff8 <malloc+0x12c>
    printf(" FAULT\n");
 3c6:	00001c97          	auipc	s9,0x1
 3ca:	c4ac8c93          	addi	s9,s9,-950 # 1010 <malloc+0x144>
  for (i = 0; i < used; i++) {
 3ce:	4b81                	li	s7,0
      for (int j = 1; j < used; j++) {
 3d0:	4d85                	li	s11,1
 3d2:	a835                	j	40e <simulate_lru+0xa6>
    if (found >= 0) {
 3d4:	0404dc63          	bgez	s1,42c <simulate_lru+0xc4>
    faults++;
 3d8:	2a85                	addiw	s5,s5,1
    if (used < frame_count) {
 3da:	09495b63          	bge	s2,s4,470 <simulate_lru+0x108>
      frames[used] = r;
 3de:	00291793          	slli	a5,s2,0x2
 3e2:	f9078793          	addi	a5,a5,-112
 3e6:	97a2                	add	a5,a5,s0
 3e8:	feb7a023          	sw	a1,-32(a5)
      lru[used] = 0;
 3ec:	fc07a023          	sw	zero,-64(a5)
      used++;
 3f0:	2905                	addiw	s2,s2,1
    printf("Ref %d: ", r);
 3f2:	8562                	mv	a0,s8
 3f4:	225000ef          	jal	e18 <printf>
    print_frames(frames, frame_count);
 3f8:	85d2                	mv	a1,s4
 3fa:	f7040513          	addi	a0,s0,-144
 3fe:	c03ff0ef          	jal	0 <print_frames>
    printf(" FAULT\n");
 402:	8566                	mv	a0,s9
 404:	215000ef          	jal	e18 <printf>
  for (i = 0; i < ref_count; i++) {
 408:	0991                	addi	s3,s3,4
 40a:	09698663          	beq	s3,s6,496 <simulate_lru+0x12e>
    int r = refs[i];
 40e:	0009a583          	lw	a1,0(s3)
  for (i = 0; i < used; i++) {
 412:	0f205a63          	blez	s2,506 <simulate_lru+0x19e>
 416:	f7040793          	addi	a5,s0,-144
 41a:	84de                	mv	s1,s7
    if (frames[i] == value)
 41c:	4398                	lw	a4,0(a5)
 41e:	fab70be3          	beq	a4,a1,3d4 <simulate_lru+0x6c>
  for (i = 0; i < used; i++) {
 422:	2485                	addiw	s1,s1,1
 424:	0791                	addi	a5,a5,4
 426:	ff249be3          	bne	s1,s2,41c <simulate_lru+0xb4>
 42a:	b77d                	j	3d8 <simulate_lru+0x70>
      hits++;
 42c:	2d05                	addiw	s10,s10,1
      printf("Ref %d: ", r);
 42e:	8562                	mv	a0,s8
 430:	1e9000ef          	jal	e18 <printf>
      print_frames(frames, used);
 434:	85ca                	mv	a1,s2
 436:	f7040513          	addi	a0,s0,-144
 43a:	bc7ff0ef          	jal	0 <print_frames>
      printf(" HIT\n");
 43e:	00001517          	auipc	a0,0x1
 442:	bca50513          	addi	a0,a0,-1078 # 1008 <malloc+0x13c>
 446:	1d3000ef          	jal	e18 <printf>
      for (int j = 0; j < used; j++)
 44a:	00291693          	slli	a3,s2,0x2
 44e:	f5040793          	addi	a5,s0,-176
 452:	96be                	add	a3,a3,a5
        lru[j]++;
 454:	4398                	lw	a4,0(a5)
 456:	2705                	addiw	a4,a4,1
 458:	c398                	sw	a4,0(a5)
      for (int j = 0; j < used; j++)
 45a:	0791                	addi	a5,a5,4
 45c:	fed79ce3          	bne	a5,a3,454 <simulate_lru+0xec>
      lru[found] = 0;
 460:	00249793          	slli	a5,s1,0x2
 464:	f9078793          	addi	a5,a5,-112
 468:	97a2                	add	a5,a5,s0
 46a:	fc07a023          	sw	zero,-64(a5)
      continue;
 46e:	bf69                	j	408 <simulate_lru+0xa0>
      int max = lru[0];
 470:	f5042603          	lw	a2,-176(s0)
      for (int j = 1; j < used; j++) {
 474:	092ddc63          	bge	s11,s2,50c <simulate_lru+0x1a4>
 478:	f5040713          	addi	a4,s0,-176
 47c:	87ee                	mv	a5,s11
      int evict = 0;
 47e:	855e                	mv	a0,s7
 480:	a029                	j	48a <simulate_lru+0x122>
      for (int j = 1; j < used; j++) {
 482:	2785                	addiw	a5,a5,1
 484:	0711                	addi	a4,a4,4
 486:	05278b63          	beq	a5,s2,4dc <simulate_lru+0x174>
        if (lru[j] > max) {
 48a:	4354                	lw	a3,4(a4)
 48c:	fed65be3          	bge	a2,a3,482 <simulate_lru+0x11a>
          max = lru[j];
 490:	8636                	mv	a2,a3
          evict = j;
 492:	853e                	mv	a0,a5
 494:	b7fd                	j	482 <simulate_lru+0x11a>
 496:	74aa                	ld	s1,168(sp)
 498:	790a                	ld	s2,160(sp)
 49a:	69ea                	ld	s3,152(sp)
 49c:	6b0a                	ld	s6,128(sp)
 49e:	7be6                	ld	s7,120(sp)
 4a0:	7c46                	ld	s8,112(sp)
 4a2:	7ca6                	ld	s9,104(sp)
 4a4:	6de6                	ld	s11,88(sp)
  *hits_out = hits;
 4a6:	f4843783          	ld	a5,-184(s0)
 4aa:	01a7a023          	sw	s10,0(a5)
  *faults_out = faults;
 4ae:	f4043783          	ld	a5,-192(s0)
 4b2:	0157a023          	sw	s5,0(a5)
  printf("LRU with %d frames: %d faults, %d hits\n\n", frame_count, faults,
 4b6:	86ea                	mv	a3,s10
 4b8:	8656                	mv	a2,s5
 4ba:	85d2                	mv	a1,s4
 4bc:	00001517          	auipc	a0,0x1
 4c0:	bbc50513          	addi	a0,a0,-1092 # 1078 <malloc+0x1ac>
 4c4:	155000ef          	jal	e18 <printf>
}
 4c8:	70ea                	ld	ra,184(sp)
 4ca:	744a                	ld	s0,176(sp)
 4cc:	6a4a                	ld	s4,144(sp)
 4ce:	6aaa                	ld	s5,136(sp)
 4d0:	7d06                	ld	s10,96(sp)
 4d2:	6129                	addi	sp,sp,192
 4d4:	8082                	ret
  int faults = 0;
 4d6:	4a81                	li	s5,0
  int hits = 0;
 4d8:	4d01                	li	s10,0
 4da:	b7f1                	j	4a6 <simulate_lru+0x13e>
      frames[evict] = r;
 4dc:	050a                	slli	a0,a0,0x2
 4de:	f9050793          	addi	a5,a0,-112
 4e2:	00878533          	add	a0,a5,s0
 4e6:	feb52023          	sw	a1,-32(a0)
      lru[evict] = 0;
 4ea:	fc052023          	sw	zero,-64(a0)
      for (int j = 0; j < used; j++)
 4ee:	00291693          	slli	a3,s2,0x2
 4f2:	f5040793          	addi	a5,s0,-176
 4f6:	96be                	add	a3,a3,a5
        lru[j]++;
 4f8:	4398                	lw	a4,0(a5)
 4fa:	2705                	addiw	a4,a4,1
 4fc:	c398                	sw	a4,0(a5)
      for (int j = 0; j < used; j++)
 4fe:	0791                	addi	a5,a5,4
 500:	fef69ce3          	bne	a3,a5,4f8 <simulate_lru+0x190>
 504:	b5fd                	j	3f2 <simulate_lru+0x8a>
    faults++;
 506:	2a85                	addiw	s5,s5,1
    if (used < frame_count) {
 508:	ed494be3          	blt	s2,s4,3de <simulate_lru+0x76>
      frames[evict] = r;
 50c:	f6b42823          	sw	a1,-144(s0)
      lru[evict] = 0;
 510:	f4042823          	sw	zero,-176(s0)
      for (int j = 0; j < used; j++)
 514:	ed205fe3          	blez	s2,3f2 <simulate_lru+0x8a>
 518:	bfd9                	j	4ee <simulate_lru+0x186>

000000000000051a <main>:

int
main(void)
{
 51a:	7115                	addi	sp,sp,-224
 51c:	ed86                	sd	ra,216(sp)
 51e:	e9a2                	sd	s0,208(sp)
 520:	e5a6                	sd	s1,200(sp)
 522:	e1ca                	sd	s2,192(sp)
 524:	fd4e                	sd	s3,184(sp)
 526:	f952                	sd	s4,176(sp)
 528:	f556                	sd	s5,168(sp)
 52a:	f15a                	sd	s6,160(sp)
 52c:	ed5e                	sd	s7,152(sp)
 52e:	e962                	sd	s8,144(sp)
 530:	e566                	sd	s9,136(sp)
 532:	e16a                	sd	s10,128(sp)
 534:	1180                	addi	s0,sp,224
  int refs[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0,
 536:	00001797          	auipc	a5,0x1
 53a:	d0278793          	addi	a5,a5,-766 # 1238 <malloc+0x36c>
 53e:	0007be03          	ld	t3,0(a5)
 542:	0087b303          	ld	t1,8(a5)
 546:	0107b883          	ld	a7,16(a5)
 54a:	0187b803          	ld	a6,24(a5)
 54e:	7388                	ld	a0,32(a5)
 550:	778c                	ld	a1,40(a5)
 552:	7b90                	ld	a2,48(a5)
 554:	7f94                	ld	a3,56(a5)
 556:	63b8                	ld	a4,64(a5)
 558:	67bc                	ld	a5,72(a5)
 55a:	f5c43823          	sd	t3,-176(s0)
 55e:	f4643c23          	sd	t1,-168(s0)
 562:	f7143023          	sd	a7,-160(s0)
 566:	f7043423          	sd	a6,-152(s0)
 56a:	f6a43823          	sd	a0,-144(s0)
 56e:	f6b43c23          	sd	a1,-136(s0)
 572:	f8c43023          	sd	a2,-128(s0)
 576:	f8d43423          	sd	a3,-120(s0)
 57a:	f8e43823          	sd	a4,-112(s0)
 57e:	f8f43c23          	sd	a5,-104(s0)
               1};
  int ref_count = 20;
  int frames[] = {3, 4, 5};
 582:	478d                	li	a5,3
 584:	f4f42023          	sw	a5,-192(s0)
 588:	4791                	li	a5,4
 58a:	f4f42223          	sw	a5,-188(s0)
 58e:	4795                	li	a5,5
 590:	f4f42423          	sw	a5,-184(s0)
  int i;

  printf("Reference string: ");
 594:	00001517          	auipc	a0,0x1
 598:	b1450513          	addi	a0,a0,-1260 # 10a8 <malloc+0x1dc>
 59c:	07d000ef          	jal	e18 <printf>
  for (i = 0; i < ref_count; i++)
 5a0:	f5040493          	addi	s1,s0,-176
 5a4:	f9c40913          	addi	s2,s0,-100
 5a8:	fa040a13          	addi	s4,s0,-96
    printf("%d%c", refs[i], (i + 1 == ref_count) ? '\n' : ' ');
 5ac:	00001997          	auipc	s3,0x1
 5b0:	b1498993          	addi	s3,s3,-1260 # 10c0 <malloc+0x1f4>
 5b4:	a809                	j	5c6 <main+0xac>
 5b6:	02000613          	li	a2,32
 5ba:	854e                	mv	a0,s3
 5bc:	05d000ef          	jal	e18 <printf>
  for (i = 0; i < ref_count; i++)
 5c0:	0491                	addi	s1,s1,4
 5c2:	01448c63          	beq	s1,s4,5da <main+0xc0>
    printf("%d%c", refs[i], (i + 1 == ref_count) ? '\n' : ' ');
 5c6:	408c                	lw	a1,0(s1)
 5c8:	ff2497e3          	bne	s1,s2,5b6 <main+0x9c>
 5cc:	4629                	li	a2,10
 5ce:	00001517          	auipc	a0,0x1
 5d2:	af250513          	addi	a0,a0,-1294 # 10c0 <malloc+0x1f4>
 5d6:	043000ef          	jal	e18 <printf>

  printf("\n");
 5da:	00001517          	auipc	a0,0x1
 5de:	a6650513          	addi	a0,a0,-1434 # 1040 <malloc+0x174>
 5e2:	037000ef          	jal	e18 <printf>
  for (i = 0; i < 3; i++) {
 5e6:	f4040a93          	addi	s5,s0,-192
 5ea:	f4c40b13          	addi	s6,s0,-180
  printf("\n");
 5ee:	8956                	mv	s2,s5
    int opt_hits, opt_faults;

    simulate_fifo(frames[i], refs, ref_count, &fifo_hits, &fifo_faults);
    simulate_lru(frames[i], refs, ref_count, &lru_hits, &lru_faults);
    simulate_optimal(frames[i], refs, ref_count, &opt_hits, &opt_faults);
    printf("Summary for %d frames: FIFO %d faults/%d hits, LRU %d faults/%d hits, Optimal %d faults/%d hits\n\n",
 5f0:	00001997          	auipc	s3,0x1
 5f4:	ad898993          	addi	s3,s3,-1320 # 10c8 <malloc+0x1fc>
    simulate_fifo(frames[i], refs, ref_count, &fifo_hits, &fifo_faults);
 5f8:	00092483          	lw	s1,0(s2)
 5fc:	f2c40713          	addi	a4,s0,-212
 600:	f2840693          	addi	a3,s0,-216
 604:	4651                	li	a2,20
 606:	f5040593          	addi	a1,s0,-176
 60a:	8526                	mv	a0,s1
 60c:	a87ff0ef          	jal	92 <simulate_fifo>
    simulate_lru(frames[i], refs, ref_count, &lru_hits, &lru_faults);
 610:	f3440713          	addi	a4,s0,-204
 614:	f3040693          	addi	a3,s0,-208
 618:	4651                	li	a2,20
 61a:	f5040593          	addi	a1,s0,-176
 61e:	8526                	mv	a0,s1
 620:	d49ff0ef          	jal	368 <simulate_lru>
    simulate_optimal(frames[i], refs, ref_count, &opt_hits, &opt_faults);
 624:	f3c40713          	addi	a4,s0,-196
 628:	f3840693          	addi	a3,s0,-200
 62c:	4651                	li	a2,20
 62e:	f5040593          	addi	a1,s0,-176
 632:	8526                	mv	a0,s1
 634:	ba1ff0ef          	jal	1d4 <simulate_optimal>
    printf("Summary for %d frames: FIFO %d faults/%d hits, LRU %d faults/%d hits, Optimal %d faults/%d hits\n\n",
 638:	f3842883          	lw	a7,-200(s0)
 63c:	f3c42803          	lw	a6,-196(s0)
 640:	f3042783          	lw	a5,-208(s0)
 644:	f3442703          	lw	a4,-204(s0)
 648:	f2842683          	lw	a3,-216(s0)
 64c:	f2c42603          	lw	a2,-212(s0)
 650:	85a6                	mv	a1,s1
 652:	854e                	mv	a0,s3
 654:	7c4000ef          	jal	e18 <printf>
  for (i = 0; i < 3; i++) {
 658:	0911                	addi	s2,s2,4
 65a:	f9691fe3          	bne	s2,s6,5f8 <main+0xde>
           frames[i], fifo_faults, fifo_hits, lru_faults, lru_hits, opt_faults,
           opt_hits);
  }

  printf("Frames | Algorithm | Faults | Hits | Hit ratio | Fault ratio\n");
 65e:	00001517          	auipc	a0,0x1
 662:	ad250513          	addi	a0,a0,-1326 # 1130 <malloc+0x264>
 666:	7b2000ef          	jal	e18 <printf>

    simulate_fifo(f, refs, ref_count, &fifo_hits, &fifo_faults);
    simulate_lru(f, refs, ref_count, &lru_hits, &lru_faults);
    simulate_optimal(f, refs, ref_count, &opt_hits, &opt_faults);

    fifo_ratio = (fifo_hits * 100) / ref_count;
 66a:	06400913          	li	s2,100
    int f = frames[i];
 66e:	000aa483          	lw	s1,0(s5)
    simulate_fifo(f, refs, ref_count, &fifo_hits, &fifo_faults);
 672:	f2c40713          	addi	a4,s0,-212
 676:	f2840693          	addi	a3,s0,-216
 67a:	4651                	li	a2,20
 67c:	f5040593          	addi	a1,s0,-176
 680:	8526                	mv	a0,s1
 682:	a11ff0ef          	jal	92 <simulate_fifo>
    simulate_lru(f, refs, ref_count, &lru_hits, &lru_faults);
 686:	f3440713          	addi	a4,s0,-204
 68a:	f3040693          	addi	a3,s0,-208
 68e:	4651                	li	a2,20
 690:	f5040593          	addi	a1,s0,-176
 694:	8526                	mv	a0,s1
 696:	cd3ff0ef          	jal	368 <simulate_lru>
    simulate_optimal(f, refs, ref_count, &opt_hits, &opt_faults);
 69a:	f3c40713          	addi	a4,s0,-196
 69e:	f3840693          	addi	a3,s0,-200
 6a2:	4651                	li	a2,20
 6a4:	f5040593          	addi	a1,s0,-176
 6a8:	8526                	mv	a0,s1
 6aa:	b2bff0ef          	jal	1d4 <simulate_optimal>
    fifo_ratio = (fifo_hits * 100) / ref_count;
 6ae:	f2842683          	lw	a3,-216(s0)
 6b2:	02d9073b          	mulw	a4,s2,a3
 6b6:	47d1                	li	a5,20
 6b8:	02f7473b          	divw	a4,a4,a5
    lru_ratio = (lru_hits * 100) / ref_count;
 6bc:	f3042c03          	lw	s8,-208(s0)
 6c0:	03890a3b          	mulw	s4,s2,s8
 6c4:	02fa4a3b          	divw	s4,s4,a5
 6c8:	000a0c9b          	sext.w	s9,s4
    opt_ratio = (opt_hits * 100) / ref_count;
 6cc:	f3842b83          	lw	s7,-200(s0)
 6d0:	037909bb          	mulw	s3,s2,s7
 6d4:	02f9c9bb          	divw	s3,s3,a5
 6d8:	00098d1b          	sext.w	s10,s3

    printf("%d      | FIFO      | %d     | %d    | %d%%       | %d%%\n",
 6dc:	40e907bb          	subw	a5,s2,a4
 6e0:	2701                	sext.w	a4,a4
 6e2:	f2c42603          	lw	a2,-212(s0)
 6e6:	85a6                	mv	a1,s1
 6e8:	00001517          	auipc	a0,0x1
 6ec:	a8850513          	addi	a0,a0,-1400 # 1170 <malloc+0x2a4>
 6f0:	728000ef          	jal	e18 <printf>
           f, fifo_faults, fifo_hits, fifo_ratio, 100 - fifo_ratio);
    printf("%d      | LRU       | %d     | %d    | %d%%       | %d%%\n",
 6f4:	414907bb          	subw	a5,s2,s4
 6f8:	8766                	mv	a4,s9
 6fa:	86e2                	mv	a3,s8
 6fc:	f3442603          	lw	a2,-204(s0)
 700:	85a6                	mv	a1,s1
 702:	00001517          	auipc	a0,0x1
 706:	aae50513          	addi	a0,a0,-1362 # 11b0 <malloc+0x2e4>
 70a:	70e000ef          	jal	e18 <printf>
           f, lru_faults, lru_hits, lru_ratio, 100 - lru_ratio);
    printf("%d      | Optimal   | %d     | %d    | %d%%       | %d%%\n",
 70e:	413907bb          	subw	a5,s2,s3
 712:	876a                	mv	a4,s10
 714:	86de                	mv	a3,s7
 716:	f3c42603          	lw	a2,-196(s0)
 71a:	85a6                	mv	a1,s1
 71c:	00001517          	auipc	a0,0x1
 720:	ad450513          	addi	a0,a0,-1324 # 11f0 <malloc+0x324>
 724:	6f4000ef          	jal	e18 <printf>
  for (i = 0; i < 3; i++) {
 728:	0a91                	addi	s5,s5,4
 72a:	f56a92e3          	bne	s5,s6,66e <main+0x154>
           f, opt_faults, opt_hits, opt_ratio, 100 - opt_ratio);
  }

  exit(0);
 72e:	4501                	li	a0,0
 730:	298000ef          	jal	9c8 <exit>

0000000000000734 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 734:	1141                	addi	sp,sp,-16
 736:	e406                	sd	ra,8(sp)
 738:	e022                	sd	s0,0(sp)
 73a:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 73c:	ddfff0ef          	jal	51a <main>
  exit(r);
 740:	288000ef          	jal	9c8 <exit>

0000000000000744 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 744:	1141                	addi	sp,sp,-16
 746:	e422                	sd	s0,8(sp)
 748:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 74a:	87aa                	mv	a5,a0
 74c:	0585                	addi	a1,a1,1
 74e:	0785                	addi	a5,a5,1
 750:	fff5c703          	lbu	a4,-1(a1)
 754:	fee78fa3          	sb	a4,-1(a5)
 758:	fb75                	bnez	a4,74c <strcpy+0x8>
    ;
  return os;
}
 75a:	6422                	ld	s0,8(sp)
 75c:	0141                	addi	sp,sp,16
 75e:	8082                	ret

0000000000000760 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 760:	1141                	addi	sp,sp,-16
 762:	e422                	sd	s0,8(sp)
 764:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 766:	00054783          	lbu	a5,0(a0)
 76a:	cb91                	beqz	a5,77e <strcmp+0x1e>
 76c:	0005c703          	lbu	a4,0(a1)
 770:	00f71763          	bne	a4,a5,77e <strcmp+0x1e>
    p++, q++;
 774:	0505                	addi	a0,a0,1
 776:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 778:	00054783          	lbu	a5,0(a0)
 77c:	fbe5                	bnez	a5,76c <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 77e:	0005c503          	lbu	a0,0(a1)
}
 782:	40a7853b          	subw	a0,a5,a0
 786:	6422                	ld	s0,8(sp)
 788:	0141                	addi	sp,sp,16
 78a:	8082                	ret

000000000000078c <strlen>:

uint
strlen(const char *s)
{
 78c:	1141                	addi	sp,sp,-16
 78e:	e422                	sd	s0,8(sp)
 790:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 792:	00054783          	lbu	a5,0(a0)
 796:	cf91                	beqz	a5,7b2 <strlen+0x26>
 798:	0505                	addi	a0,a0,1
 79a:	87aa                	mv	a5,a0
 79c:	86be                	mv	a3,a5
 79e:	0785                	addi	a5,a5,1
 7a0:	fff7c703          	lbu	a4,-1(a5)
 7a4:	ff65                	bnez	a4,79c <strlen+0x10>
 7a6:	40a6853b          	subw	a0,a3,a0
 7aa:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 7ac:	6422                	ld	s0,8(sp)
 7ae:	0141                	addi	sp,sp,16
 7b0:	8082                	ret
  for (n = 0; s[n]; n++)
 7b2:	4501                	li	a0,0
 7b4:	bfe5                	j	7ac <strlen+0x20>

00000000000007b6 <memset>:

void *
memset(void *dst, int c, uint n)
{
 7b6:	1141                	addi	sp,sp,-16
 7b8:	e422                	sd	s0,8(sp)
 7ba:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 7bc:	ca19                	beqz	a2,7d2 <memset+0x1c>
 7be:	87aa                	mv	a5,a0
 7c0:	1602                	slli	a2,a2,0x20
 7c2:	9201                	srli	a2,a2,0x20
 7c4:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 7c8:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 7cc:	0785                	addi	a5,a5,1
 7ce:	fee79de3          	bne	a5,a4,7c8 <memset+0x12>
  }
  return dst;
}
 7d2:	6422                	ld	s0,8(sp)
 7d4:	0141                	addi	sp,sp,16
 7d6:	8082                	ret

00000000000007d8 <strchr>:

char *
strchr(const char *s, char c)
{
 7d8:	1141                	addi	sp,sp,-16
 7da:	e422                	sd	s0,8(sp)
 7dc:	0800                	addi	s0,sp,16
  for (; *s; s++)
 7de:	00054783          	lbu	a5,0(a0)
 7e2:	cb99                	beqz	a5,7f8 <strchr+0x20>
    if (*s == c)
 7e4:	00f58763          	beq	a1,a5,7f2 <strchr+0x1a>
  for (; *s; s++)
 7e8:	0505                	addi	a0,a0,1
 7ea:	00054783          	lbu	a5,0(a0)
 7ee:	fbfd                	bnez	a5,7e4 <strchr+0xc>
      return (char *)s;
  return 0;
 7f0:	4501                	li	a0,0
}
 7f2:	6422                	ld	s0,8(sp)
 7f4:	0141                	addi	sp,sp,16
 7f6:	8082                	ret
  return 0;
 7f8:	4501                	li	a0,0
 7fa:	bfe5                	j	7f2 <strchr+0x1a>

00000000000007fc <gets>:

char *
gets(char *buf, int max)
{
 7fc:	711d                	addi	sp,sp,-96
 7fe:	ec86                	sd	ra,88(sp)
 800:	e8a2                	sd	s0,80(sp)
 802:	e4a6                	sd	s1,72(sp)
 804:	e0ca                	sd	s2,64(sp)
 806:	fc4e                	sd	s3,56(sp)
 808:	f852                	sd	s4,48(sp)
 80a:	f456                	sd	s5,40(sp)
 80c:	f05a                	sd	s6,32(sp)
 80e:	ec5e                	sd	s7,24(sp)
 810:	1080                	addi	s0,sp,96
 812:	8baa                	mv	s7,a0
 814:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 816:	892a                	mv	s2,a0
 818:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if (cc < 1)
      break;
    buf[i++] = c;
    if (c == '\n' || c == '\r')
 81a:	4aa9                	li	s5,10
 81c:	4b35                	li	s6,13
  for (i = 0; i + 1 < max;) {
 81e:	89a6                	mv	s3,s1
 820:	2485                	addiw	s1,s1,1
 822:	0344d663          	bge	s1,s4,84e <gets+0x52>
    cc = read(0, &c, 1);
 826:	4605                	li	a2,1
 828:	faf40593          	addi	a1,s0,-81
 82c:	4501                	li	a0,0
 82e:	1b2000ef          	jal	9e0 <read>
    if (cc < 1)
 832:	00a05e63          	blez	a0,84e <gets+0x52>
    buf[i++] = c;
 836:	faf44783          	lbu	a5,-81(s0)
 83a:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 83e:	01578763          	beq	a5,s5,84c <gets+0x50>
 842:	0905                	addi	s2,s2,1
 844:	fd679de3          	bne	a5,s6,81e <gets+0x22>
    buf[i++] = c;
 848:	89a6                	mv	s3,s1
 84a:	a011                	j	84e <gets+0x52>
 84c:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 84e:	99de                	add	s3,s3,s7
 850:	00098023          	sb	zero,0(s3)
  return buf;
}
 854:	855e                	mv	a0,s7
 856:	60e6                	ld	ra,88(sp)
 858:	6446                	ld	s0,80(sp)
 85a:	64a6                	ld	s1,72(sp)
 85c:	6906                	ld	s2,64(sp)
 85e:	79e2                	ld	s3,56(sp)
 860:	7a42                	ld	s4,48(sp)
 862:	7aa2                	ld	s5,40(sp)
 864:	7b02                	ld	s6,32(sp)
 866:	6be2                	ld	s7,24(sp)
 868:	6125                	addi	sp,sp,96
 86a:	8082                	ret

000000000000086c <stat>:

int
stat(const char *n, struct stat *st)
{
 86c:	1101                	addi	sp,sp,-32
 86e:	ec06                	sd	ra,24(sp)
 870:	e822                	sd	s0,16(sp)
 872:	e04a                	sd	s2,0(sp)
 874:	1000                	addi	s0,sp,32
 876:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 878:	4581                	li	a1,0
 87a:	18e000ef          	jal	a08 <open>
  if (fd < 0)
 87e:	02054263          	bltz	a0,8a2 <stat+0x36>
 882:	e426                	sd	s1,8(sp)
 884:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 886:	85ca                	mv	a1,s2
 888:	198000ef          	jal	a20 <fstat>
 88c:	892a                	mv	s2,a0
  close(fd);
 88e:	8526                	mv	a0,s1
 890:	160000ef          	jal	9f0 <close>
  return r;
 894:	64a2                	ld	s1,8(sp)
}
 896:	854a                	mv	a0,s2
 898:	60e2                	ld	ra,24(sp)
 89a:	6442                	ld	s0,16(sp)
 89c:	6902                	ld	s2,0(sp)
 89e:	6105                	addi	sp,sp,32
 8a0:	8082                	ret
    return -1;
 8a2:	597d                	li	s2,-1
 8a4:	bfcd                	j	896 <stat+0x2a>

00000000000008a6 <atoi>:

int
atoi(const char *s)
{
 8a6:	1141                	addi	sp,sp,-16
 8a8:	e422                	sd	s0,8(sp)
 8aa:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 8ac:	00054683          	lbu	a3,0(a0)
 8b0:	fd06879b          	addiw	a5,a3,-48
 8b4:	0ff7f793          	zext.b	a5,a5
 8b8:	4625                	li	a2,9
 8ba:	02f66863          	bltu	a2,a5,8ea <atoi+0x44>
 8be:	872a                	mv	a4,a0
  n = 0;
 8c0:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 8c2:	0705                	addi	a4,a4,1
 8c4:	0025179b          	slliw	a5,a0,0x2
 8c8:	9fa9                	addw	a5,a5,a0
 8ca:	0017979b          	slliw	a5,a5,0x1
 8ce:	9fb5                	addw	a5,a5,a3
 8d0:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 8d4:	00074683          	lbu	a3,0(a4)
 8d8:	fd06879b          	addiw	a5,a3,-48
 8dc:	0ff7f793          	zext.b	a5,a5
 8e0:	fef671e3          	bgeu	a2,a5,8c2 <atoi+0x1c>
  return n;
}
 8e4:	6422                	ld	s0,8(sp)
 8e6:	0141                	addi	sp,sp,16
 8e8:	8082                	ret
  n = 0;
 8ea:	4501                	li	a0,0
 8ec:	bfe5                	j	8e4 <atoi+0x3e>

00000000000008ee <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 8ee:	1141                	addi	sp,sp,-16
 8f0:	e422                	sd	s0,8(sp)
 8f2:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 8f4:	02b57463          	bgeu	a0,a1,91c <memmove+0x2e>
    while (n-- > 0)
 8f8:	00c05f63          	blez	a2,916 <memmove+0x28>
 8fc:	1602                	slli	a2,a2,0x20
 8fe:	9201                	srli	a2,a2,0x20
 900:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 904:	872a                	mv	a4,a0
      *dst++ = *src++;
 906:	0585                	addi	a1,a1,1
 908:	0705                	addi	a4,a4,1
 90a:	fff5c683          	lbu	a3,-1(a1)
 90e:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 912:	fef71ae3          	bne	a4,a5,906 <memmove+0x18>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 916:	6422                	ld	s0,8(sp)
 918:	0141                	addi	sp,sp,16
 91a:	8082                	ret
    dst += n;
 91c:	00c50733          	add	a4,a0,a2
    src += n;
 920:	95b2                	add	a1,a1,a2
    while (n-- > 0)
 922:	fec05ae3          	blez	a2,916 <memmove+0x28>
 926:	fff6079b          	addiw	a5,a2,-1
 92a:	1782                	slli	a5,a5,0x20
 92c:	9381                	srli	a5,a5,0x20
 92e:	fff7c793          	not	a5,a5
 932:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 934:	15fd                	addi	a1,a1,-1
 936:	177d                	addi	a4,a4,-1
 938:	0005c683          	lbu	a3,0(a1)
 93c:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 940:	fee79ae3          	bne	a5,a4,934 <memmove+0x46>
 944:	bfc9                	j	916 <memmove+0x28>

0000000000000946 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 946:	1141                	addi	sp,sp,-16
 948:	e422                	sd	s0,8(sp)
 94a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 94c:	ca05                	beqz	a2,97c <memcmp+0x36>
 94e:	fff6069b          	addiw	a3,a2,-1
 952:	1682                	slli	a3,a3,0x20
 954:	9281                	srli	a3,a3,0x20
 956:	0685                	addi	a3,a3,1
 958:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 95a:	00054783          	lbu	a5,0(a0)
 95e:	0005c703          	lbu	a4,0(a1)
 962:	00e79863          	bne	a5,a4,972 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 966:	0505                	addi	a0,a0,1
    p2++;
 968:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 96a:	fed518e3          	bne	a0,a3,95a <memcmp+0x14>
  }
  return 0;
 96e:	4501                	li	a0,0
 970:	a019                	j	976 <memcmp+0x30>
      return *p1 - *p2;
 972:	40e7853b          	subw	a0,a5,a4
}
 976:	6422                	ld	s0,8(sp)
 978:	0141                	addi	sp,sp,16
 97a:	8082                	ret
  return 0;
 97c:	4501                	li	a0,0
 97e:	bfe5                	j	976 <memcmp+0x30>

0000000000000980 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 980:	1141                	addi	sp,sp,-16
 982:	e406                	sd	ra,8(sp)
 984:	e022                	sd	s0,0(sp)
 986:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 988:	f67ff0ef          	jal	8ee <memmove>
}
 98c:	60a2                	ld	ra,8(sp)
 98e:	6402                	ld	s0,0(sp)
 990:	0141                	addi	sp,sp,16
 992:	8082                	ret

0000000000000994 <sbrk>:

char *
sbrk(int n)
{
 994:	1141                	addi	sp,sp,-16
 996:	e406                	sd	ra,8(sp)
 998:	e022                	sd	s0,0(sp)
 99a:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 99c:	4585                	li	a1,1
 99e:	0b2000ef          	jal	a50 <sys_sbrk>
}
 9a2:	60a2                	ld	ra,8(sp)
 9a4:	6402                	ld	s0,0(sp)
 9a6:	0141                	addi	sp,sp,16
 9a8:	8082                	ret

00000000000009aa <sbrklazy>:

char *
sbrklazy(int n)
{
 9aa:	1141                	addi	sp,sp,-16
 9ac:	e406                	sd	ra,8(sp)
 9ae:	e022                	sd	s0,0(sp)
 9b0:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 9b2:	4589                	li	a1,2
 9b4:	09c000ef          	jal	a50 <sys_sbrk>
}
 9b8:	60a2                	ld	ra,8(sp)
 9ba:	6402                	ld	s0,0(sp)
 9bc:	0141                	addi	sp,sp,16
 9be:	8082                	ret

00000000000009c0 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 9c0:	4885                	li	a7,1
 ecall
 9c2:	00000073          	ecall
 ret
 9c6:	8082                	ret

00000000000009c8 <exit>:
.global exit
exit:
 li a7, SYS_exit
 9c8:	4889                	li	a7,2
 ecall
 9ca:	00000073          	ecall
 ret
 9ce:	8082                	ret

00000000000009d0 <wait>:
.global wait
wait:
 li a7, SYS_wait
 9d0:	488d                	li	a7,3
 ecall
 9d2:	00000073          	ecall
 ret
 9d6:	8082                	ret

00000000000009d8 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 9d8:	4891                	li	a7,4
 ecall
 9da:	00000073          	ecall
 ret
 9de:	8082                	ret

00000000000009e0 <read>:
.global read
read:
 li a7, SYS_read
 9e0:	4895                	li	a7,5
 ecall
 9e2:	00000073          	ecall
 ret
 9e6:	8082                	ret

00000000000009e8 <write>:
.global write
write:
 li a7, SYS_write
 9e8:	48c1                	li	a7,16
 ecall
 9ea:	00000073          	ecall
 ret
 9ee:	8082                	ret

00000000000009f0 <close>:
.global close
close:
 li a7, SYS_close
 9f0:	48d5                	li	a7,21
 ecall
 9f2:	00000073          	ecall
 ret
 9f6:	8082                	ret

00000000000009f8 <kill>:
.global kill
kill:
 li a7, SYS_kill
 9f8:	4899                	li	a7,6
 ecall
 9fa:	00000073          	ecall
 ret
 9fe:	8082                	ret

0000000000000a00 <exec>:
.global exec
exec:
 li a7, SYS_exec
 a00:	489d                	li	a7,7
 ecall
 a02:	00000073          	ecall
 ret
 a06:	8082                	ret

0000000000000a08 <open>:
.global open
open:
 li a7, SYS_open
 a08:	48bd                	li	a7,15
 ecall
 a0a:	00000073          	ecall
 ret
 a0e:	8082                	ret

0000000000000a10 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 a10:	48c5                	li	a7,17
 ecall
 a12:	00000073          	ecall
 ret
 a16:	8082                	ret

0000000000000a18 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 a18:	48c9                	li	a7,18
 ecall
 a1a:	00000073          	ecall
 ret
 a1e:	8082                	ret

0000000000000a20 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 a20:	48a1                	li	a7,8
 ecall
 a22:	00000073          	ecall
 ret
 a26:	8082                	ret

0000000000000a28 <link>:
.global link
link:
 li a7, SYS_link
 a28:	48cd                	li	a7,19
 ecall
 a2a:	00000073          	ecall
 ret
 a2e:	8082                	ret

0000000000000a30 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 a30:	48d1                	li	a7,20
 ecall
 a32:	00000073          	ecall
 ret
 a36:	8082                	ret

0000000000000a38 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 a38:	48a5                	li	a7,9
 ecall
 a3a:	00000073          	ecall
 ret
 a3e:	8082                	ret

0000000000000a40 <dup>:
.global dup
dup:
 li a7, SYS_dup
 a40:	48a9                	li	a7,10
 ecall
 a42:	00000073          	ecall
 ret
 a46:	8082                	ret

0000000000000a48 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 a48:	48ad                	li	a7,11
 ecall
 a4a:	00000073          	ecall
 ret
 a4e:	8082                	ret

0000000000000a50 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 a50:	48b1                	li	a7,12
 ecall
 a52:	00000073          	ecall
 ret
 a56:	8082                	ret

0000000000000a58 <pause>:
.global pause
pause:
 li a7, SYS_pause
 a58:	48b5                	li	a7,13
 ecall
 a5a:	00000073          	ecall
 ret
 a5e:	8082                	ret

0000000000000a60 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 a60:	48b9                	li	a7,14
 ecall
 a62:	00000073          	ecall
 ret
 a66:	8082                	ret

0000000000000a68 <sync>:
.global sync
sync:
 li a7, SYS_sync
 a68:	48d9                	li	a7,22
 ecall
 a6a:	00000073          	ecall
 ret
 a6e:	8082                	ret

0000000000000a70 <kallocstats>:
.global kallocstats
kallocstats:
 li a7, SYS_kallocstats
 a70:	48dd                	li	a7,23
 ecall
 a72:	00000073          	ecall
 ret
 a76:	8082                	ret

0000000000000a78 <vtop>:
.global vtop
vtop:
 li a7, SYS_vtop
 a78:	48e1                	li	a7,24
 ecall
 a7a:	00000073          	ecall
 ret
 a7e:	8082                	ret

0000000000000a80 <pageinfo>:
.global pageinfo
pageinfo:
 li a7, SYS_pageinfo
 a80:	48e5                	li	a7,25
 ecall
 a82:	00000073          	ecall
 ret
 a86:	8082                	ret

0000000000000a88 <setreadonly>:
.global setreadonly
setreadonly:
 li a7, SYS_setreadonly
 a88:	48e9                	li	a7,26
 ecall
 a8a:	00000073          	ecall
 ret
 a8e:	8082                	ret

0000000000000a90 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 a90:	1101                	addi	sp,sp,-32
 a92:	ec06                	sd	ra,24(sp)
 a94:	e822                	sd	s0,16(sp)
 a96:	1000                	addi	s0,sp,32
 a98:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 a9c:	4605                	li	a2,1
 a9e:	fef40593          	addi	a1,s0,-17
 aa2:	f47ff0ef          	jal	9e8 <write>
}
 aa6:	60e2                	ld	ra,24(sp)
 aa8:	6442                	ld	s0,16(sp)
 aaa:	6105                	addi	sp,sp,32
 aac:	8082                	ret

0000000000000aae <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 aae:	715d                	addi	sp,sp,-80
 ab0:	e486                	sd	ra,72(sp)
 ab2:	e0a2                	sd	s0,64(sp)
 ab4:	f84a                	sd	s2,48(sp)
 ab6:	0880                	addi	s0,sp,80
 ab8:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 aba:	c299                	beqz	a3,ac0 <printint+0x12>
 abc:	0805c363          	bltz	a1,b42 <printint+0x94>
  neg = 0;
 ac0:	4881                	li	a7,0
 ac2:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 ac6:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
 ac8:	00000517          	auipc	a0,0x0
 acc:	7c050513          	addi	a0,a0,1984 # 1288 <digits>
 ad0:	883e                	mv	a6,a5
 ad2:	2785                	addiw	a5,a5,1
 ad4:	02c5f733          	remu	a4,a1,a2
 ad8:	972a                	add	a4,a4,a0
 ada:	00074703          	lbu	a4,0(a4)
 ade:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
 ae2:	872e                	mv	a4,a1
 ae4:	02c5d5b3          	divu	a1,a1,a2
 ae8:	0685                	addi	a3,a3,1
 aea:	fec773e3          	bgeu	a4,a2,ad0 <printint+0x22>
  if (neg)
 aee:	00088b63          	beqz	a7,b04 <printint+0x56>
    buf[i++] = '-';
 af2:	fd078793          	addi	a5,a5,-48
 af6:	97a2                	add	a5,a5,s0
 af8:	02d00713          	li	a4,45
 afc:	fee78423          	sb	a4,-24(a5)
 b00:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
 b04:	02f05a63          	blez	a5,b38 <printint+0x8a>
 b08:	fc26                	sd	s1,56(sp)
 b0a:	f44e                	sd	s3,40(sp)
 b0c:	fb840713          	addi	a4,s0,-72
 b10:	00f704b3          	add	s1,a4,a5
 b14:	fff70993          	addi	s3,a4,-1
 b18:	99be                	add	s3,s3,a5
 b1a:	37fd                	addiw	a5,a5,-1
 b1c:	1782                	slli	a5,a5,0x20
 b1e:	9381                	srli	a5,a5,0x20
 b20:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 b24:	fff4c583          	lbu	a1,-1(s1)
 b28:	854a                	mv	a0,s2
 b2a:	f67ff0ef          	jal	a90 <putc>
  while (--i >= 0)
 b2e:	14fd                	addi	s1,s1,-1
 b30:	ff349ae3          	bne	s1,s3,b24 <printint+0x76>
 b34:	74e2                	ld	s1,56(sp)
 b36:	79a2                	ld	s3,40(sp)
}
 b38:	60a6                	ld	ra,72(sp)
 b3a:	6406                	ld	s0,64(sp)
 b3c:	7942                	ld	s2,48(sp)
 b3e:	6161                	addi	sp,sp,80
 b40:	8082                	ret
    x = -xx;
 b42:	40b005b3          	neg	a1,a1
    neg = 1;
 b46:	4885                	li	a7,1
    x = -xx;
 b48:	bfad                	j	ac2 <printint+0x14>

0000000000000b4a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 b4a:	711d                	addi	sp,sp,-96
 b4c:	ec86                	sd	ra,88(sp)
 b4e:	e8a2                	sd	s0,80(sp)
 b50:	e0ca                	sd	s2,64(sp)
 b52:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 b54:	0005c903          	lbu	s2,0(a1)
 b58:	28090663          	beqz	s2,de4 <vprintf+0x29a>
 b5c:	e4a6                	sd	s1,72(sp)
 b5e:	fc4e                	sd	s3,56(sp)
 b60:	f852                	sd	s4,48(sp)
 b62:	f456                	sd	s5,40(sp)
 b64:	f05a                	sd	s6,32(sp)
 b66:	ec5e                	sd	s7,24(sp)
 b68:	e862                	sd	s8,16(sp)
 b6a:	e466                	sd	s9,8(sp)
 b6c:	8b2a                	mv	s6,a0
 b6e:	8a2e                	mv	s4,a1
 b70:	8bb2                	mv	s7,a2
  state = 0;
 b72:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 b74:	4481                	li	s1,0
 b76:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 b78:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 b7c:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 b80:	06c00c93          	li	s9,108
 b84:	a005                	j	ba4 <vprintf+0x5a>
        putc(fd, c0);
 b86:	85ca                	mv	a1,s2
 b88:	855a                	mv	a0,s6
 b8a:	f07ff0ef          	jal	a90 <putc>
 b8e:	a019                	j	b94 <vprintf+0x4a>
    } else if (state == '%') {
 b90:	03598263          	beq	s3,s5,bb4 <vprintf+0x6a>
  for (i = 0; fmt[i]; i++) {
 b94:	2485                	addiw	s1,s1,1
 b96:	8726                	mv	a4,s1
 b98:	009a07b3          	add	a5,s4,s1
 b9c:	0007c903          	lbu	s2,0(a5)
 ba0:	22090a63          	beqz	s2,dd4 <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 ba4:	0009079b          	sext.w	a5,s2
    if (state == 0) {
 ba8:	fe0994e3          	bnez	s3,b90 <vprintf+0x46>
      if (c0 == '%') {
 bac:	fd579de3          	bne	a5,s5,b86 <vprintf+0x3c>
        state = '%';
 bb0:	89be                	mv	s3,a5
 bb2:	b7cd                	j	b94 <vprintf+0x4a>
        c1 = fmt[i + 1] & 0xff;
 bb4:	00ea06b3          	add	a3,s4,a4
 bb8:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 bbc:	8636                	mv	a2,a3
      if (c1)
 bbe:	c681                	beqz	a3,bc6 <vprintf+0x7c>
        c2 = fmt[i + 2] & 0xff;
 bc0:	9752                	add	a4,a4,s4
 bc2:	00274603          	lbu	a2,2(a4)
      if (c0 == 'd') {
 bc6:	05878363          	beq	a5,s8,c0c <vprintf+0xc2>
      } else if (c0 == 'l' && c1 == 'd') {
 bca:	05978d63          	beq	a5,s9,c24 <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 bce:	07500713          	li	a4,117
 bd2:	0ee78763          	beq	a5,a4,cc0 <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 bd6:	07800713          	li	a4,120
 bda:	12e78963          	beq	a5,a4,d0c <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 bde:	07000713          	li	a4,112
 be2:	14e78e63          	beq	a5,a4,d3e <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 be6:	06300713          	li	a4,99
 bea:	18e78e63          	beq	a5,a4,d86 <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 bee:	07300713          	li	a4,115
 bf2:	1ae78463          	beq	a5,a4,d9a <vprintf+0x250>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 bf6:	02500713          	li	a4,37
 bfa:	04e79563          	bne	a5,a4,c44 <vprintf+0xfa>
        putc(fd, '%');
 bfe:	02500593          	li	a1,37
 c02:	855a                	mv	a0,s6
 c04:	e8dff0ef          	jal	a90 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 c08:	4981                	li	s3,0
 c0a:	b769                	j	b94 <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 c0c:	008b8913          	addi	s2,s7,8
 c10:	4685                	li	a3,1
 c12:	4629                	li	a2,10
 c14:	000ba583          	lw	a1,0(s7)
 c18:	855a                	mv	a0,s6
 c1a:	e95ff0ef          	jal	aae <printint>
 c1e:	8bca                	mv	s7,s2
      state = 0;
 c20:	4981                	li	s3,0
 c22:	bf8d                	j	b94 <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'd') {
 c24:	06400793          	li	a5,100
 c28:	02f68963          	beq	a3,a5,c5a <vprintf+0x110>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 c2c:	06c00793          	li	a5,108
 c30:	04f68263          	beq	a3,a5,c74 <vprintf+0x12a>
      } else if (c0 == 'l' && c1 == 'u') {
 c34:	07500793          	li	a5,117
 c38:	0af68063          	beq	a3,a5,cd8 <vprintf+0x18e>
      } else if (c0 == 'l' && c1 == 'x') {
 c3c:	07800793          	li	a5,120
 c40:	0ef68263          	beq	a3,a5,d24 <vprintf+0x1da>
        putc(fd, '%');
 c44:	02500593          	li	a1,37
 c48:	855a                	mv	a0,s6
 c4a:	e47ff0ef          	jal	a90 <putc>
        putc(fd, c0);
 c4e:	85ca                	mv	a1,s2
 c50:	855a                	mv	a0,s6
 c52:	e3fff0ef          	jal	a90 <putc>
      state = 0;
 c56:	4981                	li	s3,0
 c58:	bf35                	j	b94 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 c5a:	008b8913          	addi	s2,s7,8
 c5e:	4685                	li	a3,1
 c60:	4629                	li	a2,10
 c62:	000bb583          	ld	a1,0(s7)
 c66:	855a                	mv	a0,s6
 c68:	e47ff0ef          	jal	aae <printint>
        i += 1;
 c6c:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 c6e:	8bca                	mv	s7,s2
      state = 0;
 c70:	4981                	li	s3,0
        i += 1;
 c72:	b70d                	j	b94 <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 c74:	06400793          	li	a5,100
 c78:	02f60763          	beq	a2,a5,ca6 <vprintf+0x15c>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 c7c:	07500793          	li	a5,117
 c80:	06f60963          	beq	a2,a5,cf2 <vprintf+0x1a8>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 c84:	07800793          	li	a5,120
 c88:	faf61ee3          	bne	a2,a5,c44 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 c8c:	008b8913          	addi	s2,s7,8
 c90:	4681                	li	a3,0
 c92:	4641                	li	a2,16
 c94:	000bb583          	ld	a1,0(s7)
 c98:	855a                	mv	a0,s6
 c9a:	e15ff0ef          	jal	aae <printint>
        i += 2;
 c9e:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 ca0:	8bca                	mv	s7,s2
      state = 0;
 ca2:	4981                	li	s3,0
        i += 2;
 ca4:	bdc5                	j	b94 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 ca6:	008b8913          	addi	s2,s7,8
 caa:	4685                	li	a3,1
 cac:	4629                	li	a2,10
 cae:	000bb583          	ld	a1,0(s7)
 cb2:	855a                	mv	a0,s6
 cb4:	dfbff0ef          	jal	aae <printint>
        i += 2;
 cb8:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 cba:	8bca                	mv	s7,s2
      state = 0;
 cbc:	4981                	li	s3,0
        i += 2;
 cbe:	bdd9                	j	b94 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 cc0:	008b8913          	addi	s2,s7,8
 cc4:	4681                	li	a3,0
 cc6:	4629                	li	a2,10
 cc8:	000be583          	lwu	a1,0(s7)
 ccc:	855a                	mv	a0,s6
 cce:	de1ff0ef          	jal	aae <printint>
 cd2:	8bca                	mv	s7,s2
      state = 0;
 cd4:	4981                	li	s3,0
 cd6:	bd7d                	j	b94 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 cd8:	008b8913          	addi	s2,s7,8
 cdc:	4681                	li	a3,0
 cde:	4629                	li	a2,10
 ce0:	000bb583          	ld	a1,0(s7)
 ce4:	855a                	mv	a0,s6
 ce6:	dc9ff0ef          	jal	aae <printint>
        i += 1;
 cea:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 cec:	8bca                	mv	s7,s2
      state = 0;
 cee:	4981                	li	s3,0
        i += 1;
 cf0:	b555                	j	b94 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 cf2:	008b8913          	addi	s2,s7,8
 cf6:	4681                	li	a3,0
 cf8:	4629                	li	a2,10
 cfa:	000bb583          	ld	a1,0(s7)
 cfe:	855a                	mv	a0,s6
 d00:	dafff0ef          	jal	aae <printint>
        i += 2;
 d04:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 d06:	8bca                	mv	s7,s2
      state = 0;
 d08:	4981                	li	s3,0
        i += 2;
 d0a:	b569                	j	b94 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 d0c:	008b8913          	addi	s2,s7,8
 d10:	4681                	li	a3,0
 d12:	4641                	li	a2,16
 d14:	000be583          	lwu	a1,0(s7)
 d18:	855a                	mv	a0,s6
 d1a:	d95ff0ef          	jal	aae <printint>
 d1e:	8bca                	mv	s7,s2
      state = 0;
 d20:	4981                	li	s3,0
 d22:	bd8d                	j	b94 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 d24:	008b8913          	addi	s2,s7,8
 d28:	4681                	li	a3,0
 d2a:	4641                	li	a2,16
 d2c:	000bb583          	ld	a1,0(s7)
 d30:	855a                	mv	a0,s6
 d32:	d7dff0ef          	jal	aae <printint>
        i += 1;
 d36:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 d38:	8bca                	mv	s7,s2
      state = 0;
 d3a:	4981                	li	s3,0
        i += 1;
 d3c:	bda1                	j	b94 <vprintf+0x4a>
 d3e:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 d40:	008b8d13          	addi	s10,s7,8
 d44:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 d48:	03000593          	li	a1,48
 d4c:	855a                	mv	a0,s6
 d4e:	d43ff0ef          	jal	a90 <putc>
  putc(fd, 'x');
 d52:	07800593          	li	a1,120
 d56:	855a                	mv	a0,s6
 d58:	d39ff0ef          	jal	a90 <putc>
 d5c:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 d5e:	00000b97          	auipc	s7,0x0
 d62:	52ab8b93          	addi	s7,s7,1322 # 1288 <digits>
 d66:	03c9d793          	srli	a5,s3,0x3c
 d6a:	97de                	add	a5,a5,s7
 d6c:	0007c583          	lbu	a1,0(a5)
 d70:	855a                	mv	a0,s6
 d72:	d1fff0ef          	jal	a90 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 d76:	0992                	slli	s3,s3,0x4
 d78:	397d                	addiw	s2,s2,-1
 d7a:	fe0916e3          	bnez	s2,d66 <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 d7e:	8bea                	mv	s7,s10
      state = 0;
 d80:	4981                	li	s3,0
 d82:	6d02                	ld	s10,0(sp)
 d84:	bd01                	j	b94 <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 d86:	008b8913          	addi	s2,s7,8
 d8a:	000bc583          	lbu	a1,0(s7)
 d8e:	855a                	mv	a0,s6
 d90:	d01ff0ef          	jal	a90 <putc>
 d94:	8bca                	mv	s7,s2
      state = 0;
 d96:	4981                	li	s3,0
 d98:	bbf5                	j	b94 <vprintf+0x4a>
        if ((s = va_arg(ap, char *)) == 0)
 d9a:	008b8993          	addi	s3,s7,8
 d9e:	000bb903          	ld	s2,0(s7)
 da2:	00090f63          	beqz	s2,dc0 <vprintf+0x276>
        for (; *s; s++)
 da6:	00094583          	lbu	a1,0(s2)
 daa:	c195                	beqz	a1,dce <vprintf+0x284>
          putc(fd, *s);
 dac:	855a                	mv	a0,s6
 dae:	ce3ff0ef          	jal	a90 <putc>
        for (; *s; s++)
 db2:	0905                	addi	s2,s2,1
 db4:	00094583          	lbu	a1,0(s2)
 db8:	f9f5                	bnez	a1,dac <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
 dba:	8bce                	mv	s7,s3
      state = 0;
 dbc:	4981                	li	s3,0
 dbe:	bbd9                	j	b94 <vprintf+0x4a>
          s = "(null)";
 dc0:	00000917          	auipc	s2,0x0
 dc4:	47090913          	addi	s2,s2,1136 # 1230 <malloc+0x364>
        for (; *s; s++)
 dc8:	02800593          	li	a1,40
 dcc:	b7c5                	j	dac <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
 dce:	8bce                	mv	s7,s3
      state = 0;
 dd0:	4981                	li	s3,0
 dd2:	b3c9                	j	b94 <vprintf+0x4a>
 dd4:	64a6                	ld	s1,72(sp)
 dd6:	79e2                	ld	s3,56(sp)
 dd8:	7a42                	ld	s4,48(sp)
 dda:	7aa2                	ld	s5,40(sp)
 ddc:	7b02                	ld	s6,32(sp)
 dde:	6be2                	ld	s7,24(sp)
 de0:	6c42                	ld	s8,16(sp)
 de2:	6ca2                	ld	s9,8(sp)
    }
  }
}
 de4:	60e6                	ld	ra,88(sp)
 de6:	6446                	ld	s0,80(sp)
 de8:	6906                	ld	s2,64(sp)
 dea:	6125                	addi	sp,sp,96
 dec:	8082                	ret

0000000000000dee <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 dee:	715d                	addi	sp,sp,-80
 df0:	ec06                	sd	ra,24(sp)
 df2:	e822                	sd	s0,16(sp)
 df4:	1000                	addi	s0,sp,32
 df6:	e010                	sd	a2,0(s0)
 df8:	e414                	sd	a3,8(s0)
 dfa:	e818                	sd	a4,16(s0)
 dfc:	ec1c                	sd	a5,24(s0)
 dfe:	03043023          	sd	a6,32(s0)
 e02:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 e06:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 e0a:	8622                	mv	a2,s0
 e0c:	d3fff0ef          	jal	b4a <vprintf>
}
 e10:	60e2                	ld	ra,24(sp)
 e12:	6442                	ld	s0,16(sp)
 e14:	6161                	addi	sp,sp,80
 e16:	8082                	ret

0000000000000e18 <printf>:

void
printf(const char *fmt, ...)
{
 e18:	711d                	addi	sp,sp,-96
 e1a:	ec06                	sd	ra,24(sp)
 e1c:	e822                	sd	s0,16(sp)
 e1e:	1000                	addi	s0,sp,32
 e20:	e40c                	sd	a1,8(s0)
 e22:	e810                	sd	a2,16(s0)
 e24:	ec14                	sd	a3,24(s0)
 e26:	f018                	sd	a4,32(s0)
 e28:	f41c                	sd	a5,40(s0)
 e2a:	03043823          	sd	a6,48(s0)
 e2e:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 e32:	00840613          	addi	a2,s0,8
 e36:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 e3a:	85aa                	mv	a1,a0
 e3c:	4505                	li	a0,1
 e3e:	d0dff0ef          	jal	b4a <vprintf>
}
 e42:	60e2                	ld	ra,24(sp)
 e44:	6442                	ld	s0,16(sp)
 e46:	6125                	addi	sp,sp,96
 e48:	8082                	ret

0000000000000e4a <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 e4a:	1141                	addi	sp,sp,-16
 e4c:	e422                	sd	s0,8(sp)
 e4e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 e50:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 e54:	00001797          	auipc	a5,0x1
 e58:	1ac7b783          	ld	a5,428(a5) # 2000 <freep>
 e5c:	a02d                	j	e86 <free+0x3c>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
    bp->s.size += p->s.ptr->s.size;
 e5e:	4618                	lw	a4,8(a2)
 e60:	9f2d                	addw	a4,a4,a1
 e62:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 e66:	6398                	ld	a4,0(a5)
 e68:	6310                	ld	a2,0(a4)
 e6a:	a83d                	j	ea8 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
    p->s.size += bp->s.size;
 e6c:	ff852703          	lw	a4,-8(a0)
 e70:	9f31                	addw	a4,a4,a2
 e72:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 e74:	ff053683          	ld	a3,-16(a0)
 e78:	a091                	j	ebc <free+0x72>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 e7a:	6398                	ld	a4,0(a5)
 e7c:	00e7e463          	bltu	a5,a4,e84 <free+0x3a>
 e80:	00e6ea63          	bltu	a3,a4,e94 <free+0x4a>
{
 e84:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 e86:	fed7fae3          	bgeu	a5,a3,e7a <free+0x30>
 e8a:	6398                	ld	a4,0(a5)
 e8c:	00e6e463          	bltu	a3,a4,e94 <free+0x4a>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 e90:	fee7eae3          	bltu	a5,a4,e84 <free+0x3a>
  if (bp + bp->s.size == p->s.ptr) {
 e94:	ff852583          	lw	a1,-8(a0)
 e98:	6390                	ld	a2,0(a5)
 e9a:	02059813          	slli	a6,a1,0x20
 e9e:	01c85713          	srli	a4,a6,0x1c
 ea2:	9736                	add	a4,a4,a3
 ea4:	fae60de3          	beq	a2,a4,e5e <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 ea8:	fec53823          	sd	a2,-16(a0)
  if (p + p->s.size == bp) {
 eac:	4790                	lw	a2,8(a5)
 eae:	02061593          	slli	a1,a2,0x20
 eb2:	01c5d713          	srli	a4,a1,0x1c
 eb6:	973e                	add	a4,a4,a5
 eb8:	fae68ae3          	beq	a3,a4,e6c <free+0x22>
    p->s.ptr = bp->s.ptr;
 ebc:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 ebe:	00001717          	auipc	a4,0x1
 ec2:	14f73123          	sd	a5,322(a4) # 2000 <freep>
}
 ec6:	6422                	ld	s0,8(sp)
 ec8:	0141                	addi	sp,sp,16
 eca:	8082                	ret

0000000000000ecc <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 ecc:	7139                	addi	sp,sp,-64
 ece:	fc06                	sd	ra,56(sp)
 ed0:	f822                	sd	s0,48(sp)
 ed2:	f426                	sd	s1,40(sp)
 ed4:	ec4e                	sd	s3,24(sp)
 ed6:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 ed8:	02051493          	slli	s1,a0,0x20
 edc:	9081                	srli	s1,s1,0x20
 ede:	04bd                	addi	s1,s1,15
 ee0:	8091                	srli	s1,s1,0x4
 ee2:	0014899b          	addiw	s3,s1,1
 ee6:	0485                	addi	s1,s1,1
  if ((prevp = freep) == 0) {
 ee8:	00001517          	auipc	a0,0x1
 eec:	11853503          	ld	a0,280(a0) # 2000 <freep>
 ef0:	c915                	beqz	a0,f24 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 ef2:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 ef4:	4798                	lw	a4,8(a5)
 ef6:	08977a63          	bgeu	a4,s1,f8a <malloc+0xbe>
 efa:	f04a                	sd	s2,32(sp)
 efc:	e852                	sd	s4,16(sp)
 efe:	e456                	sd	s5,8(sp)
 f00:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 f02:	8a4e                	mv	s4,s3
 f04:	0009871b          	sext.w	a4,s3
 f08:	6685                	lui	a3,0x1
 f0a:	00d77363          	bgeu	a4,a3,f10 <malloc+0x44>
 f0e:	6a05                	lui	s4,0x1
 f10:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 f14:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 f18:	00001917          	auipc	s2,0x1
 f1c:	0e890913          	addi	s2,s2,232 # 2000 <freep>
  if (p == SBRK_ERROR)
 f20:	5afd                	li	s5,-1
 f22:	a081                	j	f62 <malloc+0x96>
 f24:	f04a                	sd	s2,32(sp)
 f26:	e852                	sd	s4,16(sp)
 f28:	e456                	sd	s5,8(sp)
 f2a:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 f2c:	00001797          	auipc	a5,0x1
 f30:	0e478793          	addi	a5,a5,228 # 2010 <base>
 f34:	00001717          	auipc	a4,0x1
 f38:	0cf73623          	sd	a5,204(a4) # 2000 <freep>
 f3c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 f3e:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 f42:	b7c1                	j	f02 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 f44:	6398                	ld	a4,0(a5)
 f46:	e118                	sd	a4,0(a0)
 f48:	a8a9                	j	fa2 <malloc+0xd6>
  hp->s.size = nu;
 f4a:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 f4e:	0541                	addi	a0,a0,16
 f50:	efbff0ef          	jal	e4a <free>
  return freep;
 f54:	00093503          	ld	a0,0(s2)
      if ((p = morecore(nunits)) == 0)
 f58:	c12d                	beqz	a0,fba <malloc+0xee>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 f5a:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 f5c:	4798                	lw	a4,8(a5)
 f5e:	02977263          	bgeu	a4,s1,f82 <malloc+0xb6>
    if (p == freep)
 f62:	00093703          	ld	a4,0(s2)
 f66:	853e                	mv	a0,a5
 f68:	fef719e3          	bne	a4,a5,f5a <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 f6c:	8552                	mv	a0,s4
 f6e:	a27ff0ef          	jal	994 <sbrk>
  if (p == SBRK_ERROR)
 f72:	fd551ce3          	bne	a0,s5,f4a <malloc+0x7e>
        return 0;
 f76:	4501                	li	a0,0
 f78:	7902                	ld	s2,32(sp)
 f7a:	6a42                	ld	s4,16(sp)
 f7c:	6aa2                	ld	s5,8(sp)
 f7e:	6b02                	ld	s6,0(sp)
 f80:	a03d                	j	fae <malloc+0xe2>
 f82:	7902                	ld	s2,32(sp)
 f84:	6a42                	ld	s4,16(sp)
 f86:	6aa2                	ld	s5,8(sp)
 f88:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 f8a:	fae48de3          	beq	s1,a4,f44 <malloc+0x78>
        p->s.size -= nunits;
 f8e:	4137073b          	subw	a4,a4,s3
 f92:	c798                	sw	a4,8(a5)
        p += p->s.size;
 f94:	02071693          	slli	a3,a4,0x20
 f98:	01c6d713          	srli	a4,a3,0x1c
 f9c:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 f9e:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 fa2:	00001717          	auipc	a4,0x1
 fa6:	04a73f23          	sd	a0,94(a4) # 2000 <freep>
      return (void *)(p + 1);
 faa:	01078513          	addi	a0,a5,16
  }
}
 fae:	70e2                	ld	ra,56(sp)
 fb0:	7442                	ld	s0,48(sp)
 fb2:	74a2                	ld	s1,40(sp)
 fb4:	69e2                	ld	s3,24(sp)
 fb6:	6121                	addi	sp,sp,64
 fb8:	8082                	ret
 fba:	7902                	ld	s2,32(sp)
 fbc:	6a42                	ld	s4,16(sp)
 fbe:	6aa2                	ld	s5,8(sp)
 fc0:	6b02                	ld	s6,0(sp)
 fc2:	b7f5                	j	fae <malloc+0xe2>
