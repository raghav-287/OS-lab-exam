#include "kernel/types.h"
#include "user/user.h"

#define NCHILDREN 3
#define CHUNK 100000

int
main(void)
{
  int pid;
  int p[2];
  int total = 0;
  int value;
  int i;
  char children[3][3];

  children[0][0] = 'A';
  children[1][0] = 'A';
  children[2][0] = 'A';
  children[0][1] = 'B';
  children[1][1] = 'B';
  children[2][1] = 'B';
  children[0][2] = 'C';
  children[1][2] = 'C';
  children[2][2] = 'C';

  if (pipe(p) < 0) {
    printf("synctest: pipe failed\n");
    exit(1);
  }

  for (i = 0; i < NCHILDREN; i++) {
    pid = fork();
    if (pid < 0) {
      printf("synctest: fork failed\n");
      exit(1);
    }
    if (pid == 0) {
      close(p[0]);
      value = CHUNK;
      if (write(p[1], &value, sizeof(value)) != sizeof(value)) {
        exit(1);
      }
      close(p[1]);
      exit(0);
    }
  }

  close(p[1]);

  for (i = 0; i < NCHILDREN; i++) {
    if (read(p[0], &value, sizeof(value)) != sizeof(value)) {
      printf("synctest: read failed\n");
      exit(1);
    }
    total += value;
  }
  close(p[0]);

  while (wait(0) >= 0)
    ;
  for (i = 0; i < NCHILDREN; i++) {
    for(int j =0;j<5;j++){
      printf(" %c\t", children[i][0]);
      printf(" %c\t", children[i][1]);
      printf(" %c\n", children[i][2]);
    }
    
  }

  exit(0);
}

