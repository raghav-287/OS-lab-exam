#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  void *a = sbrk(4096);
  void *b = sbrk(4096);
  uint64 pa1, pa2, bad;

  if ((uint64)a == (uint64)-1 || (uint64)b == (uint64)-1) {
    printf("sbrk failed\n");
    exit(1);
  }

  *(char *)a = 'A';
  *(char *)b = 'B';

  pa1 = vtop((uint64)a + 7);
  pa2 = vtop((uint64)b + 11);
  printf("VA 0x%lx -> PA 0x%lx\n", (unsigned long)((uint64)a + 7),
         (unsigned long)pa1);
  printf("VA 0x%lx -> PA 0x%lx\n", (unsigned long)((uint64)b + 11),
         (unsigned long)pa2);

  bad = 0x8000;
  if (vtop(bad) == 0)
    printf("Unmapped VA 0x%lx -> not mapped (expected)\n", (unsigned long)bad);
  else
    printf("Unmapped VA 0x%lx -> mapped unexpectedly\n", (unsigned long)bad);

  exit(0);
}
