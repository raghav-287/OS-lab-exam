#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  struct kalloc_stats stats;
  char *p1, *p2, *p3;

  if (kallocstats(&stats) < 0) {
    printf("kallocstats failed\n");
    exit(1);
  }

  printf("Initial allocator statistics:\n");
  printf("Total Allocated Pages: %d\n", (int)stats.total_allocated_pages);
  printf("Total Freed Pages: %d\n", (int)stats.total_freed_pages);
  printf("Currently Allocated Pages: %d\n",
         (int)stats.current_allocated_pages);
  printf("Available Pages: %d\n", (int)stats.available_pages);

  p1 = sbrk(4096);
  p2 = sbrk(4096);
  p3 = sbrk(4096);
  if ((uint64)p1 == (uint64)-1 || (uint64)p2 == (uint64)-1 ||
      (uint64)p3 == (uint64)-1) {
    printf("sbrk failed\n");
    exit(1);
  }

  p1[0] = 'A';
  p2[0] = 'B';
  p3[0] = 'C';

  if (kallocstats(&stats) < 0) {
    printf("kallocstats failed\n");
    exit(1);
  }

  printf("After allocating and touching 3 pages:\n");
  printf("Total Allocated Pages: %d\n", (int)stats.total_allocated_pages);
  printf("Total Freed Pages: %d\n", (int)stats.total_freed_pages);
  printf("Currently Allocated Pages: %d\n",
         (int)stats.current_allocated_pages);
  printf("Available Pages: %d\n", (int)stats.available_pages);

  if (sbrk(-12288) == (char *)-1) {
    printf("sbrk shrink failed\n");
    exit(1);
  }

  if (kallocstats(&stats) < 0) {
    printf("kallocstats failed\n");
    exit(1);
  }

  printf("After releasing 3 pages:\n");
  printf("Total Allocated Pages: %d\n", (int)stats.total_allocated_pages);
  printf("Total Freed Pages: %d\n", (int)stats.total_freed_pages);
  printf("Currently Allocated Pages: %d\n",
         (int)stats.current_allocated_pages);
  printf("Available Pages: %d\n", (int)stats.available_pages);

  exit(0);
}



