user/pageinfo.o: user/pageinfo.c kernel/types.h kernel/stat.h user/user.h
