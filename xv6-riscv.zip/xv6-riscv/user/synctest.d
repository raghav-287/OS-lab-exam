user/synctest.o: user/synctest.c kernel/types.h user/user.h
