
user/_usertests:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <copyinstr1>:
}

// what if you pass ridiculous string pointers to system calls?
void
copyinstr1(char *s)
{
       0:	711d                	addi	sp,sp,-96
       2:	ec86                	sd	ra,88(sp)
       4:	e8a2                	sd	s0,80(sp)
       6:	e4a6                	sd	s1,72(sp)
       8:	e0ca                	sd	s2,64(sp)
       a:	fc4e                	sd	s3,56(sp)
       c:	1080                	addi	s0,sp,96
  uint64 addrs[] = {0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
       e:	00008797          	auipc	a5,0x8
      12:	66278793          	addi	a5,a5,1634 # 8670 <malloc+0x2aea>
      16:	638c                	ld	a1,0(a5)
      18:	6790                	ld	a2,8(a5)
      1a:	6b94                	ld	a3,16(a5)
      1c:	6f98                	ld	a4,24(a5)
      1e:	739c                	ld	a5,32(a5)
      20:	fab43423          	sd	a1,-88(s0)
      24:	fac43823          	sd	a2,-80(s0)
      28:	fad43c23          	sd	a3,-72(s0)
      2c:	fce43023          	sd	a4,-64(s0)
      30:	fcf43423          	sd	a5,-56(s0)
                    0xffffffffffffffff};

  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
      34:	fa840493          	addi	s1,s0,-88
      38:	fd040993          	addi	s3,s0,-48
    uint64 addr = addrs[ai];

    int fd = open((char *)addr, O_CREATE | O_WRONLY);
      3c:	0004b903          	ld	s2,0(s1)
      40:	20100593          	li	a1,513
      44:	854a                	mv	a0,s2
      46:	67c050ef          	jal	56c2 <open>
    if (fd >= 0) {
      4a:	00055c63          	bgez	a0,62 <copyinstr1+0x62>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
      4e:	04a1                	addi	s1,s1,8
      50:	ff3496e3          	bne	s1,s3,3c <copyinstr1+0x3c>
      printf("open(%p) returned %d, not -1\n", (void *)addr, fd);
      exit(1);
    }
  }
}
      54:	60e6                	ld	ra,88(sp)
      56:	6446                	ld	s0,80(sp)
      58:	64a6                	ld	s1,72(sp)
      5a:	6906                	ld	s2,64(sp)
      5c:	79e2                	ld	s3,56(sp)
      5e:	6125                	addi	sp,sp,96
      60:	8082                	ret
      printf("open(%p) returned %d, not -1\n", (void *)addr, fd);
      62:	862a                	mv	a2,a0
      64:	85ca                	mv	a1,s2
      66:	00006517          	auipc	a0,0x6
      6a:	c1a50513          	addi	a0,a0,-998 # 5c80 <malloc+0xfa>
      6e:	265050ef          	jal	5ad2 <printf>
      exit(1);
      72:	4505                	li	a0,1
      74:	60e050ef          	jal	5682 <exit>

0000000000000078 <bsstest>:
void
bsstest(char *s)
{
  int i;

  for (i = 0; i < sizeof(uninit); i++) {
      78:	0000b797          	auipc	a5,0xb
      7c:	58078793          	addi	a5,a5,1408 # b5f8 <uninit>
      80:	0000e697          	auipc	a3,0xe
      84:	c8868693          	addi	a3,a3,-888 # dd08 <buf>
    if (uninit[i] != '\0') {
      88:	0007c703          	lbu	a4,0(a5)
      8c:	e709                	bnez	a4,96 <bsstest+0x1e>
  for (i = 0; i < sizeof(uninit); i++) {
      8e:	0785                	addi	a5,a5,1
      90:	fed79ce3          	bne	a5,a3,88 <bsstest+0x10>
      94:	8082                	ret
{
      96:	1141                	addi	sp,sp,-16
      98:	e406                	sd	ra,8(sp)
      9a:	e022                	sd	s0,0(sp)
      9c:	0800                	addi	s0,sp,16
      printf("%s: bss test failed\n", s);
      9e:	85aa                	mv	a1,a0
      a0:	00006517          	auipc	a0,0x6
      a4:	c0050513          	addi	a0,a0,-1024 # 5ca0 <malloc+0x11a>
      a8:	22b050ef          	jal	5ad2 <printf>
      exit(1);
      ac:	4505                	li	a0,1
      ae:	5d4050ef          	jal	5682 <exit>

00000000000000b2 <opentest>:
{
      b2:	1101                	addi	sp,sp,-32
      b4:	ec06                	sd	ra,24(sp)
      b6:	e822                	sd	s0,16(sp)
      b8:	e426                	sd	s1,8(sp)
      ba:	1000                	addi	s0,sp,32
      bc:	84aa                	mv	s1,a0
  fd = open("echo", 0);
      be:	4581                	li	a1,0
      c0:	00006517          	auipc	a0,0x6
      c4:	bf850513          	addi	a0,a0,-1032 # 5cb8 <malloc+0x132>
      c8:	5fa050ef          	jal	56c2 <open>
  if (fd < 0) {
      cc:	02054263          	bltz	a0,f0 <opentest+0x3e>
  close(fd);
      d0:	5da050ef          	jal	56aa <close>
  fd = open("doesnotexist", 0);
      d4:	4581                	li	a1,0
      d6:	00006517          	auipc	a0,0x6
      da:	c0250513          	addi	a0,a0,-1022 # 5cd8 <malloc+0x152>
      de:	5e4050ef          	jal	56c2 <open>
  if (fd >= 0) {
      e2:	02055163          	bgez	a0,104 <opentest+0x52>
}
      e6:	60e2                	ld	ra,24(sp)
      e8:	6442                	ld	s0,16(sp)
      ea:	64a2                	ld	s1,8(sp)
      ec:	6105                	addi	sp,sp,32
      ee:	8082                	ret
    printf("%s: open echo failed!\n", s);
      f0:	85a6                	mv	a1,s1
      f2:	00006517          	auipc	a0,0x6
      f6:	bce50513          	addi	a0,a0,-1074 # 5cc0 <malloc+0x13a>
      fa:	1d9050ef          	jal	5ad2 <printf>
    exit(1);
      fe:	4505                	li	a0,1
     100:	582050ef          	jal	5682 <exit>
    printf("%s: open doesnotexist succeeded!\n", s);
     104:	85a6                	mv	a1,s1
     106:	00006517          	auipc	a0,0x6
     10a:	be250513          	addi	a0,a0,-1054 # 5ce8 <malloc+0x162>
     10e:	1c5050ef          	jal	5ad2 <printf>
    exit(1);
     112:	4505                	li	a0,1
     114:	56e050ef          	jal	5682 <exit>

0000000000000118 <truncate2>:
{
     118:	7179                	addi	sp,sp,-48
     11a:	f406                	sd	ra,40(sp)
     11c:	f022                	sd	s0,32(sp)
     11e:	ec26                	sd	s1,24(sp)
     120:	e84a                	sd	s2,16(sp)
     122:	e44e                	sd	s3,8(sp)
     124:	1800                	addi	s0,sp,48
     126:	89aa                	mv	s3,a0
  unlink("truncfile");
     128:	00006517          	auipc	a0,0x6
     12c:	be850513          	addi	a0,a0,-1048 # 5d10 <malloc+0x18a>
     130:	5a2050ef          	jal	56d2 <unlink>
  int fd1 = open("truncfile", O_CREATE | O_TRUNC | O_WRONLY);
     134:	60100593          	li	a1,1537
     138:	00006517          	auipc	a0,0x6
     13c:	bd850513          	addi	a0,a0,-1064 # 5d10 <malloc+0x18a>
     140:	582050ef          	jal	56c2 <open>
     144:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     146:	4611                	li	a2,4
     148:	00006597          	auipc	a1,0x6
     14c:	bd858593          	addi	a1,a1,-1064 # 5d20 <malloc+0x19a>
     150:	552050ef          	jal	56a2 <write>
  int fd2 = open("truncfile", O_TRUNC | O_WRONLY);
     154:	40100593          	li	a1,1025
     158:	00006517          	auipc	a0,0x6
     15c:	bb850513          	addi	a0,a0,-1096 # 5d10 <malloc+0x18a>
     160:	562050ef          	jal	56c2 <open>
     164:	892a                	mv	s2,a0
  int n = write(fd1, "x", 1);
     166:	4605                	li	a2,1
     168:	00006597          	auipc	a1,0x6
     16c:	bc058593          	addi	a1,a1,-1088 # 5d28 <malloc+0x1a2>
     170:	8526                	mv	a0,s1
     172:	530050ef          	jal	56a2 <write>
  if (n != -1) {
     176:	57fd                	li	a5,-1
     178:	02f51563          	bne	a0,a5,1a2 <truncate2+0x8a>
  unlink("truncfile");
     17c:	00006517          	auipc	a0,0x6
     180:	b9450513          	addi	a0,a0,-1132 # 5d10 <malloc+0x18a>
     184:	54e050ef          	jal	56d2 <unlink>
  close(fd1);
     188:	8526                	mv	a0,s1
     18a:	520050ef          	jal	56aa <close>
  close(fd2);
     18e:	854a                	mv	a0,s2
     190:	51a050ef          	jal	56aa <close>
}
     194:	70a2                	ld	ra,40(sp)
     196:	7402                	ld	s0,32(sp)
     198:	64e2                	ld	s1,24(sp)
     19a:	6942                	ld	s2,16(sp)
     19c:	69a2                	ld	s3,8(sp)
     19e:	6145                	addi	sp,sp,48
     1a0:	8082                	ret
    printf("%s: write returned %d, expected -1\n", s, n);
     1a2:	862a                	mv	a2,a0
     1a4:	85ce                	mv	a1,s3
     1a6:	00006517          	auipc	a0,0x6
     1aa:	b8a50513          	addi	a0,a0,-1142 # 5d30 <malloc+0x1aa>
     1ae:	125050ef          	jal	5ad2 <printf>
    exit(1);
     1b2:	4505                	li	a0,1
     1b4:	4ce050ef          	jal	5682 <exit>

00000000000001b8 <createtest>:
{
     1b8:	7179                	addi	sp,sp,-48
     1ba:	f406                	sd	ra,40(sp)
     1bc:	f022                	sd	s0,32(sp)
     1be:	ec26                	sd	s1,24(sp)
     1c0:	e84a                	sd	s2,16(sp)
     1c2:	1800                	addi	s0,sp,48
  name[0] = 'a';
     1c4:	06100793          	li	a5,97
     1c8:	fcf40c23          	sb	a5,-40(s0)
  name[2] = '\0';
     1cc:	fc040d23          	sb	zero,-38(s0)
     1d0:	03000493          	li	s1,48
  for (i = 0; i < N; i++) {
     1d4:	06400913          	li	s2,100
    name[1] = '0' + i;
     1d8:	fc940ca3          	sb	s1,-39(s0)
    fd = open(name, O_CREATE | O_RDWR);
     1dc:	20200593          	li	a1,514
     1e0:	fd840513          	addi	a0,s0,-40
     1e4:	4de050ef          	jal	56c2 <open>
    close(fd);
     1e8:	4c2050ef          	jal	56aa <close>
  for (i = 0; i < N; i++) {
     1ec:	2485                	addiw	s1,s1,1
     1ee:	0ff4f493          	zext.b	s1,s1
     1f2:	ff2493e3          	bne	s1,s2,1d8 <createtest+0x20>
  name[0] = 'a';
     1f6:	06100793          	li	a5,97
     1fa:	fcf40c23          	sb	a5,-40(s0)
  name[2] = '\0';
     1fe:	fc040d23          	sb	zero,-38(s0)
     202:	03000493          	li	s1,48
  for (i = 0; i < N; i++) {
     206:	06400913          	li	s2,100
    name[1] = '0' + i;
     20a:	fc940ca3          	sb	s1,-39(s0)
    unlink(name);
     20e:	fd840513          	addi	a0,s0,-40
     212:	4c0050ef          	jal	56d2 <unlink>
  for (i = 0; i < N; i++) {
     216:	2485                	addiw	s1,s1,1
     218:	0ff4f493          	zext.b	s1,s1
     21c:	ff2497e3          	bne	s1,s2,20a <createtest+0x52>
}
     220:	70a2                	ld	ra,40(sp)
     222:	7402                	ld	s0,32(sp)
     224:	64e2                	ld	s1,24(sp)
     226:	6942                	ld	s2,16(sp)
     228:	6145                	addi	sp,sp,48
     22a:	8082                	ret

000000000000022c <bigwrite>:
{
     22c:	715d                	addi	sp,sp,-80
     22e:	e486                	sd	ra,72(sp)
     230:	e0a2                	sd	s0,64(sp)
     232:	fc26                	sd	s1,56(sp)
     234:	f84a                	sd	s2,48(sp)
     236:	f44e                	sd	s3,40(sp)
     238:	f052                	sd	s4,32(sp)
     23a:	ec56                	sd	s5,24(sp)
     23c:	e85a                	sd	s6,16(sp)
     23e:	e45e                	sd	s7,8(sp)
     240:	0880                	addi	s0,sp,80
     242:	8baa                	mv	s7,a0
  unlink("bigwrite");
     244:	00006517          	auipc	a0,0x6
     248:	b1450513          	addi	a0,a0,-1260 # 5d58 <malloc+0x1d2>
     24c:	486050ef          	jal	56d2 <unlink>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     250:	1f300493          	li	s1,499
    fd = open("bigwrite", O_CREATE | O_RDWR);
     254:	00006a97          	auipc	s5,0x6
     258:	b04a8a93          	addi	s5,s5,-1276 # 5d58 <malloc+0x1d2>
      int cc = write(fd, buf, sz);
     25c:	0000ea17          	auipc	s4,0xe
     260:	aaca0a13          	addi	s4,s4,-1364 # dd08 <buf>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     264:	6b0d                	lui	s6,0x3
     266:	1c9b0b13          	addi	s6,s6,457 # 31c9 <dirfile+0x69>
    fd = open("bigwrite", O_CREATE | O_RDWR);
     26a:	20200593          	li	a1,514
     26e:	8556                	mv	a0,s5
     270:	452050ef          	jal	56c2 <open>
     274:	892a                	mv	s2,a0
    if (fd < 0) {
     276:	04054563          	bltz	a0,2c0 <bigwrite+0x94>
      int cc = write(fd, buf, sz);
     27a:	8626                	mv	a2,s1
     27c:	85d2                	mv	a1,s4
     27e:	424050ef          	jal	56a2 <write>
     282:	89aa                	mv	s3,a0
      if (cc != sz) {
     284:	04a49863          	bne	s1,a0,2d4 <bigwrite+0xa8>
      int cc = write(fd, buf, sz);
     288:	8626                	mv	a2,s1
     28a:	85d2                	mv	a1,s4
     28c:	854a                	mv	a0,s2
     28e:	414050ef          	jal	56a2 <write>
      if (cc != sz) {
     292:	04951263          	bne	a0,s1,2d6 <bigwrite+0xaa>
    close(fd);
     296:	854a                	mv	a0,s2
     298:	412050ef          	jal	56aa <close>
    unlink("bigwrite");
     29c:	8556                	mv	a0,s5
     29e:	434050ef          	jal	56d2 <unlink>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     2a2:	1d74849b          	addiw	s1,s1,471
     2a6:	fd6492e3          	bne	s1,s6,26a <bigwrite+0x3e>
}
     2aa:	60a6                	ld	ra,72(sp)
     2ac:	6406                	ld	s0,64(sp)
     2ae:	74e2                	ld	s1,56(sp)
     2b0:	7942                	ld	s2,48(sp)
     2b2:	79a2                	ld	s3,40(sp)
     2b4:	7a02                	ld	s4,32(sp)
     2b6:	6ae2                	ld	s5,24(sp)
     2b8:	6b42                	ld	s6,16(sp)
     2ba:	6ba2                	ld	s7,8(sp)
     2bc:	6161                	addi	sp,sp,80
     2be:	8082                	ret
      printf("%s: cannot create bigwrite\n", s);
     2c0:	85de                	mv	a1,s7
     2c2:	00006517          	auipc	a0,0x6
     2c6:	aa650513          	addi	a0,a0,-1370 # 5d68 <malloc+0x1e2>
     2ca:	009050ef          	jal	5ad2 <printf>
      exit(1);
     2ce:	4505                	li	a0,1
     2d0:	3b2050ef          	jal	5682 <exit>
      if (cc != sz) {
     2d4:	89a6                	mv	s3,s1
        printf("%s: write(%d) ret %d\n", s, sz, cc);
     2d6:	86aa                	mv	a3,a0
     2d8:	864e                	mv	a2,s3
     2da:	85de                	mv	a1,s7
     2dc:	00006517          	auipc	a0,0x6
     2e0:	aac50513          	addi	a0,a0,-1364 # 5d88 <malloc+0x202>
     2e4:	7ee050ef          	jal	5ad2 <printf>
        exit(1);
     2e8:	4505                	li	a0,1
     2ea:	398050ef          	jal	5682 <exit>

00000000000002ee <badwrite>:
// file is deleted? if the kernel has this bug, it will panic: balloc:
// out of blocks. assumed_free may need to be raised to be more than
// the number of free blocks. this test takes a long time.
void
badwrite(char *s)
{
     2ee:	7179                	addi	sp,sp,-48
     2f0:	f406                	sd	ra,40(sp)
     2f2:	f022                	sd	s0,32(sp)
     2f4:	ec26                	sd	s1,24(sp)
     2f6:	e84a                	sd	s2,16(sp)
     2f8:	e44e                	sd	s3,8(sp)
     2fa:	e052                	sd	s4,0(sp)
     2fc:	1800                	addi	s0,sp,48
  int assumed_free = 600;

  unlink("junk");
     2fe:	00006517          	auipc	a0,0x6
     302:	aa250513          	addi	a0,a0,-1374 # 5da0 <malloc+0x21a>
     306:	3cc050ef          	jal	56d2 <unlink>
     30a:	25800913          	li	s2,600
  for (int i = 0; i < assumed_free; i++) {
    int fd = open("junk", O_CREATE | O_WRONLY);
     30e:	00006997          	auipc	s3,0x6
     312:	a9298993          	addi	s3,s3,-1390 # 5da0 <malloc+0x21a>
    if (fd < 0) {
      printf("open junk failed\n");
      exit(1);
    }
    write(fd, (char *)0xffffffffffL, 1);
     316:	5a7d                	li	s4,-1
     318:	018a5a13          	srli	s4,s4,0x18
    int fd = open("junk", O_CREATE | O_WRONLY);
     31c:	20100593          	li	a1,513
     320:	854e                	mv	a0,s3
     322:	3a0050ef          	jal	56c2 <open>
     326:	84aa                	mv	s1,a0
    if (fd < 0) {
     328:	04054d63          	bltz	a0,382 <badwrite+0x94>
    write(fd, (char *)0xffffffffffL, 1);
     32c:	4605                	li	a2,1
     32e:	85d2                	mv	a1,s4
     330:	372050ef          	jal	56a2 <write>
    close(fd);
     334:	8526                	mv	a0,s1
     336:	374050ef          	jal	56aa <close>
    unlink("junk");
     33a:	854e                	mv	a0,s3
     33c:	396050ef          	jal	56d2 <unlink>
  for (int i = 0; i < assumed_free; i++) {
     340:	397d                	addiw	s2,s2,-1
     342:	fc091de3          	bnez	s2,31c <badwrite+0x2e>
  }

  int fd = open("junk", O_CREATE | O_WRONLY);
     346:	20100593          	li	a1,513
     34a:	00006517          	auipc	a0,0x6
     34e:	a5650513          	addi	a0,a0,-1450 # 5da0 <malloc+0x21a>
     352:	370050ef          	jal	56c2 <open>
     356:	84aa                	mv	s1,a0
  if (fd < 0) {
     358:	02054e63          	bltz	a0,394 <badwrite+0xa6>
    printf("open junk failed\n");
    exit(1);
  }
  if (write(fd, "x", 1) != 1) {
     35c:	4605                	li	a2,1
     35e:	00006597          	auipc	a1,0x6
     362:	9ca58593          	addi	a1,a1,-1590 # 5d28 <malloc+0x1a2>
     366:	33c050ef          	jal	56a2 <write>
     36a:	4785                	li	a5,1
     36c:	02f50d63          	beq	a0,a5,3a6 <badwrite+0xb8>
    printf("write failed\n");
     370:	00006517          	auipc	a0,0x6
     374:	a5050513          	addi	a0,a0,-1456 # 5dc0 <malloc+0x23a>
     378:	75a050ef          	jal	5ad2 <printf>
    exit(1);
     37c:	4505                	li	a0,1
     37e:	304050ef          	jal	5682 <exit>
      printf("open junk failed\n");
     382:	00006517          	auipc	a0,0x6
     386:	a2650513          	addi	a0,a0,-1498 # 5da8 <malloc+0x222>
     38a:	748050ef          	jal	5ad2 <printf>
      exit(1);
     38e:	4505                	li	a0,1
     390:	2f2050ef          	jal	5682 <exit>
    printf("open junk failed\n");
     394:	00006517          	auipc	a0,0x6
     398:	a1450513          	addi	a0,a0,-1516 # 5da8 <malloc+0x222>
     39c:	736050ef          	jal	5ad2 <printf>
    exit(1);
     3a0:	4505                	li	a0,1
     3a2:	2e0050ef          	jal	5682 <exit>
  }
  close(fd);
     3a6:	8526                	mv	a0,s1
     3a8:	302050ef          	jal	56aa <close>
  unlink("junk");
     3ac:	00006517          	auipc	a0,0x6
     3b0:	9f450513          	addi	a0,a0,-1548 # 5da0 <malloc+0x21a>
     3b4:	31e050ef          	jal	56d2 <unlink>

  exit(0);
     3b8:	4501                	li	a0,0
     3ba:	2c8050ef          	jal	5682 <exit>

00000000000003be <outofinodes>:
  }
}

void
outofinodes(char *s)
{
     3be:	715d                	addi	sp,sp,-80
     3c0:	e486                	sd	ra,72(sp)
     3c2:	e0a2                	sd	s0,64(sp)
     3c4:	fc26                	sd	s1,56(sp)
     3c6:	f84a                	sd	s2,48(sp)
     3c8:	f44e                	sd	s3,40(sp)
     3ca:	0880                	addi	s0,sp,80
  int nzz = 32 * 32;
  for (int i = 0; i < nzz; i++) {
     3cc:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     3ce:	07a00913          	li	s2,122
  for (int i = 0; i < nzz; i++) {
     3d2:	40000993          	li	s3,1024
    name[0] = 'z';
     3d6:	fb240823          	sb	s2,-80(s0)
    name[1] = 'z';
     3da:	fb2408a3          	sb	s2,-79(s0)
    name[2] = '0' + (i / 32);
     3de:	41f4d71b          	sraiw	a4,s1,0x1f
     3e2:	01b7571b          	srliw	a4,a4,0x1b
     3e6:	009707bb          	addw	a5,a4,s1
     3ea:	4057d69b          	sraiw	a3,a5,0x5
     3ee:	0306869b          	addiw	a3,a3,48
     3f2:	fad40923          	sb	a3,-78(s0)
    name[3] = '0' + (i % 32);
     3f6:	8bfd                	andi	a5,a5,31
     3f8:	9f99                	subw	a5,a5,a4
     3fa:	0307879b          	addiw	a5,a5,48
     3fe:	faf409a3          	sb	a5,-77(s0)
    name[4] = '\0';
     402:	fa040a23          	sb	zero,-76(s0)
    unlink(name);
     406:	fb040513          	addi	a0,s0,-80
     40a:	2c8050ef          	jal	56d2 <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
     40e:	60200593          	li	a1,1538
     412:	fb040513          	addi	a0,s0,-80
     416:	2ac050ef          	jal	56c2 <open>
    if (fd < 0) {
     41a:	00054763          	bltz	a0,428 <outofinodes+0x6a>
      // failure is eventually expected.
      break;
    }
    close(fd);
     41e:	28c050ef          	jal	56aa <close>
  for (int i = 0; i < nzz; i++) {
     422:	2485                	addiw	s1,s1,1
     424:	fb3499e3          	bne	s1,s3,3d6 <outofinodes+0x18>
     428:	4481                	li	s1,0
  }

  for (int i = 0; i < nzz; i++) {
    char name[32];
    name[0] = 'z';
     42a:	07a00913          	li	s2,122
  for (int i = 0; i < nzz; i++) {
     42e:	40000993          	li	s3,1024
    name[0] = 'z';
     432:	fb240823          	sb	s2,-80(s0)
    name[1] = 'z';
     436:	fb2408a3          	sb	s2,-79(s0)
    name[2] = '0' + (i / 32);
     43a:	41f4d71b          	sraiw	a4,s1,0x1f
     43e:	01b7571b          	srliw	a4,a4,0x1b
     442:	009707bb          	addw	a5,a4,s1
     446:	4057d69b          	sraiw	a3,a5,0x5
     44a:	0306869b          	addiw	a3,a3,48
     44e:	fad40923          	sb	a3,-78(s0)
    name[3] = '0' + (i % 32);
     452:	8bfd                	andi	a5,a5,31
     454:	9f99                	subw	a5,a5,a4
     456:	0307879b          	addiw	a5,a5,48
     45a:	faf409a3          	sb	a5,-77(s0)
    name[4] = '\0';
     45e:	fa040a23          	sb	zero,-76(s0)
    unlink(name);
     462:	fb040513          	addi	a0,s0,-80
     466:	26c050ef          	jal	56d2 <unlink>
  for (int i = 0; i < nzz; i++) {
     46a:	2485                	addiw	s1,s1,1
     46c:	fd3493e3          	bne	s1,s3,432 <outofinodes+0x74>
  }
}
     470:	60a6                	ld	ra,72(sp)
     472:	6406                	ld	s0,64(sp)
     474:	74e2                	ld	s1,56(sp)
     476:	7942                	ld	s2,48(sp)
     478:	79a2                	ld	s3,40(sp)
     47a:	6161                	addi	sp,sp,80
     47c:	8082                	ret

000000000000047e <copyin>:
{
     47e:	7159                	addi	sp,sp,-112
     480:	f486                	sd	ra,104(sp)
     482:	f0a2                	sd	s0,96(sp)
     484:	eca6                	sd	s1,88(sp)
     486:	e8ca                	sd	s2,80(sp)
     488:	e4ce                	sd	s3,72(sp)
     48a:	e0d2                	sd	s4,64(sp)
     48c:	fc56                	sd	s5,56(sp)
     48e:	1880                	addi	s0,sp,112
  uint64 addrs[] = {0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     490:	00008797          	auipc	a5,0x8
     494:	1e078793          	addi	a5,a5,480 # 8670 <malloc+0x2aea>
     498:	638c                	ld	a1,0(a5)
     49a:	6790                	ld	a2,8(a5)
     49c:	6b94                	ld	a3,16(a5)
     49e:	6f98                	ld	a4,24(a5)
     4a0:	739c                	ld	a5,32(a5)
     4a2:	f8b43c23          	sd	a1,-104(s0)
     4a6:	fac43023          	sd	a2,-96(s0)
     4aa:	fad43423          	sd	a3,-88(s0)
     4ae:	fae43823          	sd	a4,-80(s0)
     4b2:	faf43c23          	sd	a5,-72(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     4b6:	f9840913          	addi	s2,s0,-104
     4ba:	fc040a93          	addi	s5,s0,-64
    int fd = open("copyin1", O_CREATE | O_WRONLY);
     4be:	00006a17          	auipc	s4,0x6
     4c2:	912a0a13          	addi	s4,s4,-1774 # 5dd0 <malloc+0x24a>
    uint64 addr = addrs[ai];
     4c6:	00093983          	ld	s3,0(s2)
    int fd = open("copyin1", O_CREATE | O_WRONLY);
     4ca:	20100593          	li	a1,513
     4ce:	8552                	mv	a0,s4
     4d0:	1f2050ef          	jal	56c2 <open>
     4d4:	84aa                	mv	s1,a0
    if (fd < 0) {
     4d6:	06054763          	bltz	a0,544 <copyin+0xc6>
    int n = write(fd, (void *)addr, 8192);
     4da:	6609                	lui	a2,0x2
     4dc:	85ce                	mv	a1,s3
     4de:	1c4050ef          	jal	56a2 <write>
    if (n >= 0) {
     4e2:	06055a63          	bgez	a0,556 <copyin+0xd8>
    close(fd);
     4e6:	8526                	mv	a0,s1
     4e8:	1c2050ef          	jal	56aa <close>
    unlink("copyin1");
     4ec:	8552                	mv	a0,s4
     4ee:	1e4050ef          	jal	56d2 <unlink>
    n = write(1, (char *)addr, 8192);
     4f2:	6609                	lui	a2,0x2
     4f4:	85ce                	mv	a1,s3
     4f6:	4505                	li	a0,1
     4f8:	1aa050ef          	jal	56a2 <write>
    if (n > 0) {
     4fc:	06a04863          	bgtz	a0,56c <copyin+0xee>
    if (pipe(fds) < 0) {
     500:	f9040513          	addi	a0,s0,-112
     504:	18e050ef          	jal	5692 <pipe>
     508:	06054d63          	bltz	a0,582 <copyin+0x104>
    n = write(fds[1], (char *)addr, 8192);
     50c:	6609                	lui	a2,0x2
     50e:	85ce                	mv	a1,s3
     510:	f9442503          	lw	a0,-108(s0)
     514:	18e050ef          	jal	56a2 <write>
    if (n > 0) {
     518:	06a04e63          	bgtz	a0,594 <copyin+0x116>
    close(fds[0]);
     51c:	f9042503          	lw	a0,-112(s0)
     520:	18a050ef          	jal	56aa <close>
    close(fds[1]);
     524:	f9442503          	lw	a0,-108(s0)
     528:	182050ef          	jal	56aa <close>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     52c:	0921                	addi	s2,s2,8
     52e:	f9591ce3          	bne	s2,s5,4c6 <copyin+0x48>
}
     532:	70a6                	ld	ra,104(sp)
     534:	7406                	ld	s0,96(sp)
     536:	64e6                	ld	s1,88(sp)
     538:	6946                	ld	s2,80(sp)
     53a:	69a6                	ld	s3,72(sp)
     53c:	6a06                	ld	s4,64(sp)
     53e:	7ae2                	ld	s5,56(sp)
     540:	6165                	addi	sp,sp,112
     542:	8082                	ret
      printf("open(copyin1) failed\n");
     544:	00006517          	auipc	a0,0x6
     548:	89450513          	addi	a0,a0,-1900 # 5dd8 <malloc+0x252>
     54c:	586050ef          	jal	5ad2 <printf>
      exit(1);
     550:	4505                	li	a0,1
     552:	130050ef          	jal	5682 <exit>
      printf("write(fd, %p, 8192) returned %d, not -1\n", (void *)addr, n);
     556:	862a                	mv	a2,a0
     558:	85ce                	mv	a1,s3
     55a:	00006517          	auipc	a0,0x6
     55e:	89650513          	addi	a0,a0,-1898 # 5df0 <malloc+0x26a>
     562:	570050ef          	jal	5ad2 <printf>
      exit(1);
     566:	4505                	li	a0,1
     568:	11a050ef          	jal	5682 <exit>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", (void *)addr, n);
     56c:	862a                	mv	a2,a0
     56e:	85ce                	mv	a1,s3
     570:	00006517          	auipc	a0,0x6
     574:	8b050513          	addi	a0,a0,-1872 # 5e20 <malloc+0x29a>
     578:	55a050ef          	jal	5ad2 <printf>
      exit(1);
     57c:	4505                	li	a0,1
     57e:	104050ef          	jal	5682 <exit>
      printf("pipe() failed\n");
     582:	00006517          	auipc	a0,0x6
     586:	8ce50513          	addi	a0,a0,-1842 # 5e50 <malloc+0x2ca>
     58a:	548050ef          	jal	5ad2 <printf>
      exit(1);
     58e:	4505                	li	a0,1
     590:	0f2050ef          	jal	5682 <exit>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", (void *)addr,
     594:	862a                	mv	a2,a0
     596:	85ce                	mv	a1,s3
     598:	00006517          	auipc	a0,0x6
     59c:	8c850513          	addi	a0,a0,-1848 # 5e60 <malloc+0x2da>
     5a0:	532050ef          	jal	5ad2 <printf>
      exit(1);
     5a4:	4505                	li	a0,1
     5a6:	0dc050ef          	jal	5682 <exit>

00000000000005aa <copyout>:
{
     5aa:	7119                	addi	sp,sp,-128
     5ac:	fc86                	sd	ra,120(sp)
     5ae:	f8a2                	sd	s0,112(sp)
     5b0:	f4a6                	sd	s1,104(sp)
     5b2:	f0ca                	sd	s2,96(sp)
     5b4:	ecce                	sd	s3,88(sp)
     5b6:	e8d2                	sd	s4,80(sp)
     5b8:	e4d6                	sd	s5,72(sp)
     5ba:	e0da                	sd	s6,64(sp)
     5bc:	0100                	addi	s0,sp,128
  uint64 addrs[] = {0LL,          0x80000000LL, 0x3fffffe000,
     5be:	00008797          	auipc	a5,0x8
     5c2:	0b278793          	addi	a5,a5,178 # 8670 <malloc+0x2aea>
     5c6:	7788                	ld	a0,40(a5)
     5c8:	7b8c                	ld	a1,48(a5)
     5ca:	7f90                	ld	a2,56(a5)
     5cc:	63b4                	ld	a3,64(a5)
     5ce:	67b8                	ld	a4,72(a5)
     5d0:	6bbc                	ld	a5,80(a5)
     5d2:	f8a43823          	sd	a0,-112(s0)
     5d6:	f8b43c23          	sd	a1,-104(s0)
     5da:	fac43023          	sd	a2,-96(s0)
     5de:	fad43423          	sd	a3,-88(s0)
     5e2:	fae43823          	sd	a4,-80(s0)
     5e6:	faf43c23          	sd	a5,-72(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     5ea:	f9040913          	addi	s2,s0,-112
     5ee:	fc040b13          	addi	s6,s0,-64
    int fd = open("README", 0);
     5f2:	00006a17          	auipc	s4,0x6
     5f6:	89ea0a13          	addi	s4,s4,-1890 # 5e90 <malloc+0x30a>
    n = write(fds[1], "x", 1);
     5fa:	00005a97          	auipc	s5,0x5
     5fe:	72ea8a93          	addi	s5,s5,1838 # 5d28 <malloc+0x1a2>
    uint64 addr = addrs[ai];
     602:	00093983          	ld	s3,0(s2)
    int fd = open("README", 0);
     606:	4581                	li	a1,0
     608:	8552                	mv	a0,s4
     60a:	0b8050ef          	jal	56c2 <open>
     60e:	84aa                	mv	s1,a0
    if (fd < 0) {
     610:	06054763          	bltz	a0,67e <copyout+0xd4>
    int n = read(fd, (void *)addr, 8192);
     614:	6609                	lui	a2,0x2
     616:	85ce                	mv	a1,s3
     618:	082050ef          	jal	569a <read>
    if (n > 0) {
     61c:	06a04a63          	bgtz	a0,690 <copyout+0xe6>
    close(fd);
     620:	8526                	mv	a0,s1
     622:	088050ef          	jal	56aa <close>
    if (pipe(fds) < 0) {
     626:	f8840513          	addi	a0,s0,-120
     62a:	068050ef          	jal	5692 <pipe>
     62e:	06054c63          	bltz	a0,6a6 <copyout+0xfc>
    n = write(fds[1], "x", 1);
     632:	4605                	li	a2,1
     634:	85d6                	mv	a1,s5
     636:	f8c42503          	lw	a0,-116(s0)
     63a:	068050ef          	jal	56a2 <write>
    if (n != 1) {
     63e:	4785                	li	a5,1
     640:	06f51c63          	bne	a0,a5,6b8 <copyout+0x10e>
    n = read(fds[0], (void *)addr, 8192);
     644:	6609                	lui	a2,0x2
     646:	85ce                	mv	a1,s3
     648:	f8842503          	lw	a0,-120(s0)
     64c:	04e050ef          	jal	569a <read>
    if (n > 0) {
     650:	06a04d63          	bgtz	a0,6ca <copyout+0x120>
    close(fds[0]);
     654:	f8842503          	lw	a0,-120(s0)
     658:	052050ef          	jal	56aa <close>
    close(fds[1]);
     65c:	f8c42503          	lw	a0,-116(s0)
     660:	04a050ef          	jal	56aa <close>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     664:	0921                	addi	s2,s2,8
     666:	f9691ee3          	bne	s2,s6,602 <copyout+0x58>
}
     66a:	70e6                	ld	ra,120(sp)
     66c:	7446                	ld	s0,112(sp)
     66e:	74a6                	ld	s1,104(sp)
     670:	7906                	ld	s2,96(sp)
     672:	69e6                	ld	s3,88(sp)
     674:	6a46                	ld	s4,80(sp)
     676:	6aa6                	ld	s5,72(sp)
     678:	6b06                	ld	s6,64(sp)
     67a:	6109                	addi	sp,sp,128
     67c:	8082                	ret
      printf("open(README) failed\n");
     67e:	00006517          	auipc	a0,0x6
     682:	81a50513          	addi	a0,a0,-2022 # 5e98 <malloc+0x312>
     686:	44c050ef          	jal	5ad2 <printf>
      exit(1);
     68a:	4505                	li	a0,1
     68c:	7f7040ef          	jal	5682 <exit>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", (void *)addr, n);
     690:	862a                	mv	a2,a0
     692:	85ce                	mv	a1,s3
     694:	00006517          	auipc	a0,0x6
     698:	81c50513          	addi	a0,a0,-2020 # 5eb0 <malloc+0x32a>
     69c:	436050ef          	jal	5ad2 <printf>
      exit(1);
     6a0:	4505                	li	a0,1
     6a2:	7e1040ef          	jal	5682 <exit>
      printf("pipe() failed\n");
     6a6:	00005517          	auipc	a0,0x5
     6aa:	7aa50513          	addi	a0,a0,1962 # 5e50 <malloc+0x2ca>
     6ae:	424050ef          	jal	5ad2 <printf>
      exit(1);
     6b2:	4505                	li	a0,1
     6b4:	7cf040ef          	jal	5682 <exit>
      printf("pipe write failed\n");
     6b8:	00006517          	auipc	a0,0x6
     6bc:	82850513          	addi	a0,a0,-2008 # 5ee0 <malloc+0x35a>
     6c0:	412050ef          	jal	5ad2 <printf>
      exit(1);
     6c4:	4505                	li	a0,1
     6c6:	7bd040ef          	jal	5682 <exit>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", (void *)addr,
     6ca:	862a                	mv	a2,a0
     6cc:	85ce                	mv	a1,s3
     6ce:	00006517          	auipc	a0,0x6
     6d2:	82a50513          	addi	a0,a0,-2006 # 5ef8 <malloc+0x372>
     6d6:	3fc050ef          	jal	5ad2 <printf>
      exit(1);
     6da:	4505                	li	a0,1
     6dc:	7a7040ef          	jal	5682 <exit>

00000000000006e0 <truncate1>:
{
     6e0:	711d                	addi	sp,sp,-96
     6e2:	ec86                	sd	ra,88(sp)
     6e4:	e8a2                	sd	s0,80(sp)
     6e6:	e4a6                	sd	s1,72(sp)
     6e8:	e0ca                	sd	s2,64(sp)
     6ea:	fc4e                	sd	s3,56(sp)
     6ec:	f852                	sd	s4,48(sp)
     6ee:	f456                	sd	s5,40(sp)
     6f0:	1080                	addi	s0,sp,96
     6f2:	8aaa                	mv	s5,a0
  unlink("truncfile");
     6f4:	00005517          	auipc	a0,0x5
     6f8:	61c50513          	addi	a0,a0,1564 # 5d10 <malloc+0x18a>
     6fc:	7d7040ef          	jal	56d2 <unlink>
  int fd1 = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
     700:	60100593          	li	a1,1537
     704:	00005517          	auipc	a0,0x5
     708:	60c50513          	addi	a0,a0,1548 # 5d10 <malloc+0x18a>
     70c:	7b7040ef          	jal	56c2 <open>
     710:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     712:	4611                	li	a2,4
     714:	00005597          	auipc	a1,0x5
     718:	60c58593          	addi	a1,a1,1548 # 5d20 <malloc+0x19a>
     71c:	787040ef          	jal	56a2 <write>
  close(fd1);
     720:	8526                	mv	a0,s1
     722:	789040ef          	jal	56aa <close>
  int fd2 = open("truncfile", O_RDONLY);
     726:	4581                	li	a1,0
     728:	00005517          	auipc	a0,0x5
     72c:	5e850513          	addi	a0,a0,1512 # 5d10 <malloc+0x18a>
     730:	793040ef          	jal	56c2 <open>
     734:	84aa                	mv	s1,a0
  int n = read(fd2, buf, sizeof(buf));
     736:	02000613          	li	a2,32
     73a:	fa040593          	addi	a1,s0,-96
     73e:	75d040ef          	jal	569a <read>
  if (n != 4) {
     742:	4791                	li	a5,4
     744:	0af51863          	bne	a0,a5,7f4 <truncate1+0x114>
  fd1 = open("truncfile", O_WRONLY | O_TRUNC);
     748:	40100593          	li	a1,1025
     74c:	00005517          	auipc	a0,0x5
     750:	5c450513          	addi	a0,a0,1476 # 5d10 <malloc+0x18a>
     754:	76f040ef          	jal	56c2 <open>
     758:	89aa                	mv	s3,a0
  int fd3 = open("truncfile", O_RDONLY);
     75a:	4581                	li	a1,0
     75c:	00005517          	auipc	a0,0x5
     760:	5b450513          	addi	a0,a0,1460 # 5d10 <malloc+0x18a>
     764:	75f040ef          	jal	56c2 <open>
     768:	892a                	mv	s2,a0
  n = read(fd3, buf, sizeof(buf));
     76a:	02000613          	li	a2,32
     76e:	fa040593          	addi	a1,s0,-96
     772:	729040ef          	jal	569a <read>
     776:	8a2a                	mv	s4,a0
  if (n != 0) {
     778:	e949                	bnez	a0,80a <truncate1+0x12a>
  n = read(fd2, buf, sizeof(buf));
     77a:	02000613          	li	a2,32
     77e:	fa040593          	addi	a1,s0,-96
     782:	8526                	mv	a0,s1
     784:	717040ef          	jal	569a <read>
     788:	8a2a                	mv	s4,a0
  if (n != 0) {
     78a:	e155                	bnez	a0,82e <truncate1+0x14e>
  write(fd1, "abcdef", 6);
     78c:	4619                	li	a2,6
     78e:	00005597          	auipc	a1,0x5
     792:	7fa58593          	addi	a1,a1,2042 # 5f88 <malloc+0x402>
     796:	854e                	mv	a0,s3
     798:	70b040ef          	jal	56a2 <write>
  n = read(fd3, buf, sizeof(buf));
     79c:	02000613          	li	a2,32
     7a0:	fa040593          	addi	a1,s0,-96
     7a4:	854a                	mv	a0,s2
     7a6:	6f5040ef          	jal	569a <read>
  if (n != 6) {
     7aa:	4799                	li	a5,6
     7ac:	0af51363          	bne	a0,a5,852 <truncate1+0x172>
  n = read(fd2, buf, sizeof(buf));
     7b0:	02000613          	li	a2,32
     7b4:	fa040593          	addi	a1,s0,-96
     7b8:	8526                	mv	a0,s1
     7ba:	6e1040ef          	jal	569a <read>
  if (n != 2) {
     7be:	4789                	li	a5,2
     7c0:	0af51463          	bne	a0,a5,868 <truncate1+0x188>
  unlink("truncfile");
     7c4:	00005517          	auipc	a0,0x5
     7c8:	54c50513          	addi	a0,a0,1356 # 5d10 <malloc+0x18a>
     7cc:	707040ef          	jal	56d2 <unlink>
  close(fd1);
     7d0:	854e                	mv	a0,s3
     7d2:	6d9040ef          	jal	56aa <close>
  close(fd2);
     7d6:	8526                	mv	a0,s1
     7d8:	6d3040ef          	jal	56aa <close>
  close(fd3);
     7dc:	854a                	mv	a0,s2
     7de:	6cd040ef          	jal	56aa <close>
}
     7e2:	60e6                	ld	ra,88(sp)
     7e4:	6446                	ld	s0,80(sp)
     7e6:	64a6                	ld	s1,72(sp)
     7e8:	6906                	ld	s2,64(sp)
     7ea:	79e2                	ld	s3,56(sp)
     7ec:	7a42                	ld	s4,48(sp)
     7ee:	7aa2                	ld	s5,40(sp)
     7f0:	6125                	addi	sp,sp,96
     7f2:	8082                	ret
    printf("%s: read %d bytes, wanted 4\n", s, n);
     7f4:	862a                	mv	a2,a0
     7f6:	85d6                	mv	a1,s5
     7f8:	00005517          	auipc	a0,0x5
     7fc:	73050513          	addi	a0,a0,1840 # 5f28 <malloc+0x3a2>
     800:	2d2050ef          	jal	5ad2 <printf>
    exit(1);
     804:	4505                	li	a0,1
     806:	67d040ef          	jal	5682 <exit>
    printf("aaa fd3=%d\n", fd3);
     80a:	85ca                	mv	a1,s2
     80c:	00005517          	auipc	a0,0x5
     810:	73c50513          	addi	a0,a0,1852 # 5f48 <malloc+0x3c2>
     814:	2be050ef          	jal	5ad2 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     818:	8652                	mv	a2,s4
     81a:	85d6                	mv	a1,s5
     81c:	00005517          	auipc	a0,0x5
     820:	73c50513          	addi	a0,a0,1852 # 5f58 <malloc+0x3d2>
     824:	2ae050ef          	jal	5ad2 <printf>
    exit(1);
     828:	4505                	li	a0,1
     82a:	659040ef          	jal	5682 <exit>
    printf("bbb fd2=%d\n", fd2);
     82e:	85a6                	mv	a1,s1
     830:	00005517          	auipc	a0,0x5
     834:	74850513          	addi	a0,a0,1864 # 5f78 <malloc+0x3f2>
     838:	29a050ef          	jal	5ad2 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     83c:	8652                	mv	a2,s4
     83e:	85d6                	mv	a1,s5
     840:	00005517          	auipc	a0,0x5
     844:	71850513          	addi	a0,a0,1816 # 5f58 <malloc+0x3d2>
     848:	28a050ef          	jal	5ad2 <printf>
    exit(1);
     84c:	4505                	li	a0,1
     84e:	635040ef          	jal	5682 <exit>
    printf("%s: read %d bytes, wanted 6\n", s, n);
     852:	862a                	mv	a2,a0
     854:	85d6                	mv	a1,s5
     856:	00005517          	auipc	a0,0x5
     85a:	73a50513          	addi	a0,a0,1850 # 5f90 <malloc+0x40a>
     85e:	274050ef          	jal	5ad2 <printf>
    exit(1);
     862:	4505                	li	a0,1
     864:	61f040ef          	jal	5682 <exit>
    printf("%s: read %d bytes, wanted 2\n", s, n);
     868:	862a                	mv	a2,a0
     86a:	85d6                	mv	a1,s5
     86c:	00005517          	auipc	a0,0x5
     870:	74450513          	addi	a0,a0,1860 # 5fb0 <malloc+0x42a>
     874:	25e050ef          	jal	5ad2 <printf>
    exit(1);
     878:	4505                	li	a0,1
     87a:	609040ef          	jal	5682 <exit>

000000000000087e <writetest>:
{
     87e:	7139                	addi	sp,sp,-64
     880:	fc06                	sd	ra,56(sp)
     882:	f822                	sd	s0,48(sp)
     884:	f426                	sd	s1,40(sp)
     886:	f04a                	sd	s2,32(sp)
     888:	ec4e                	sd	s3,24(sp)
     88a:	e852                	sd	s4,16(sp)
     88c:	e456                	sd	s5,8(sp)
     88e:	e05a                	sd	s6,0(sp)
     890:	0080                	addi	s0,sp,64
     892:	8b2a                	mv	s6,a0
  fd = open("small", O_CREATE | O_RDWR);
     894:	20200593          	li	a1,514
     898:	00005517          	auipc	a0,0x5
     89c:	73850513          	addi	a0,a0,1848 # 5fd0 <malloc+0x44a>
     8a0:	623040ef          	jal	56c2 <open>
  if (fd < 0) {
     8a4:	08054f63          	bltz	a0,942 <writetest+0xc4>
     8a8:	892a                	mv	s2,a0
     8aa:	4481                	li	s1,0
    if (write(fd, "aaaaaaaaaa", SZ) != SZ) {
     8ac:	00005997          	auipc	s3,0x5
     8b0:	74c98993          	addi	s3,s3,1868 # 5ff8 <malloc+0x472>
    if (write(fd, "bbbbbbbbbb", SZ) != SZ) {
     8b4:	00005a97          	auipc	s5,0x5
     8b8:	77ca8a93          	addi	s5,s5,1916 # 6030 <malloc+0x4aa>
  for (i = 0; i < N; i++) {
     8bc:	06400a13          	li	s4,100
    if (write(fd, "aaaaaaaaaa", SZ) != SZ) {
     8c0:	4629                	li	a2,10
     8c2:	85ce                	mv	a1,s3
     8c4:	854a                	mv	a0,s2
     8c6:	5dd040ef          	jal	56a2 <write>
     8ca:	47a9                	li	a5,10
     8cc:	08f51563          	bne	a0,a5,956 <writetest+0xd8>
    if (write(fd, "bbbbbbbbbb", SZ) != SZ) {
     8d0:	4629                	li	a2,10
     8d2:	85d6                	mv	a1,s5
     8d4:	854a                	mv	a0,s2
     8d6:	5cd040ef          	jal	56a2 <write>
     8da:	47a9                	li	a5,10
     8dc:	08f51863          	bne	a0,a5,96c <writetest+0xee>
  for (i = 0; i < N; i++) {
     8e0:	2485                	addiw	s1,s1,1
     8e2:	fd449fe3          	bne	s1,s4,8c0 <writetest+0x42>
  close(fd);
     8e6:	854a                	mv	a0,s2
     8e8:	5c3040ef          	jal	56aa <close>
  fd = open("small", O_RDONLY);
     8ec:	4581                	li	a1,0
     8ee:	00005517          	auipc	a0,0x5
     8f2:	6e250513          	addi	a0,a0,1762 # 5fd0 <malloc+0x44a>
     8f6:	5cd040ef          	jal	56c2 <open>
     8fa:	84aa                	mv	s1,a0
  if (fd < 0) {
     8fc:	08054363          	bltz	a0,982 <writetest+0x104>
  i = read(fd, buf, N * SZ * 2);
     900:	7d000613          	li	a2,2000
     904:	0000d597          	auipc	a1,0xd
     908:	40458593          	addi	a1,a1,1028 # dd08 <buf>
     90c:	58f040ef          	jal	569a <read>
  if (i != N * SZ * 2) {
     910:	7d000793          	li	a5,2000
     914:	08f51163          	bne	a0,a5,996 <writetest+0x118>
  close(fd);
     918:	8526                	mv	a0,s1
     91a:	591040ef          	jal	56aa <close>
  if (unlink("small") < 0) {
     91e:	00005517          	auipc	a0,0x5
     922:	6b250513          	addi	a0,a0,1714 # 5fd0 <malloc+0x44a>
     926:	5ad040ef          	jal	56d2 <unlink>
     92a:	08054063          	bltz	a0,9aa <writetest+0x12c>
}
     92e:	70e2                	ld	ra,56(sp)
     930:	7442                	ld	s0,48(sp)
     932:	74a2                	ld	s1,40(sp)
     934:	7902                	ld	s2,32(sp)
     936:	69e2                	ld	s3,24(sp)
     938:	6a42                	ld	s4,16(sp)
     93a:	6aa2                	ld	s5,8(sp)
     93c:	6b02                	ld	s6,0(sp)
     93e:	6121                	addi	sp,sp,64
     940:	8082                	ret
    printf("%s: error: creat small failed!\n", s);
     942:	85da                	mv	a1,s6
     944:	00005517          	auipc	a0,0x5
     948:	69450513          	addi	a0,a0,1684 # 5fd8 <malloc+0x452>
     94c:	186050ef          	jal	5ad2 <printf>
    exit(1);
     950:	4505                	li	a0,1
     952:	531040ef          	jal	5682 <exit>
      printf("%s: error: write aa %d new file failed\n", s, i);
     956:	8626                	mv	a2,s1
     958:	85da                	mv	a1,s6
     95a:	00005517          	auipc	a0,0x5
     95e:	6ae50513          	addi	a0,a0,1710 # 6008 <malloc+0x482>
     962:	170050ef          	jal	5ad2 <printf>
      exit(1);
     966:	4505                	li	a0,1
     968:	51b040ef          	jal	5682 <exit>
      printf("%s: error: write bb %d new file failed\n", s, i);
     96c:	8626                	mv	a2,s1
     96e:	85da                	mv	a1,s6
     970:	00005517          	auipc	a0,0x5
     974:	6d050513          	addi	a0,a0,1744 # 6040 <malloc+0x4ba>
     978:	15a050ef          	jal	5ad2 <printf>
      exit(1);
     97c:	4505                	li	a0,1
     97e:	505040ef          	jal	5682 <exit>
    printf("%s: error: open small failed!\n", s);
     982:	85da                	mv	a1,s6
     984:	00005517          	auipc	a0,0x5
     988:	6e450513          	addi	a0,a0,1764 # 6068 <malloc+0x4e2>
     98c:	146050ef          	jal	5ad2 <printf>
    exit(1);
     990:	4505                	li	a0,1
     992:	4f1040ef          	jal	5682 <exit>
    printf("%s: read failed\n", s);
     996:	85da                	mv	a1,s6
     998:	00005517          	auipc	a0,0x5
     99c:	6f050513          	addi	a0,a0,1776 # 6088 <malloc+0x502>
     9a0:	132050ef          	jal	5ad2 <printf>
    exit(1);
     9a4:	4505                	li	a0,1
     9a6:	4dd040ef          	jal	5682 <exit>
    printf("%s: unlink small failed\n", s);
     9aa:	85da                	mv	a1,s6
     9ac:	00005517          	auipc	a0,0x5
     9b0:	6f450513          	addi	a0,a0,1780 # 60a0 <malloc+0x51a>
     9b4:	11e050ef          	jal	5ad2 <printf>
    exit(1);
     9b8:	4505                	li	a0,1
     9ba:	4c9040ef          	jal	5682 <exit>

00000000000009be <writebig>:
{
     9be:	7139                	addi	sp,sp,-64
     9c0:	fc06                	sd	ra,56(sp)
     9c2:	f822                	sd	s0,48(sp)
     9c4:	f426                	sd	s1,40(sp)
     9c6:	f04a                	sd	s2,32(sp)
     9c8:	ec4e                	sd	s3,24(sp)
     9ca:	e852                	sd	s4,16(sp)
     9cc:	e456                	sd	s5,8(sp)
     9ce:	0080                	addi	s0,sp,64
     9d0:	8aaa                	mv	s5,a0
  fd = open("big", O_CREATE | O_RDWR);
     9d2:	20200593          	li	a1,514
     9d6:	00005517          	auipc	a0,0x5
     9da:	6ea50513          	addi	a0,a0,1770 # 60c0 <malloc+0x53a>
     9de:	4e5040ef          	jal	56c2 <open>
     9e2:	89aa                	mv	s3,a0
  for (i = 0; i < MAXFILE; i++) {
     9e4:	4481                	li	s1,0
    ((int *)buf)[0] = i;
     9e6:	0000d917          	auipc	s2,0xd
     9ea:	32290913          	addi	s2,s2,802 # dd08 <buf>
  for (i = 0; i < MAXFILE; i++) {
     9ee:	10c00a13          	li	s4,268
  if (fd < 0) {
     9f2:	06054463          	bltz	a0,a5a <writebig+0x9c>
    ((int *)buf)[0] = i;
     9f6:	00992023          	sw	s1,0(s2)
    if (write(fd, buf, BSIZE) != BSIZE) {
     9fa:	40000613          	li	a2,1024
     9fe:	85ca                	mv	a1,s2
     a00:	854e                	mv	a0,s3
     a02:	4a1040ef          	jal	56a2 <write>
     a06:	40000793          	li	a5,1024
     a0a:	06f51263          	bne	a0,a5,a6e <writebig+0xb0>
  for (i = 0; i < MAXFILE; i++) {
     a0e:	2485                	addiw	s1,s1,1
     a10:	ff4493e3          	bne	s1,s4,9f6 <writebig+0x38>
  close(fd);
     a14:	854e                	mv	a0,s3
     a16:	495040ef          	jal	56aa <close>
  fd = open("big", O_RDONLY);
     a1a:	4581                	li	a1,0
     a1c:	00005517          	auipc	a0,0x5
     a20:	6a450513          	addi	a0,a0,1700 # 60c0 <malloc+0x53a>
     a24:	49f040ef          	jal	56c2 <open>
     a28:	89aa                	mv	s3,a0
  n = 0;
     a2a:	4481                	li	s1,0
    i = read(fd, buf, BSIZE);
     a2c:	0000d917          	auipc	s2,0xd
     a30:	2dc90913          	addi	s2,s2,732 # dd08 <buf>
  if (fd < 0) {
     a34:	04054863          	bltz	a0,a84 <writebig+0xc6>
    i = read(fd, buf, BSIZE);
     a38:	40000613          	li	a2,1024
     a3c:	85ca                	mv	a1,s2
     a3e:	854e                	mv	a0,s3
     a40:	45b040ef          	jal	569a <read>
    if (i == 0) {
     a44:	c931                	beqz	a0,a98 <writebig+0xda>
    } else if (i != BSIZE) {
     a46:	40000793          	li	a5,1024
     a4a:	08f51a63          	bne	a0,a5,ade <writebig+0x120>
    if (((int *)buf)[0] != n) {
     a4e:	00092683          	lw	a3,0(s2)
     a52:	0a969163          	bne	a3,s1,af4 <writebig+0x136>
    n++;
     a56:	2485                	addiw	s1,s1,1
    i = read(fd, buf, BSIZE);
     a58:	b7c5                	j	a38 <writebig+0x7a>
    printf("%s: error: creat big failed!\n", s);
     a5a:	85d6                	mv	a1,s5
     a5c:	00005517          	auipc	a0,0x5
     a60:	66c50513          	addi	a0,a0,1644 # 60c8 <malloc+0x542>
     a64:	06e050ef          	jal	5ad2 <printf>
    exit(1);
     a68:	4505                	li	a0,1
     a6a:	419040ef          	jal	5682 <exit>
      printf("%s: error: write big file failed i=%d\n", s, i);
     a6e:	8626                	mv	a2,s1
     a70:	85d6                	mv	a1,s5
     a72:	00005517          	auipc	a0,0x5
     a76:	67650513          	addi	a0,a0,1654 # 60e8 <malloc+0x562>
     a7a:	058050ef          	jal	5ad2 <printf>
      exit(1);
     a7e:	4505                	li	a0,1
     a80:	403040ef          	jal	5682 <exit>
    printf("%s: error: open big failed!\n", s);
     a84:	85d6                	mv	a1,s5
     a86:	00005517          	auipc	a0,0x5
     a8a:	68a50513          	addi	a0,a0,1674 # 6110 <malloc+0x58a>
     a8e:	044050ef          	jal	5ad2 <printf>
    exit(1);
     a92:	4505                	li	a0,1
     a94:	3ef040ef          	jal	5682 <exit>
      if (n != MAXFILE) {
     a98:	10c00793          	li	a5,268
     a9c:	02f49663          	bne	s1,a5,ac8 <writebig+0x10a>
  close(fd);
     aa0:	854e                	mv	a0,s3
     aa2:	409040ef          	jal	56aa <close>
  if (unlink("big") < 0) {
     aa6:	00005517          	auipc	a0,0x5
     aaa:	61a50513          	addi	a0,a0,1562 # 60c0 <malloc+0x53a>
     aae:	425040ef          	jal	56d2 <unlink>
     ab2:	04054c63          	bltz	a0,b0a <writebig+0x14c>
}
     ab6:	70e2                	ld	ra,56(sp)
     ab8:	7442                	ld	s0,48(sp)
     aba:	74a2                	ld	s1,40(sp)
     abc:	7902                	ld	s2,32(sp)
     abe:	69e2                	ld	s3,24(sp)
     ac0:	6a42                	ld	s4,16(sp)
     ac2:	6aa2                	ld	s5,8(sp)
     ac4:	6121                	addi	sp,sp,64
     ac6:	8082                	ret
        printf("%s: read only %d blocks from big", s, n);
     ac8:	8626                	mv	a2,s1
     aca:	85d6                	mv	a1,s5
     acc:	00005517          	auipc	a0,0x5
     ad0:	66450513          	addi	a0,a0,1636 # 6130 <malloc+0x5aa>
     ad4:	7ff040ef          	jal	5ad2 <printf>
        exit(1);
     ad8:	4505                	li	a0,1
     ada:	3a9040ef          	jal	5682 <exit>
      printf("%s: read failed %d\n", s, i);
     ade:	862a                	mv	a2,a0
     ae0:	85d6                	mv	a1,s5
     ae2:	00005517          	auipc	a0,0x5
     ae6:	67650513          	addi	a0,a0,1654 # 6158 <malloc+0x5d2>
     aea:	7e9040ef          	jal	5ad2 <printf>
      exit(1);
     aee:	4505                	li	a0,1
     af0:	393040ef          	jal	5682 <exit>
      printf("%s: read content of block %d is %d\n", s, n, ((int *)buf)[0]);
     af4:	8626                	mv	a2,s1
     af6:	85d6                	mv	a1,s5
     af8:	00005517          	auipc	a0,0x5
     afc:	67850513          	addi	a0,a0,1656 # 6170 <malloc+0x5ea>
     b00:	7d3040ef          	jal	5ad2 <printf>
      exit(1);
     b04:	4505                	li	a0,1
     b06:	37d040ef          	jal	5682 <exit>
    printf("%s: unlink big failed\n", s);
     b0a:	85d6                	mv	a1,s5
     b0c:	00005517          	auipc	a0,0x5
     b10:	68c50513          	addi	a0,a0,1676 # 6198 <malloc+0x612>
     b14:	7bf040ef          	jal	5ad2 <printf>
    exit(1);
     b18:	4505                	li	a0,1
     b1a:	369040ef          	jal	5682 <exit>

0000000000000b1e <unlinkread>:
{
     b1e:	7179                	addi	sp,sp,-48
     b20:	f406                	sd	ra,40(sp)
     b22:	f022                	sd	s0,32(sp)
     b24:	ec26                	sd	s1,24(sp)
     b26:	e84a                	sd	s2,16(sp)
     b28:	e44e                	sd	s3,8(sp)
     b2a:	1800                	addi	s0,sp,48
     b2c:	89aa                	mv	s3,a0
  fd = open("unlinkread", O_CREATE | O_RDWR);
     b2e:	20200593          	li	a1,514
     b32:	00005517          	auipc	a0,0x5
     b36:	67e50513          	addi	a0,a0,1662 # 61b0 <malloc+0x62a>
     b3a:	389040ef          	jal	56c2 <open>
  if (fd < 0) {
     b3e:	0a054f63          	bltz	a0,bfc <unlinkread+0xde>
     b42:	84aa                	mv	s1,a0
  write(fd, "hello", SZ);
     b44:	4615                	li	a2,5
     b46:	00005597          	auipc	a1,0x5
     b4a:	69a58593          	addi	a1,a1,1690 # 61e0 <malloc+0x65a>
     b4e:	355040ef          	jal	56a2 <write>
  close(fd);
     b52:	8526                	mv	a0,s1
     b54:	357040ef          	jal	56aa <close>
  fd = open("unlinkread", O_RDWR);
     b58:	4589                	li	a1,2
     b5a:	00005517          	auipc	a0,0x5
     b5e:	65650513          	addi	a0,a0,1622 # 61b0 <malloc+0x62a>
     b62:	361040ef          	jal	56c2 <open>
     b66:	84aa                	mv	s1,a0
  if (fd < 0) {
     b68:	0a054463          	bltz	a0,c10 <unlinkread+0xf2>
  if (unlink("unlinkread") != 0) {
     b6c:	00005517          	auipc	a0,0x5
     b70:	64450513          	addi	a0,a0,1604 # 61b0 <malloc+0x62a>
     b74:	35f040ef          	jal	56d2 <unlink>
     b78:	e555                	bnez	a0,c24 <unlinkread+0x106>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
     b7a:	20200593          	li	a1,514
     b7e:	00005517          	auipc	a0,0x5
     b82:	63250513          	addi	a0,a0,1586 # 61b0 <malloc+0x62a>
     b86:	33d040ef          	jal	56c2 <open>
     b8a:	892a                	mv	s2,a0
  write(fd1, "yyy", 3);
     b8c:	460d                	li	a2,3
     b8e:	00005597          	auipc	a1,0x5
     b92:	69a58593          	addi	a1,a1,1690 # 6228 <malloc+0x6a2>
     b96:	30d040ef          	jal	56a2 <write>
  close(fd1);
     b9a:	854a                	mv	a0,s2
     b9c:	30f040ef          	jal	56aa <close>
  if (read(fd, buf, sizeof(buf)) != SZ) {
     ba0:	660d                	lui	a2,0x3
     ba2:	0000d597          	auipc	a1,0xd
     ba6:	16658593          	addi	a1,a1,358 # dd08 <buf>
     baa:	8526                	mv	a0,s1
     bac:	2ef040ef          	jal	569a <read>
     bb0:	4795                	li	a5,5
     bb2:	08f51363          	bne	a0,a5,c38 <unlinkread+0x11a>
  if (buf[0] != 'h') {
     bb6:	0000d717          	auipc	a4,0xd
     bba:	15274703          	lbu	a4,338(a4) # dd08 <buf>
     bbe:	06800793          	li	a5,104
     bc2:	08f71563          	bne	a4,a5,c4c <unlinkread+0x12e>
  if (write(fd, buf, 10) != 10) {
     bc6:	4629                	li	a2,10
     bc8:	0000d597          	auipc	a1,0xd
     bcc:	14058593          	addi	a1,a1,320 # dd08 <buf>
     bd0:	8526                	mv	a0,s1
     bd2:	2d1040ef          	jal	56a2 <write>
     bd6:	47a9                	li	a5,10
     bd8:	08f51463          	bne	a0,a5,c60 <unlinkread+0x142>
  close(fd);
     bdc:	8526                	mv	a0,s1
     bde:	2cd040ef          	jal	56aa <close>
  unlink("unlinkread");
     be2:	00005517          	auipc	a0,0x5
     be6:	5ce50513          	addi	a0,a0,1486 # 61b0 <malloc+0x62a>
     bea:	2e9040ef          	jal	56d2 <unlink>
}
     bee:	70a2                	ld	ra,40(sp)
     bf0:	7402                	ld	s0,32(sp)
     bf2:	64e2                	ld	s1,24(sp)
     bf4:	6942                	ld	s2,16(sp)
     bf6:	69a2                	ld	s3,8(sp)
     bf8:	6145                	addi	sp,sp,48
     bfa:	8082                	ret
    printf("%s: create unlinkread failed\n", s);
     bfc:	85ce                	mv	a1,s3
     bfe:	00005517          	auipc	a0,0x5
     c02:	5c250513          	addi	a0,a0,1474 # 61c0 <malloc+0x63a>
     c06:	6cd040ef          	jal	5ad2 <printf>
    exit(1);
     c0a:	4505                	li	a0,1
     c0c:	277040ef          	jal	5682 <exit>
    printf("%s: open unlinkread failed\n", s);
     c10:	85ce                	mv	a1,s3
     c12:	00005517          	auipc	a0,0x5
     c16:	5d650513          	addi	a0,a0,1494 # 61e8 <malloc+0x662>
     c1a:	6b9040ef          	jal	5ad2 <printf>
    exit(1);
     c1e:	4505                	li	a0,1
     c20:	263040ef          	jal	5682 <exit>
    printf("%s: unlink unlinkread failed\n", s);
     c24:	85ce                	mv	a1,s3
     c26:	00005517          	auipc	a0,0x5
     c2a:	5e250513          	addi	a0,a0,1506 # 6208 <malloc+0x682>
     c2e:	6a5040ef          	jal	5ad2 <printf>
    exit(1);
     c32:	4505                	li	a0,1
     c34:	24f040ef          	jal	5682 <exit>
    printf("%s: unlinkread read failed", s);
     c38:	85ce                	mv	a1,s3
     c3a:	00005517          	auipc	a0,0x5
     c3e:	5f650513          	addi	a0,a0,1526 # 6230 <malloc+0x6aa>
     c42:	691040ef          	jal	5ad2 <printf>
    exit(1);
     c46:	4505                	li	a0,1
     c48:	23b040ef          	jal	5682 <exit>
    printf("%s: unlinkread wrong data\n", s);
     c4c:	85ce                	mv	a1,s3
     c4e:	00005517          	auipc	a0,0x5
     c52:	60250513          	addi	a0,a0,1538 # 6250 <malloc+0x6ca>
     c56:	67d040ef          	jal	5ad2 <printf>
    exit(1);
     c5a:	4505                	li	a0,1
     c5c:	227040ef          	jal	5682 <exit>
    printf("%s: unlinkread write failed\n", s);
     c60:	85ce                	mv	a1,s3
     c62:	00005517          	auipc	a0,0x5
     c66:	60e50513          	addi	a0,a0,1550 # 6270 <malloc+0x6ea>
     c6a:	669040ef          	jal	5ad2 <printf>
    exit(1);
     c6e:	4505                	li	a0,1
     c70:	213040ef          	jal	5682 <exit>

0000000000000c74 <linktest>:
{
     c74:	1101                	addi	sp,sp,-32
     c76:	ec06                	sd	ra,24(sp)
     c78:	e822                	sd	s0,16(sp)
     c7a:	e426                	sd	s1,8(sp)
     c7c:	e04a                	sd	s2,0(sp)
     c7e:	1000                	addi	s0,sp,32
     c80:	892a                	mv	s2,a0
  unlink("lf1");
     c82:	00005517          	auipc	a0,0x5
     c86:	60e50513          	addi	a0,a0,1550 # 6290 <malloc+0x70a>
     c8a:	249040ef          	jal	56d2 <unlink>
  unlink("lf2");
     c8e:	00005517          	auipc	a0,0x5
     c92:	60a50513          	addi	a0,a0,1546 # 6298 <malloc+0x712>
     c96:	23d040ef          	jal	56d2 <unlink>
  fd = open("lf1", O_CREATE | O_RDWR);
     c9a:	20200593          	li	a1,514
     c9e:	00005517          	auipc	a0,0x5
     ca2:	5f250513          	addi	a0,a0,1522 # 6290 <malloc+0x70a>
     ca6:	21d040ef          	jal	56c2 <open>
  if (fd < 0) {
     caa:	0c054f63          	bltz	a0,d88 <linktest+0x114>
     cae:	84aa                	mv	s1,a0
  if (write(fd, "hello", SZ) != SZ) {
     cb0:	4615                	li	a2,5
     cb2:	00005597          	auipc	a1,0x5
     cb6:	52e58593          	addi	a1,a1,1326 # 61e0 <malloc+0x65a>
     cba:	1e9040ef          	jal	56a2 <write>
     cbe:	4795                	li	a5,5
     cc0:	0cf51e63          	bne	a0,a5,d9c <linktest+0x128>
  close(fd);
     cc4:	8526                	mv	a0,s1
     cc6:	1e5040ef          	jal	56aa <close>
  if (link("lf1", "lf2") < 0) {
     cca:	00005597          	auipc	a1,0x5
     cce:	5ce58593          	addi	a1,a1,1486 # 6298 <malloc+0x712>
     cd2:	00005517          	auipc	a0,0x5
     cd6:	5be50513          	addi	a0,a0,1470 # 6290 <malloc+0x70a>
     cda:	209040ef          	jal	56e2 <link>
     cde:	0c054963          	bltz	a0,db0 <linktest+0x13c>
  unlink("lf1");
     ce2:	00005517          	auipc	a0,0x5
     ce6:	5ae50513          	addi	a0,a0,1454 # 6290 <malloc+0x70a>
     cea:	1e9040ef          	jal	56d2 <unlink>
  if (open("lf1", 0) >= 0) {
     cee:	4581                	li	a1,0
     cf0:	00005517          	auipc	a0,0x5
     cf4:	5a050513          	addi	a0,a0,1440 # 6290 <malloc+0x70a>
     cf8:	1cb040ef          	jal	56c2 <open>
     cfc:	0c055463          	bgez	a0,dc4 <linktest+0x150>
  fd = open("lf2", 0);
     d00:	4581                	li	a1,0
     d02:	00005517          	auipc	a0,0x5
     d06:	59650513          	addi	a0,a0,1430 # 6298 <malloc+0x712>
     d0a:	1b9040ef          	jal	56c2 <open>
     d0e:	84aa                	mv	s1,a0
  if (fd < 0) {
     d10:	0c054463          	bltz	a0,dd8 <linktest+0x164>
  if (read(fd, buf, sizeof(buf)) != SZ) {
     d14:	660d                	lui	a2,0x3
     d16:	0000d597          	auipc	a1,0xd
     d1a:	ff258593          	addi	a1,a1,-14 # dd08 <buf>
     d1e:	17d040ef          	jal	569a <read>
     d22:	4795                	li	a5,5
     d24:	0cf51463          	bne	a0,a5,dec <linktest+0x178>
  close(fd);
     d28:	8526                	mv	a0,s1
     d2a:	181040ef          	jal	56aa <close>
  if (link("lf2", "lf2") >= 0) {
     d2e:	00005597          	auipc	a1,0x5
     d32:	56a58593          	addi	a1,a1,1386 # 6298 <malloc+0x712>
     d36:	852e                	mv	a0,a1
     d38:	1ab040ef          	jal	56e2 <link>
     d3c:	0c055263          	bgez	a0,e00 <linktest+0x18c>
  unlink("lf2");
     d40:	00005517          	auipc	a0,0x5
     d44:	55850513          	addi	a0,a0,1368 # 6298 <malloc+0x712>
     d48:	18b040ef          	jal	56d2 <unlink>
  if (link("lf2", "lf1") >= 0) {
     d4c:	00005597          	auipc	a1,0x5
     d50:	54458593          	addi	a1,a1,1348 # 6290 <malloc+0x70a>
     d54:	00005517          	auipc	a0,0x5
     d58:	54450513          	addi	a0,a0,1348 # 6298 <malloc+0x712>
     d5c:	187040ef          	jal	56e2 <link>
     d60:	0a055a63          	bgez	a0,e14 <linktest+0x1a0>
  if (link(".", "lf1") >= 0) {
     d64:	00005597          	auipc	a1,0x5
     d68:	52c58593          	addi	a1,a1,1324 # 6290 <malloc+0x70a>
     d6c:	00005517          	auipc	a0,0x5
     d70:	63450513          	addi	a0,a0,1588 # 63a0 <malloc+0x81a>
     d74:	16f040ef          	jal	56e2 <link>
     d78:	0a055863          	bgez	a0,e28 <linktest+0x1b4>
}
     d7c:	60e2                	ld	ra,24(sp)
     d7e:	6442                	ld	s0,16(sp)
     d80:	64a2                	ld	s1,8(sp)
     d82:	6902                	ld	s2,0(sp)
     d84:	6105                	addi	sp,sp,32
     d86:	8082                	ret
    printf("%s: create lf1 failed\n", s);
     d88:	85ca                	mv	a1,s2
     d8a:	00005517          	auipc	a0,0x5
     d8e:	51650513          	addi	a0,a0,1302 # 62a0 <malloc+0x71a>
     d92:	541040ef          	jal	5ad2 <printf>
    exit(1);
     d96:	4505                	li	a0,1
     d98:	0eb040ef          	jal	5682 <exit>
    printf("%s: write lf1 failed\n", s);
     d9c:	85ca                	mv	a1,s2
     d9e:	00005517          	auipc	a0,0x5
     da2:	51a50513          	addi	a0,a0,1306 # 62b8 <malloc+0x732>
     da6:	52d040ef          	jal	5ad2 <printf>
    exit(1);
     daa:	4505                	li	a0,1
     dac:	0d7040ef          	jal	5682 <exit>
    printf("%s: link lf1 lf2 failed\n", s);
     db0:	85ca                	mv	a1,s2
     db2:	00005517          	auipc	a0,0x5
     db6:	51e50513          	addi	a0,a0,1310 # 62d0 <malloc+0x74a>
     dba:	519040ef          	jal	5ad2 <printf>
    exit(1);
     dbe:	4505                	li	a0,1
     dc0:	0c3040ef          	jal	5682 <exit>
    printf("%s: unlinked lf1 but it is still there!\n", s);
     dc4:	85ca                	mv	a1,s2
     dc6:	00005517          	auipc	a0,0x5
     dca:	52a50513          	addi	a0,a0,1322 # 62f0 <malloc+0x76a>
     dce:	505040ef          	jal	5ad2 <printf>
    exit(1);
     dd2:	4505                	li	a0,1
     dd4:	0af040ef          	jal	5682 <exit>
    printf("%s: open lf2 failed\n", s);
     dd8:	85ca                	mv	a1,s2
     dda:	00005517          	auipc	a0,0x5
     dde:	54650513          	addi	a0,a0,1350 # 6320 <malloc+0x79a>
     de2:	4f1040ef          	jal	5ad2 <printf>
    exit(1);
     de6:	4505                	li	a0,1
     de8:	09b040ef          	jal	5682 <exit>
    printf("%s: read lf2 failed\n", s);
     dec:	85ca                	mv	a1,s2
     dee:	00005517          	auipc	a0,0x5
     df2:	54a50513          	addi	a0,a0,1354 # 6338 <malloc+0x7b2>
     df6:	4dd040ef          	jal	5ad2 <printf>
    exit(1);
     dfa:	4505                	li	a0,1
     dfc:	087040ef          	jal	5682 <exit>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
     e00:	85ca                	mv	a1,s2
     e02:	00005517          	auipc	a0,0x5
     e06:	54e50513          	addi	a0,a0,1358 # 6350 <malloc+0x7ca>
     e0a:	4c9040ef          	jal	5ad2 <printf>
    exit(1);
     e0e:	4505                	li	a0,1
     e10:	073040ef          	jal	5682 <exit>
    printf("%s: link non-existent succeeded! oops\n", s);
     e14:	85ca                	mv	a1,s2
     e16:	00005517          	auipc	a0,0x5
     e1a:	56250513          	addi	a0,a0,1378 # 6378 <malloc+0x7f2>
     e1e:	4b5040ef          	jal	5ad2 <printf>
    exit(1);
     e22:	4505                	li	a0,1
     e24:	05f040ef          	jal	5682 <exit>
    printf("%s: link . lf1 succeeded! oops\n", s);
     e28:	85ca                	mv	a1,s2
     e2a:	00005517          	auipc	a0,0x5
     e2e:	57e50513          	addi	a0,a0,1406 # 63a8 <malloc+0x822>
     e32:	4a1040ef          	jal	5ad2 <printf>
    exit(1);
     e36:	4505                	li	a0,1
     e38:	04b040ef          	jal	5682 <exit>

0000000000000e3c <validatetest>:
{
     e3c:	7139                	addi	sp,sp,-64
     e3e:	fc06                	sd	ra,56(sp)
     e40:	f822                	sd	s0,48(sp)
     e42:	f426                	sd	s1,40(sp)
     e44:	f04a                	sd	s2,32(sp)
     e46:	ec4e                	sd	s3,24(sp)
     e48:	e852                	sd	s4,16(sp)
     e4a:	e456                	sd	s5,8(sp)
     e4c:	e05a                	sd	s6,0(sp)
     e4e:	0080                	addi	s0,sp,64
     e50:	8b2a                	mv	s6,a0
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     e52:	4481                	li	s1,0
    if (link("nosuchfile", (char *)p) != -1) {
     e54:	00005997          	auipc	s3,0x5
     e58:	57498993          	addi	s3,s3,1396 # 63c8 <malloc+0x842>
     e5c:	597d                	li	s2,-1
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     e5e:	6a85                	lui	s5,0x1
     e60:	00114a37          	lui	s4,0x114
    if (link("nosuchfile", (char *)p) != -1) {
     e64:	85a6                	mv	a1,s1
     e66:	854e                	mv	a0,s3
     e68:	07b040ef          	jal	56e2 <link>
     e6c:	01251f63          	bne	a0,s2,e8a <validatetest+0x4e>
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     e70:	94d6                	add	s1,s1,s5
     e72:	ff4499e3          	bne	s1,s4,e64 <validatetest+0x28>
}
     e76:	70e2                	ld	ra,56(sp)
     e78:	7442                	ld	s0,48(sp)
     e7a:	74a2                	ld	s1,40(sp)
     e7c:	7902                	ld	s2,32(sp)
     e7e:	69e2                	ld	s3,24(sp)
     e80:	6a42                	ld	s4,16(sp)
     e82:	6aa2                	ld	s5,8(sp)
     e84:	6b02                	ld	s6,0(sp)
     e86:	6121                	addi	sp,sp,64
     e88:	8082                	ret
      printf("%s: link should not succeed\n", s);
     e8a:	85da                	mv	a1,s6
     e8c:	00005517          	auipc	a0,0x5
     e90:	54c50513          	addi	a0,a0,1356 # 63d8 <malloc+0x852>
     e94:	43f040ef          	jal	5ad2 <printf>
      exit(1);
     e98:	4505                	li	a0,1
     e9a:	7e8040ef          	jal	5682 <exit>

0000000000000e9e <bigdir>:
{
     e9e:	715d                	addi	sp,sp,-80
     ea0:	e486                	sd	ra,72(sp)
     ea2:	e0a2                	sd	s0,64(sp)
     ea4:	fc26                	sd	s1,56(sp)
     ea6:	f84a                	sd	s2,48(sp)
     ea8:	f44e                	sd	s3,40(sp)
     eaa:	f052                	sd	s4,32(sp)
     eac:	ec56                	sd	s5,24(sp)
     eae:	e85a                	sd	s6,16(sp)
     eb0:	0880                	addi	s0,sp,80
     eb2:	89aa                	mv	s3,a0
  unlink("bd");
     eb4:	00005517          	auipc	a0,0x5
     eb8:	54450513          	addi	a0,a0,1348 # 63f8 <malloc+0x872>
     ebc:	017040ef          	jal	56d2 <unlink>
  fd = open("bd", O_CREATE);
     ec0:	20000593          	li	a1,512
     ec4:	00005517          	auipc	a0,0x5
     ec8:	53450513          	addi	a0,a0,1332 # 63f8 <malloc+0x872>
     ecc:	7f6040ef          	jal	56c2 <open>
  if (fd < 0) {
     ed0:	0c054163          	bltz	a0,f92 <bigdir+0xf4>
  close(fd);
     ed4:	7d6040ef          	jal	56aa <close>
  for (i = 0; i < N; i++) {
     ed8:	4901                	li	s2,0
    name[0] = 'x';
     eda:	07800a93          	li	s5,120
    if (link("bd", name) != 0) {
     ede:	00005a17          	auipc	s4,0x5
     ee2:	51aa0a13          	addi	s4,s4,1306 # 63f8 <malloc+0x872>
  for (i = 0; i < N; i++) {
     ee6:	1f400b13          	li	s6,500
    name[0] = 'x';
     eea:	fb540823          	sb	s5,-80(s0)
    name[1] = '0' + (i / 64);
     eee:	41f9571b          	sraiw	a4,s2,0x1f
     ef2:	01a7571b          	srliw	a4,a4,0x1a
     ef6:	012707bb          	addw	a5,a4,s2
     efa:	4067d69b          	sraiw	a3,a5,0x6
     efe:	0306869b          	addiw	a3,a3,48
     f02:	fad408a3          	sb	a3,-79(s0)
    name[2] = '0' + (i % 64);
     f06:	03f7f793          	andi	a5,a5,63
     f0a:	9f99                	subw	a5,a5,a4
     f0c:	0307879b          	addiw	a5,a5,48
     f10:	faf40923          	sb	a5,-78(s0)
    name[3] = '\0';
     f14:	fa0409a3          	sb	zero,-77(s0)
    if (link("bd", name) != 0) {
     f18:	fb040593          	addi	a1,s0,-80
     f1c:	8552                	mv	a0,s4
     f1e:	7c4040ef          	jal	56e2 <link>
     f22:	84aa                	mv	s1,a0
     f24:	e149                	bnez	a0,fa6 <bigdir+0x108>
  for (i = 0; i < N; i++) {
     f26:	2905                	addiw	s2,s2,1
     f28:	fd6911e3          	bne	s2,s6,eea <bigdir+0x4c>
  unlink("bd");
     f2c:	00005517          	auipc	a0,0x5
     f30:	4cc50513          	addi	a0,a0,1228 # 63f8 <malloc+0x872>
     f34:	79e040ef          	jal	56d2 <unlink>
    name[0] = 'x';
     f38:	07800913          	li	s2,120
  for (i = 0; i < N; i++) {
     f3c:	1f400a13          	li	s4,500
    name[0] = 'x';
     f40:	fb240823          	sb	s2,-80(s0)
    name[1] = '0' + (i / 64);
     f44:	41f4d71b          	sraiw	a4,s1,0x1f
     f48:	01a7571b          	srliw	a4,a4,0x1a
     f4c:	009707bb          	addw	a5,a4,s1
     f50:	4067d69b          	sraiw	a3,a5,0x6
     f54:	0306869b          	addiw	a3,a3,48
     f58:	fad408a3          	sb	a3,-79(s0)
    name[2] = '0' + (i % 64);
     f5c:	03f7f793          	andi	a5,a5,63
     f60:	9f99                	subw	a5,a5,a4
     f62:	0307879b          	addiw	a5,a5,48
     f66:	faf40923          	sb	a5,-78(s0)
    name[3] = '\0';
     f6a:	fa0409a3          	sb	zero,-77(s0)
    if (unlink(name) != 0) {
     f6e:	fb040513          	addi	a0,s0,-80
     f72:	760040ef          	jal	56d2 <unlink>
     f76:	e529                	bnez	a0,fc0 <bigdir+0x122>
  for (i = 0; i < N; i++) {
     f78:	2485                	addiw	s1,s1,1
     f7a:	fd4493e3          	bne	s1,s4,f40 <bigdir+0xa2>
}
     f7e:	60a6                	ld	ra,72(sp)
     f80:	6406                	ld	s0,64(sp)
     f82:	74e2                	ld	s1,56(sp)
     f84:	7942                	ld	s2,48(sp)
     f86:	79a2                	ld	s3,40(sp)
     f88:	7a02                	ld	s4,32(sp)
     f8a:	6ae2                	ld	s5,24(sp)
     f8c:	6b42                	ld	s6,16(sp)
     f8e:	6161                	addi	sp,sp,80
     f90:	8082                	ret
    printf("%s: bigdir create failed\n", s);
     f92:	85ce                	mv	a1,s3
     f94:	00005517          	auipc	a0,0x5
     f98:	46c50513          	addi	a0,a0,1132 # 6400 <malloc+0x87a>
     f9c:	337040ef          	jal	5ad2 <printf>
    exit(1);
     fa0:	4505                	li	a0,1
     fa2:	6e0040ef          	jal	5682 <exit>
      printf("%s: bigdir i=%d link(bd, %s) failed\n", s, i, name);
     fa6:	fb040693          	addi	a3,s0,-80
     faa:	864a                	mv	a2,s2
     fac:	85ce                	mv	a1,s3
     fae:	00005517          	auipc	a0,0x5
     fb2:	47250513          	addi	a0,a0,1138 # 6420 <malloc+0x89a>
     fb6:	31d040ef          	jal	5ad2 <printf>
      exit(1);
     fba:	4505                	li	a0,1
     fbc:	6c6040ef          	jal	5682 <exit>
      printf("%s: bigdir unlink failed", s);
     fc0:	85ce                	mv	a1,s3
     fc2:	00005517          	auipc	a0,0x5
     fc6:	48650513          	addi	a0,a0,1158 # 6448 <malloc+0x8c2>
     fca:	309040ef          	jal	5ad2 <printf>
      exit(1);
     fce:	4505                	li	a0,1
     fd0:	6b2040ef          	jal	5682 <exit>

0000000000000fd4 <pgbug>:
{
     fd4:	7179                	addi	sp,sp,-48
     fd6:	f406                	sd	ra,40(sp)
     fd8:	f022                	sd	s0,32(sp)
     fda:	ec26                	sd	s1,24(sp)
     fdc:	1800                	addi	s0,sp,48
  argv[0] = 0;
     fde:	fc043c23          	sd	zero,-40(s0)
  exec(big, argv);
     fe2:	00009497          	auipc	s1,0x9
     fe6:	01e48493          	addi	s1,s1,30 # a000 <big>
     fea:	fd840593          	addi	a1,s0,-40
     fee:	6088                	ld	a0,0(s1)
     ff0:	6ca040ef          	jal	56ba <exec>
  pipe(big);
     ff4:	6088                	ld	a0,0(s1)
     ff6:	69c040ef          	jal	5692 <pipe>
  exit(0);
     ffa:	4501                	li	a0,0
     ffc:	686040ef          	jal	5682 <exit>

0000000000001000 <badarg>:
{
    1000:	7139                	addi	sp,sp,-64
    1002:	fc06                	sd	ra,56(sp)
    1004:	f822                	sd	s0,48(sp)
    1006:	f426                	sd	s1,40(sp)
    1008:	f04a                	sd	s2,32(sp)
    100a:	ec4e                	sd	s3,24(sp)
    100c:	0080                	addi	s0,sp,64
    100e:	64b1                	lui	s1,0xc
    1010:	35048493          	addi	s1,s1,848 # c350 <uninit+0xd58>
    argv[0] = (char *)0xffffffff;
    1014:	597d                	li	s2,-1
    1016:	02095913          	srli	s2,s2,0x20
    exec("echo", argv);
    101a:	00005997          	auipc	s3,0x5
    101e:	c9e98993          	addi	s3,s3,-866 # 5cb8 <malloc+0x132>
    argv[0] = (char *)0xffffffff;
    1022:	fd243023          	sd	s2,-64(s0)
    argv[1] = 0;
    1026:	fc043423          	sd	zero,-56(s0)
    exec("echo", argv);
    102a:	fc040593          	addi	a1,s0,-64
    102e:	854e                	mv	a0,s3
    1030:	68a040ef          	jal	56ba <exec>
  for (int i = 0; i < 50000; i++) {
    1034:	34fd                	addiw	s1,s1,-1
    1036:	f4f5                	bnez	s1,1022 <badarg+0x22>
  exit(0);
    1038:	4501                	li	a0,0
    103a:	648040ef          	jal	5682 <exit>

000000000000103e <copyinstr2>:
{
    103e:	7155                	addi	sp,sp,-208
    1040:	e586                	sd	ra,200(sp)
    1042:	e1a2                	sd	s0,192(sp)
    1044:	0980                	addi	s0,sp,208
  for (int i = 0; i < MAXPATH; i++)
    1046:	f6840793          	addi	a5,s0,-152
    104a:	fe840693          	addi	a3,s0,-24
    b[i] = 'x';
    104e:	07800713          	li	a4,120
    1052:	00e78023          	sb	a4,0(a5)
  for (int i = 0; i < MAXPATH; i++)
    1056:	0785                	addi	a5,a5,1
    1058:	fed79de3          	bne	a5,a3,1052 <copyinstr2+0x14>
  b[MAXPATH] = '\0';
    105c:	fe040423          	sb	zero,-24(s0)
  int ret = unlink(b);
    1060:	f6840513          	addi	a0,s0,-152
    1064:	66e040ef          	jal	56d2 <unlink>
  if (ret != -1) {
    1068:	57fd                	li	a5,-1
    106a:	0cf51263          	bne	a0,a5,112e <copyinstr2+0xf0>
  int fd = open(b, O_CREATE | O_WRONLY);
    106e:	20100593          	li	a1,513
    1072:	f6840513          	addi	a0,s0,-152
    1076:	64c040ef          	jal	56c2 <open>
  if (fd != -1) {
    107a:	57fd                	li	a5,-1
    107c:	0cf51563          	bne	a0,a5,1146 <copyinstr2+0x108>
  ret = link(b, b);
    1080:	f6840593          	addi	a1,s0,-152
    1084:	852e                	mv	a0,a1
    1086:	65c040ef          	jal	56e2 <link>
  if (ret != -1) {
    108a:	57fd                	li	a5,-1
    108c:	0cf51963          	bne	a0,a5,115e <copyinstr2+0x120>
  char *args[] = {"xx", 0};
    1090:	00006797          	auipc	a5,0x6
    1094:	4a078793          	addi	a5,a5,1184 # 7530 <malloc+0x19aa>
    1098:	f4f43c23          	sd	a5,-168(s0)
    109c:	f6043023          	sd	zero,-160(s0)
  ret = exec(b, args);
    10a0:	f5840593          	addi	a1,s0,-168
    10a4:	f6840513          	addi	a0,s0,-152
    10a8:	612040ef          	jal	56ba <exec>
  if (ret != -1) {
    10ac:	57fd                	li	a5,-1
    10ae:	0cf51563          	bne	a0,a5,1178 <copyinstr2+0x13a>
  int pid = fork();
    10b2:	5c8040ef          	jal	567a <fork>
  if (pid < 0) {
    10b6:	0c054d63          	bltz	a0,1190 <copyinstr2+0x152>
  if (pid == 0) {
    10ba:	0e051863          	bnez	a0,11aa <copyinstr2+0x16c>
    10be:	00009797          	auipc	a5,0x9
    10c2:	53278793          	addi	a5,a5,1330 # a5f0 <big.0>
    10c6:	0000a697          	auipc	a3,0xa
    10ca:	52a68693          	addi	a3,a3,1322 # b5f0 <big.0+0x1000>
      big[i] = 'x';
    10ce:	07800713          	li	a4,120
    10d2:	00e78023          	sb	a4,0(a5)
    for (int i = 0; i < PGSIZE; i++)
    10d6:	0785                	addi	a5,a5,1
    10d8:	fed79de3          	bne	a5,a3,10d2 <copyinstr2+0x94>
    big[PGSIZE] = '\0';
    10dc:	0000a797          	auipc	a5,0xa
    10e0:	50078a23          	sb	zero,1300(a5) # b5f0 <big.0+0x1000>
    char *args2[] = {big, big, big, 0};
    10e4:	00007797          	auipc	a5,0x7
    10e8:	58c78793          	addi	a5,a5,1420 # 8670 <malloc+0x2aea>
    10ec:	6fb0                	ld	a2,88(a5)
    10ee:	73b4                	ld	a3,96(a5)
    10f0:	77b8                	ld	a4,104(a5)
    10f2:	7bbc                	ld	a5,112(a5)
    10f4:	f2c43823          	sd	a2,-208(s0)
    10f8:	f2d43c23          	sd	a3,-200(s0)
    10fc:	f4e43023          	sd	a4,-192(s0)
    1100:	f4f43423          	sd	a5,-184(s0)
    ret = exec("echo", args2);
    1104:	f3040593          	addi	a1,s0,-208
    1108:	00005517          	auipc	a0,0x5
    110c:	bb050513          	addi	a0,a0,-1104 # 5cb8 <malloc+0x132>
    1110:	5aa040ef          	jal	56ba <exec>
    if (ret != -1) {
    1114:	57fd                	li	a5,-1
    1116:	08f50663          	beq	a0,a5,11a2 <copyinstr2+0x164>
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
    111a:	55fd                	li	a1,-1
    111c:	00005517          	auipc	a0,0x5
    1120:	3d450513          	addi	a0,a0,980 # 64f0 <malloc+0x96a>
    1124:	1af040ef          	jal	5ad2 <printf>
      exit(1);
    1128:	4505                	li	a0,1
    112a:	558040ef          	jal	5682 <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    112e:	862a                	mv	a2,a0
    1130:	f6840593          	addi	a1,s0,-152
    1134:	00005517          	auipc	a0,0x5
    1138:	33450513          	addi	a0,a0,820 # 6468 <malloc+0x8e2>
    113c:	197040ef          	jal	5ad2 <printf>
    exit(1);
    1140:	4505                	li	a0,1
    1142:	540040ef          	jal	5682 <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    1146:	862a                	mv	a2,a0
    1148:	f6840593          	addi	a1,s0,-152
    114c:	00005517          	auipc	a0,0x5
    1150:	33c50513          	addi	a0,a0,828 # 6488 <malloc+0x902>
    1154:	17f040ef          	jal	5ad2 <printf>
    exit(1);
    1158:	4505                	li	a0,1
    115a:	528040ef          	jal	5682 <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    115e:	86aa                	mv	a3,a0
    1160:	f6840613          	addi	a2,s0,-152
    1164:	85b2                	mv	a1,a2
    1166:	00005517          	auipc	a0,0x5
    116a:	34250513          	addi	a0,a0,834 # 64a8 <malloc+0x922>
    116e:	165040ef          	jal	5ad2 <printf>
    exit(1);
    1172:	4505                	li	a0,1
    1174:	50e040ef          	jal	5682 <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    1178:	567d                	li	a2,-1
    117a:	f6840593          	addi	a1,s0,-152
    117e:	00005517          	auipc	a0,0x5
    1182:	35250513          	addi	a0,a0,850 # 64d0 <malloc+0x94a>
    1186:	14d040ef          	jal	5ad2 <printf>
    exit(1);
    118a:	4505                	li	a0,1
    118c:	4f6040ef          	jal	5682 <exit>
    printf("fork failed\n");
    1190:	00007517          	auipc	a0,0x7
    1194:	b3850513          	addi	a0,a0,-1224 # 7cc8 <malloc+0x2142>
    1198:	13b040ef          	jal	5ad2 <printf>
    exit(1);
    119c:	4505                	li	a0,1
    119e:	4e4040ef          	jal	5682 <exit>
    exit(747); // OK
    11a2:	2eb00513          	li	a0,747
    11a6:	4dc040ef          	jal	5682 <exit>
  int st = 0;
    11aa:	f4042a23          	sw	zero,-172(s0)
  wait(&st);
    11ae:	f5440513          	addi	a0,s0,-172
    11b2:	4d8040ef          	jal	568a <wait>
  if (st != 747) {
    11b6:	f5442703          	lw	a4,-172(s0)
    11ba:	2eb00793          	li	a5,747
    11be:	00f71663          	bne	a4,a5,11ca <copyinstr2+0x18c>
}
    11c2:	60ae                	ld	ra,200(sp)
    11c4:	640e                	ld	s0,192(sp)
    11c6:	6169                	addi	sp,sp,208
    11c8:	8082                	ret
    printf("exec(echo, BIG) succeeded, should have failed\n");
    11ca:	00005517          	auipc	a0,0x5
    11ce:	34e50513          	addi	a0,a0,846 # 6518 <malloc+0x992>
    11d2:	101040ef          	jal	5ad2 <printf>
    exit(1);
    11d6:	4505                	li	a0,1
    11d8:	4aa040ef          	jal	5682 <exit>

00000000000011dc <truncate3>:
{
    11dc:	7159                	addi	sp,sp,-112
    11de:	f486                	sd	ra,104(sp)
    11e0:	f0a2                	sd	s0,96(sp)
    11e2:	e8ca                	sd	s2,80(sp)
    11e4:	1880                	addi	s0,sp,112
    11e6:	892a                	mv	s2,a0
  close(open("truncfile", O_CREATE | O_TRUNC | O_WRONLY));
    11e8:	60100593          	li	a1,1537
    11ec:	00005517          	auipc	a0,0x5
    11f0:	b2450513          	addi	a0,a0,-1244 # 5d10 <malloc+0x18a>
    11f4:	4ce040ef          	jal	56c2 <open>
    11f8:	4b2040ef          	jal	56aa <close>
  pid = fork();
    11fc:	47e040ef          	jal	567a <fork>
  if (pid < 0) {
    1200:	06054663          	bltz	a0,126c <truncate3+0x90>
  if (pid == 0) {
    1204:	e55d                	bnez	a0,12b2 <truncate3+0xd6>
    1206:	eca6                	sd	s1,88(sp)
    1208:	e4ce                	sd	s3,72(sp)
    120a:	e0d2                	sd	s4,64(sp)
    120c:	fc56                	sd	s5,56(sp)
    120e:	06400993          	li	s3,100
      int fd = open("truncfile", O_WRONLY);
    1212:	00005a17          	auipc	s4,0x5
    1216:	afea0a13          	addi	s4,s4,-1282 # 5d10 <malloc+0x18a>
      int n = write(fd, "1234567890", 10);
    121a:	00005a97          	auipc	s5,0x5
    121e:	35ea8a93          	addi	s5,s5,862 # 6578 <malloc+0x9f2>
      int fd = open("truncfile", O_WRONLY);
    1222:	4585                	li	a1,1
    1224:	8552                	mv	a0,s4
    1226:	49c040ef          	jal	56c2 <open>
    122a:	84aa                	mv	s1,a0
      if (fd < 0) {
    122c:	04054e63          	bltz	a0,1288 <truncate3+0xac>
      int n = write(fd, "1234567890", 10);
    1230:	4629                	li	a2,10
    1232:	85d6                	mv	a1,s5
    1234:	46e040ef          	jal	56a2 <write>
      if (n != 10) {
    1238:	47a9                	li	a5,10
    123a:	06f51163          	bne	a0,a5,129c <truncate3+0xc0>
      close(fd);
    123e:	8526                	mv	a0,s1
    1240:	46a040ef          	jal	56aa <close>
      fd = open("truncfile", O_RDONLY);
    1244:	4581                	li	a1,0
    1246:	8552                	mv	a0,s4
    1248:	47a040ef          	jal	56c2 <open>
    124c:	84aa                	mv	s1,a0
      read(fd, buf, sizeof(buf));
    124e:	02000613          	li	a2,32
    1252:	f9840593          	addi	a1,s0,-104
    1256:	444040ef          	jal	569a <read>
      close(fd);
    125a:	8526                	mv	a0,s1
    125c:	44e040ef          	jal	56aa <close>
    for (int i = 0; i < 100; i++) {
    1260:	39fd                	addiw	s3,s3,-1
    1262:	fc0990e3          	bnez	s3,1222 <truncate3+0x46>
    exit(0);
    1266:	4501                	li	a0,0
    1268:	41a040ef          	jal	5682 <exit>
    126c:	eca6                	sd	s1,88(sp)
    126e:	e4ce                	sd	s3,72(sp)
    1270:	e0d2                	sd	s4,64(sp)
    1272:	fc56                	sd	s5,56(sp)
    printf("%s: fork failed\n", s);
    1274:	85ca                	mv	a1,s2
    1276:	00005517          	auipc	a0,0x5
    127a:	2d250513          	addi	a0,a0,722 # 6548 <malloc+0x9c2>
    127e:	055040ef          	jal	5ad2 <printf>
    exit(1);
    1282:	4505                	li	a0,1
    1284:	3fe040ef          	jal	5682 <exit>
        printf("%s: open failed\n", s);
    1288:	85ca                	mv	a1,s2
    128a:	00005517          	auipc	a0,0x5
    128e:	2d650513          	addi	a0,a0,726 # 6560 <malloc+0x9da>
    1292:	041040ef          	jal	5ad2 <printf>
        exit(1);
    1296:	4505                	li	a0,1
    1298:	3ea040ef          	jal	5682 <exit>
        printf("%s: write got %d, expected 10\n", s, n);
    129c:	862a                	mv	a2,a0
    129e:	85ca                	mv	a1,s2
    12a0:	00005517          	auipc	a0,0x5
    12a4:	2e850513          	addi	a0,a0,744 # 6588 <malloc+0xa02>
    12a8:	02b040ef          	jal	5ad2 <printf>
        exit(1);
    12ac:	4505                	li	a0,1
    12ae:	3d4040ef          	jal	5682 <exit>
    12b2:	eca6                	sd	s1,88(sp)
    12b4:	e4ce                	sd	s3,72(sp)
    12b6:	e0d2                	sd	s4,64(sp)
    12b8:	fc56                	sd	s5,56(sp)
    12ba:	09600993          	li	s3,150
    int fd = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
    12be:	00005a17          	auipc	s4,0x5
    12c2:	a52a0a13          	addi	s4,s4,-1454 # 5d10 <malloc+0x18a>
    int n = write(fd, "xxx", 3);
    12c6:	00005a97          	auipc	s5,0x5
    12ca:	2e2a8a93          	addi	s5,s5,738 # 65a8 <malloc+0xa22>
    int fd = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
    12ce:	60100593          	li	a1,1537
    12d2:	8552                	mv	a0,s4
    12d4:	3ee040ef          	jal	56c2 <open>
    12d8:	84aa                	mv	s1,a0
    if (fd < 0) {
    12da:	02054d63          	bltz	a0,1314 <truncate3+0x138>
    int n = write(fd, "xxx", 3);
    12de:	460d                	li	a2,3
    12e0:	85d6                	mv	a1,s5
    12e2:	3c0040ef          	jal	56a2 <write>
    if (n != 3) {
    12e6:	478d                	li	a5,3
    12e8:	04f51063          	bne	a0,a5,1328 <truncate3+0x14c>
    close(fd);
    12ec:	8526                	mv	a0,s1
    12ee:	3bc040ef          	jal	56aa <close>
  for (int i = 0; i < 150; i++) {
    12f2:	39fd                	addiw	s3,s3,-1
    12f4:	fc099de3          	bnez	s3,12ce <truncate3+0xf2>
  wait(&xstatus);
    12f8:	fbc40513          	addi	a0,s0,-68
    12fc:	38e040ef          	jal	568a <wait>
  unlink("truncfile");
    1300:	00005517          	auipc	a0,0x5
    1304:	a1050513          	addi	a0,a0,-1520 # 5d10 <malloc+0x18a>
    1308:	3ca040ef          	jal	56d2 <unlink>
  exit(xstatus);
    130c:	fbc42503          	lw	a0,-68(s0)
    1310:	372040ef          	jal	5682 <exit>
      printf("%s: open failed\n", s);
    1314:	85ca                	mv	a1,s2
    1316:	00005517          	auipc	a0,0x5
    131a:	24a50513          	addi	a0,a0,586 # 6560 <malloc+0x9da>
    131e:	7b4040ef          	jal	5ad2 <printf>
      exit(1);
    1322:	4505                	li	a0,1
    1324:	35e040ef          	jal	5682 <exit>
      printf("%s: write got %d, expected 3\n", s, n);
    1328:	862a                	mv	a2,a0
    132a:	85ca                	mv	a1,s2
    132c:	00005517          	auipc	a0,0x5
    1330:	28450513          	addi	a0,a0,644 # 65b0 <malloc+0xa2a>
    1334:	79e040ef          	jal	5ad2 <printf>
      exit(1);
    1338:	4505                	li	a0,1
    133a:	348040ef          	jal	5682 <exit>

000000000000133e <pipe1>:
{
    133e:	711d                	addi	sp,sp,-96
    1340:	ec86                	sd	ra,88(sp)
    1342:	e8a2                	sd	s0,80(sp)
    1344:	fc4e                	sd	s3,56(sp)
    1346:	1080                	addi	s0,sp,96
    1348:	89aa                	mv	s3,a0
  if (pipe(fds) != 0) {
    134a:	fa840513          	addi	a0,s0,-88
    134e:	344040ef          	jal	5692 <pipe>
    1352:	e92d                	bnez	a0,13c4 <pipe1+0x86>
    1354:	e4a6                	sd	s1,72(sp)
    1356:	f852                	sd	s4,48(sp)
    1358:	84aa                	mv	s1,a0
  pid = fork();
    135a:	320040ef          	jal	567a <fork>
    135e:	8a2a                	mv	s4,a0
  if (pid == 0) {
    1360:	c151                	beqz	a0,13e4 <pipe1+0xa6>
  } else if (pid > 0) {
    1362:	14a05e63          	blez	a0,14be <pipe1+0x180>
    1366:	e0ca                	sd	s2,64(sp)
    1368:	f456                	sd	s5,40(sp)
    close(fds[1]);
    136a:	fac42503          	lw	a0,-84(s0)
    136e:	33c040ef          	jal	56aa <close>
    total = 0;
    1372:	8a26                	mv	s4,s1
    cc = 1;
    1374:	4905                	li	s2,1
    while ((n = read(fds[0], buf, cc)) > 0) {
    1376:	0000da97          	auipc	s5,0xd
    137a:	992a8a93          	addi	s5,s5,-1646 # dd08 <buf>
    137e:	864a                	mv	a2,s2
    1380:	85d6                	mv	a1,s5
    1382:	fa842503          	lw	a0,-88(s0)
    1386:	314040ef          	jal	569a <read>
    138a:	0ea05a63          	blez	a0,147e <pipe1+0x140>
      for (i = 0; i < n; i++) {
    138e:	0000d717          	auipc	a4,0xd
    1392:	97a70713          	addi	a4,a4,-1670 # dd08 <buf>
    1396:	00a4863b          	addw	a2,s1,a0
        if ((buf[i] & 0xff) != (seq++ & 0xff)) {
    139a:	00074683          	lbu	a3,0(a4)
    139e:	0ff4f793          	zext.b	a5,s1
    13a2:	2485                	addiw	s1,s1,1
    13a4:	0af69d63          	bne	a3,a5,145e <pipe1+0x120>
      for (i = 0; i < n; i++) {
    13a8:	0705                	addi	a4,a4,1
    13aa:	fec498e3          	bne	s1,a2,139a <pipe1+0x5c>
      total += n;
    13ae:	00aa0a3b          	addw	s4,s4,a0
      cc = cc * 2;
    13b2:	0019179b          	slliw	a5,s2,0x1
    13b6:	0007891b          	sext.w	s2,a5
      if (cc > sizeof(buf))
    13ba:	670d                	lui	a4,0x3
    13bc:	fd2771e3          	bgeu	a4,s2,137e <pipe1+0x40>
        cc = sizeof(buf);
    13c0:	690d                	lui	s2,0x3
    13c2:	bf75                	j	137e <pipe1+0x40>
    13c4:	e4a6                	sd	s1,72(sp)
    13c6:	e0ca                	sd	s2,64(sp)
    13c8:	f852                	sd	s4,48(sp)
    13ca:	f456                	sd	s5,40(sp)
    13cc:	f05a                	sd	s6,32(sp)
    13ce:	ec5e                	sd	s7,24(sp)
    printf("%s: pipe() failed\n", s);
    13d0:	85ce                	mv	a1,s3
    13d2:	00005517          	auipc	a0,0x5
    13d6:	1fe50513          	addi	a0,a0,510 # 65d0 <malloc+0xa4a>
    13da:	6f8040ef          	jal	5ad2 <printf>
    exit(1);
    13de:	4505                	li	a0,1
    13e0:	2a2040ef          	jal	5682 <exit>
    13e4:	e0ca                	sd	s2,64(sp)
    13e6:	f456                	sd	s5,40(sp)
    13e8:	f05a                	sd	s6,32(sp)
    13ea:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    13ec:	fa842503          	lw	a0,-88(s0)
    13f0:	2ba040ef          	jal	56aa <close>
    for (n = 0; n < N; n++) {
    13f4:	0000db17          	auipc	s6,0xd
    13f8:	914b0b13          	addi	s6,s6,-1772 # dd08 <buf>
    13fc:	416004bb          	negw	s1,s6
    1400:	0ff4f493          	zext.b	s1,s1
    1404:	409b0913          	addi	s2,s6,1033
      if (write(fds[1], buf, SZ) != SZ) {
    1408:	8bda                	mv	s7,s6
    for (n = 0; n < N; n++) {
    140a:	6a85                	lui	s5,0x1
    140c:	42da8a93          	addi	s5,s5,1069 # 142d <pipe1+0xef>
{
    1410:	87da                	mv	a5,s6
        buf[i] = seq++;
    1412:	0097873b          	addw	a4,a5,s1
    1416:	00e78023          	sb	a4,0(a5)
      for (i = 0; i < SZ; i++)
    141a:	0785                	addi	a5,a5,1
    141c:	ff279be3          	bne	a5,s2,1412 <pipe1+0xd4>
    1420:	409a0a1b          	addiw	s4,s4,1033
      if (write(fds[1], buf, SZ) != SZ) {
    1424:	40900613          	li	a2,1033
    1428:	85de                	mv	a1,s7
    142a:	fac42503          	lw	a0,-84(s0)
    142e:	274040ef          	jal	56a2 <write>
    1432:	40900793          	li	a5,1033
    1436:	00f51a63          	bne	a0,a5,144a <pipe1+0x10c>
    for (n = 0; n < N; n++) {
    143a:	24a5                	addiw	s1,s1,9
    143c:	0ff4f493          	zext.b	s1,s1
    1440:	fd5a18e3          	bne	s4,s5,1410 <pipe1+0xd2>
    exit(0);
    1444:	4501                	li	a0,0
    1446:	23c040ef          	jal	5682 <exit>
        printf("%s: pipe1 oops 1\n", s);
    144a:	85ce                	mv	a1,s3
    144c:	00005517          	auipc	a0,0x5
    1450:	19c50513          	addi	a0,a0,412 # 65e8 <malloc+0xa62>
    1454:	67e040ef          	jal	5ad2 <printf>
        exit(1);
    1458:	4505                	li	a0,1
    145a:	228040ef          	jal	5682 <exit>
          printf("%s: pipe1 oops 2\n", s);
    145e:	85ce                	mv	a1,s3
    1460:	00005517          	auipc	a0,0x5
    1464:	1a050513          	addi	a0,a0,416 # 6600 <malloc+0xa7a>
    1468:	66a040ef          	jal	5ad2 <printf>
          return;
    146c:	64a6                	ld	s1,72(sp)
    146e:	6906                	ld	s2,64(sp)
    1470:	7a42                	ld	s4,48(sp)
    1472:	7aa2                	ld	s5,40(sp)
}
    1474:	60e6                	ld	ra,88(sp)
    1476:	6446                	ld	s0,80(sp)
    1478:	79e2                	ld	s3,56(sp)
    147a:	6125                	addi	sp,sp,96
    147c:	8082                	ret
    if (total != N * SZ) {
    147e:	6785                	lui	a5,0x1
    1480:	42d78793          	addi	a5,a5,1069 # 142d <pipe1+0xef>
    1484:	00fa0f63          	beq	s4,a5,14a2 <pipe1+0x164>
    1488:	f05a                	sd	s6,32(sp)
    148a:	ec5e                	sd	s7,24(sp)
      printf("%s: pipe1 oops 3 total %d\n", s, total);
    148c:	8652                	mv	a2,s4
    148e:	85ce                	mv	a1,s3
    1490:	00005517          	auipc	a0,0x5
    1494:	18850513          	addi	a0,a0,392 # 6618 <malloc+0xa92>
    1498:	63a040ef          	jal	5ad2 <printf>
      exit(1);
    149c:	4505                	li	a0,1
    149e:	1e4040ef          	jal	5682 <exit>
    14a2:	f05a                	sd	s6,32(sp)
    14a4:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    14a6:	fa842503          	lw	a0,-88(s0)
    14aa:	200040ef          	jal	56aa <close>
    wait(&xstatus);
    14ae:	fa440513          	addi	a0,s0,-92
    14b2:	1d8040ef          	jal	568a <wait>
    exit(xstatus);
    14b6:	fa442503          	lw	a0,-92(s0)
    14ba:	1c8040ef          	jal	5682 <exit>
    14be:	e0ca                	sd	s2,64(sp)
    14c0:	f456                	sd	s5,40(sp)
    14c2:	f05a                	sd	s6,32(sp)
    14c4:	ec5e                	sd	s7,24(sp)
    printf("%s: fork() failed\n", s);
    14c6:	85ce                	mv	a1,s3
    14c8:	00005517          	auipc	a0,0x5
    14cc:	17050513          	addi	a0,a0,368 # 6638 <malloc+0xab2>
    14d0:	602040ef          	jal	5ad2 <printf>
    exit(1);
    14d4:	4505                	li	a0,1
    14d6:	1ac040ef          	jal	5682 <exit>

00000000000014da <exitwait>:
{
    14da:	7139                	addi	sp,sp,-64
    14dc:	fc06                	sd	ra,56(sp)
    14de:	f822                	sd	s0,48(sp)
    14e0:	f426                	sd	s1,40(sp)
    14e2:	f04a                	sd	s2,32(sp)
    14e4:	ec4e                	sd	s3,24(sp)
    14e6:	e852                	sd	s4,16(sp)
    14e8:	0080                	addi	s0,sp,64
    14ea:	8a2a                	mv	s4,a0
  for (i = 0; i < 100; i++) {
    14ec:	4901                	li	s2,0
    14ee:	06400993          	li	s3,100
    pid = fork();
    14f2:	188040ef          	jal	567a <fork>
    14f6:	84aa                	mv	s1,a0
    if (pid < 0) {
    14f8:	02054863          	bltz	a0,1528 <exitwait+0x4e>
    if (pid) {
    14fc:	c525                	beqz	a0,1564 <exitwait+0x8a>
      if (wait(&xstate) != pid) {
    14fe:	fcc40513          	addi	a0,s0,-52
    1502:	188040ef          	jal	568a <wait>
    1506:	02951b63          	bne	a0,s1,153c <exitwait+0x62>
      if (i != xstate) {
    150a:	fcc42783          	lw	a5,-52(s0)
    150e:	05279163          	bne	a5,s2,1550 <exitwait+0x76>
  for (i = 0; i < 100; i++) {
    1512:	2905                	addiw	s2,s2,1 # 3001 <subdir+0x5b5>
    1514:	fd391fe3          	bne	s2,s3,14f2 <exitwait+0x18>
}
    1518:	70e2                	ld	ra,56(sp)
    151a:	7442                	ld	s0,48(sp)
    151c:	74a2                	ld	s1,40(sp)
    151e:	7902                	ld	s2,32(sp)
    1520:	69e2                	ld	s3,24(sp)
    1522:	6a42                	ld	s4,16(sp)
    1524:	6121                	addi	sp,sp,64
    1526:	8082                	ret
      printf("%s: fork failed\n", s);
    1528:	85d2                	mv	a1,s4
    152a:	00005517          	auipc	a0,0x5
    152e:	01e50513          	addi	a0,a0,30 # 6548 <malloc+0x9c2>
    1532:	5a0040ef          	jal	5ad2 <printf>
      exit(1);
    1536:	4505                	li	a0,1
    1538:	14a040ef          	jal	5682 <exit>
        printf("%s: wait wrong pid\n", s);
    153c:	85d2                	mv	a1,s4
    153e:	00005517          	auipc	a0,0x5
    1542:	11250513          	addi	a0,a0,274 # 6650 <malloc+0xaca>
    1546:	58c040ef          	jal	5ad2 <printf>
        exit(1);
    154a:	4505                	li	a0,1
    154c:	136040ef          	jal	5682 <exit>
        printf("%s: wait wrong exit status\n", s);
    1550:	85d2                	mv	a1,s4
    1552:	00005517          	auipc	a0,0x5
    1556:	11650513          	addi	a0,a0,278 # 6668 <malloc+0xae2>
    155a:	578040ef          	jal	5ad2 <printf>
        exit(1);
    155e:	4505                	li	a0,1
    1560:	122040ef          	jal	5682 <exit>
      exit(i);
    1564:	854a                	mv	a0,s2
    1566:	11c040ef          	jal	5682 <exit>

000000000000156a <twochildren>:
{
    156a:	1101                	addi	sp,sp,-32
    156c:	ec06                	sd	ra,24(sp)
    156e:	e822                	sd	s0,16(sp)
    1570:	e426                	sd	s1,8(sp)
    1572:	e04a                	sd	s2,0(sp)
    1574:	1000                	addi	s0,sp,32
    1576:	892a                	mv	s2,a0
    1578:	3e800493          	li	s1,1000
    int pid1 = fork();
    157c:	0fe040ef          	jal	567a <fork>
    if (pid1 < 0) {
    1580:	02054663          	bltz	a0,15ac <twochildren+0x42>
    if (pid1 == 0) {
    1584:	cd15                	beqz	a0,15c0 <twochildren+0x56>
      int pid2 = fork();
    1586:	0f4040ef          	jal	567a <fork>
      if (pid2 < 0) {
    158a:	02054d63          	bltz	a0,15c4 <twochildren+0x5a>
      if (pid2 == 0) {
    158e:	c529                	beqz	a0,15d8 <twochildren+0x6e>
        wait(0);
    1590:	4501                	li	a0,0
    1592:	0f8040ef          	jal	568a <wait>
        wait(0);
    1596:	4501                	li	a0,0
    1598:	0f2040ef          	jal	568a <wait>
  for (int i = 0; i < 1000; i++) {
    159c:	34fd                	addiw	s1,s1,-1
    159e:	fcf9                	bnez	s1,157c <twochildren+0x12>
}
    15a0:	60e2                	ld	ra,24(sp)
    15a2:	6442                	ld	s0,16(sp)
    15a4:	64a2                	ld	s1,8(sp)
    15a6:	6902                	ld	s2,0(sp)
    15a8:	6105                	addi	sp,sp,32
    15aa:	8082                	ret
      printf("%s: fork failed\n", s);
    15ac:	85ca                	mv	a1,s2
    15ae:	00005517          	auipc	a0,0x5
    15b2:	f9a50513          	addi	a0,a0,-102 # 6548 <malloc+0x9c2>
    15b6:	51c040ef          	jal	5ad2 <printf>
      exit(1);
    15ba:	4505                	li	a0,1
    15bc:	0c6040ef          	jal	5682 <exit>
      exit(0);
    15c0:	0c2040ef          	jal	5682 <exit>
        printf("%s: fork failed\n", s);
    15c4:	85ca                	mv	a1,s2
    15c6:	00005517          	auipc	a0,0x5
    15ca:	f8250513          	addi	a0,a0,-126 # 6548 <malloc+0x9c2>
    15ce:	504040ef          	jal	5ad2 <printf>
        exit(1);
    15d2:	4505                	li	a0,1
    15d4:	0ae040ef          	jal	5682 <exit>
        exit(0);
    15d8:	0aa040ef          	jal	5682 <exit>

00000000000015dc <forkfork>:
{
    15dc:	7179                	addi	sp,sp,-48
    15de:	f406                	sd	ra,40(sp)
    15e0:	f022                	sd	s0,32(sp)
    15e2:	ec26                	sd	s1,24(sp)
    15e4:	1800                	addi	s0,sp,48
    15e6:	84aa                	mv	s1,a0
    int pid = fork();
    15e8:	092040ef          	jal	567a <fork>
    if (pid < 0) {
    15ec:	02054b63          	bltz	a0,1622 <forkfork+0x46>
    if (pid == 0) {
    15f0:	c139                	beqz	a0,1636 <forkfork+0x5a>
    int pid = fork();
    15f2:	088040ef          	jal	567a <fork>
    if (pid < 0) {
    15f6:	02054663          	bltz	a0,1622 <forkfork+0x46>
    if (pid == 0) {
    15fa:	cd15                	beqz	a0,1636 <forkfork+0x5a>
    wait(&xstatus);
    15fc:	fdc40513          	addi	a0,s0,-36
    1600:	08a040ef          	jal	568a <wait>
    if (xstatus != 0) {
    1604:	fdc42783          	lw	a5,-36(s0)
    1608:	ebb9                	bnez	a5,165e <forkfork+0x82>
    wait(&xstatus);
    160a:	fdc40513          	addi	a0,s0,-36
    160e:	07c040ef          	jal	568a <wait>
    if (xstatus != 0) {
    1612:	fdc42783          	lw	a5,-36(s0)
    1616:	e7a1                	bnez	a5,165e <forkfork+0x82>
}
    1618:	70a2                	ld	ra,40(sp)
    161a:	7402                	ld	s0,32(sp)
    161c:	64e2                	ld	s1,24(sp)
    161e:	6145                	addi	sp,sp,48
    1620:	8082                	ret
      printf("%s: fork failed", s);
    1622:	85a6                	mv	a1,s1
    1624:	00005517          	auipc	a0,0x5
    1628:	06450513          	addi	a0,a0,100 # 6688 <malloc+0xb02>
    162c:	4a6040ef          	jal	5ad2 <printf>
      exit(1);
    1630:	4505                	li	a0,1
    1632:	050040ef          	jal	5682 <exit>
{
    1636:	0c800493          	li	s1,200
        int pid1 = fork();
    163a:	040040ef          	jal	567a <fork>
        if (pid1 < 0) {
    163e:	00054b63          	bltz	a0,1654 <forkfork+0x78>
        if (pid1 == 0) {
    1642:	cd01                	beqz	a0,165a <forkfork+0x7e>
        wait(0);
    1644:	4501                	li	a0,0
    1646:	044040ef          	jal	568a <wait>
      for (int j = 0; j < 200; j++) {
    164a:	34fd                	addiw	s1,s1,-1
    164c:	f4fd                	bnez	s1,163a <forkfork+0x5e>
      exit(0);
    164e:	4501                	li	a0,0
    1650:	032040ef          	jal	5682 <exit>
          exit(1);
    1654:	4505                	li	a0,1
    1656:	02c040ef          	jal	5682 <exit>
          exit(0);
    165a:	028040ef          	jal	5682 <exit>
      printf("%s: fork in child failed", s);
    165e:	85a6                	mv	a1,s1
    1660:	00005517          	auipc	a0,0x5
    1664:	03850513          	addi	a0,a0,56 # 6698 <malloc+0xb12>
    1668:	46a040ef          	jal	5ad2 <printf>
      exit(1);
    166c:	4505                	li	a0,1
    166e:	014040ef          	jal	5682 <exit>

0000000000001672 <reparent2>:
{
    1672:	1101                	addi	sp,sp,-32
    1674:	ec06                	sd	ra,24(sp)
    1676:	e822                	sd	s0,16(sp)
    1678:	e426                	sd	s1,8(sp)
    167a:	1000                	addi	s0,sp,32
    167c:	32000493          	li	s1,800
    int pid1 = fork();
    1680:	7fb030ef          	jal	567a <fork>
    if (pid1 < 0) {
    1684:	00054b63          	bltz	a0,169a <reparent2+0x28>
    if (pid1 == 0) {
    1688:	c115                	beqz	a0,16ac <reparent2+0x3a>
    wait(0);
    168a:	4501                	li	a0,0
    168c:	7ff030ef          	jal	568a <wait>
  for (int i = 0; i < 800; i++) {
    1690:	34fd                	addiw	s1,s1,-1
    1692:	f4fd                	bnez	s1,1680 <reparent2+0xe>
  exit(0);
    1694:	4501                	li	a0,0
    1696:	7ed030ef          	jal	5682 <exit>
      printf("fork failed\n");
    169a:	00006517          	auipc	a0,0x6
    169e:	62e50513          	addi	a0,a0,1582 # 7cc8 <malloc+0x2142>
    16a2:	430040ef          	jal	5ad2 <printf>
      exit(1);
    16a6:	4505                	li	a0,1
    16a8:	7db030ef          	jal	5682 <exit>
      fork();
    16ac:	7cf030ef          	jal	567a <fork>
      fork();
    16b0:	7cb030ef          	jal	567a <fork>
      exit(0);
    16b4:	4501                	li	a0,0
    16b6:	7cd030ef          	jal	5682 <exit>

00000000000016ba <createdelete>:
{
    16ba:	7175                	addi	sp,sp,-144
    16bc:	e506                	sd	ra,136(sp)
    16be:	e122                	sd	s0,128(sp)
    16c0:	fca6                	sd	s1,120(sp)
    16c2:	f8ca                	sd	s2,112(sp)
    16c4:	f4ce                	sd	s3,104(sp)
    16c6:	f0d2                	sd	s4,96(sp)
    16c8:	ecd6                	sd	s5,88(sp)
    16ca:	e8da                	sd	s6,80(sp)
    16cc:	e4de                	sd	s7,72(sp)
    16ce:	e0e2                	sd	s8,64(sp)
    16d0:	fc66                	sd	s9,56(sp)
    16d2:	0900                	addi	s0,sp,144
    16d4:	8caa                	mv	s9,a0
  for (pi = 0; pi < NCHILD; pi++) {
    16d6:	4901                	li	s2,0
    16d8:	4991                	li	s3,4
    pid = fork();
    16da:	7a1030ef          	jal	567a <fork>
    16de:	84aa                	mv	s1,a0
    if (pid < 0) {
    16e0:	02054d63          	bltz	a0,171a <createdelete+0x60>
    if (pid == 0) {
    16e4:	c529                	beqz	a0,172e <createdelete+0x74>
  for (pi = 0; pi < NCHILD; pi++) {
    16e6:	2905                	addiw	s2,s2,1
    16e8:	ff3919e3          	bne	s2,s3,16da <createdelete+0x20>
    16ec:	4491                	li	s1,4
    wait(&xstatus);
    16ee:	f7c40513          	addi	a0,s0,-132
    16f2:	799030ef          	jal	568a <wait>
    if (xstatus != 0)
    16f6:	f7c42903          	lw	s2,-132(s0)
    16fa:	0a091e63          	bnez	s2,17b6 <createdelete+0xfc>
  for (pi = 0; pi < NCHILD; pi++) {
    16fe:	34fd                	addiw	s1,s1,-1
    1700:	f4fd                	bnez	s1,16ee <createdelete+0x34>
  name[0] = name[1] = name[2] = 0;
    1702:	f8040123          	sb	zero,-126(s0)
    1706:	03000993          	li	s3,48
    170a:	5a7d                	li	s4,-1
    170c:	07000c13          	li	s8,112
      if ((i == 0 || i >= N / 2) && fd < 0) {
    1710:	4b25                	li	s6,9
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    1712:	4ba1                	li	s7,8
    for (pi = 0; pi < NCHILD; pi++) {
    1714:	07400a93          	li	s5,116
    1718:	aa39                	j	1836 <createdelete+0x17c>
      printf("%s: fork failed\n", s);
    171a:	85e6                	mv	a1,s9
    171c:	00005517          	auipc	a0,0x5
    1720:	e2c50513          	addi	a0,a0,-468 # 6548 <malloc+0x9c2>
    1724:	3ae040ef          	jal	5ad2 <printf>
      exit(1);
    1728:	4505                	li	a0,1
    172a:	759030ef          	jal	5682 <exit>
      name[0] = 'p' + pi;
    172e:	0709091b          	addiw	s2,s2,112
    1732:	f9240023          	sb	s2,-128(s0)
      name[2] = '\0';
    1736:	f8040123          	sb	zero,-126(s0)
      for (i = 0; i < N; i++) {
    173a:	4951                	li	s2,20
    173c:	a831                	j	1758 <createdelete+0x9e>
          printf("%s: create failed\n", s);
    173e:	85e6                	mv	a1,s9
    1740:	00005517          	auipc	a0,0x5
    1744:	f7850513          	addi	a0,a0,-136 # 66b8 <malloc+0xb32>
    1748:	38a040ef          	jal	5ad2 <printf>
          exit(1);
    174c:	4505                	li	a0,1
    174e:	735030ef          	jal	5682 <exit>
      for (i = 0; i < N; i++) {
    1752:	2485                	addiw	s1,s1,1
    1754:	05248e63          	beq	s1,s2,17b0 <createdelete+0xf6>
        name[1] = '0' + i;
    1758:	0304879b          	addiw	a5,s1,48
    175c:	f8f400a3          	sb	a5,-127(s0)
        fd = open(name, O_CREATE | O_RDWR);
    1760:	20200593          	li	a1,514
    1764:	f8040513          	addi	a0,s0,-128
    1768:	75b030ef          	jal	56c2 <open>
        if (fd < 0) {
    176c:	fc0549e3          	bltz	a0,173e <createdelete+0x84>
        close(fd);
    1770:	73b030ef          	jal	56aa <close>
        if (i > 0 && (i % 2) == 0) {
    1774:	10905063          	blez	s1,1874 <createdelete+0x1ba>
    1778:	0014f793          	andi	a5,s1,1
    177c:	fbf9                	bnez	a5,1752 <createdelete+0x98>
          name[1] = '0' + (i / 2);
    177e:	01f4d79b          	srliw	a5,s1,0x1f
    1782:	9fa5                	addw	a5,a5,s1
    1784:	4017d79b          	sraiw	a5,a5,0x1
    1788:	0307879b          	addiw	a5,a5,48
    178c:	f8f400a3          	sb	a5,-127(s0)
          if (unlink(name) < 0) {
    1790:	f8040513          	addi	a0,s0,-128
    1794:	73f030ef          	jal	56d2 <unlink>
    1798:	fa055de3          	bgez	a0,1752 <createdelete+0x98>
            printf("%s: unlink failed\n", s);
    179c:	85e6                	mv	a1,s9
    179e:	00005517          	auipc	a0,0x5
    17a2:	f3250513          	addi	a0,a0,-206 # 66d0 <malloc+0xb4a>
    17a6:	32c040ef          	jal	5ad2 <printf>
            exit(1);
    17aa:	4505                	li	a0,1
    17ac:	6d7030ef          	jal	5682 <exit>
      exit(0);
    17b0:	4501                	li	a0,0
    17b2:	6d1030ef          	jal	5682 <exit>
      exit(1);
    17b6:	4505                	li	a0,1
    17b8:	6cb030ef          	jal	5682 <exit>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    17bc:	f8040613          	addi	a2,s0,-128
    17c0:	85e6                	mv	a1,s9
    17c2:	00005517          	auipc	a0,0x5
    17c6:	f2650513          	addi	a0,a0,-218 # 66e8 <malloc+0xb62>
    17ca:	308040ef          	jal	5ad2 <printf>
        exit(1);
    17ce:	4505                	li	a0,1
    17d0:	6b3030ef          	jal	5682 <exit>
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    17d4:	034bfb63          	bgeu	s7,s4,180a <createdelete+0x150>
      if (fd >= 0)
    17d8:	02055663          	bgez	a0,1804 <createdelete+0x14a>
    for (pi = 0; pi < NCHILD; pi++) {
    17dc:	2485                	addiw	s1,s1,1
    17de:	0ff4f493          	zext.b	s1,s1
    17e2:	05548263          	beq	s1,s5,1826 <createdelete+0x16c>
      name[0] = 'p' + pi;
    17e6:	f8940023          	sb	s1,-128(s0)
      name[1] = '0' + i;
    17ea:	f93400a3          	sb	s3,-127(s0)
      fd = open(name, 0);
    17ee:	4581                	li	a1,0
    17f0:	f8040513          	addi	a0,s0,-128
    17f4:	6cf030ef          	jal	56c2 <open>
      if ((i == 0 || i >= N / 2) && fd < 0) {
    17f8:	00090463          	beqz	s2,1800 <createdelete+0x146>
    17fc:	fd2b5ce3          	bge	s6,s2,17d4 <createdelete+0x11a>
    1800:	fa054ee3          	bltz	a0,17bc <createdelete+0x102>
        close(fd);
    1804:	6a7030ef          	jal	56aa <close>
    1808:	bfd1                	j	17dc <createdelete+0x122>
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    180a:	fc0549e3          	bltz	a0,17dc <createdelete+0x122>
        printf("%s: oops createdelete %s did exist\n", s, name);
    180e:	f8040613          	addi	a2,s0,-128
    1812:	85e6                	mv	a1,s9
    1814:	00005517          	auipc	a0,0x5
    1818:	efc50513          	addi	a0,a0,-260 # 6710 <malloc+0xb8a>
    181c:	2b6040ef          	jal	5ad2 <printf>
        exit(1);
    1820:	4505                	li	a0,1
    1822:	661030ef          	jal	5682 <exit>
  for (i = 0; i < N; i++) {
    1826:	2905                	addiw	s2,s2,1
    1828:	2a05                	addiw	s4,s4,1
    182a:	2985                	addiw	s3,s3,1
    182c:	0ff9f993          	zext.b	s3,s3
    1830:	47d1                	li	a5,20
    1832:	02f90863          	beq	s2,a5,1862 <createdelete+0x1a8>
    for (pi = 0; pi < NCHILD; pi++) {
    1836:	84e2                	mv	s1,s8
    1838:	b77d                	j	17e6 <createdelete+0x12c>
  for (i = 0; i < N; i++) {
    183a:	2905                	addiw	s2,s2,1
    183c:	0ff97913          	zext.b	s2,s2
    1840:	03490c63          	beq	s2,s4,1878 <createdelete+0x1be>
  name[0] = name[1] = name[2] = 0;
    1844:	84d6                	mv	s1,s5
      name[0] = 'p' + pi;
    1846:	f8940023          	sb	s1,-128(s0)
      name[1] = '0' + i;
    184a:	f92400a3          	sb	s2,-127(s0)
      unlink(name);
    184e:	f8040513          	addi	a0,s0,-128
    1852:	681030ef          	jal	56d2 <unlink>
    for (pi = 0; pi < NCHILD; pi++) {
    1856:	2485                	addiw	s1,s1,1
    1858:	0ff4f493          	zext.b	s1,s1
    185c:	ff3495e3          	bne	s1,s3,1846 <createdelete+0x18c>
    1860:	bfe9                	j	183a <createdelete+0x180>
    1862:	03000913          	li	s2,48
  name[0] = name[1] = name[2] = 0;
    1866:	07000a93          	li	s5,112
    for (pi = 0; pi < NCHILD; pi++) {
    186a:	07400993          	li	s3,116
  for (i = 0; i < N; i++) {
    186e:	04400a13          	li	s4,68
    1872:	bfc9                	j	1844 <createdelete+0x18a>
      for (i = 0; i < N; i++) {
    1874:	2485                	addiw	s1,s1,1
    1876:	b5cd                	j	1758 <createdelete+0x9e>
}
    1878:	60aa                	ld	ra,136(sp)
    187a:	640a                	ld	s0,128(sp)
    187c:	74e6                	ld	s1,120(sp)
    187e:	7946                	ld	s2,112(sp)
    1880:	79a6                	ld	s3,104(sp)
    1882:	7a06                	ld	s4,96(sp)
    1884:	6ae6                	ld	s5,88(sp)
    1886:	6b46                	ld	s6,80(sp)
    1888:	6ba6                	ld	s7,72(sp)
    188a:	6c06                	ld	s8,64(sp)
    188c:	7ce2                	ld	s9,56(sp)
    188e:	6149                	addi	sp,sp,144
    1890:	8082                	ret

0000000000001892 <linkunlink>:
{
    1892:	711d                	addi	sp,sp,-96
    1894:	ec86                	sd	ra,88(sp)
    1896:	e8a2                	sd	s0,80(sp)
    1898:	e4a6                	sd	s1,72(sp)
    189a:	e0ca                	sd	s2,64(sp)
    189c:	fc4e                	sd	s3,56(sp)
    189e:	f852                	sd	s4,48(sp)
    18a0:	f456                	sd	s5,40(sp)
    18a2:	f05a                	sd	s6,32(sp)
    18a4:	ec5e                	sd	s7,24(sp)
    18a6:	e862                	sd	s8,16(sp)
    18a8:	e466                	sd	s9,8(sp)
    18aa:	1080                	addi	s0,sp,96
    18ac:	84aa                	mv	s1,a0
  unlink("x");
    18ae:	00004517          	auipc	a0,0x4
    18b2:	47a50513          	addi	a0,a0,1146 # 5d28 <malloc+0x1a2>
    18b6:	61d030ef          	jal	56d2 <unlink>
  pid = fork();
    18ba:	5c1030ef          	jal	567a <fork>
  if (pid < 0) {
    18be:	02054b63          	bltz	a0,18f4 <linkunlink+0x62>
    18c2:	8caa                	mv	s9,a0
  unsigned int x = (pid ? 1 : 97);
    18c4:	06100913          	li	s2,97
    18c8:	c111                	beqz	a0,18cc <linkunlink+0x3a>
    18ca:	4905                	li	s2,1
    18cc:	06400493          	li	s1,100
    x = x * 1103515245 + 12345;
    18d0:	41c65a37          	lui	s4,0x41c65
    18d4:	e6da0a1b          	addiw	s4,s4,-403 # 41c64e6d <base+0x41c54165>
    18d8:	698d                	lui	s3,0x3
    18da:	0399899b          	addiw	s3,s3,57 # 3039 <subdir+0x5ed>
    if ((x % 3) == 0) {
    18de:	4a8d                	li	s5,3
    } else if ((x % 3) == 1) {
    18e0:	4b85                	li	s7,1
      unlink("x");
    18e2:	00004b17          	auipc	s6,0x4
    18e6:	446b0b13          	addi	s6,s6,1094 # 5d28 <malloc+0x1a2>
      link("cat", "x");
    18ea:	00005c17          	auipc	s8,0x5
    18ee:	e4ec0c13          	addi	s8,s8,-434 # 6738 <malloc+0xbb2>
    18f2:	a025                	j	191a <linkunlink+0x88>
    printf("%s: fork failed\n", s);
    18f4:	85a6                	mv	a1,s1
    18f6:	00005517          	auipc	a0,0x5
    18fa:	c5250513          	addi	a0,a0,-942 # 6548 <malloc+0x9c2>
    18fe:	1d4040ef          	jal	5ad2 <printf>
    exit(1);
    1902:	4505                	li	a0,1
    1904:	57f030ef          	jal	5682 <exit>
      close(open("x", O_RDWR | O_CREATE));
    1908:	20200593          	li	a1,514
    190c:	855a                	mv	a0,s6
    190e:	5b5030ef          	jal	56c2 <open>
    1912:	599030ef          	jal	56aa <close>
  for (i = 0; i < 100; i++) {
    1916:	34fd                	addiw	s1,s1,-1
    1918:	c495                	beqz	s1,1944 <linkunlink+0xb2>
    x = x * 1103515245 + 12345;
    191a:	034907bb          	mulw	a5,s2,s4
    191e:	013787bb          	addw	a5,a5,s3
    1922:	0007891b          	sext.w	s2,a5
    if ((x % 3) == 0) {
    1926:	0357f7bb          	remuw	a5,a5,s5
    192a:	2781                	sext.w	a5,a5
    192c:	dff1                	beqz	a5,1908 <linkunlink+0x76>
    } else if ((x % 3) == 1) {
    192e:	01778663          	beq	a5,s7,193a <linkunlink+0xa8>
      unlink("x");
    1932:	855a                	mv	a0,s6
    1934:	59f030ef          	jal	56d2 <unlink>
    1938:	bff9                	j	1916 <linkunlink+0x84>
      link("cat", "x");
    193a:	85da                	mv	a1,s6
    193c:	8562                	mv	a0,s8
    193e:	5a5030ef          	jal	56e2 <link>
    1942:	bfd1                	j	1916 <linkunlink+0x84>
  if (pid)
    1944:	020c8263          	beqz	s9,1968 <linkunlink+0xd6>
    wait(0);
    1948:	4501                	li	a0,0
    194a:	541030ef          	jal	568a <wait>
}
    194e:	60e6                	ld	ra,88(sp)
    1950:	6446                	ld	s0,80(sp)
    1952:	64a6                	ld	s1,72(sp)
    1954:	6906                	ld	s2,64(sp)
    1956:	79e2                	ld	s3,56(sp)
    1958:	7a42                	ld	s4,48(sp)
    195a:	7aa2                	ld	s5,40(sp)
    195c:	7b02                	ld	s6,32(sp)
    195e:	6be2                	ld	s7,24(sp)
    1960:	6c42                	ld	s8,16(sp)
    1962:	6ca2                	ld	s9,8(sp)
    1964:	6125                	addi	sp,sp,96
    1966:	8082                	ret
    exit(0);
    1968:	4501                	li	a0,0
    196a:	519030ef          	jal	5682 <exit>

000000000000196e <forktest>:
{
    196e:	7179                	addi	sp,sp,-48
    1970:	f406                	sd	ra,40(sp)
    1972:	f022                	sd	s0,32(sp)
    1974:	ec26                	sd	s1,24(sp)
    1976:	e84a                	sd	s2,16(sp)
    1978:	e44e                	sd	s3,8(sp)
    197a:	1800                	addi	s0,sp,48
    197c:	89aa                	mv	s3,a0
  for (n = 0; n < N; n++) {
    197e:	4481                	li	s1,0
    1980:	3e800913          	li	s2,1000
    pid = fork();
    1984:	4f7030ef          	jal	567a <fork>
    if (pid < 0)
    1988:	06054063          	bltz	a0,19e8 <forktest+0x7a>
    if (pid == 0)
    198c:	cd11                	beqz	a0,19a8 <forktest+0x3a>
  for (n = 0; n < N; n++) {
    198e:	2485                	addiw	s1,s1,1
    1990:	ff249ae3          	bne	s1,s2,1984 <forktest+0x16>
    printf("%s: fork claimed to work 1000 times!\n", s);
    1994:	85ce                	mv	a1,s3
    1996:	00005517          	auipc	a0,0x5
    199a:	df250513          	addi	a0,a0,-526 # 6788 <malloc+0xc02>
    199e:	134040ef          	jal	5ad2 <printf>
    exit(1);
    19a2:	4505                	li	a0,1
    19a4:	4df030ef          	jal	5682 <exit>
      exit(0);
    19a8:	4db030ef          	jal	5682 <exit>
    printf("%s: no fork at all!\n", s);
    19ac:	85ce                	mv	a1,s3
    19ae:	00005517          	auipc	a0,0x5
    19b2:	d9250513          	addi	a0,a0,-622 # 6740 <malloc+0xbba>
    19b6:	11c040ef          	jal	5ad2 <printf>
    exit(1);
    19ba:	4505                	li	a0,1
    19bc:	4c7030ef          	jal	5682 <exit>
      printf("%s: wait stopped early\n", s);
    19c0:	85ce                	mv	a1,s3
    19c2:	00005517          	auipc	a0,0x5
    19c6:	d9650513          	addi	a0,a0,-618 # 6758 <malloc+0xbd2>
    19ca:	108040ef          	jal	5ad2 <printf>
      exit(1);
    19ce:	4505                	li	a0,1
    19d0:	4b3030ef          	jal	5682 <exit>
    printf("%s: wait got too many\n", s);
    19d4:	85ce                	mv	a1,s3
    19d6:	00005517          	auipc	a0,0x5
    19da:	d9a50513          	addi	a0,a0,-614 # 6770 <malloc+0xbea>
    19de:	0f4040ef          	jal	5ad2 <printf>
    exit(1);
    19e2:	4505                	li	a0,1
    19e4:	49f030ef          	jal	5682 <exit>
  if (n == 0) {
    19e8:	d0f1                	beqz	s1,19ac <forktest+0x3e>
  for (; n > 0; n--) {
    19ea:	00905963          	blez	s1,19fc <forktest+0x8e>
    if (wait(0) < 0) {
    19ee:	4501                	li	a0,0
    19f0:	49b030ef          	jal	568a <wait>
    19f4:	fc0546e3          	bltz	a0,19c0 <forktest+0x52>
  for (; n > 0; n--) {
    19f8:	34fd                	addiw	s1,s1,-1
    19fa:	f8f5                	bnez	s1,19ee <forktest+0x80>
  if (wait(0) != -1) {
    19fc:	4501                	li	a0,0
    19fe:	48d030ef          	jal	568a <wait>
    1a02:	57fd                	li	a5,-1
    1a04:	fcf518e3          	bne	a0,a5,19d4 <forktest+0x66>
}
    1a08:	70a2                	ld	ra,40(sp)
    1a0a:	7402                	ld	s0,32(sp)
    1a0c:	64e2                	ld	s1,24(sp)
    1a0e:	6942                	ld	s2,16(sp)
    1a10:	69a2                	ld	s3,8(sp)
    1a12:	6145                	addi	sp,sp,48
    1a14:	8082                	ret

0000000000001a16 <kernmem>:
{
    1a16:	715d                	addi	sp,sp,-80
    1a18:	e486                	sd	ra,72(sp)
    1a1a:	e0a2                	sd	s0,64(sp)
    1a1c:	fc26                	sd	s1,56(sp)
    1a1e:	f84a                	sd	s2,48(sp)
    1a20:	f44e                	sd	s3,40(sp)
    1a22:	f052                	sd	s4,32(sp)
    1a24:	ec56                	sd	s5,24(sp)
    1a26:	0880                	addi	s0,sp,80
    1a28:	8aaa                	mv	s5,a0
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1a2a:	4485                	li	s1,1
    1a2c:	04fe                	slli	s1,s1,0x1f
    if (xstatus != -1) // did kernel kill child?
    1a2e:	5a7d                	li	s4,-1
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1a30:	69b1                	lui	s3,0xc
    1a32:	35098993          	addi	s3,s3,848 # c350 <uninit+0xd58>
    1a36:	1003d937          	lui	s2,0x1003d
    1a3a:	090e                	slli	s2,s2,0x3
    1a3c:	48090913          	addi	s2,s2,1152 # 1003d480 <base+0x1002c778>
    pid = fork();
    1a40:	43b030ef          	jal	567a <fork>
    if (pid < 0) {
    1a44:	02054763          	bltz	a0,1a72 <kernmem+0x5c>
    if (pid == 0) {
    1a48:	cd1d                	beqz	a0,1a86 <kernmem+0x70>
    wait(&xstatus);
    1a4a:	fbc40513          	addi	a0,s0,-68
    1a4e:	43d030ef          	jal	568a <wait>
    if (xstatus != -1) // did kernel kill child?
    1a52:	fbc42783          	lw	a5,-68(s0)
    1a56:	05479563          	bne	a5,s4,1aa0 <kernmem+0x8a>
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1a5a:	94ce                	add	s1,s1,s3
    1a5c:	ff2492e3          	bne	s1,s2,1a40 <kernmem+0x2a>
}
    1a60:	60a6                	ld	ra,72(sp)
    1a62:	6406                	ld	s0,64(sp)
    1a64:	74e2                	ld	s1,56(sp)
    1a66:	7942                	ld	s2,48(sp)
    1a68:	79a2                	ld	s3,40(sp)
    1a6a:	7a02                	ld	s4,32(sp)
    1a6c:	6ae2                	ld	s5,24(sp)
    1a6e:	6161                	addi	sp,sp,80
    1a70:	8082                	ret
      printf("%s: fork failed\n", s);
    1a72:	85d6                	mv	a1,s5
    1a74:	00005517          	auipc	a0,0x5
    1a78:	ad450513          	addi	a0,a0,-1324 # 6548 <malloc+0x9c2>
    1a7c:	056040ef          	jal	5ad2 <printf>
      exit(1);
    1a80:	4505                	li	a0,1
    1a82:	401030ef          	jal	5682 <exit>
      printf("%s: oops could read %p = %x\n", s, a, *a);
    1a86:	0004c683          	lbu	a3,0(s1)
    1a8a:	8626                	mv	a2,s1
    1a8c:	85d6                	mv	a1,s5
    1a8e:	00005517          	auipc	a0,0x5
    1a92:	d2250513          	addi	a0,a0,-734 # 67b0 <malloc+0xc2a>
    1a96:	03c040ef          	jal	5ad2 <printf>
      exit(1);
    1a9a:	4505                	li	a0,1
    1a9c:	3e7030ef          	jal	5682 <exit>
      exit(1);
    1aa0:	4505                	li	a0,1
    1aa2:	3e1030ef          	jal	5682 <exit>

0000000000001aa6 <MAXVAplus>:
{
    1aa6:	7179                	addi	sp,sp,-48
    1aa8:	f406                	sd	ra,40(sp)
    1aaa:	f022                	sd	s0,32(sp)
    1aac:	1800                	addi	s0,sp,48
  volatile uint64 a = MAXVA;
    1aae:	4785                	li	a5,1
    1ab0:	179a                	slli	a5,a5,0x26
    1ab2:	fcf43c23          	sd	a5,-40(s0)
  for (; a != 0; a <<= 1) {
    1ab6:	fd843783          	ld	a5,-40(s0)
    1aba:	cf85                	beqz	a5,1af2 <MAXVAplus+0x4c>
    1abc:	ec26                	sd	s1,24(sp)
    1abe:	e84a                	sd	s2,16(sp)
    1ac0:	892a                	mv	s2,a0
    if (xstatus != -1) // did kernel kill child?
    1ac2:	54fd                	li	s1,-1
    pid = fork();
    1ac4:	3b7030ef          	jal	567a <fork>
    if (pid < 0) {
    1ac8:	02054963          	bltz	a0,1afa <MAXVAplus+0x54>
    if (pid == 0) {
    1acc:	c129                	beqz	a0,1b0e <MAXVAplus+0x68>
    wait(&xstatus);
    1ace:	fd440513          	addi	a0,s0,-44
    1ad2:	3b9030ef          	jal	568a <wait>
    if (xstatus != -1) // did kernel kill child?
    1ad6:	fd442783          	lw	a5,-44(s0)
    1ada:	04979c63          	bne	a5,s1,1b32 <MAXVAplus+0x8c>
  for (; a != 0; a <<= 1) {
    1ade:	fd843783          	ld	a5,-40(s0)
    1ae2:	0786                	slli	a5,a5,0x1
    1ae4:	fcf43c23          	sd	a5,-40(s0)
    1ae8:	fd843783          	ld	a5,-40(s0)
    1aec:	ffe1                	bnez	a5,1ac4 <MAXVAplus+0x1e>
    1aee:	64e2                	ld	s1,24(sp)
    1af0:	6942                	ld	s2,16(sp)
}
    1af2:	70a2                	ld	ra,40(sp)
    1af4:	7402                	ld	s0,32(sp)
    1af6:	6145                	addi	sp,sp,48
    1af8:	8082                	ret
      printf("%s: fork failed\n", s);
    1afa:	85ca                	mv	a1,s2
    1afc:	00005517          	auipc	a0,0x5
    1b00:	a4c50513          	addi	a0,a0,-1460 # 6548 <malloc+0x9c2>
    1b04:	7cf030ef          	jal	5ad2 <printf>
      exit(1);
    1b08:	4505                	li	a0,1
    1b0a:	379030ef          	jal	5682 <exit>
      *(char *)a = 99;
    1b0e:	fd843783          	ld	a5,-40(s0)
    1b12:	06300713          	li	a4,99
    1b16:	00e78023          	sb	a4,0(a5)
      printf("%s: oops wrote %p\n", s, (void *)a);
    1b1a:	fd843603          	ld	a2,-40(s0)
    1b1e:	85ca                	mv	a1,s2
    1b20:	00005517          	auipc	a0,0x5
    1b24:	cb050513          	addi	a0,a0,-848 # 67d0 <malloc+0xc4a>
    1b28:	7ab030ef          	jal	5ad2 <printf>
      exit(1);
    1b2c:	4505                	li	a0,1
    1b2e:	355030ef          	jal	5682 <exit>
      exit(1);
    1b32:	4505                	li	a0,1
    1b34:	34f030ef          	jal	5682 <exit>

0000000000001b38 <stacktest>:
{
    1b38:	7179                	addi	sp,sp,-48
    1b3a:	f406                	sd	ra,40(sp)
    1b3c:	f022                	sd	s0,32(sp)
    1b3e:	ec26                	sd	s1,24(sp)
    1b40:	1800                	addi	s0,sp,48
    1b42:	84aa                	mv	s1,a0
  pid = fork();
    1b44:	337030ef          	jal	567a <fork>
  if (pid == 0) {
    1b48:	cd11                	beqz	a0,1b64 <stacktest+0x2c>
  } else if (pid < 0) {
    1b4a:	02054c63          	bltz	a0,1b82 <stacktest+0x4a>
  wait(&xstatus);
    1b4e:	fdc40513          	addi	a0,s0,-36
    1b52:	339030ef          	jal	568a <wait>
  if (xstatus == -1) // kernel killed child?
    1b56:	fdc42503          	lw	a0,-36(s0)
    1b5a:	57fd                	li	a5,-1
    1b5c:	02f50d63          	beq	a0,a5,1b96 <stacktest+0x5e>
    exit(xstatus);
    1b60:	323030ef          	jal	5682 <exit>

static inline uint64
r_sp()
{
  uint64 x;
  asm volatile("mv %0, sp" : "=r"(x));
    1b64:	870a                	mv	a4,sp
    printf("%s: stacktest: read below stack %d\n", s, *sp);
    1b66:	77fd                	lui	a5,0xfffff
    1b68:	97ba                	add	a5,a5,a4
    1b6a:	0007c603          	lbu	a2,0(a5) # fffffffffffff000 <base+0xfffffffffffee2f8>
    1b6e:	85a6                	mv	a1,s1
    1b70:	00005517          	auipc	a0,0x5
    1b74:	c7850513          	addi	a0,a0,-904 # 67e8 <malloc+0xc62>
    1b78:	75b030ef          	jal	5ad2 <printf>
    exit(1);
    1b7c:	4505                	li	a0,1
    1b7e:	305030ef          	jal	5682 <exit>
    printf("%s: fork failed\n", s);
    1b82:	85a6                	mv	a1,s1
    1b84:	00005517          	auipc	a0,0x5
    1b88:	9c450513          	addi	a0,a0,-1596 # 6548 <malloc+0x9c2>
    1b8c:	747030ef          	jal	5ad2 <printf>
    exit(1);
    1b90:	4505                	li	a0,1
    1b92:	2f1030ef          	jal	5682 <exit>
    exit(0);
    1b96:	4501                	li	a0,0
    1b98:	2eb030ef          	jal	5682 <exit>

0000000000001b9c <nowrite>:
{
    1b9c:	7159                	addi	sp,sp,-112
    1b9e:	f486                	sd	ra,104(sp)
    1ba0:	f0a2                	sd	s0,96(sp)
    1ba2:	eca6                	sd	s1,88(sp)
    1ba4:	e8ca                	sd	s2,80(sp)
    1ba6:	e4ce                	sd	s3,72(sp)
    1ba8:	1880                	addi	s0,sp,112
    1baa:	89aa                	mv	s3,a0
  uint64 addrs[] = {0,
    1bac:	00007797          	auipc	a5,0x7
    1bb0:	ac478793          	addi	a5,a5,-1340 # 8670 <malloc+0x2aea>
    1bb4:	7788                	ld	a0,40(a5)
    1bb6:	7b8c                	ld	a1,48(a5)
    1bb8:	7f90                	ld	a2,56(a5)
    1bba:	63b4                	ld	a3,64(a5)
    1bbc:	67b8                	ld	a4,72(a5)
    1bbe:	6bbc                	ld	a5,80(a5)
    1bc0:	f8a43c23          	sd	a0,-104(s0)
    1bc4:	fab43023          	sd	a1,-96(s0)
    1bc8:	fac43423          	sd	a2,-88(s0)
    1bcc:	fad43823          	sd	a3,-80(s0)
    1bd0:	fae43c23          	sd	a4,-72(s0)
    1bd4:	fcf43023          	sd	a5,-64(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1bd8:	4481                	li	s1,0
    1bda:	4919                	li	s2,6
    pid = fork();
    1bdc:	29f030ef          	jal	567a <fork>
    if (pid == 0) {
    1be0:	c105                	beqz	a0,1c00 <nowrite+0x64>
    } else if (pid < 0) {
    1be2:	04054263          	bltz	a0,1c26 <nowrite+0x8a>
    wait(&xstatus);
    1be6:	fcc40513          	addi	a0,s0,-52
    1bea:	2a1030ef          	jal	568a <wait>
    if (xstatus == 0) {
    1bee:	fcc42783          	lw	a5,-52(s0)
    1bf2:	c7a1                	beqz	a5,1c3a <nowrite+0x9e>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1bf4:	2485                	addiw	s1,s1,1
    1bf6:	ff2493e3          	bne	s1,s2,1bdc <nowrite+0x40>
  exit(0);
    1bfa:	4501                	li	a0,0
    1bfc:	287030ef          	jal	5682 <exit>
      volatile int *addr = (int *)addrs[ai];
    1c00:	048e                	slli	s1,s1,0x3
    1c02:	fd048793          	addi	a5,s1,-48
    1c06:	008784b3          	add	s1,a5,s0
    1c0a:	fc84b603          	ld	a2,-56(s1)
      *addr = 10;
    1c0e:	47a9                	li	a5,10
    1c10:	c21c                	sw	a5,0(a2)
      printf("%s: write to %p did not fail!\n", s, addr);
    1c12:	85ce                	mv	a1,s3
    1c14:	00005517          	auipc	a0,0x5
    1c18:	bfc50513          	addi	a0,a0,-1028 # 6810 <malloc+0xc8a>
    1c1c:	6b7030ef          	jal	5ad2 <printf>
      exit(0);
    1c20:	4501                	li	a0,0
    1c22:	261030ef          	jal	5682 <exit>
      printf("%s: fork failed\n", s);
    1c26:	85ce                	mv	a1,s3
    1c28:	00005517          	auipc	a0,0x5
    1c2c:	92050513          	addi	a0,a0,-1760 # 6548 <malloc+0x9c2>
    1c30:	6a3030ef          	jal	5ad2 <printf>
      exit(1);
    1c34:	4505                	li	a0,1
    1c36:	24d030ef          	jal	5682 <exit>
      exit(1);
    1c3a:	4505                	li	a0,1
    1c3c:	247030ef          	jal	5682 <exit>

0000000000001c40 <manywrites>:
{
    1c40:	711d                	addi	sp,sp,-96
    1c42:	ec86                	sd	ra,88(sp)
    1c44:	e8a2                	sd	s0,80(sp)
    1c46:	e4a6                	sd	s1,72(sp)
    1c48:	e0ca                	sd	s2,64(sp)
    1c4a:	fc4e                	sd	s3,56(sp)
    1c4c:	f456                	sd	s5,40(sp)
    1c4e:	1080                	addi	s0,sp,96
    1c50:	8aaa                	mv	s5,a0
  for (int ci = 0; ci < nchildren; ci++) {
    1c52:	4981                	li	s3,0
    1c54:	4911                	li	s2,4
    int pid = fork();
    1c56:	225030ef          	jal	567a <fork>
    1c5a:	84aa                	mv	s1,a0
    if (pid < 0) {
    1c5c:	02054963          	bltz	a0,1c8e <manywrites+0x4e>
    if (pid == 0) {
    1c60:	c139                	beqz	a0,1ca6 <manywrites+0x66>
  for (int ci = 0; ci < nchildren; ci++) {
    1c62:	2985                	addiw	s3,s3,1
    1c64:	ff2999e3          	bne	s3,s2,1c56 <manywrites+0x16>
    1c68:	f852                	sd	s4,48(sp)
    1c6a:	f05a                	sd	s6,32(sp)
    1c6c:	ec5e                	sd	s7,24(sp)
    1c6e:	4491                	li	s1,4
    int st = 0;
    1c70:	fa042423          	sw	zero,-88(s0)
    wait(&st);
    1c74:	fa840513          	addi	a0,s0,-88
    1c78:	213030ef          	jal	568a <wait>
    if (st != 0)
    1c7c:	fa842503          	lw	a0,-88(s0)
    1c80:	0c051863          	bnez	a0,1d50 <manywrites+0x110>
  for (int ci = 0; ci < nchildren; ci++) {
    1c84:	34fd                	addiw	s1,s1,-1
    1c86:	f4ed                	bnez	s1,1c70 <manywrites+0x30>
  exit(0);
    1c88:	4501                	li	a0,0
    1c8a:	1f9030ef          	jal	5682 <exit>
    1c8e:	f852                	sd	s4,48(sp)
    1c90:	f05a                	sd	s6,32(sp)
    1c92:	ec5e                	sd	s7,24(sp)
      printf("fork failed\n");
    1c94:	00006517          	auipc	a0,0x6
    1c98:	03450513          	addi	a0,a0,52 # 7cc8 <malloc+0x2142>
    1c9c:	637030ef          	jal	5ad2 <printf>
      exit(1);
    1ca0:	4505                	li	a0,1
    1ca2:	1e1030ef          	jal	5682 <exit>
    1ca6:	f852                	sd	s4,48(sp)
    1ca8:	f05a                	sd	s6,32(sp)
    1caa:	ec5e                	sd	s7,24(sp)
      name[0] = 'b';
    1cac:	06200793          	li	a5,98
    1cb0:	faf40423          	sb	a5,-88(s0)
      name[1] = 'a' + ci;
    1cb4:	0619879b          	addiw	a5,s3,97
    1cb8:	faf404a3          	sb	a5,-87(s0)
      name[2] = '\0';
    1cbc:	fa040523          	sb	zero,-86(s0)
      unlink(name);
    1cc0:	fa840513          	addi	a0,s0,-88
    1cc4:	20f030ef          	jal	56d2 <unlink>
    1cc8:	4bf9                	li	s7,30
          int cc = write(fd, buf, sz);
    1cca:	0000cb17          	auipc	s6,0xc
    1cce:	03eb0b13          	addi	s6,s6,62 # dd08 <buf>
        for (int i = 0; i < ci + 1; i++) {
    1cd2:	8a26                	mv	s4,s1
    1cd4:	0209c863          	bltz	s3,1d04 <manywrites+0xc4>
          int fd = open(name, O_CREATE | O_RDWR);
    1cd8:	20200593          	li	a1,514
    1cdc:	fa840513          	addi	a0,s0,-88
    1ce0:	1e3030ef          	jal	56c2 <open>
    1ce4:	892a                	mv	s2,a0
          if (fd < 0) {
    1ce6:	02054d63          	bltz	a0,1d20 <manywrites+0xe0>
          int cc = write(fd, buf, sz);
    1cea:	660d                	lui	a2,0x3
    1cec:	85da                	mv	a1,s6
    1cee:	1b5030ef          	jal	56a2 <write>
          if (cc != sz) {
    1cf2:	678d                	lui	a5,0x3
    1cf4:	04f51263          	bne	a0,a5,1d38 <manywrites+0xf8>
          close(fd);
    1cf8:	854a                	mv	a0,s2
    1cfa:	1b1030ef          	jal	56aa <close>
        for (int i = 0; i < ci + 1; i++) {
    1cfe:	2a05                	addiw	s4,s4,1
    1d00:	fd49dce3          	bge	s3,s4,1cd8 <manywrites+0x98>
        unlink(name);
    1d04:	fa840513          	addi	a0,s0,-88
    1d08:	1cb030ef          	jal	56d2 <unlink>
      for (int iters = 0; iters < howmany; iters++) {
    1d0c:	3bfd                	addiw	s7,s7,-1
    1d0e:	fc0b92e3          	bnez	s7,1cd2 <manywrites+0x92>
      unlink(name);
    1d12:	fa840513          	addi	a0,s0,-88
    1d16:	1bd030ef          	jal	56d2 <unlink>
      exit(0);
    1d1a:	4501                	li	a0,0
    1d1c:	167030ef          	jal	5682 <exit>
            printf("%s: cannot create %s\n", s, name);
    1d20:	fa840613          	addi	a2,s0,-88
    1d24:	85d6                	mv	a1,s5
    1d26:	00005517          	auipc	a0,0x5
    1d2a:	b0a50513          	addi	a0,a0,-1270 # 6830 <malloc+0xcaa>
    1d2e:	5a5030ef          	jal	5ad2 <printf>
            exit(1);
    1d32:	4505                	li	a0,1
    1d34:	14f030ef          	jal	5682 <exit>
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    1d38:	86aa                	mv	a3,a0
    1d3a:	660d                	lui	a2,0x3
    1d3c:	85d6                	mv	a1,s5
    1d3e:	00004517          	auipc	a0,0x4
    1d42:	04a50513          	addi	a0,a0,74 # 5d88 <malloc+0x202>
    1d46:	58d030ef          	jal	5ad2 <printf>
            exit(1);
    1d4a:	4505                	li	a0,1
    1d4c:	137030ef          	jal	5682 <exit>
      exit(st);
    1d50:	133030ef          	jal	5682 <exit>

0000000000001d54 <copyinstr3>:
{
    1d54:	7179                	addi	sp,sp,-48
    1d56:	f406                	sd	ra,40(sp)
    1d58:	f022                	sd	s0,32(sp)
    1d5a:	ec26                	sd	s1,24(sp)
    1d5c:	1800                	addi	s0,sp,48
  sbrk(8192);
    1d5e:	6509                	lui	a0,0x2
    1d60:	0ef030ef          	jal	564e <sbrk>
  uint64 top = (uint64)sbrk(0);
    1d64:	4501                	li	a0,0
    1d66:	0e9030ef          	jal	564e <sbrk>
  if ((top % PGSIZE) != 0) {
    1d6a:	03451793          	slli	a5,a0,0x34
    1d6e:	e7bd                	bnez	a5,1ddc <copyinstr3+0x88>
  top = (uint64)sbrk(0);
    1d70:	4501                	li	a0,0
    1d72:	0dd030ef          	jal	564e <sbrk>
  if (top % PGSIZE) {
    1d76:	03451793          	slli	a5,a0,0x34
    1d7a:	ebad                	bnez	a5,1dec <copyinstr3+0x98>
  char *b = (char *)(top - 1);
    1d7c:	fff50493          	addi	s1,a0,-1 # 1fff <sbrkbasic+0xa1>
  *b = 'x';
    1d80:	07800793          	li	a5,120
    1d84:	fef50fa3          	sb	a5,-1(a0)
  int ret = unlink(b);
    1d88:	8526                	mv	a0,s1
    1d8a:	149030ef          	jal	56d2 <unlink>
  if (ret != -1) {
    1d8e:	57fd                	li	a5,-1
    1d90:	06f51763          	bne	a0,a5,1dfe <copyinstr3+0xaa>
  int fd = open(b, O_CREATE | O_WRONLY);
    1d94:	20100593          	li	a1,513
    1d98:	8526                	mv	a0,s1
    1d9a:	129030ef          	jal	56c2 <open>
  if (fd != -1) {
    1d9e:	57fd                	li	a5,-1
    1da0:	06f51a63          	bne	a0,a5,1e14 <copyinstr3+0xc0>
  ret = link(b, b);
    1da4:	85a6                	mv	a1,s1
    1da6:	8526                	mv	a0,s1
    1da8:	13b030ef          	jal	56e2 <link>
  if (ret != -1) {
    1dac:	57fd                	li	a5,-1
    1dae:	06f51e63          	bne	a0,a5,1e2a <copyinstr3+0xd6>
  char *args[] = {"xx", 0};
    1db2:	00005797          	auipc	a5,0x5
    1db6:	77e78793          	addi	a5,a5,1918 # 7530 <malloc+0x19aa>
    1dba:	fcf43823          	sd	a5,-48(s0)
    1dbe:	fc043c23          	sd	zero,-40(s0)
  ret = exec(b, args);
    1dc2:	fd040593          	addi	a1,s0,-48
    1dc6:	8526                	mv	a0,s1
    1dc8:	0f3030ef          	jal	56ba <exec>
  if (ret != -1) {
    1dcc:	57fd                	li	a5,-1
    1dce:	06f51a63          	bne	a0,a5,1e42 <copyinstr3+0xee>
}
    1dd2:	70a2                	ld	ra,40(sp)
    1dd4:	7402                	ld	s0,32(sp)
    1dd6:	64e2                	ld	s1,24(sp)
    1dd8:	6145                	addi	sp,sp,48
    1dda:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    1ddc:	0347d513          	srli	a0,a5,0x34
    1de0:	6785                	lui	a5,0x1
    1de2:	40a7853b          	subw	a0,a5,a0
    1de6:	069030ef          	jal	564e <sbrk>
    1dea:	b759                	j	1d70 <copyinstr3+0x1c>
    printf("oops\n");
    1dec:	00005517          	auipc	a0,0x5
    1df0:	a5c50513          	addi	a0,a0,-1444 # 6848 <malloc+0xcc2>
    1df4:	4df030ef          	jal	5ad2 <printf>
    exit(1);
    1df8:	4505                	li	a0,1
    1dfa:	089030ef          	jal	5682 <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1dfe:	862a                	mv	a2,a0
    1e00:	85a6                	mv	a1,s1
    1e02:	00004517          	auipc	a0,0x4
    1e06:	66650513          	addi	a0,a0,1638 # 6468 <malloc+0x8e2>
    1e0a:	4c9030ef          	jal	5ad2 <printf>
    exit(1);
    1e0e:	4505                	li	a0,1
    1e10:	073030ef          	jal	5682 <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    1e14:	862a                	mv	a2,a0
    1e16:	85a6                	mv	a1,s1
    1e18:	00004517          	auipc	a0,0x4
    1e1c:	67050513          	addi	a0,a0,1648 # 6488 <malloc+0x902>
    1e20:	4b3030ef          	jal	5ad2 <printf>
    exit(1);
    1e24:	4505                	li	a0,1
    1e26:	05d030ef          	jal	5682 <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    1e2a:	86aa                	mv	a3,a0
    1e2c:	8626                	mv	a2,s1
    1e2e:	85a6                	mv	a1,s1
    1e30:	00004517          	auipc	a0,0x4
    1e34:	67850513          	addi	a0,a0,1656 # 64a8 <malloc+0x922>
    1e38:	49b030ef          	jal	5ad2 <printf>
    exit(1);
    1e3c:	4505                	li	a0,1
    1e3e:	045030ef          	jal	5682 <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    1e42:	567d                	li	a2,-1
    1e44:	85a6                	mv	a1,s1
    1e46:	00004517          	auipc	a0,0x4
    1e4a:	68a50513          	addi	a0,a0,1674 # 64d0 <malloc+0x94a>
    1e4e:	485030ef          	jal	5ad2 <printf>
    exit(1);
    1e52:	4505                	li	a0,1
    1e54:	02f030ef          	jal	5682 <exit>

0000000000001e58 <rwsbrk>:
{
    1e58:	1101                	addi	sp,sp,-32
    1e5a:	ec06                	sd	ra,24(sp)
    1e5c:	e822                	sd	s0,16(sp)
    1e5e:	1000                	addi	s0,sp,32
  uint64 a = (uint64)sbrk(8192);
    1e60:	6509                	lui	a0,0x2
    1e62:	7ec030ef          	jal	564e <sbrk>
  if (a == (uint64)SBRK_ERROR) {
    1e66:	57fd                	li	a5,-1
    1e68:	04f50a63          	beq	a0,a5,1ebc <rwsbrk+0x64>
    1e6c:	e426                	sd	s1,8(sp)
    1e6e:	84aa                	mv	s1,a0
  if (sbrk(-8192) == SBRK_ERROR) {
    1e70:	7579                	lui	a0,0xffffe
    1e72:	7dc030ef          	jal	564e <sbrk>
    1e76:	57fd                	li	a5,-1
    1e78:	04f50d63          	beq	a0,a5,1ed2 <rwsbrk+0x7a>
    1e7c:	e04a                	sd	s2,0(sp)
  fd = open("rwsbrk", O_CREATE | O_WRONLY);
    1e7e:	20100593          	li	a1,513
    1e82:	00005517          	auipc	a0,0x5
    1e86:	a0650513          	addi	a0,a0,-1530 # 6888 <malloc+0xd02>
    1e8a:	039030ef          	jal	56c2 <open>
    1e8e:	892a                	mv	s2,a0
  if (fd < 0) {
    1e90:	04054b63          	bltz	a0,1ee6 <rwsbrk+0x8e>
  n = write(fd, (void *)(a + PGSIZE), 1024);
    1e94:	6785                	lui	a5,0x1
    1e96:	94be                	add	s1,s1,a5
    1e98:	40000613          	li	a2,1024
    1e9c:	85a6                	mv	a1,s1
    1e9e:	005030ef          	jal	56a2 <write>
    1ea2:	862a                	mv	a2,a0
  if (n >= 0) {
    1ea4:	04054a63          	bltz	a0,1ef8 <rwsbrk+0xa0>
    printf("write(fd, %p, 1024) returned %d, not -1\n", (void *)a + PGSIZE, n);
    1ea8:	85a6                	mv	a1,s1
    1eaa:	00005517          	auipc	a0,0x5
    1eae:	9fe50513          	addi	a0,a0,-1538 # 68a8 <malloc+0xd22>
    1eb2:	421030ef          	jal	5ad2 <printf>
    exit(1);
    1eb6:	4505                	li	a0,1
    1eb8:	7ca030ef          	jal	5682 <exit>
    1ebc:	e426                	sd	s1,8(sp)
    1ebe:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) failed\n");
    1ec0:	00005517          	auipc	a0,0x5
    1ec4:	99050513          	addi	a0,a0,-1648 # 6850 <malloc+0xcca>
    1ec8:	40b030ef          	jal	5ad2 <printf>
    exit(1);
    1ecc:	4505                	li	a0,1
    1ece:	7b4030ef          	jal	5682 <exit>
    1ed2:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) shrink failed\n");
    1ed4:	00005517          	auipc	a0,0x5
    1ed8:	99450513          	addi	a0,a0,-1644 # 6868 <malloc+0xce2>
    1edc:	3f7030ef          	jal	5ad2 <printf>
    exit(1);
    1ee0:	4505                	li	a0,1
    1ee2:	7a0030ef          	jal	5682 <exit>
    printf("open(rwsbrk) failed\n");
    1ee6:	00005517          	auipc	a0,0x5
    1eea:	9aa50513          	addi	a0,a0,-1622 # 6890 <malloc+0xd0a>
    1eee:	3e5030ef          	jal	5ad2 <printf>
    exit(1);
    1ef2:	4505                	li	a0,1
    1ef4:	78e030ef          	jal	5682 <exit>
  close(fd);
    1ef8:	854a                	mv	a0,s2
    1efa:	7b0030ef          	jal	56aa <close>
  unlink("rwsbrk");
    1efe:	00005517          	auipc	a0,0x5
    1f02:	98a50513          	addi	a0,a0,-1654 # 6888 <malloc+0xd02>
    1f06:	7cc030ef          	jal	56d2 <unlink>
  fd = open("README", O_RDONLY);
    1f0a:	4581                	li	a1,0
    1f0c:	00004517          	auipc	a0,0x4
    1f10:	f8450513          	addi	a0,a0,-124 # 5e90 <malloc+0x30a>
    1f14:	7ae030ef          	jal	56c2 <open>
    1f18:	892a                	mv	s2,a0
  if (fd < 0) {
    1f1a:	02054363          	bltz	a0,1f40 <rwsbrk+0xe8>
  n = read(fd, (void *)(a + PGSIZE), 10);
    1f1e:	4629                	li	a2,10
    1f20:	85a6                	mv	a1,s1
    1f22:	778030ef          	jal	569a <read>
    1f26:	862a                	mv	a2,a0
  if (n >= 0) {
    1f28:	02054563          	bltz	a0,1f52 <rwsbrk+0xfa>
    printf("read(fd, %p, 10) returned %d, not -1\n", (void *)a + PGSIZE, n);
    1f2c:	85a6                	mv	a1,s1
    1f2e:	00005517          	auipc	a0,0x5
    1f32:	9aa50513          	addi	a0,a0,-1622 # 68d8 <malloc+0xd52>
    1f36:	39d030ef          	jal	5ad2 <printf>
    exit(1);
    1f3a:	4505                	li	a0,1
    1f3c:	746030ef          	jal	5682 <exit>
    printf("open(README) failed\n");
    1f40:	00004517          	auipc	a0,0x4
    1f44:	f5850513          	addi	a0,a0,-168 # 5e98 <malloc+0x312>
    1f48:	38b030ef          	jal	5ad2 <printf>
    exit(1);
    1f4c:	4505                	li	a0,1
    1f4e:	734030ef          	jal	5682 <exit>
  close(fd);
    1f52:	854a                	mv	a0,s2
    1f54:	756030ef          	jal	56aa <close>
  exit(0);
    1f58:	4501                	li	a0,0
    1f5a:	728030ef          	jal	5682 <exit>

0000000000001f5e <sbrkbasic>:
{
    1f5e:	7139                	addi	sp,sp,-64
    1f60:	fc06                	sd	ra,56(sp)
    1f62:	f822                	sd	s0,48(sp)
    1f64:	ec4e                	sd	s3,24(sp)
    1f66:	0080                	addi	s0,sp,64
    1f68:	89aa                	mv	s3,a0
  pid = fork();
    1f6a:	710030ef          	jal	567a <fork>
  if (pid < 0) {
    1f6e:	02054b63          	bltz	a0,1fa4 <sbrkbasic+0x46>
  if (pid == 0) {
    1f72:	e939                	bnez	a0,1fc8 <sbrkbasic+0x6a>
    a = sbrk(TOOMUCH);
    1f74:	40000537          	lui	a0,0x40000
    1f78:	6d6030ef          	jal	564e <sbrk>
    if (a == (char *)SBRK_ERROR) {
    1f7c:	57fd                	li	a5,-1
    1f7e:	02f50f63          	beq	a0,a5,1fbc <sbrkbasic+0x5e>
    1f82:	f426                	sd	s1,40(sp)
    1f84:	f04a                	sd	s2,32(sp)
    1f86:	e852                	sd	s4,16(sp)
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    1f88:	400007b7          	lui	a5,0x40000
    1f8c:	97aa                	add	a5,a5,a0
      *b = 99;
    1f8e:	06300693          	li	a3,99
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    1f92:	6705                	lui	a4,0x1
      *b = 99;
    1f94:	00d50023          	sb	a3,0(a0) # 40000000 <base+0x3ffef2f8>
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    1f98:	953a                	add	a0,a0,a4
    1f9a:	fef51de3          	bne	a0,a5,1f94 <sbrkbasic+0x36>
    exit(1);
    1f9e:	4505                	li	a0,1
    1fa0:	6e2030ef          	jal	5682 <exit>
    1fa4:	f426                	sd	s1,40(sp)
    1fa6:	f04a                	sd	s2,32(sp)
    1fa8:	e852                	sd	s4,16(sp)
    printf("fork failed in sbrkbasic\n");
    1faa:	00005517          	auipc	a0,0x5
    1fae:	95650513          	addi	a0,a0,-1706 # 6900 <malloc+0xd7a>
    1fb2:	321030ef          	jal	5ad2 <printf>
    exit(1);
    1fb6:	4505                	li	a0,1
    1fb8:	6ca030ef          	jal	5682 <exit>
    1fbc:	f426                	sd	s1,40(sp)
    1fbe:	f04a                	sd	s2,32(sp)
    1fc0:	e852                	sd	s4,16(sp)
      exit(0);
    1fc2:	4501                	li	a0,0
    1fc4:	6be030ef          	jal	5682 <exit>
  wait(&xstatus);
    1fc8:	fcc40513          	addi	a0,s0,-52
    1fcc:	6be030ef          	jal	568a <wait>
  if (xstatus == 1) {
    1fd0:	fcc42703          	lw	a4,-52(s0)
    1fd4:	4785                	li	a5,1
    1fd6:	00f70e63          	beq	a4,a5,1ff2 <sbrkbasic+0x94>
    1fda:	f426                	sd	s1,40(sp)
    1fdc:	f04a                	sd	s2,32(sp)
    1fde:	e852                	sd	s4,16(sp)
  a = sbrk(0);
    1fe0:	4501                	li	a0,0
    1fe2:	66c030ef          	jal	564e <sbrk>
    1fe6:	84aa                	mv	s1,a0
  for (i = 0; i < 5000; i++) {
    1fe8:	4901                	li	s2,0
    1fea:	6a05                	lui	s4,0x1
    1fec:	388a0a13          	addi	s4,s4,904 # 1388 <pipe1+0x4a>
    1ff0:	a839                	j	200e <sbrkbasic+0xb0>
    1ff2:	f426                	sd	s1,40(sp)
    1ff4:	f04a                	sd	s2,32(sp)
    1ff6:	e852                	sd	s4,16(sp)
    printf("%s: too much memory allocated!\n", s);
    1ff8:	85ce                	mv	a1,s3
    1ffa:	00005517          	auipc	a0,0x5
    1ffe:	92650513          	addi	a0,a0,-1754 # 6920 <malloc+0xd9a>
    2002:	2d1030ef          	jal	5ad2 <printf>
    exit(1);
    2006:	4505                	li	a0,1
    2008:	67a030ef          	jal	5682 <exit>
    200c:	84be                	mv	s1,a5
    b = sbrk(1);
    200e:	4505                	li	a0,1
    2010:	63e030ef          	jal	564e <sbrk>
    if (b != a) {
    2014:	04951263          	bne	a0,s1,2058 <sbrkbasic+0xfa>
    *b = 1;
    2018:	4785                	li	a5,1
    201a:	00f48023          	sb	a5,0(s1)
    a = b + 1;
    201e:	00148793          	addi	a5,s1,1
  for (i = 0; i < 5000; i++) {
    2022:	2905                	addiw	s2,s2,1
    2024:	ff4914e3          	bne	s2,s4,200c <sbrkbasic+0xae>
  pid = fork();
    2028:	652030ef          	jal	567a <fork>
    202c:	892a                	mv	s2,a0
  if (pid < 0) {
    202e:	04054263          	bltz	a0,2072 <sbrkbasic+0x114>
  c = sbrk(1);
    2032:	4505                	li	a0,1
    2034:	61a030ef          	jal	564e <sbrk>
  c = sbrk(1);
    2038:	4505                	li	a0,1
    203a:	614030ef          	jal	564e <sbrk>
  if (c != a + 1) {
    203e:	0489                	addi	s1,s1,2
    2040:	04a48363          	beq	s1,a0,2086 <sbrkbasic+0x128>
    printf("%s: sbrk test failed post-fork\n", s);
    2044:	85ce                	mv	a1,s3
    2046:	00005517          	auipc	a0,0x5
    204a:	93a50513          	addi	a0,a0,-1734 # 6980 <malloc+0xdfa>
    204e:	285030ef          	jal	5ad2 <printf>
    exit(1);
    2052:	4505                	li	a0,1
    2054:	62e030ef          	jal	5682 <exit>
      printf("%s: sbrk test failed %d %p %p\n", s, i, a, b);
    2058:	872a                	mv	a4,a0
    205a:	86a6                	mv	a3,s1
    205c:	864a                	mv	a2,s2
    205e:	85ce                	mv	a1,s3
    2060:	00005517          	auipc	a0,0x5
    2064:	8e050513          	addi	a0,a0,-1824 # 6940 <malloc+0xdba>
    2068:	26b030ef          	jal	5ad2 <printf>
      exit(1);
    206c:	4505                	li	a0,1
    206e:	614030ef          	jal	5682 <exit>
    printf("%s: sbrk test fork failed\n", s);
    2072:	85ce                	mv	a1,s3
    2074:	00005517          	auipc	a0,0x5
    2078:	8ec50513          	addi	a0,a0,-1812 # 6960 <malloc+0xdda>
    207c:	257030ef          	jal	5ad2 <printf>
    exit(1);
    2080:	4505                	li	a0,1
    2082:	600030ef          	jal	5682 <exit>
  if (pid == 0)
    2086:	00091563          	bnez	s2,2090 <sbrkbasic+0x132>
    exit(0);
    208a:	4501                	li	a0,0
    208c:	5f6030ef          	jal	5682 <exit>
  wait(&xstatus);
    2090:	fcc40513          	addi	a0,s0,-52
    2094:	5f6030ef          	jal	568a <wait>
  exit(xstatus);
    2098:	fcc42503          	lw	a0,-52(s0)
    209c:	5e6030ef          	jal	5682 <exit>

00000000000020a0 <sbrkmuch>:
{
    20a0:	7179                	addi	sp,sp,-48
    20a2:	f406                	sd	ra,40(sp)
    20a4:	f022                	sd	s0,32(sp)
    20a6:	ec26                	sd	s1,24(sp)
    20a8:	e84a                	sd	s2,16(sp)
    20aa:	e44e                	sd	s3,8(sp)
    20ac:	e052                	sd	s4,0(sp)
    20ae:	1800                	addi	s0,sp,48
    20b0:	89aa                	mv	s3,a0
  oldbrk = sbrk(0);
    20b2:	4501                	li	a0,0
    20b4:	59a030ef          	jal	564e <sbrk>
    20b8:	892a                	mv	s2,a0
  a = sbrk(0);
    20ba:	4501                	li	a0,0
    20bc:	592030ef          	jal	564e <sbrk>
    20c0:	84aa                	mv	s1,a0
  p = sbrk(amt);
    20c2:	06400537          	lui	a0,0x6400
    20c6:	9d05                	subw	a0,a0,s1
    20c8:	586030ef          	jal	564e <sbrk>
  if (p != a) {
    20cc:	08a49763          	bne	s1,a0,215a <sbrkmuch+0xba>
  *lastaddr = 99;
    20d0:	064007b7          	lui	a5,0x6400
    20d4:	06300713          	li	a4,99
    20d8:	fee78fa3          	sb	a4,-1(a5) # 63fffff <base+0x63ef2f7>
  a = sbrk(0);
    20dc:	4501                	li	a0,0
    20de:	570030ef          	jal	564e <sbrk>
    20e2:	84aa                	mv	s1,a0
  c = sbrk(-PGSIZE);
    20e4:	757d                	lui	a0,0xfffff
    20e6:	568030ef          	jal	564e <sbrk>
  if (c == (char *)SBRK_ERROR) {
    20ea:	57fd                	li	a5,-1
    20ec:	08f50163          	beq	a0,a5,216e <sbrkmuch+0xce>
  c = sbrk(0);
    20f0:	4501                	li	a0,0
    20f2:	55c030ef          	jal	564e <sbrk>
  if (c != a - PGSIZE) {
    20f6:	77fd                	lui	a5,0xfffff
    20f8:	97a6                	add	a5,a5,s1
    20fa:	08f51463          	bne	a0,a5,2182 <sbrkmuch+0xe2>
  a = sbrk(0);
    20fe:	4501                	li	a0,0
    2100:	54e030ef          	jal	564e <sbrk>
    2104:	84aa                	mv	s1,a0
  c = sbrk(PGSIZE);
    2106:	6505                	lui	a0,0x1
    2108:	546030ef          	jal	564e <sbrk>
    210c:	8a2a                	mv	s4,a0
  if (c != a || sbrk(0) != a + PGSIZE) {
    210e:	08a49663          	bne	s1,a0,219a <sbrkmuch+0xfa>
    2112:	4501                	li	a0,0
    2114:	53a030ef          	jal	564e <sbrk>
    2118:	6785                	lui	a5,0x1
    211a:	97a6                	add	a5,a5,s1
    211c:	06f51f63          	bne	a0,a5,219a <sbrkmuch+0xfa>
  if (*lastaddr == 99) {
    2120:	064007b7          	lui	a5,0x6400
    2124:	fff7c703          	lbu	a4,-1(a5) # 63fffff <base+0x63ef2f7>
    2128:	06300793          	li	a5,99
    212c:	08f70363          	beq	a4,a5,21b2 <sbrkmuch+0x112>
  a = sbrk(0);
    2130:	4501                	li	a0,0
    2132:	51c030ef          	jal	564e <sbrk>
    2136:	84aa                	mv	s1,a0
  c = sbrk(-(sbrk(0) - oldbrk));
    2138:	4501                	li	a0,0
    213a:	514030ef          	jal	564e <sbrk>
    213e:	40a9053b          	subw	a0,s2,a0
    2142:	50c030ef          	jal	564e <sbrk>
  if (c != a) {
    2146:	08a49063          	bne	s1,a0,21c6 <sbrkmuch+0x126>
}
    214a:	70a2                	ld	ra,40(sp)
    214c:	7402                	ld	s0,32(sp)
    214e:	64e2                	ld	s1,24(sp)
    2150:	6942                	ld	s2,16(sp)
    2152:	69a2                	ld	s3,8(sp)
    2154:	6a02                	ld	s4,0(sp)
    2156:	6145                	addi	sp,sp,48
    2158:	8082                	ret
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n",
    215a:	85ce                	mv	a1,s3
    215c:	00005517          	auipc	a0,0x5
    2160:	84450513          	addi	a0,a0,-1980 # 69a0 <malloc+0xe1a>
    2164:	16f030ef          	jal	5ad2 <printf>
    exit(1);
    2168:	4505                	li	a0,1
    216a:	518030ef          	jal	5682 <exit>
    printf("%s: sbrk could not deallocate\n", s);
    216e:	85ce                	mv	a1,s3
    2170:	00005517          	auipc	a0,0x5
    2174:	87850513          	addi	a0,a0,-1928 # 69e8 <malloc+0xe62>
    2178:	15b030ef          	jal	5ad2 <printf>
    exit(1);
    217c:	4505                	li	a0,1
    217e:	504030ef          	jal	5682 <exit>
    printf("%s: sbrk deallocation produced wrong address, a %p c %p\n", s, a,
    2182:	86aa                	mv	a3,a0
    2184:	8626                	mv	a2,s1
    2186:	85ce                	mv	a1,s3
    2188:	00005517          	auipc	a0,0x5
    218c:	88050513          	addi	a0,a0,-1920 # 6a08 <malloc+0xe82>
    2190:	143030ef          	jal	5ad2 <printf>
    exit(1);
    2194:	4505                	li	a0,1
    2196:	4ec030ef          	jal	5682 <exit>
    printf("%s: sbrk re-allocation failed, a %p c %p\n", s, a, c);
    219a:	86d2                	mv	a3,s4
    219c:	8626                	mv	a2,s1
    219e:	85ce                	mv	a1,s3
    21a0:	00005517          	auipc	a0,0x5
    21a4:	8a850513          	addi	a0,a0,-1880 # 6a48 <malloc+0xec2>
    21a8:	12b030ef          	jal	5ad2 <printf>
    exit(1);
    21ac:	4505                	li	a0,1
    21ae:	4d4030ef          	jal	5682 <exit>
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    21b2:	85ce                	mv	a1,s3
    21b4:	00005517          	auipc	a0,0x5
    21b8:	8c450513          	addi	a0,a0,-1852 # 6a78 <malloc+0xef2>
    21bc:	117030ef          	jal	5ad2 <printf>
    exit(1);
    21c0:	4505                	li	a0,1
    21c2:	4c0030ef          	jal	5682 <exit>
    printf("%s: sbrk downsize failed, a %p c %p\n", s, a, c);
    21c6:	86aa                	mv	a3,a0
    21c8:	8626                	mv	a2,s1
    21ca:	85ce                	mv	a1,s3
    21cc:	00005517          	auipc	a0,0x5
    21d0:	8e450513          	addi	a0,a0,-1820 # 6ab0 <malloc+0xf2a>
    21d4:	0ff030ef          	jal	5ad2 <printf>
    exit(1);
    21d8:	4505                	li	a0,1
    21da:	4a8030ef          	jal	5682 <exit>

00000000000021de <sbrkarg>:
{
    21de:	7179                	addi	sp,sp,-48
    21e0:	f406                	sd	ra,40(sp)
    21e2:	f022                	sd	s0,32(sp)
    21e4:	ec26                	sd	s1,24(sp)
    21e6:	e84a                	sd	s2,16(sp)
    21e8:	e44e                	sd	s3,8(sp)
    21ea:	1800                	addi	s0,sp,48
    21ec:	89aa                	mv	s3,a0
  a = sbrk(PGSIZE);
    21ee:	6505                	lui	a0,0x1
    21f0:	45e030ef          	jal	564e <sbrk>
    21f4:	892a                	mv	s2,a0
  fd = open("sbrk", O_CREATE | O_WRONLY);
    21f6:	20100593          	li	a1,513
    21fa:	00005517          	auipc	a0,0x5
    21fe:	8de50513          	addi	a0,a0,-1826 # 6ad8 <malloc+0xf52>
    2202:	4c0030ef          	jal	56c2 <open>
    2206:	84aa                	mv	s1,a0
  unlink("sbrk");
    2208:	00005517          	auipc	a0,0x5
    220c:	8d050513          	addi	a0,a0,-1840 # 6ad8 <malloc+0xf52>
    2210:	4c2030ef          	jal	56d2 <unlink>
  if (fd < 0) {
    2214:	0204c963          	bltz	s1,2246 <sbrkarg+0x68>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    2218:	6605                	lui	a2,0x1
    221a:	85ca                	mv	a1,s2
    221c:	8526                	mv	a0,s1
    221e:	484030ef          	jal	56a2 <write>
    2222:	02054c63          	bltz	a0,225a <sbrkarg+0x7c>
  close(fd);
    2226:	8526                	mv	a0,s1
    2228:	482030ef          	jal	56aa <close>
  a = sbrk(PGSIZE);
    222c:	6505                	lui	a0,0x1
    222e:	420030ef          	jal	564e <sbrk>
  if (pipe((int *)a) != 0) {
    2232:	460030ef          	jal	5692 <pipe>
    2236:	ed05                	bnez	a0,226e <sbrkarg+0x90>
}
    2238:	70a2                	ld	ra,40(sp)
    223a:	7402                	ld	s0,32(sp)
    223c:	64e2                	ld	s1,24(sp)
    223e:	6942                	ld	s2,16(sp)
    2240:	69a2                	ld	s3,8(sp)
    2242:	6145                	addi	sp,sp,48
    2244:	8082                	ret
    printf("%s: open sbrk failed\n", s);
    2246:	85ce                	mv	a1,s3
    2248:	00005517          	auipc	a0,0x5
    224c:	89850513          	addi	a0,a0,-1896 # 6ae0 <malloc+0xf5a>
    2250:	083030ef          	jal	5ad2 <printf>
    exit(1);
    2254:	4505                	li	a0,1
    2256:	42c030ef          	jal	5682 <exit>
    printf("%s: write sbrk failed\n", s);
    225a:	85ce                	mv	a1,s3
    225c:	00005517          	auipc	a0,0x5
    2260:	89c50513          	addi	a0,a0,-1892 # 6af8 <malloc+0xf72>
    2264:	06f030ef          	jal	5ad2 <printf>
    exit(1);
    2268:	4505                	li	a0,1
    226a:	418030ef          	jal	5682 <exit>
    printf("%s: pipe() failed\n", s);
    226e:	85ce                	mv	a1,s3
    2270:	00004517          	auipc	a0,0x4
    2274:	36050513          	addi	a0,a0,864 # 65d0 <malloc+0xa4a>
    2278:	05b030ef          	jal	5ad2 <printf>
    exit(1);
    227c:	4505                	li	a0,1
    227e:	404030ef          	jal	5682 <exit>

0000000000002282 <argptest>:
{
    2282:	1101                	addi	sp,sp,-32
    2284:	ec06                	sd	ra,24(sp)
    2286:	e822                	sd	s0,16(sp)
    2288:	e426                	sd	s1,8(sp)
    228a:	e04a                	sd	s2,0(sp)
    228c:	1000                	addi	s0,sp,32
    228e:	892a                	mv	s2,a0
  fd = open("init", O_RDONLY);
    2290:	4581                	li	a1,0
    2292:	00005517          	auipc	a0,0x5
    2296:	87e50513          	addi	a0,a0,-1922 # 6b10 <malloc+0xf8a>
    229a:	428030ef          	jal	56c2 <open>
  if (fd < 0) {
    229e:	02054563          	bltz	a0,22c8 <argptest+0x46>
    22a2:	84aa                	mv	s1,a0
  read(fd, sbrk(0) - 1, -1);
    22a4:	4501                	li	a0,0
    22a6:	3a8030ef          	jal	564e <sbrk>
    22aa:	567d                	li	a2,-1
    22ac:	fff50593          	addi	a1,a0,-1
    22b0:	8526                	mv	a0,s1
    22b2:	3e8030ef          	jal	569a <read>
  close(fd);
    22b6:	8526                	mv	a0,s1
    22b8:	3f2030ef          	jal	56aa <close>
}
    22bc:	60e2                	ld	ra,24(sp)
    22be:	6442                	ld	s0,16(sp)
    22c0:	64a2                	ld	s1,8(sp)
    22c2:	6902                	ld	s2,0(sp)
    22c4:	6105                	addi	sp,sp,32
    22c6:	8082                	ret
    printf("%s: open failed\n", s);
    22c8:	85ca                	mv	a1,s2
    22ca:	00004517          	auipc	a0,0x4
    22ce:	29650513          	addi	a0,a0,662 # 6560 <malloc+0x9da>
    22d2:	001030ef          	jal	5ad2 <printf>
    exit(1);
    22d6:	4505                	li	a0,1
    22d8:	3aa030ef          	jal	5682 <exit>

00000000000022dc <sbrkbugs>:
{
    22dc:	1141                	addi	sp,sp,-16
    22de:	e406                	sd	ra,8(sp)
    22e0:	e022                	sd	s0,0(sp)
    22e2:	0800                	addi	s0,sp,16
  int pid = fork();
    22e4:	396030ef          	jal	567a <fork>
  if (pid < 0) {
    22e8:	00054c63          	bltz	a0,2300 <sbrkbugs+0x24>
  if (pid == 0) {
    22ec:	e11d                	bnez	a0,2312 <sbrkbugs+0x36>
    int sz = (uint64)sbrk(0);
    22ee:	360030ef          	jal	564e <sbrk>
    sbrk(-sz);
    22f2:	40a0053b          	negw	a0,a0
    22f6:	358030ef          	jal	564e <sbrk>
    exit(0);
    22fa:	4501                	li	a0,0
    22fc:	386030ef          	jal	5682 <exit>
    printf("fork failed\n");
    2300:	00006517          	auipc	a0,0x6
    2304:	9c850513          	addi	a0,a0,-1592 # 7cc8 <malloc+0x2142>
    2308:	7ca030ef          	jal	5ad2 <printf>
    exit(1);
    230c:	4505                	li	a0,1
    230e:	374030ef          	jal	5682 <exit>
  wait(0);
    2312:	4501                	li	a0,0
    2314:	376030ef          	jal	568a <wait>
  pid = fork();
    2318:	362030ef          	jal	567a <fork>
  if (pid < 0) {
    231c:	00054f63          	bltz	a0,233a <sbrkbugs+0x5e>
  if (pid == 0) {
    2320:	e515                	bnez	a0,234c <sbrkbugs+0x70>
    int sz = (uint64)sbrk(0);
    2322:	32c030ef          	jal	564e <sbrk>
    sbrk(-(sz - 3500));
    2326:	6785                	lui	a5,0x1
    2328:	dac7879b          	addiw	a5,a5,-596 # dac <linktest+0x138>
    232c:	40a7853b          	subw	a0,a5,a0
    2330:	31e030ef          	jal	564e <sbrk>
    exit(0);
    2334:	4501                	li	a0,0
    2336:	34c030ef          	jal	5682 <exit>
    printf("fork failed\n");
    233a:	00006517          	auipc	a0,0x6
    233e:	98e50513          	addi	a0,a0,-1650 # 7cc8 <malloc+0x2142>
    2342:	790030ef          	jal	5ad2 <printf>
    exit(1);
    2346:	4505                	li	a0,1
    2348:	33a030ef          	jal	5682 <exit>
  wait(0);
    234c:	4501                	li	a0,0
    234e:	33c030ef          	jal	568a <wait>
  pid = fork();
    2352:	328030ef          	jal	567a <fork>
  if (pid < 0) {
    2356:	02054263          	bltz	a0,237a <sbrkbugs+0x9e>
  if (pid == 0) {
    235a:	e90d                	bnez	a0,238c <sbrkbugs+0xb0>
    sbrk((10 * PGSIZE + 2048) - (uint64)sbrk(0));
    235c:	2f2030ef          	jal	564e <sbrk>
    2360:	67ad                	lui	a5,0xb
    2362:	8007879b          	addiw	a5,a5,-2048 # a800 <big.0+0x210>
    2366:	40a7853b          	subw	a0,a5,a0
    236a:	2e4030ef          	jal	564e <sbrk>
    sbrk(-10);
    236e:	5559                	li	a0,-10
    2370:	2de030ef          	jal	564e <sbrk>
    exit(0);
    2374:	4501                	li	a0,0
    2376:	30c030ef          	jal	5682 <exit>
    printf("fork failed\n");
    237a:	00006517          	auipc	a0,0x6
    237e:	94e50513          	addi	a0,a0,-1714 # 7cc8 <malloc+0x2142>
    2382:	750030ef          	jal	5ad2 <printf>
    exit(1);
    2386:	4505                	li	a0,1
    2388:	2fa030ef          	jal	5682 <exit>
  wait(0);
    238c:	4501                	li	a0,0
    238e:	2fc030ef          	jal	568a <wait>
  exit(0);
    2392:	4501                	li	a0,0
    2394:	2ee030ef          	jal	5682 <exit>

0000000000002398 <sbrklast>:
{
    2398:	7179                	addi	sp,sp,-48
    239a:	f406                	sd	ra,40(sp)
    239c:	f022                	sd	s0,32(sp)
    239e:	ec26                	sd	s1,24(sp)
    23a0:	e84a                	sd	s2,16(sp)
    23a2:	e44e                	sd	s3,8(sp)
    23a4:	e052                	sd	s4,0(sp)
    23a6:	1800                	addi	s0,sp,48
  uint64 top = (uint64)sbrk(0);
    23a8:	4501                	li	a0,0
    23aa:	2a4030ef          	jal	564e <sbrk>
  if ((top % PGSIZE) != 0)
    23ae:	03451793          	slli	a5,a0,0x34
    23b2:	ebad                	bnez	a5,2424 <sbrklast+0x8c>
  sbrk(PGSIZE);
    23b4:	6505                	lui	a0,0x1
    23b6:	298030ef          	jal	564e <sbrk>
  sbrk(10);
    23ba:	4529                	li	a0,10
    23bc:	292030ef          	jal	564e <sbrk>
  sbrk(-20);
    23c0:	5531                	li	a0,-20
    23c2:	28c030ef          	jal	564e <sbrk>
  top = (uint64)sbrk(0);
    23c6:	4501                	li	a0,0
    23c8:	286030ef          	jal	564e <sbrk>
    23cc:	84aa                	mv	s1,a0
  char *p = (char *)(top - 64);
    23ce:	fc050913          	addi	s2,a0,-64 # fc0 <bigdir+0x122>
  p[0] = 'x';
    23d2:	07800a13          	li	s4,120
    23d6:	fd450023          	sb	s4,-64(a0)
  p[1] = '\0';
    23da:	fc0500a3          	sb	zero,-63(a0)
  int fd = open(p, O_RDWR | O_CREATE);
    23de:	20200593          	li	a1,514
    23e2:	854a                	mv	a0,s2
    23e4:	2de030ef          	jal	56c2 <open>
    23e8:	89aa                	mv	s3,a0
  write(fd, p, 1);
    23ea:	4605                	li	a2,1
    23ec:	85ca                	mv	a1,s2
    23ee:	2b4030ef          	jal	56a2 <write>
  close(fd);
    23f2:	854e                	mv	a0,s3
    23f4:	2b6030ef          	jal	56aa <close>
  fd = open(p, O_RDWR);
    23f8:	4589                	li	a1,2
    23fa:	854a                	mv	a0,s2
    23fc:	2c6030ef          	jal	56c2 <open>
  p[0] = '\0';
    2400:	fc048023          	sb	zero,-64(s1)
  read(fd, p, 1);
    2404:	4605                	li	a2,1
    2406:	85ca                	mv	a1,s2
    2408:	292030ef          	jal	569a <read>
  if (p[0] != 'x')
    240c:	fc04c783          	lbu	a5,-64(s1)
    2410:	03479263          	bne	a5,s4,2434 <sbrklast+0x9c>
}
    2414:	70a2                	ld	ra,40(sp)
    2416:	7402                	ld	s0,32(sp)
    2418:	64e2                	ld	s1,24(sp)
    241a:	6942                	ld	s2,16(sp)
    241c:	69a2                	ld	s3,8(sp)
    241e:	6a02                	ld	s4,0(sp)
    2420:	6145                	addi	sp,sp,48
    2422:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    2424:	0347d513          	srli	a0,a5,0x34
    2428:	6785                	lui	a5,0x1
    242a:	40a7853b          	subw	a0,a5,a0
    242e:	220030ef          	jal	564e <sbrk>
    2432:	b749                	j	23b4 <sbrklast+0x1c>
    exit(1);
    2434:	4505                	li	a0,1
    2436:	24c030ef          	jal	5682 <exit>

000000000000243a <sbrk8000>:
{
    243a:	1141                	addi	sp,sp,-16
    243c:	e406                	sd	ra,8(sp)
    243e:	e022                	sd	s0,0(sp)
    2440:	0800                	addi	s0,sp,16
  sbrk(0x80000004);
    2442:	80000537          	lui	a0,0x80000
    2446:	0511                	addi	a0,a0,4 # ffffffff80000004 <base+0xffffffff7ffef2fc>
    2448:	206030ef          	jal	564e <sbrk>
  volatile char *top = sbrk(0);
    244c:	4501                	li	a0,0
    244e:	200030ef          	jal	564e <sbrk>
  *(top - 1) = *(top - 1) + 1;
    2452:	fff54783          	lbu	a5,-1(a0)
    2456:	2785                	addiw	a5,a5,1 # 1001 <badarg+0x1>
    2458:	0ff7f793          	zext.b	a5,a5
    245c:	fef50fa3          	sb	a5,-1(a0)
}
    2460:	60a2                	ld	ra,8(sp)
    2462:	6402                	ld	s0,0(sp)
    2464:	0141                	addi	sp,sp,16
    2466:	8082                	ret

0000000000002468 <execout>:
{
    2468:	715d                	addi	sp,sp,-80
    246a:	e486                	sd	ra,72(sp)
    246c:	e0a2                	sd	s0,64(sp)
    246e:	fc26                	sd	s1,56(sp)
    2470:	f84a                	sd	s2,48(sp)
    2472:	f44e                	sd	s3,40(sp)
    2474:	f052                	sd	s4,32(sp)
    2476:	0880                	addi	s0,sp,80
  for (int avail = 0; avail < 15; avail++) {
    2478:	4901                	li	s2,0
    247a:	49bd                	li	s3,15
    int pid = fork();
    247c:	1fe030ef          	jal	567a <fork>
    2480:	84aa                	mv	s1,a0
    if (pid < 0) {
    2482:	00054c63          	bltz	a0,249a <execout+0x32>
    } else if (pid == 0) {
    2486:	c11d                	beqz	a0,24ac <execout+0x44>
      wait((int *)0);
    2488:	4501                	li	a0,0
    248a:	200030ef          	jal	568a <wait>
  for (int avail = 0; avail < 15; avail++) {
    248e:	2905                	addiw	s2,s2,1
    2490:	ff3916e3          	bne	s2,s3,247c <execout+0x14>
  exit(0);
    2494:	4501                	li	a0,0
    2496:	1ec030ef          	jal	5682 <exit>
      printf("fork failed\n");
    249a:	00006517          	auipc	a0,0x6
    249e:	82e50513          	addi	a0,a0,-2002 # 7cc8 <malloc+0x2142>
    24a2:	630030ef          	jal	5ad2 <printf>
      exit(1);
    24a6:	4505                	li	a0,1
    24a8:	1da030ef          	jal	5682 <exit>
        if (a == SBRK_ERROR)
    24ac:	59fd                	li	s3,-1
        *(a + PGSIZE - 1) = 1;
    24ae:	4a05                	li	s4,1
        char *a = sbrk(PGSIZE);
    24b0:	6505                	lui	a0,0x1
    24b2:	19c030ef          	jal	564e <sbrk>
        if (a == SBRK_ERROR)
    24b6:	01350763          	beq	a0,s3,24c4 <execout+0x5c>
        *(a + PGSIZE - 1) = 1;
    24ba:	6785                	lui	a5,0x1
    24bc:	953e                	add	a0,a0,a5
    24be:	ff450fa3          	sb	s4,-1(a0) # fff <pgbug+0x2b>
      while (1) {
    24c2:	b7fd                	j	24b0 <execout+0x48>
      for (int i = 0; i < avail; i++)
    24c4:	01205863          	blez	s2,24d4 <execout+0x6c>
        sbrk(-PGSIZE);
    24c8:	757d                	lui	a0,0xfffff
    24ca:	184030ef          	jal	564e <sbrk>
      for (int i = 0; i < avail; i++)
    24ce:	2485                	addiw	s1,s1,1
    24d0:	ff249ce3          	bne	s1,s2,24c8 <execout+0x60>
      close(1);
    24d4:	4505                	li	a0,1
    24d6:	1d4030ef          	jal	56aa <close>
      char *args[] = {"echo", "x", 0};
    24da:	00003517          	auipc	a0,0x3
    24de:	7de50513          	addi	a0,a0,2014 # 5cb8 <malloc+0x132>
    24e2:	faa43c23          	sd	a0,-72(s0)
    24e6:	00004797          	auipc	a5,0x4
    24ea:	84278793          	addi	a5,a5,-1982 # 5d28 <malloc+0x1a2>
    24ee:	fcf43023          	sd	a5,-64(s0)
    24f2:	fc043423          	sd	zero,-56(s0)
      exec("echo", args);
    24f6:	fb840593          	addi	a1,s0,-72
    24fa:	1c0030ef          	jal	56ba <exec>
      exit(0);
    24fe:	4501                	li	a0,0
    2500:	182030ef          	jal	5682 <exit>

0000000000002504 <fourteen>:
{
    2504:	1101                	addi	sp,sp,-32
    2506:	ec06                	sd	ra,24(sp)
    2508:	e822                	sd	s0,16(sp)
    250a:	e426                	sd	s1,8(sp)
    250c:	1000                	addi	s0,sp,32
    250e:	84aa                	mv	s1,a0
  if (mkdir("12345678901234") != 0) {
    2510:	00004517          	auipc	a0,0x4
    2514:	7d850513          	addi	a0,a0,2008 # 6ce8 <malloc+0x1162>
    2518:	1d2030ef          	jal	56ea <mkdir>
    251c:	e555                	bnez	a0,25c8 <fourteen+0xc4>
  if (mkdir("12345678901234/123456789012345") != 0) {
    251e:	00004517          	auipc	a0,0x4
    2522:	62250513          	addi	a0,a0,1570 # 6b40 <malloc+0xfba>
    2526:	1c4030ef          	jal	56ea <mkdir>
    252a:	e94d                	bnez	a0,25dc <fourteen+0xd8>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    252c:	20000593          	li	a1,512
    2530:	00004517          	auipc	a0,0x4
    2534:	66850513          	addi	a0,a0,1640 # 6b98 <malloc+0x1012>
    2538:	18a030ef          	jal	56c2 <open>
  if (fd < 0) {
    253c:	0a054a63          	bltz	a0,25f0 <fourteen+0xec>
  close(fd);
    2540:	16a030ef          	jal	56aa <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    2544:	4581                	li	a1,0
    2546:	00004517          	auipc	a0,0x4
    254a:	6ca50513          	addi	a0,a0,1738 # 6c10 <malloc+0x108a>
    254e:	174030ef          	jal	56c2 <open>
  if (fd < 0) {
    2552:	0a054963          	bltz	a0,2604 <fourteen+0x100>
  close(fd);
    2556:	154030ef          	jal	56aa <close>
  if (mkdir("12345678901234/12345678901234") == 0) {
    255a:	00004517          	auipc	a0,0x4
    255e:	72650513          	addi	a0,a0,1830 # 6c80 <malloc+0x10fa>
    2562:	188030ef          	jal	56ea <mkdir>
    2566:	c94d                	beqz	a0,2618 <fourteen+0x114>
  if (mkdir("123456789012345/12345678901234") == 0) {
    2568:	00004517          	auipc	a0,0x4
    256c:	77050513          	addi	a0,a0,1904 # 6cd8 <malloc+0x1152>
    2570:	17a030ef          	jal	56ea <mkdir>
    2574:	cd45                	beqz	a0,262c <fourteen+0x128>
  unlink("123456789012345/12345678901234");
    2576:	00004517          	auipc	a0,0x4
    257a:	76250513          	addi	a0,a0,1890 # 6cd8 <malloc+0x1152>
    257e:	154030ef          	jal	56d2 <unlink>
  unlink("12345678901234/12345678901234");
    2582:	00004517          	auipc	a0,0x4
    2586:	6fe50513          	addi	a0,a0,1790 # 6c80 <malloc+0x10fa>
    258a:	148030ef          	jal	56d2 <unlink>
  unlink("12345678901234/12345678901234/12345678901234");
    258e:	00004517          	auipc	a0,0x4
    2592:	68250513          	addi	a0,a0,1666 # 6c10 <malloc+0x108a>
    2596:	13c030ef          	jal	56d2 <unlink>
  unlink("123456789012345/123456789012345/123456789012345");
    259a:	00004517          	auipc	a0,0x4
    259e:	5fe50513          	addi	a0,a0,1534 # 6b98 <malloc+0x1012>
    25a2:	130030ef          	jal	56d2 <unlink>
  unlink("12345678901234/123456789012345");
    25a6:	00004517          	auipc	a0,0x4
    25aa:	59a50513          	addi	a0,a0,1434 # 6b40 <malloc+0xfba>
    25ae:	124030ef          	jal	56d2 <unlink>
  unlink("12345678901234");
    25b2:	00004517          	auipc	a0,0x4
    25b6:	73650513          	addi	a0,a0,1846 # 6ce8 <malloc+0x1162>
    25ba:	118030ef          	jal	56d2 <unlink>
}
    25be:	60e2                	ld	ra,24(sp)
    25c0:	6442                	ld	s0,16(sp)
    25c2:	64a2                	ld	s1,8(sp)
    25c4:	6105                	addi	sp,sp,32
    25c6:	8082                	ret
    printf("%s: mkdir 12345678901234 failed\n", s);
    25c8:	85a6                	mv	a1,s1
    25ca:	00004517          	auipc	a0,0x4
    25ce:	54e50513          	addi	a0,a0,1358 # 6b18 <malloc+0xf92>
    25d2:	500030ef          	jal	5ad2 <printf>
    exit(1);
    25d6:	4505                	li	a0,1
    25d8:	0aa030ef          	jal	5682 <exit>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    25dc:	85a6                	mv	a1,s1
    25de:	00004517          	auipc	a0,0x4
    25e2:	58250513          	addi	a0,a0,1410 # 6b60 <malloc+0xfda>
    25e6:	4ec030ef          	jal	5ad2 <printf>
    exit(1);
    25ea:	4505                	li	a0,1
    25ec:	096030ef          	jal	5682 <exit>
    printf(
    25f0:	85a6                	mv	a1,s1
    25f2:	00004517          	auipc	a0,0x4
    25f6:	5d650513          	addi	a0,a0,1494 # 6bc8 <malloc+0x1042>
    25fa:	4d8030ef          	jal	5ad2 <printf>
    exit(1);
    25fe:	4505                	li	a0,1
    2600:	082030ef          	jal	5682 <exit>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    2604:	85a6                	mv	a1,s1
    2606:	00004517          	auipc	a0,0x4
    260a:	63a50513          	addi	a0,a0,1594 # 6c40 <malloc+0x10ba>
    260e:	4c4030ef          	jal	5ad2 <printf>
    exit(1);
    2612:	4505                	li	a0,1
    2614:	06e030ef          	jal	5682 <exit>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    2618:	85a6                	mv	a1,s1
    261a:	00004517          	auipc	a0,0x4
    261e:	68650513          	addi	a0,a0,1670 # 6ca0 <malloc+0x111a>
    2622:	4b0030ef          	jal	5ad2 <printf>
    exit(1);
    2626:	4505                	li	a0,1
    2628:	05a030ef          	jal	5682 <exit>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    262c:	85a6                	mv	a1,s1
    262e:	00004517          	auipc	a0,0x4
    2632:	6ca50513          	addi	a0,a0,1738 # 6cf8 <malloc+0x1172>
    2636:	49c030ef          	jal	5ad2 <printf>
    exit(1);
    263a:	4505                	li	a0,1
    263c:	046030ef          	jal	5682 <exit>

0000000000002640 <diskfull>:
{
    2640:	b8010113          	addi	sp,sp,-1152
    2644:	46113c23          	sd	ra,1144(sp)
    2648:	46813823          	sd	s0,1136(sp)
    264c:	46913423          	sd	s1,1128(sp)
    2650:	47213023          	sd	s2,1120(sp)
    2654:	45313c23          	sd	s3,1112(sp)
    2658:	45413823          	sd	s4,1104(sp)
    265c:	45513423          	sd	s5,1096(sp)
    2660:	45613023          	sd	s6,1088(sp)
    2664:	43713c23          	sd	s7,1080(sp)
    2668:	43813823          	sd	s8,1072(sp)
    266c:	43913423          	sd	s9,1064(sp)
    2670:	48010413          	addi	s0,sp,1152
    2674:	8caa                	mv	s9,a0
  unlink("diskfulldir");
    2676:	00004517          	auipc	a0,0x4
    267a:	6ba50513          	addi	a0,a0,1722 # 6d30 <malloc+0x11aa>
    267e:	054030ef          	jal	56d2 <unlink>
    2682:	03000993          	li	s3,48
    name[0] = 'b';
    2686:	06200b13          	li	s6,98
    name[1] = 'i';
    268a:	06900a93          	li	s5,105
    name[2] = 'g';
    268e:	06700a13          	li	s4,103
    2692:	10c00b93          	li	s7,268
  for (fi = 0; done == 0 && '0' + fi < 0177; fi++) {
    2696:	07f00c13          	li	s8,127
    269a:	aab9                	j	27f8 <diskfull+0x1b8>
      printf("%s: could not create file %s\n", s, name);
    269c:	b8040613          	addi	a2,s0,-1152
    26a0:	85e6                	mv	a1,s9
    26a2:	00004517          	auipc	a0,0x4
    26a6:	69e50513          	addi	a0,a0,1694 # 6d40 <malloc+0x11ba>
    26aa:	428030ef          	jal	5ad2 <printf>
      break;
    26ae:	a039                	j	26bc <diskfull+0x7c>
        close(fd);
    26b0:	854a                	mv	a0,s2
    26b2:	7f9020ef          	jal	56aa <close>
    close(fd);
    26b6:	854a                	mv	a0,s2
    26b8:	7f3020ef          	jal	56aa <close>
  for (int i = 0; i < nzz; i++) {
    26bc:	4481                	li	s1,0
    name[0] = 'z';
    26be:	07a00913          	li	s2,122
  for (int i = 0; i < nzz; i++) {
    26c2:	08000993          	li	s3,128
    name[0] = 'z';
    26c6:	bb240023          	sb	s2,-1120(s0)
    name[1] = 'z';
    26ca:	bb2400a3          	sb	s2,-1119(s0)
    name[2] = '0' + (i / 32);
    26ce:	41f4d71b          	sraiw	a4,s1,0x1f
    26d2:	01b7571b          	srliw	a4,a4,0x1b
    26d6:	009707bb          	addw	a5,a4,s1
    26da:	4057d69b          	sraiw	a3,a5,0x5
    26de:	0306869b          	addiw	a3,a3,48
    26e2:	bad40123          	sb	a3,-1118(s0)
    name[3] = '0' + (i % 32);
    26e6:	8bfd                	andi	a5,a5,31
    26e8:	9f99                	subw	a5,a5,a4
    26ea:	0307879b          	addiw	a5,a5,48
    26ee:	baf401a3          	sb	a5,-1117(s0)
    name[4] = '\0';
    26f2:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    26f6:	ba040513          	addi	a0,s0,-1120
    26fa:	7d9020ef          	jal	56d2 <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    26fe:	60200593          	li	a1,1538
    2702:	ba040513          	addi	a0,s0,-1120
    2706:	7bd020ef          	jal	56c2 <open>
    if (fd < 0)
    270a:	00054763          	bltz	a0,2718 <diskfull+0xd8>
    close(fd);
    270e:	79d020ef          	jal	56aa <close>
  for (int i = 0; i < nzz; i++) {
    2712:	2485                	addiw	s1,s1,1
    2714:	fb3499e3          	bne	s1,s3,26c6 <diskfull+0x86>
  if (mkdir("diskfulldir") == 0)
    2718:	00004517          	auipc	a0,0x4
    271c:	61850513          	addi	a0,a0,1560 # 6d30 <malloc+0x11aa>
    2720:	7cb020ef          	jal	56ea <mkdir>
    2724:	12050063          	beqz	a0,2844 <diskfull+0x204>
  unlink("diskfulldir");
    2728:	00004517          	auipc	a0,0x4
    272c:	60850513          	addi	a0,a0,1544 # 6d30 <malloc+0x11aa>
    2730:	7a3020ef          	jal	56d2 <unlink>
  for (int i = 0; i < nzz; i++) {
    2734:	4481                	li	s1,0
    name[0] = 'z';
    2736:	07a00913          	li	s2,122
  for (int i = 0; i < nzz; i++) {
    273a:	08000993          	li	s3,128
    name[0] = 'z';
    273e:	bb240023          	sb	s2,-1120(s0)
    name[1] = 'z';
    2742:	bb2400a3          	sb	s2,-1119(s0)
    name[2] = '0' + (i / 32);
    2746:	41f4d71b          	sraiw	a4,s1,0x1f
    274a:	01b7571b          	srliw	a4,a4,0x1b
    274e:	009707bb          	addw	a5,a4,s1
    2752:	4057d69b          	sraiw	a3,a5,0x5
    2756:	0306869b          	addiw	a3,a3,48
    275a:	bad40123          	sb	a3,-1118(s0)
    name[3] = '0' + (i % 32);
    275e:	8bfd                	andi	a5,a5,31
    2760:	9f99                	subw	a5,a5,a4
    2762:	0307879b          	addiw	a5,a5,48
    2766:	baf401a3          	sb	a5,-1117(s0)
    name[4] = '\0';
    276a:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    276e:	ba040513          	addi	a0,s0,-1120
    2772:	761020ef          	jal	56d2 <unlink>
  for (int i = 0; i < nzz; i++) {
    2776:	2485                	addiw	s1,s1,1
    2778:	fd3493e3          	bne	s1,s3,273e <diskfull+0xfe>
    277c:	03000493          	li	s1,48
    name[0] = 'b';
    2780:	06200a93          	li	s5,98
    name[1] = 'i';
    2784:	06900a13          	li	s4,105
    name[2] = 'g';
    2788:	06700993          	li	s3,103
  for (int i = 0; '0' + i < 0177; i++) {
    278c:	07f00913          	li	s2,127
    name[0] = 'b';
    2790:	bb540023          	sb	s5,-1120(s0)
    name[1] = 'i';
    2794:	bb4400a3          	sb	s4,-1119(s0)
    name[2] = 'g';
    2798:	bb340123          	sb	s3,-1118(s0)
    name[3] = '0' + i;
    279c:	ba9401a3          	sb	s1,-1117(s0)
    name[4] = '\0';
    27a0:	ba040223          	sb	zero,-1116(s0)
    unlink(name);
    27a4:	ba040513          	addi	a0,s0,-1120
    27a8:	72b020ef          	jal	56d2 <unlink>
  for (int i = 0; '0' + i < 0177; i++) {
    27ac:	2485                	addiw	s1,s1,1
    27ae:	0ff4f493          	zext.b	s1,s1
    27b2:	fd249fe3          	bne	s1,s2,2790 <diskfull+0x150>
}
    27b6:	47813083          	ld	ra,1144(sp)
    27ba:	47013403          	ld	s0,1136(sp)
    27be:	46813483          	ld	s1,1128(sp)
    27c2:	46013903          	ld	s2,1120(sp)
    27c6:	45813983          	ld	s3,1112(sp)
    27ca:	45013a03          	ld	s4,1104(sp)
    27ce:	44813a83          	ld	s5,1096(sp)
    27d2:	44013b03          	ld	s6,1088(sp)
    27d6:	43813b83          	ld	s7,1080(sp)
    27da:	43013c03          	ld	s8,1072(sp)
    27de:	42813c83          	ld	s9,1064(sp)
    27e2:	48010113          	addi	sp,sp,1152
    27e6:	8082                	ret
    close(fd);
    27e8:	854a                	mv	a0,s2
    27ea:	6c1020ef          	jal	56aa <close>
  for (fi = 0; done == 0 && '0' + fi < 0177; fi++) {
    27ee:	2985                	addiw	s3,s3,1
    27f0:	0ff9f993          	zext.b	s3,s3
    27f4:	ed8984e3          	beq	s3,s8,26bc <diskfull+0x7c>
    name[0] = 'b';
    27f8:	b9640023          	sb	s6,-1152(s0)
    name[1] = 'i';
    27fc:	b95400a3          	sb	s5,-1151(s0)
    name[2] = 'g';
    2800:	b9440123          	sb	s4,-1150(s0)
    name[3] = '0' + fi;
    2804:	b93401a3          	sb	s3,-1149(s0)
    name[4] = '\0';
    2808:	b8040223          	sb	zero,-1148(s0)
    unlink(name);
    280c:	b8040513          	addi	a0,s0,-1152
    2810:	6c3020ef          	jal	56d2 <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    2814:	60200593          	li	a1,1538
    2818:	b8040513          	addi	a0,s0,-1152
    281c:	6a7020ef          	jal	56c2 <open>
    2820:	892a                	mv	s2,a0
    if (fd < 0) {
    2822:	e6054de3          	bltz	a0,269c <diskfull+0x5c>
    2826:	84de                	mv	s1,s7
      if (write(fd, buf, BSIZE) != BSIZE) {
    2828:	40000613          	li	a2,1024
    282c:	ba040593          	addi	a1,s0,-1120
    2830:	854a                	mv	a0,s2
    2832:	671020ef          	jal	56a2 <write>
    2836:	40000793          	li	a5,1024
    283a:	e6f51be3          	bne	a0,a5,26b0 <diskfull+0x70>
    for (int i = 0; i < MAXFILE; i++) {
    283e:	34fd                	addiw	s1,s1,-1
    2840:	f4e5                	bnez	s1,2828 <diskfull+0x1e8>
    2842:	b75d                	j	27e8 <diskfull+0x1a8>
    printf("%s: mkdir(diskfulldir) unexpectedly succeeded!\n", s);
    2844:	85e6                	mv	a1,s9
    2846:	00004517          	auipc	a0,0x4
    284a:	51a50513          	addi	a0,a0,1306 # 6d60 <malloc+0x11da>
    284e:	284030ef          	jal	5ad2 <printf>
    2852:	bdd9                	j	2728 <diskfull+0xe8>

0000000000002854 <iputtest>:
{
    2854:	1101                	addi	sp,sp,-32
    2856:	ec06                	sd	ra,24(sp)
    2858:	e822                	sd	s0,16(sp)
    285a:	e426                	sd	s1,8(sp)
    285c:	1000                	addi	s0,sp,32
    285e:	84aa                	mv	s1,a0
  if (mkdir("iputdir") < 0) {
    2860:	00004517          	auipc	a0,0x4
    2864:	53050513          	addi	a0,a0,1328 # 6d90 <malloc+0x120a>
    2868:	683020ef          	jal	56ea <mkdir>
    286c:	02054f63          	bltz	a0,28aa <iputtest+0x56>
  if (chdir("iputdir") < 0) {
    2870:	00004517          	auipc	a0,0x4
    2874:	52050513          	addi	a0,a0,1312 # 6d90 <malloc+0x120a>
    2878:	67b020ef          	jal	56f2 <chdir>
    287c:	04054163          	bltz	a0,28be <iputtest+0x6a>
  if (unlink("../iputdir") < 0) {
    2880:	00004517          	auipc	a0,0x4
    2884:	55050513          	addi	a0,a0,1360 # 6dd0 <malloc+0x124a>
    2888:	64b020ef          	jal	56d2 <unlink>
    288c:	04054363          	bltz	a0,28d2 <iputtest+0x7e>
  if (chdir("/") < 0) {
    2890:	00004517          	auipc	a0,0x4
    2894:	57050513          	addi	a0,a0,1392 # 6e00 <malloc+0x127a>
    2898:	65b020ef          	jal	56f2 <chdir>
    289c:	04054563          	bltz	a0,28e6 <iputtest+0x92>
}
    28a0:	60e2                	ld	ra,24(sp)
    28a2:	6442                	ld	s0,16(sp)
    28a4:	64a2                	ld	s1,8(sp)
    28a6:	6105                	addi	sp,sp,32
    28a8:	8082                	ret
    printf("%s: mkdir failed\n", s);
    28aa:	85a6                	mv	a1,s1
    28ac:	00004517          	auipc	a0,0x4
    28b0:	4ec50513          	addi	a0,a0,1260 # 6d98 <malloc+0x1212>
    28b4:	21e030ef          	jal	5ad2 <printf>
    exit(1);
    28b8:	4505                	li	a0,1
    28ba:	5c9020ef          	jal	5682 <exit>
    printf("%s: chdir iputdir failed\n", s);
    28be:	85a6                	mv	a1,s1
    28c0:	00004517          	auipc	a0,0x4
    28c4:	4f050513          	addi	a0,a0,1264 # 6db0 <malloc+0x122a>
    28c8:	20a030ef          	jal	5ad2 <printf>
    exit(1);
    28cc:	4505                	li	a0,1
    28ce:	5b5020ef          	jal	5682 <exit>
    printf("%s: unlink ../iputdir failed\n", s);
    28d2:	85a6                	mv	a1,s1
    28d4:	00004517          	auipc	a0,0x4
    28d8:	50c50513          	addi	a0,a0,1292 # 6de0 <malloc+0x125a>
    28dc:	1f6030ef          	jal	5ad2 <printf>
    exit(1);
    28e0:	4505                	li	a0,1
    28e2:	5a1020ef          	jal	5682 <exit>
    printf("%s: chdir / failed\n", s);
    28e6:	85a6                	mv	a1,s1
    28e8:	00004517          	auipc	a0,0x4
    28ec:	52050513          	addi	a0,a0,1312 # 6e08 <malloc+0x1282>
    28f0:	1e2030ef          	jal	5ad2 <printf>
    exit(1);
    28f4:	4505                	li	a0,1
    28f6:	58d020ef          	jal	5682 <exit>

00000000000028fa <exitiputtest>:
{
    28fa:	7179                	addi	sp,sp,-48
    28fc:	f406                	sd	ra,40(sp)
    28fe:	f022                	sd	s0,32(sp)
    2900:	ec26                	sd	s1,24(sp)
    2902:	1800                	addi	s0,sp,48
    2904:	84aa                	mv	s1,a0
  pid = fork();
    2906:	575020ef          	jal	567a <fork>
  if (pid < 0) {
    290a:	02054e63          	bltz	a0,2946 <exitiputtest+0x4c>
  if (pid == 0) {
    290e:	e541                	bnez	a0,2996 <exitiputtest+0x9c>
    if (mkdir("iputdir") < 0) {
    2910:	00004517          	auipc	a0,0x4
    2914:	48050513          	addi	a0,a0,1152 # 6d90 <malloc+0x120a>
    2918:	5d3020ef          	jal	56ea <mkdir>
    291c:	02054f63          	bltz	a0,295a <exitiputtest+0x60>
    if (chdir("iputdir") < 0) {
    2920:	00004517          	auipc	a0,0x4
    2924:	47050513          	addi	a0,a0,1136 # 6d90 <malloc+0x120a>
    2928:	5cb020ef          	jal	56f2 <chdir>
    292c:	04054163          	bltz	a0,296e <exitiputtest+0x74>
    if (unlink("../iputdir") < 0) {
    2930:	00004517          	auipc	a0,0x4
    2934:	4a050513          	addi	a0,a0,1184 # 6dd0 <malloc+0x124a>
    2938:	59b020ef          	jal	56d2 <unlink>
    293c:	04054363          	bltz	a0,2982 <exitiputtest+0x88>
    exit(0);
    2940:	4501                	li	a0,0
    2942:	541020ef          	jal	5682 <exit>
    printf("%s: fork failed\n", s);
    2946:	85a6                	mv	a1,s1
    2948:	00004517          	auipc	a0,0x4
    294c:	c0050513          	addi	a0,a0,-1024 # 6548 <malloc+0x9c2>
    2950:	182030ef          	jal	5ad2 <printf>
    exit(1);
    2954:	4505                	li	a0,1
    2956:	52d020ef          	jal	5682 <exit>
      printf("%s: mkdir failed\n", s);
    295a:	85a6                	mv	a1,s1
    295c:	00004517          	auipc	a0,0x4
    2960:	43c50513          	addi	a0,a0,1084 # 6d98 <malloc+0x1212>
    2964:	16e030ef          	jal	5ad2 <printf>
      exit(1);
    2968:	4505                	li	a0,1
    296a:	519020ef          	jal	5682 <exit>
      printf("%s: child chdir failed\n", s);
    296e:	85a6                	mv	a1,s1
    2970:	00004517          	auipc	a0,0x4
    2974:	4b050513          	addi	a0,a0,1200 # 6e20 <malloc+0x129a>
    2978:	15a030ef          	jal	5ad2 <printf>
      exit(1);
    297c:	4505                	li	a0,1
    297e:	505020ef          	jal	5682 <exit>
      printf("%s: unlink ../iputdir failed\n", s);
    2982:	85a6                	mv	a1,s1
    2984:	00004517          	auipc	a0,0x4
    2988:	45c50513          	addi	a0,a0,1116 # 6de0 <malloc+0x125a>
    298c:	146030ef          	jal	5ad2 <printf>
      exit(1);
    2990:	4505                	li	a0,1
    2992:	4f1020ef          	jal	5682 <exit>
  wait(&xstatus);
    2996:	fdc40513          	addi	a0,s0,-36
    299a:	4f1020ef          	jal	568a <wait>
  exit(xstatus);
    299e:	fdc42503          	lw	a0,-36(s0)
    29a2:	4e1020ef          	jal	5682 <exit>

00000000000029a6 <dirtest>:
{
    29a6:	1101                	addi	sp,sp,-32
    29a8:	ec06                	sd	ra,24(sp)
    29aa:	e822                	sd	s0,16(sp)
    29ac:	e426                	sd	s1,8(sp)
    29ae:	1000                	addi	s0,sp,32
    29b0:	84aa                	mv	s1,a0
  if (mkdir("dir0") < 0) {
    29b2:	00004517          	auipc	a0,0x4
    29b6:	48650513          	addi	a0,a0,1158 # 6e38 <malloc+0x12b2>
    29ba:	531020ef          	jal	56ea <mkdir>
    29be:	02054f63          	bltz	a0,29fc <dirtest+0x56>
  if (chdir("dir0") < 0) {
    29c2:	00004517          	auipc	a0,0x4
    29c6:	47650513          	addi	a0,a0,1142 # 6e38 <malloc+0x12b2>
    29ca:	529020ef          	jal	56f2 <chdir>
    29ce:	04054163          	bltz	a0,2a10 <dirtest+0x6a>
  if (chdir("..") < 0) {
    29d2:	00004517          	auipc	a0,0x4
    29d6:	48650513          	addi	a0,a0,1158 # 6e58 <malloc+0x12d2>
    29da:	519020ef          	jal	56f2 <chdir>
    29de:	04054363          	bltz	a0,2a24 <dirtest+0x7e>
  if (unlink("dir0") < 0) {
    29e2:	00004517          	auipc	a0,0x4
    29e6:	45650513          	addi	a0,a0,1110 # 6e38 <malloc+0x12b2>
    29ea:	4e9020ef          	jal	56d2 <unlink>
    29ee:	04054563          	bltz	a0,2a38 <dirtest+0x92>
}
    29f2:	60e2                	ld	ra,24(sp)
    29f4:	6442                	ld	s0,16(sp)
    29f6:	64a2                	ld	s1,8(sp)
    29f8:	6105                	addi	sp,sp,32
    29fa:	8082                	ret
    printf("%s: mkdir failed\n", s);
    29fc:	85a6                	mv	a1,s1
    29fe:	00004517          	auipc	a0,0x4
    2a02:	39a50513          	addi	a0,a0,922 # 6d98 <malloc+0x1212>
    2a06:	0cc030ef          	jal	5ad2 <printf>
    exit(1);
    2a0a:	4505                	li	a0,1
    2a0c:	477020ef          	jal	5682 <exit>
    printf("%s: chdir dir0 failed\n", s);
    2a10:	85a6                	mv	a1,s1
    2a12:	00004517          	auipc	a0,0x4
    2a16:	42e50513          	addi	a0,a0,1070 # 6e40 <malloc+0x12ba>
    2a1a:	0b8030ef          	jal	5ad2 <printf>
    exit(1);
    2a1e:	4505                	li	a0,1
    2a20:	463020ef          	jal	5682 <exit>
    printf("%s: chdir .. failed\n", s);
    2a24:	85a6                	mv	a1,s1
    2a26:	00004517          	auipc	a0,0x4
    2a2a:	43a50513          	addi	a0,a0,1082 # 6e60 <malloc+0x12da>
    2a2e:	0a4030ef          	jal	5ad2 <printf>
    exit(1);
    2a32:	4505                	li	a0,1
    2a34:	44f020ef          	jal	5682 <exit>
    printf("%s: unlink dir0 failed\n", s);
    2a38:	85a6                	mv	a1,s1
    2a3a:	00004517          	auipc	a0,0x4
    2a3e:	43e50513          	addi	a0,a0,1086 # 6e78 <malloc+0x12f2>
    2a42:	090030ef          	jal	5ad2 <printf>
    exit(1);
    2a46:	4505                	li	a0,1
    2a48:	43b020ef          	jal	5682 <exit>

0000000000002a4c <subdir>:
{
    2a4c:	1101                	addi	sp,sp,-32
    2a4e:	ec06                	sd	ra,24(sp)
    2a50:	e822                	sd	s0,16(sp)
    2a52:	e426                	sd	s1,8(sp)
    2a54:	e04a                	sd	s2,0(sp)
    2a56:	1000                	addi	s0,sp,32
    2a58:	892a                	mv	s2,a0
  unlink("ff");
    2a5a:	00004517          	auipc	a0,0x4
    2a5e:	56650513          	addi	a0,a0,1382 # 6fc0 <malloc+0x143a>
    2a62:	471020ef          	jal	56d2 <unlink>
  if (mkdir("dd") != 0) {
    2a66:	00004517          	auipc	a0,0x4
    2a6a:	42a50513          	addi	a0,a0,1066 # 6e90 <malloc+0x130a>
    2a6e:	47d020ef          	jal	56ea <mkdir>
    2a72:	2e051263          	bnez	a0,2d56 <subdir+0x30a>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    2a76:	20200593          	li	a1,514
    2a7a:	00004517          	auipc	a0,0x4
    2a7e:	43650513          	addi	a0,a0,1078 # 6eb0 <malloc+0x132a>
    2a82:	441020ef          	jal	56c2 <open>
    2a86:	84aa                	mv	s1,a0
  if (fd < 0) {
    2a88:	2e054163          	bltz	a0,2d6a <subdir+0x31e>
  write(fd, "ff", 2);
    2a8c:	4609                	li	a2,2
    2a8e:	00004597          	auipc	a1,0x4
    2a92:	53258593          	addi	a1,a1,1330 # 6fc0 <malloc+0x143a>
    2a96:	40d020ef          	jal	56a2 <write>
  close(fd);
    2a9a:	8526                	mv	a0,s1
    2a9c:	40f020ef          	jal	56aa <close>
  if (unlink("dd") >= 0) {
    2aa0:	00004517          	auipc	a0,0x4
    2aa4:	3f050513          	addi	a0,a0,1008 # 6e90 <malloc+0x130a>
    2aa8:	42b020ef          	jal	56d2 <unlink>
    2aac:	2c055963          	bgez	a0,2d7e <subdir+0x332>
  if (mkdir("/dd/dd") != 0) {
    2ab0:	00004517          	auipc	a0,0x4
    2ab4:	45850513          	addi	a0,a0,1112 # 6f08 <malloc+0x1382>
    2ab8:	433020ef          	jal	56ea <mkdir>
    2abc:	2c051b63          	bnez	a0,2d92 <subdir+0x346>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    2ac0:	20200593          	li	a1,514
    2ac4:	00004517          	auipc	a0,0x4
    2ac8:	46c50513          	addi	a0,a0,1132 # 6f30 <malloc+0x13aa>
    2acc:	3f7020ef          	jal	56c2 <open>
    2ad0:	84aa                	mv	s1,a0
  if (fd < 0) {
    2ad2:	2c054a63          	bltz	a0,2da6 <subdir+0x35a>
  write(fd, "FF", 2);
    2ad6:	4609                	li	a2,2
    2ad8:	00004597          	auipc	a1,0x4
    2adc:	48858593          	addi	a1,a1,1160 # 6f60 <malloc+0x13da>
    2ae0:	3c3020ef          	jal	56a2 <write>
  close(fd);
    2ae4:	8526                	mv	a0,s1
    2ae6:	3c5020ef          	jal	56aa <close>
  fd = open("dd/dd/../ff", 0);
    2aea:	4581                	li	a1,0
    2aec:	00004517          	auipc	a0,0x4
    2af0:	47c50513          	addi	a0,a0,1148 # 6f68 <malloc+0x13e2>
    2af4:	3cf020ef          	jal	56c2 <open>
    2af8:	84aa                	mv	s1,a0
  if (fd < 0) {
    2afa:	2c054063          	bltz	a0,2dba <subdir+0x36e>
  cc = read(fd, buf, sizeof(buf));
    2afe:	660d                	lui	a2,0x3
    2b00:	0000b597          	auipc	a1,0xb
    2b04:	20858593          	addi	a1,a1,520 # dd08 <buf>
    2b08:	393020ef          	jal	569a <read>
  if (cc != 2 || buf[0] != 'f') {
    2b0c:	4789                	li	a5,2
    2b0e:	2cf51063          	bne	a0,a5,2dce <subdir+0x382>
    2b12:	0000b717          	auipc	a4,0xb
    2b16:	1f674703          	lbu	a4,502(a4) # dd08 <buf>
    2b1a:	06600793          	li	a5,102
    2b1e:	2af71863          	bne	a4,a5,2dce <subdir+0x382>
  close(fd);
    2b22:	8526                	mv	a0,s1
    2b24:	387020ef          	jal	56aa <close>
  if (link("dd/dd/ff", "dd/dd/ffff") != 0) {
    2b28:	00004597          	auipc	a1,0x4
    2b2c:	49058593          	addi	a1,a1,1168 # 6fb8 <malloc+0x1432>
    2b30:	00004517          	auipc	a0,0x4
    2b34:	40050513          	addi	a0,a0,1024 # 6f30 <malloc+0x13aa>
    2b38:	3ab020ef          	jal	56e2 <link>
    2b3c:	2a051363          	bnez	a0,2de2 <subdir+0x396>
  if (unlink("dd/dd/ff") != 0) {
    2b40:	00004517          	auipc	a0,0x4
    2b44:	3f050513          	addi	a0,a0,1008 # 6f30 <malloc+0x13aa>
    2b48:	38b020ef          	jal	56d2 <unlink>
    2b4c:	2a051563          	bnez	a0,2df6 <subdir+0x3aa>
  if (open("dd/dd/ff", O_RDONLY) >= 0) {
    2b50:	4581                	li	a1,0
    2b52:	00004517          	auipc	a0,0x4
    2b56:	3de50513          	addi	a0,a0,990 # 6f30 <malloc+0x13aa>
    2b5a:	369020ef          	jal	56c2 <open>
    2b5e:	2a055663          	bgez	a0,2e0a <subdir+0x3be>
  if (chdir("dd") != 0) {
    2b62:	00004517          	auipc	a0,0x4
    2b66:	32e50513          	addi	a0,a0,814 # 6e90 <malloc+0x130a>
    2b6a:	389020ef          	jal	56f2 <chdir>
    2b6e:	2a051863          	bnez	a0,2e1e <subdir+0x3d2>
  if (chdir("dd/../../dd") != 0) {
    2b72:	00004517          	auipc	a0,0x4
    2b76:	4de50513          	addi	a0,a0,1246 # 7050 <malloc+0x14ca>
    2b7a:	379020ef          	jal	56f2 <chdir>
    2b7e:	2a051a63          	bnez	a0,2e32 <subdir+0x3e6>
  if (chdir("dd/../../../dd") != 0) {
    2b82:	00004517          	auipc	a0,0x4
    2b86:	4fe50513          	addi	a0,a0,1278 # 7080 <malloc+0x14fa>
    2b8a:	369020ef          	jal	56f2 <chdir>
    2b8e:	2a051c63          	bnez	a0,2e46 <subdir+0x3fa>
  if (chdir("./..") != 0) {
    2b92:	00004517          	auipc	a0,0x4
    2b96:	52650513          	addi	a0,a0,1318 # 70b8 <malloc+0x1532>
    2b9a:	359020ef          	jal	56f2 <chdir>
    2b9e:	2a051e63          	bnez	a0,2e5a <subdir+0x40e>
  fd = open("dd/dd/ffff", 0);
    2ba2:	4581                	li	a1,0
    2ba4:	00004517          	auipc	a0,0x4
    2ba8:	41450513          	addi	a0,a0,1044 # 6fb8 <malloc+0x1432>
    2bac:	317020ef          	jal	56c2 <open>
    2bb0:	84aa                	mv	s1,a0
  if (fd < 0) {
    2bb2:	2a054e63          	bltz	a0,2e6e <subdir+0x422>
  if (read(fd, buf, sizeof(buf)) != 2) {
    2bb6:	660d                	lui	a2,0x3
    2bb8:	0000b597          	auipc	a1,0xb
    2bbc:	15058593          	addi	a1,a1,336 # dd08 <buf>
    2bc0:	2db020ef          	jal	569a <read>
    2bc4:	4789                	li	a5,2
    2bc6:	2af51e63          	bne	a0,a5,2e82 <subdir+0x436>
  close(fd);
    2bca:	8526                	mv	a0,s1
    2bcc:	2df020ef          	jal	56aa <close>
  if (open("dd/dd/ff", O_RDONLY) >= 0) {
    2bd0:	4581                	li	a1,0
    2bd2:	00004517          	auipc	a0,0x4
    2bd6:	35e50513          	addi	a0,a0,862 # 6f30 <malloc+0x13aa>
    2bda:	2e9020ef          	jal	56c2 <open>
    2bde:	2a055c63          	bgez	a0,2e96 <subdir+0x44a>
  if (open("dd/ff/ff", O_CREATE | O_RDWR) >= 0) {
    2be2:	20200593          	li	a1,514
    2be6:	00004517          	auipc	a0,0x4
    2bea:	56250513          	addi	a0,a0,1378 # 7148 <malloc+0x15c2>
    2bee:	2d5020ef          	jal	56c2 <open>
    2bf2:	2a055c63          	bgez	a0,2eaa <subdir+0x45e>
  if (open("dd/xx/ff", O_CREATE | O_RDWR) >= 0) {
    2bf6:	20200593          	li	a1,514
    2bfa:	00004517          	auipc	a0,0x4
    2bfe:	57e50513          	addi	a0,a0,1406 # 7178 <malloc+0x15f2>
    2c02:	2c1020ef          	jal	56c2 <open>
    2c06:	2a055c63          	bgez	a0,2ebe <subdir+0x472>
  if (open("dd", O_CREATE) >= 0) {
    2c0a:	20000593          	li	a1,512
    2c0e:	00004517          	auipc	a0,0x4
    2c12:	28250513          	addi	a0,a0,642 # 6e90 <malloc+0x130a>
    2c16:	2ad020ef          	jal	56c2 <open>
    2c1a:	2a055c63          	bgez	a0,2ed2 <subdir+0x486>
  if (open("dd", O_RDWR) >= 0) {
    2c1e:	4589                	li	a1,2
    2c20:	00004517          	auipc	a0,0x4
    2c24:	27050513          	addi	a0,a0,624 # 6e90 <malloc+0x130a>
    2c28:	29b020ef          	jal	56c2 <open>
    2c2c:	2a055d63          	bgez	a0,2ee6 <subdir+0x49a>
  if (open("dd", O_WRONLY) >= 0) {
    2c30:	4585                	li	a1,1
    2c32:	00004517          	auipc	a0,0x4
    2c36:	25e50513          	addi	a0,a0,606 # 6e90 <malloc+0x130a>
    2c3a:	289020ef          	jal	56c2 <open>
    2c3e:	2a055e63          	bgez	a0,2efa <subdir+0x4ae>
  if (link("dd/ff/ff", "dd/dd/xx") == 0) {
    2c42:	00004597          	auipc	a1,0x4
    2c46:	5c658593          	addi	a1,a1,1478 # 7208 <malloc+0x1682>
    2c4a:	00004517          	auipc	a0,0x4
    2c4e:	4fe50513          	addi	a0,a0,1278 # 7148 <malloc+0x15c2>
    2c52:	291020ef          	jal	56e2 <link>
    2c56:	2a050c63          	beqz	a0,2f0e <subdir+0x4c2>
  if (link("dd/xx/ff", "dd/dd/xx") == 0) {
    2c5a:	00004597          	auipc	a1,0x4
    2c5e:	5ae58593          	addi	a1,a1,1454 # 7208 <malloc+0x1682>
    2c62:	00004517          	auipc	a0,0x4
    2c66:	51650513          	addi	a0,a0,1302 # 7178 <malloc+0x15f2>
    2c6a:	279020ef          	jal	56e2 <link>
    2c6e:	2a050a63          	beqz	a0,2f22 <subdir+0x4d6>
  if (link("dd/ff", "dd/dd/ffff") == 0) {
    2c72:	00004597          	auipc	a1,0x4
    2c76:	34658593          	addi	a1,a1,838 # 6fb8 <malloc+0x1432>
    2c7a:	00004517          	auipc	a0,0x4
    2c7e:	23650513          	addi	a0,a0,566 # 6eb0 <malloc+0x132a>
    2c82:	261020ef          	jal	56e2 <link>
    2c86:	2a050863          	beqz	a0,2f36 <subdir+0x4ea>
  if (mkdir("dd/ff/ff") == 0) {
    2c8a:	00004517          	auipc	a0,0x4
    2c8e:	4be50513          	addi	a0,a0,1214 # 7148 <malloc+0x15c2>
    2c92:	259020ef          	jal	56ea <mkdir>
    2c96:	2a050a63          	beqz	a0,2f4a <subdir+0x4fe>
  if (mkdir("dd/xx/ff") == 0) {
    2c9a:	00004517          	auipc	a0,0x4
    2c9e:	4de50513          	addi	a0,a0,1246 # 7178 <malloc+0x15f2>
    2ca2:	249020ef          	jal	56ea <mkdir>
    2ca6:	2a050c63          	beqz	a0,2f5e <subdir+0x512>
  if (mkdir("dd/dd/ffff") == 0) {
    2caa:	00004517          	auipc	a0,0x4
    2cae:	30e50513          	addi	a0,a0,782 # 6fb8 <malloc+0x1432>
    2cb2:	239020ef          	jal	56ea <mkdir>
    2cb6:	2a050e63          	beqz	a0,2f72 <subdir+0x526>
  if (unlink("dd/xx/ff") == 0) {
    2cba:	00004517          	auipc	a0,0x4
    2cbe:	4be50513          	addi	a0,a0,1214 # 7178 <malloc+0x15f2>
    2cc2:	211020ef          	jal	56d2 <unlink>
    2cc6:	2c050063          	beqz	a0,2f86 <subdir+0x53a>
  if (unlink("dd/ff/ff") == 0) {
    2cca:	00004517          	auipc	a0,0x4
    2cce:	47e50513          	addi	a0,a0,1150 # 7148 <malloc+0x15c2>
    2cd2:	201020ef          	jal	56d2 <unlink>
    2cd6:	2c050263          	beqz	a0,2f9a <subdir+0x54e>
  if (chdir("dd/ff") == 0) {
    2cda:	00004517          	auipc	a0,0x4
    2cde:	1d650513          	addi	a0,a0,470 # 6eb0 <malloc+0x132a>
    2ce2:	211020ef          	jal	56f2 <chdir>
    2ce6:	2c050463          	beqz	a0,2fae <subdir+0x562>
  if (chdir("dd/xx") == 0) {
    2cea:	00004517          	auipc	a0,0x4
    2cee:	66e50513          	addi	a0,a0,1646 # 7358 <malloc+0x17d2>
    2cf2:	201020ef          	jal	56f2 <chdir>
    2cf6:	2c050663          	beqz	a0,2fc2 <subdir+0x576>
  if (unlink("dd/dd/ffff") != 0) {
    2cfa:	00004517          	auipc	a0,0x4
    2cfe:	2be50513          	addi	a0,a0,702 # 6fb8 <malloc+0x1432>
    2d02:	1d1020ef          	jal	56d2 <unlink>
    2d06:	2c051863          	bnez	a0,2fd6 <subdir+0x58a>
  if (unlink("dd/ff") != 0) {
    2d0a:	00004517          	auipc	a0,0x4
    2d0e:	1a650513          	addi	a0,a0,422 # 6eb0 <malloc+0x132a>
    2d12:	1c1020ef          	jal	56d2 <unlink>
    2d16:	2c051a63          	bnez	a0,2fea <subdir+0x59e>
  if (unlink("dd") == 0) {
    2d1a:	00004517          	auipc	a0,0x4
    2d1e:	17650513          	addi	a0,a0,374 # 6e90 <malloc+0x130a>
    2d22:	1b1020ef          	jal	56d2 <unlink>
    2d26:	2c050c63          	beqz	a0,2ffe <subdir+0x5b2>
  if (unlink("dd/dd") < 0) {
    2d2a:	00004517          	auipc	a0,0x4
    2d2e:	69e50513          	addi	a0,a0,1694 # 73c8 <malloc+0x1842>
    2d32:	1a1020ef          	jal	56d2 <unlink>
    2d36:	2c054e63          	bltz	a0,3012 <subdir+0x5c6>
  if (unlink("dd") < 0) {
    2d3a:	00004517          	auipc	a0,0x4
    2d3e:	15650513          	addi	a0,a0,342 # 6e90 <malloc+0x130a>
    2d42:	191020ef          	jal	56d2 <unlink>
    2d46:	2e054063          	bltz	a0,3026 <subdir+0x5da>
}
    2d4a:	60e2                	ld	ra,24(sp)
    2d4c:	6442                	ld	s0,16(sp)
    2d4e:	64a2                	ld	s1,8(sp)
    2d50:	6902                	ld	s2,0(sp)
    2d52:	6105                	addi	sp,sp,32
    2d54:	8082                	ret
    printf("%s: mkdir dd failed\n", s);
    2d56:	85ca                	mv	a1,s2
    2d58:	00004517          	auipc	a0,0x4
    2d5c:	14050513          	addi	a0,a0,320 # 6e98 <malloc+0x1312>
    2d60:	573020ef          	jal	5ad2 <printf>
    exit(1);
    2d64:	4505                	li	a0,1
    2d66:	11d020ef          	jal	5682 <exit>
    printf("%s: create dd/ff failed\n", s);
    2d6a:	85ca                	mv	a1,s2
    2d6c:	00004517          	auipc	a0,0x4
    2d70:	14c50513          	addi	a0,a0,332 # 6eb8 <malloc+0x1332>
    2d74:	55f020ef          	jal	5ad2 <printf>
    exit(1);
    2d78:	4505                	li	a0,1
    2d7a:	109020ef          	jal	5682 <exit>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    2d7e:	85ca                	mv	a1,s2
    2d80:	00004517          	auipc	a0,0x4
    2d84:	15850513          	addi	a0,a0,344 # 6ed8 <malloc+0x1352>
    2d88:	54b020ef          	jal	5ad2 <printf>
    exit(1);
    2d8c:	4505                	li	a0,1
    2d8e:	0f5020ef          	jal	5682 <exit>
    printf("%s: subdir mkdir dd/dd failed\n", s);
    2d92:	85ca                	mv	a1,s2
    2d94:	00004517          	auipc	a0,0x4
    2d98:	17c50513          	addi	a0,a0,380 # 6f10 <malloc+0x138a>
    2d9c:	537020ef          	jal	5ad2 <printf>
    exit(1);
    2da0:	4505                	li	a0,1
    2da2:	0e1020ef          	jal	5682 <exit>
    printf("%s: create dd/dd/ff failed\n", s);
    2da6:	85ca                	mv	a1,s2
    2da8:	00004517          	auipc	a0,0x4
    2dac:	19850513          	addi	a0,a0,408 # 6f40 <malloc+0x13ba>
    2db0:	523020ef          	jal	5ad2 <printf>
    exit(1);
    2db4:	4505                	li	a0,1
    2db6:	0cd020ef          	jal	5682 <exit>
    printf("%s: open dd/dd/../ff failed\n", s);
    2dba:	85ca                	mv	a1,s2
    2dbc:	00004517          	auipc	a0,0x4
    2dc0:	1bc50513          	addi	a0,a0,444 # 6f78 <malloc+0x13f2>
    2dc4:	50f020ef          	jal	5ad2 <printf>
    exit(1);
    2dc8:	4505                	li	a0,1
    2dca:	0b9020ef          	jal	5682 <exit>
    printf("%s: dd/dd/../ff wrong content\n", s);
    2dce:	85ca                	mv	a1,s2
    2dd0:	00004517          	auipc	a0,0x4
    2dd4:	1c850513          	addi	a0,a0,456 # 6f98 <malloc+0x1412>
    2dd8:	4fb020ef          	jal	5ad2 <printf>
    exit(1);
    2ddc:	4505                	li	a0,1
    2dde:	0a5020ef          	jal	5682 <exit>
    printf("%s: link dd/dd/ff dd/dd/ffff failed\n", s);
    2de2:	85ca                	mv	a1,s2
    2de4:	00004517          	auipc	a0,0x4
    2de8:	1e450513          	addi	a0,a0,484 # 6fc8 <malloc+0x1442>
    2dec:	4e7020ef          	jal	5ad2 <printf>
    exit(1);
    2df0:	4505                	li	a0,1
    2df2:	091020ef          	jal	5682 <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    2df6:	85ca                	mv	a1,s2
    2df8:	00004517          	auipc	a0,0x4
    2dfc:	1f850513          	addi	a0,a0,504 # 6ff0 <malloc+0x146a>
    2e00:	4d3020ef          	jal	5ad2 <printf>
    exit(1);
    2e04:	4505                	li	a0,1
    2e06:	07d020ef          	jal	5682 <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    2e0a:	85ca                	mv	a1,s2
    2e0c:	00004517          	auipc	a0,0x4
    2e10:	20450513          	addi	a0,a0,516 # 7010 <malloc+0x148a>
    2e14:	4bf020ef          	jal	5ad2 <printf>
    exit(1);
    2e18:	4505                	li	a0,1
    2e1a:	069020ef          	jal	5682 <exit>
    printf("%s: chdir dd failed\n", s);
    2e1e:	85ca                	mv	a1,s2
    2e20:	00004517          	auipc	a0,0x4
    2e24:	21850513          	addi	a0,a0,536 # 7038 <malloc+0x14b2>
    2e28:	4ab020ef          	jal	5ad2 <printf>
    exit(1);
    2e2c:	4505                	li	a0,1
    2e2e:	055020ef          	jal	5682 <exit>
    printf("%s: chdir dd/../../dd failed\n", s);
    2e32:	85ca                	mv	a1,s2
    2e34:	00004517          	auipc	a0,0x4
    2e38:	22c50513          	addi	a0,a0,556 # 7060 <malloc+0x14da>
    2e3c:	497020ef          	jal	5ad2 <printf>
    exit(1);
    2e40:	4505                	li	a0,1
    2e42:	041020ef          	jal	5682 <exit>
    printf("%s: chdir dd/../../../dd failed\n", s);
    2e46:	85ca                	mv	a1,s2
    2e48:	00004517          	auipc	a0,0x4
    2e4c:	24850513          	addi	a0,a0,584 # 7090 <malloc+0x150a>
    2e50:	483020ef          	jal	5ad2 <printf>
    exit(1);
    2e54:	4505                	li	a0,1
    2e56:	02d020ef          	jal	5682 <exit>
    printf("%s: chdir ./.. failed\n", s);
    2e5a:	85ca                	mv	a1,s2
    2e5c:	00004517          	auipc	a0,0x4
    2e60:	26450513          	addi	a0,a0,612 # 70c0 <malloc+0x153a>
    2e64:	46f020ef          	jal	5ad2 <printf>
    exit(1);
    2e68:	4505                	li	a0,1
    2e6a:	019020ef          	jal	5682 <exit>
    printf("%s: open dd/dd/ffff failed\n", s);
    2e6e:	85ca                	mv	a1,s2
    2e70:	00004517          	auipc	a0,0x4
    2e74:	26850513          	addi	a0,a0,616 # 70d8 <malloc+0x1552>
    2e78:	45b020ef          	jal	5ad2 <printf>
    exit(1);
    2e7c:	4505                	li	a0,1
    2e7e:	005020ef          	jal	5682 <exit>
    printf("%s: read dd/dd/ffff wrong len\n", s);
    2e82:	85ca                	mv	a1,s2
    2e84:	00004517          	auipc	a0,0x4
    2e88:	27450513          	addi	a0,a0,628 # 70f8 <malloc+0x1572>
    2e8c:	447020ef          	jal	5ad2 <printf>
    exit(1);
    2e90:	4505                	li	a0,1
    2e92:	7f0020ef          	jal	5682 <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    2e96:	85ca                	mv	a1,s2
    2e98:	00004517          	auipc	a0,0x4
    2e9c:	28050513          	addi	a0,a0,640 # 7118 <malloc+0x1592>
    2ea0:	433020ef          	jal	5ad2 <printf>
    exit(1);
    2ea4:	4505                	li	a0,1
    2ea6:	7dc020ef          	jal	5682 <exit>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    2eaa:	85ca                	mv	a1,s2
    2eac:	00004517          	auipc	a0,0x4
    2eb0:	2ac50513          	addi	a0,a0,684 # 7158 <malloc+0x15d2>
    2eb4:	41f020ef          	jal	5ad2 <printf>
    exit(1);
    2eb8:	4505                	li	a0,1
    2eba:	7c8020ef          	jal	5682 <exit>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    2ebe:	85ca                	mv	a1,s2
    2ec0:	00004517          	auipc	a0,0x4
    2ec4:	2c850513          	addi	a0,a0,712 # 7188 <malloc+0x1602>
    2ec8:	40b020ef          	jal	5ad2 <printf>
    exit(1);
    2ecc:	4505                	li	a0,1
    2ece:	7b4020ef          	jal	5682 <exit>
    printf("%s: create dd succeeded!\n", s);
    2ed2:	85ca                	mv	a1,s2
    2ed4:	00004517          	auipc	a0,0x4
    2ed8:	2d450513          	addi	a0,a0,724 # 71a8 <malloc+0x1622>
    2edc:	3f7020ef          	jal	5ad2 <printf>
    exit(1);
    2ee0:	4505                	li	a0,1
    2ee2:	7a0020ef          	jal	5682 <exit>
    printf("%s: open dd rdwr succeeded!\n", s);
    2ee6:	85ca                	mv	a1,s2
    2ee8:	00004517          	auipc	a0,0x4
    2eec:	2e050513          	addi	a0,a0,736 # 71c8 <malloc+0x1642>
    2ef0:	3e3020ef          	jal	5ad2 <printf>
    exit(1);
    2ef4:	4505                	li	a0,1
    2ef6:	78c020ef          	jal	5682 <exit>
    printf("%s: open dd wronly succeeded!\n", s);
    2efa:	85ca                	mv	a1,s2
    2efc:	00004517          	auipc	a0,0x4
    2f00:	2ec50513          	addi	a0,a0,748 # 71e8 <malloc+0x1662>
    2f04:	3cf020ef          	jal	5ad2 <printf>
    exit(1);
    2f08:	4505                	li	a0,1
    2f0a:	778020ef          	jal	5682 <exit>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    2f0e:	85ca                	mv	a1,s2
    2f10:	00004517          	auipc	a0,0x4
    2f14:	30850513          	addi	a0,a0,776 # 7218 <malloc+0x1692>
    2f18:	3bb020ef          	jal	5ad2 <printf>
    exit(1);
    2f1c:	4505                	li	a0,1
    2f1e:	764020ef          	jal	5682 <exit>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    2f22:	85ca                	mv	a1,s2
    2f24:	00004517          	auipc	a0,0x4
    2f28:	31c50513          	addi	a0,a0,796 # 7240 <malloc+0x16ba>
    2f2c:	3a7020ef          	jal	5ad2 <printf>
    exit(1);
    2f30:	4505                	li	a0,1
    2f32:	750020ef          	jal	5682 <exit>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    2f36:	85ca                	mv	a1,s2
    2f38:	00004517          	auipc	a0,0x4
    2f3c:	33050513          	addi	a0,a0,816 # 7268 <malloc+0x16e2>
    2f40:	393020ef          	jal	5ad2 <printf>
    exit(1);
    2f44:	4505                	li	a0,1
    2f46:	73c020ef          	jal	5682 <exit>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    2f4a:	85ca                	mv	a1,s2
    2f4c:	00004517          	auipc	a0,0x4
    2f50:	34450513          	addi	a0,a0,836 # 7290 <malloc+0x170a>
    2f54:	37f020ef          	jal	5ad2 <printf>
    exit(1);
    2f58:	4505                	li	a0,1
    2f5a:	728020ef          	jal	5682 <exit>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    2f5e:	85ca                	mv	a1,s2
    2f60:	00004517          	auipc	a0,0x4
    2f64:	35050513          	addi	a0,a0,848 # 72b0 <malloc+0x172a>
    2f68:	36b020ef          	jal	5ad2 <printf>
    exit(1);
    2f6c:	4505                	li	a0,1
    2f6e:	714020ef          	jal	5682 <exit>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    2f72:	85ca                	mv	a1,s2
    2f74:	00004517          	auipc	a0,0x4
    2f78:	35c50513          	addi	a0,a0,860 # 72d0 <malloc+0x174a>
    2f7c:	357020ef          	jal	5ad2 <printf>
    exit(1);
    2f80:	4505                	li	a0,1
    2f82:	700020ef          	jal	5682 <exit>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    2f86:	85ca                	mv	a1,s2
    2f88:	00004517          	auipc	a0,0x4
    2f8c:	37050513          	addi	a0,a0,880 # 72f8 <malloc+0x1772>
    2f90:	343020ef          	jal	5ad2 <printf>
    exit(1);
    2f94:	4505                	li	a0,1
    2f96:	6ec020ef          	jal	5682 <exit>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    2f9a:	85ca                	mv	a1,s2
    2f9c:	00004517          	auipc	a0,0x4
    2fa0:	37c50513          	addi	a0,a0,892 # 7318 <malloc+0x1792>
    2fa4:	32f020ef          	jal	5ad2 <printf>
    exit(1);
    2fa8:	4505                	li	a0,1
    2faa:	6d8020ef          	jal	5682 <exit>
    printf("%s: chdir dd/ff succeeded!\n", s);
    2fae:	85ca                	mv	a1,s2
    2fb0:	00004517          	auipc	a0,0x4
    2fb4:	38850513          	addi	a0,a0,904 # 7338 <malloc+0x17b2>
    2fb8:	31b020ef          	jal	5ad2 <printf>
    exit(1);
    2fbc:	4505                	li	a0,1
    2fbe:	6c4020ef          	jal	5682 <exit>
    printf("%s: chdir dd/xx succeeded!\n", s);
    2fc2:	85ca                	mv	a1,s2
    2fc4:	00004517          	auipc	a0,0x4
    2fc8:	39c50513          	addi	a0,a0,924 # 7360 <malloc+0x17da>
    2fcc:	307020ef          	jal	5ad2 <printf>
    exit(1);
    2fd0:	4505                	li	a0,1
    2fd2:	6b0020ef          	jal	5682 <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    2fd6:	85ca                	mv	a1,s2
    2fd8:	00004517          	auipc	a0,0x4
    2fdc:	01850513          	addi	a0,a0,24 # 6ff0 <malloc+0x146a>
    2fe0:	2f3020ef          	jal	5ad2 <printf>
    exit(1);
    2fe4:	4505                	li	a0,1
    2fe6:	69c020ef          	jal	5682 <exit>
    printf("%s: unlink dd/ff failed\n", s);
    2fea:	85ca                	mv	a1,s2
    2fec:	00004517          	auipc	a0,0x4
    2ff0:	39450513          	addi	a0,a0,916 # 7380 <malloc+0x17fa>
    2ff4:	2df020ef          	jal	5ad2 <printf>
    exit(1);
    2ff8:	4505                	li	a0,1
    2ffa:	688020ef          	jal	5682 <exit>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    2ffe:	85ca                	mv	a1,s2
    3000:	00004517          	auipc	a0,0x4
    3004:	3a050513          	addi	a0,a0,928 # 73a0 <malloc+0x181a>
    3008:	2cb020ef          	jal	5ad2 <printf>
    exit(1);
    300c:	4505                	li	a0,1
    300e:	674020ef          	jal	5682 <exit>
    printf("%s: unlink dd/dd failed\n", s);
    3012:	85ca                	mv	a1,s2
    3014:	00004517          	auipc	a0,0x4
    3018:	3bc50513          	addi	a0,a0,956 # 73d0 <malloc+0x184a>
    301c:	2b7020ef          	jal	5ad2 <printf>
    exit(1);
    3020:	4505                	li	a0,1
    3022:	660020ef          	jal	5682 <exit>
    printf("%s: unlink dd failed\n", s);
    3026:	85ca                	mv	a1,s2
    3028:	00004517          	auipc	a0,0x4
    302c:	3c850513          	addi	a0,a0,968 # 73f0 <malloc+0x186a>
    3030:	2a3020ef          	jal	5ad2 <printf>
    exit(1);
    3034:	4505                	li	a0,1
    3036:	64c020ef          	jal	5682 <exit>

000000000000303a <rmdot>:
{
    303a:	1101                	addi	sp,sp,-32
    303c:	ec06                	sd	ra,24(sp)
    303e:	e822                	sd	s0,16(sp)
    3040:	e426                	sd	s1,8(sp)
    3042:	1000                	addi	s0,sp,32
    3044:	84aa                	mv	s1,a0
  if (mkdir("dots") != 0) {
    3046:	00004517          	auipc	a0,0x4
    304a:	3c250513          	addi	a0,a0,962 # 7408 <malloc+0x1882>
    304e:	69c020ef          	jal	56ea <mkdir>
    3052:	e53d                	bnez	a0,30c0 <rmdot+0x86>
  if (chdir("dots") != 0) {
    3054:	00004517          	auipc	a0,0x4
    3058:	3b450513          	addi	a0,a0,948 # 7408 <malloc+0x1882>
    305c:	696020ef          	jal	56f2 <chdir>
    3060:	e935                	bnez	a0,30d4 <rmdot+0x9a>
  if (unlink(".") == 0) {
    3062:	00003517          	auipc	a0,0x3
    3066:	33e50513          	addi	a0,a0,830 # 63a0 <malloc+0x81a>
    306a:	668020ef          	jal	56d2 <unlink>
    306e:	cd2d                	beqz	a0,30e8 <rmdot+0xae>
  if (unlink("..") == 0) {
    3070:	00004517          	auipc	a0,0x4
    3074:	de850513          	addi	a0,a0,-536 # 6e58 <malloc+0x12d2>
    3078:	65a020ef          	jal	56d2 <unlink>
    307c:	c141                	beqz	a0,30fc <rmdot+0xc2>
  if (chdir("/") != 0) {
    307e:	00004517          	auipc	a0,0x4
    3082:	d8250513          	addi	a0,a0,-638 # 6e00 <malloc+0x127a>
    3086:	66c020ef          	jal	56f2 <chdir>
    308a:	e159                	bnez	a0,3110 <rmdot+0xd6>
  if (unlink("dots/.") == 0) {
    308c:	00004517          	auipc	a0,0x4
    3090:	3e450513          	addi	a0,a0,996 # 7470 <malloc+0x18ea>
    3094:	63e020ef          	jal	56d2 <unlink>
    3098:	c551                	beqz	a0,3124 <rmdot+0xea>
  if (unlink("dots/..") == 0) {
    309a:	00004517          	auipc	a0,0x4
    309e:	3fe50513          	addi	a0,a0,1022 # 7498 <malloc+0x1912>
    30a2:	630020ef          	jal	56d2 <unlink>
    30a6:	c949                	beqz	a0,3138 <rmdot+0xfe>
  if (unlink("dots") != 0) {
    30a8:	00004517          	auipc	a0,0x4
    30ac:	36050513          	addi	a0,a0,864 # 7408 <malloc+0x1882>
    30b0:	622020ef          	jal	56d2 <unlink>
    30b4:	ed41                	bnez	a0,314c <rmdot+0x112>
}
    30b6:	60e2                	ld	ra,24(sp)
    30b8:	6442                	ld	s0,16(sp)
    30ba:	64a2                	ld	s1,8(sp)
    30bc:	6105                	addi	sp,sp,32
    30be:	8082                	ret
    printf("%s: mkdir dots failed\n", s);
    30c0:	85a6                	mv	a1,s1
    30c2:	00004517          	auipc	a0,0x4
    30c6:	34e50513          	addi	a0,a0,846 # 7410 <malloc+0x188a>
    30ca:	209020ef          	jal	5ad2 <printf>
    exit(1);
    30ce:	4505                	li	a0,1
    30d0:	5b2020ef          	jal	5682 <exit>
    printf("%s: chdir dots failed\n", s);
    30d4:	85a6                	mv	a1,s1
    30d6:	00004517          	auipc	a0,0x4
    30da:	35250513          	addi	a0,a0,850 # 7428 <malloc+0x18a2>
    30de:	1f5020ef          	jal	5ad2 <printf>
    exit(1);
    30e2:	4505                	li	a0,1
    30e4:	59e020ef          	jal	5682 <exit>
    printf("%s: rm . worked!\n", s);
    30e8:	85a6                	mv	a1,s1
    30ea:	00004517          	auipc	a0,0x4
    30ee:	35650513          	addi	a0,a0,854 # 7440 <malloc+0x18ba>
    30f2:	1e1020ef          	jal	5ad2 <printf>
    exit(1);
    30f6:	4505                	li	a0,1
    30f8:	58a020ef          	jal	5682 <exit>
    printf("%s: rm .. worked!\n", s);
    30fc:	85a6                	mv	a1,s1
    30fe:	00004517          	auipc	a0,0x4
    3102:	35a50513          	addi	a0,a0,858 # 7458 <malloc+0x18d2>
    3106:	1cd020ef          	jal	5ad2 <printf>
    exit(1);
    310a:	4505                	li	a0,1
    310c:	576020ef          	jal	5682 <exit>
    printf("%s: chdir / failed\n", s);
    3110:	85a6                	mv	a1,s1
    3112:	00004517          	auipc	a0,0x4
    3116:	cf650513          	addi	a0,a0,-778 # 6e08 <malloc+0x1282>
    311a:	1b9020ef          	jal	5ad2 <printf>
    exit(1);
    311e:	4505                	li	a0,1
    3120:	562020ef          	jal	5682 <exit>
    printf("%s: unlink dots/. worked!\n", s);
    3124:	85a6                	mv	a1,s1
    3126:	00004517          	auipc	a0,0x4
    312a:	35250513          	addi	a0,a0,850 # 7478 <malloc+0x18f2>
    312e:	1a5020ef          	jal	5ad2 <printf>
    exit(1);
    3132:	4505                	li	a0,1
    3134:	54e020ef          	jal	5682 <exit>
    printf("%s: unlink dots/.. worked!\n", s);
    3138:	85a6                	mv	a1,s1
    313a:	00004517          	auipc	a0,0x4
    313e:	36650513          	addi	a0,a0,870 # 74a0 <malloc+0x191a>
    3142:	191020ef          	jal	5ad2 <printf>
    exit(1);
    3146:	4505                	li	a0,1
    3148:	53a020ef          	jal	5682 <exit>
    printf("%s: unlink dots failed!\n", s);
    314c:	85a6                	mv	a1,s1
    314e:	00004517          	auipc	a0,0x4
    3152:	37250513          	addi	a0,a0,882 # 74c0 <malloc+0x193a>
    3156:	17d020ef          	jal	5ad2 <printf>
    exit(1);
    315a:	4505                	li	a0,1
    315c:	526020ef          	jal	5682 <exit>

0000000000003160 <dirfile>:
{
    3160:	1101                	addi	sp,sp,-32
    3162:	ec06                	sd	ra,24(sp)
    3164:	e822                	sd	s0,16(sp)
    3166:	e426                	sd	s1,8(sp)
    3168:	e04a                	sd	s2,0(sp)
    316a:	1000                	addi	s0,sp,32
    316c:	892a                	mv	s2,a0
  fd = open("dirfile", O_CREATE);
    316e:	20000593          	li	a1,512
    3172:	00004517          	auipc	a0,0x4
    3176:	36e50513          	addi	a0,a0,878 # 74e0 <malloc+0x195a>
    317a:	548020ef          	jal	56c2 <open>
  if (fd < 0) {
    317e:	0c054563          	bltz	a0,3248 <dirfile+0xe8>
  close(fd);
    3182:	528020ef          	jal	56aa <close>
  if (chdir("dirfile") == 0) {
    3186:	00004517          	auipc	a0,0x4
    318a:	35a50513          	addi	a0,a0,858 # 74e0 <malloc+0x195a>
    318e:	564020ef          	jal	56f2 <chdir>
    3192:	c569                	beqz	a0,325c <dirfile+0xfc>
  fd = open("dirfile/xx", 0);
    3194:	4581                	li	a1,0
    3196:	00004517          	auipc	a0,0x4
    319a:	39250513          	addi	a0,a0,914 # 7528 <malloc+0x19a2>
    319e:	524020ef          	jal	56c2 <open>
  if (fd >= 0) {
    31a2:	0c055763          	bgez	a0,3270 <dirfile+0x110>
  fd = open("dirfile/xx", O_CREATE);
    31a6:	20000593          	li	a1,512
    31aa:	00004517          	auipc	a0,0x4
    31ae:	37e50513          	addi	a0,a0,894 # 7528 <malloc+0x19a2>
    31b2:	510020ef          	jal	56c2 <open>
  if (fd >= 0) {
    31b6:	0c055763          	bgez	a0,3284 <dirfile+0x124>
  if (mkdir("dirfile/xx") == 0) {
    31ba:	00004517          	auipc	a0,0x4
    31be:	36e50513          	addi	a0,a0,878 # 7528 <malloc+0x19a2>
    31c2:	528020ef          	jal	56ea <mkdir>
    31c6:	0c050963          	beqz	a0,3298 <dirfile+0x138>
  if (unlink("dirfile/xx") == 0) {
    31ca:	00004517          	auipc	a0,0x4
    31ce:	35e50513          	addi	a0,a0,862 # 7528 <malloc+0x19a2>
    31d2:	500020ef          	jal	56d2 <unlink>
    31d6:	0c050b63          	beqz	a0,32ac <dirfile+0x14c>
  if (link("README", "dirfile/xx") == 0) {
    31da:	00004597          	auipc	a1,0x4
    31de:	34e58593          	addi	a1,a1,846 # 7528 <malloc+0x19a2>
    31e2:	00003517          	auipc	a0,0x3
    31e6:	cae50513          	addi	a0,a0,-850 # 5e90 <malloc+0x30a>
    31ea:	4f8020ef          	jal	56e2 <link>
    31ee:	0c050963          	beqz	a0,32c0 <dirfile+0x160>
  if (unlink("dirfile") != 0) {
    31f2:	00004517          	auipc	a0,0x4
    31f6:	2ee50513          	addi	a0,a0,750 # 74e0 <malloc+0x195a>
    31fa:	4d8020ef          	jal	56d2 <unlink>
    31fe:	0c051b63          	bnez	a0,32d4 <dirfile+0x174>
  fd = open(".", O_RDWR);
    3202:	4589                	li	a1,2
    3204:	00003517          	auipc	a0,0x3
    3208:	19c50513          	addi	a0,a0,412 # 63a0 <malloc+0x81a>
    320c:	4b6020ef          	jal	56c2 <open>
  if (fd >= 0) {
    3210:	0c055c63          	bgez	a0,32e8 <dirfile+0x188>
  fd = open(".", 0);
    3214:	4581                	li	a1,0
    3216:	00003517          	auipc	a0,0x3
    321a:	18a50513          	addi	a0,a0,394 # 63a0 <malloc+0x81a>
    321e:	4a4020ef          	jal	56c2 <open>
    3222:	84aa                	mv	s1,a0
  if (write(fd, "x", 1) > 0) {
    3224:	4605                	li	a2,1
    3226:	00003597          	auipc	a1,0x3
    322a:	b0258593          	addi	a1,a1,-1278 # 5d28 <malloc+0x1a2>
    322e:	474020ef          	jal	56a2 <write>
    3232:	0ca04563          	bgtz	a0,32fc <dirfile+0x19c>
  close(fd);
    3236:	8526                	mv	a0,s1
    3238:	472020ef          	jal	56aa <close>
}
    323c:	60e2                	ld	ra,24(sp)
    323e:	6442                	ld	s0,16(sp)
    3240:	64a2                	ld	s1,8(sp)
    3242:	6902                	ld	s2,0(sp)
    3244:	6105                	addi	sp,sp,32
    3246:	8082                	ret
    printf("%s: create dirfile failed\n", s);
    3248:	85ca                	mv	a1,s2
    324a:	00004517          	auipc	a0,0x4
    324e:	29e50513          	addi	a0,a0,670 # 74e8 <malloc+0x1962>
    3252:	081020ef          	jal	5ad2 <printf>
    exit(1);
    3256:	4505                	li	a0,1
    3258:	42a020ef          	jal	5682 <exit>
    printf("%s: chdir dirfile succeeded!\n", s);
    325c:	85ca                	mv	a1,s2
    325e:	00004517          	auipc	a0,0x4
    3262:	2aa50513          	addi	a0,a0,682 # 7508 <malloc+0x1982>
    3266:	06d020ef          	jal	5ad2 <printf>
    exit(1);
    326a:	4505                	li	a0,1
    326c:	416020ef          	jal	5682 <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    3270:	85ca                	mv	a1,s2
    3272:	00004517          	auipc	a0,0x4
    3276:	2c650513          	addi	a0,a0,710 # 7538 <malloc+0x19b2>
    327a:	059020ef          	jal	5ad2 <printf>
    exit(1);
    327e:	4505                	li	a0,1
    3280:	402020ef          	jal	5682 <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    3284:	85ca                	mv	a1,s2
    3286:	00004517          	auipc	a0,0x4
    328a:	2b250513          	addi	a0,a0,690 # 7538 <malloc+0x19b2>
    328e:	045020ef          	jal	5ad2 <printf>
    exit(1);
    3292:	4505                	li	a0,1
    3294:	3ee020ef          	jal	5682 <exit>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    3298:	85ca                	mv	a1,s2
    329a:	00004517          	auipc	a0,0x4
    329e:	2c650513          	addi	a0,a0,710 # 7560 <malloc+0x19da>
    32a2:	031020ef          	jal	5ad2 <printf>
    exit(1);
    32a6:	4505                	li	a0,1
    32a8:	3da020ef          	jal	5682 <exit>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    32ac:	85ca                	mv	a1,s2
    32ae:	00004517          	auipc	a0,0x4
    32b2:	2da50513          	addi	a0,a0,730 # 7588 <malloc+0x1a02>
    32b6:	01d020ef          	jal	5ad2 <printf>
    exit(1);
    32ba:	4505                	li	a0,1
    32bc:	3c6020ef          	jal	5682 <exit>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    32c0:	85ca                	mv	a1,s2
    32c2:	00004517          	auipc	a0,0x4
    32c6:	2ee50513          	addi	a0,a0,750 # 75b0 <malloc+0x1a2a>
    32ca:	009020ef          	jal	5ad2 <printf>
    exit(1);
    32ce:	4505                	li	a0,1
    32d0:	3b2020ef          	jal	5682 <exit>
    printf("%s: unlink dirfile failed!\n", s);
    32d4:	85ca                	mv	a1,s2
    32d6:	00004517          	auipc	a0,0x4
    32da:	30250513          	addi	a0,a0,770 # 75d8 <malloc+0x1a52>
    32de:	7f4020ef          	jal	5ad2 <printf>
    exit(1);
    32e2:	4505                	li	a0,1
    32e4:	39e020ef          	jal	5682 <exit>
    printf("%s: open . for writing succeeded!\n", s);
    32e8:	85ca                	mv	a1,s2
    32ea:	00004517          	auipc	a0,0x4
    32ee:	30e50513          	addi	a0,a0,782 # 75f8 <malloc+0x1a72>
    32f2:	7e0020ef          	jal	5ad2 <printf>
    exit(1);
    32f6:	4505                	li	a0,1
    32f8:	38a020ef          	jal	5682 <exit>
    printf("%s: write . succeeded!\n", s);
    32fc:	85ca                	mv	a1,s2
    32fe:	00004517          	auipc	a0,0x4
    3302:	32250513          	addi	a0,a0,802 # 7620 <malloc+0x1a9a>
    3306:	7cc020ef          	jal	5ad2 <printf>
    exit(1);
    330a:	4505                	li	a0,1
    330c:	376020ef          	jal	5682 <exit>

0000000000003310 <iref>:
{
    3310:	7139                	addi	sp,sp,-64
    3312:	fc06                	sd	ra,56(sp)
    3314:	f822                	sd	s0,48(sp)
    3316:	f426                	sd	s1,40(sp)
    3318:	f04a                	sd	s2,32(sp)
    331a:	ec4e                	sd	s3,24(sp)
    331c:	e852                	sd	s4,16(sp)
    331e:	e456                	sd	s5,8(sp)
    3320:	e05a                	sd	s6,0(sp)
    3322:	0080                	addi	s0,sp,64
    3324:	8b2a                	mv	s6,a0
    3326:	03300913          	li	s2,51
    if (mkdir("irefd") != 0) {
    332a:	00004a17          	auipc	s4,0x4
    332e:	30ea0a13          	addi	s4,s4,782 # 7638 <malloc+0x1ab2>
    mkdir("");
    3332:	00004497          	auipc	s1,0x4
    3336:	e0e48493          	addi	s1,s1,-498 # 7140 <malloc+0x15ba>
    link("README", "");
    333a:	00003a97          	auipc	s5,0x3
    333e:	b56a8a93          	addi	s5,s5,-1194 # 5e90 <malloc+0x30a>
    fd = open("xx", O_CREATE);
    3342:	00004997          	auipc	s3,0x4
    3346:	1ee98993          	addi	s3,s3,494 # 7530 <malloc+0x19aa>
    334a:	a835                	j	3386 <iref+0x76>
      printf("%s: mkdir irefd failed\n", s);
    334c:	85da                	mv	a1,s6
    334e:	00004517          	auipc	a0,0x4
    3352:	2f250513          	addi	a0,a0,754 # 7640 <malloc+0x1aba>
    3356:	77c020ef          	jal	5ad2 <printf>
      exit(1);
    335a:	4505                	li	a0,1
    335c:	326020ef          	jal	5682 <exit>
      printf("%s: chdir irefd failed\n", s);
    3360:	85da                	mv	a1,s6
    3362:	00004517          	auipc	a0,0x4
    3366:	2f650513          	addi	a0,a0,758 # 7658 <malloc+0x1ad2>
    336a:	768020ef          	jal	5ad2 <printf>
      exit(1);
    336e:	4505                	li	a0,1
    3370:	312020ef          	jal	5682 <exit>
      close(fd);
    3374:	336020ef          	jal	56aa <close>
    3378:	a82d                	j	33b2 <iref+0xa2>
    unlink("xx");
    337a:	854e                	mv	a0,s3
    337c:	356020ef          	jal	56d2 <unlink>
  for (i = 0; i < NINODE + 1; i++) {
    3380:	397d                	addiw	s2,s2,-1
    3382:	04090263          	beqz	s2,33c6 <iref+0xb6>
    if (mkdir("irefd") != 0) {
    3386:	8552                	mv	a0,s4
    3388:	362020ef          	jal	56ea <mkdir>
    338c:	f161                	bnez	a0,334c <iref+0x3c>
    if (chdir("irefd") != 0) {
    338e:	8552                	mv	a0,s4
    3390:	362020ef          	jal	56f2 <chdir>
    3394:	f571                	bnez	a0,3360 <iref+0x50>
    mkdir("");
    3396:	8526                	mv	a0,s1
    3398:	352020ef          	jal	56ea <mkdir>
    link("README", "");
    339c:	85a6                	mv	a1,s1
    339e:	8556                	mv	a0,s5
    33a0:	342020ef          	jal	56e2 <link>
    fd = open("", O_CREATE);
    33a4:	20000593          	li	a1,512
    33a8:	8526                	mv	a0,s1
    33aa:	318020ef          	jal	56c2 <open>
    if (fd >= 0)
    33ae:	fc0553e3          	bgez	a0,3374 <iref+0x64>
    fd = open("xx", O_CREATE);
    33b2:	20000593          	li	a1,512
    33b6:	854e                	mv	a0,s3
    33b8:	30a020ef          	jal	56c2 <open>
    if (fd >= 0)
    33bc:	fa054fe3          	bltz	a0,337a <iref+0x6a>
      close(fd);
    33c0:	2ea020ef          	jal	56aa <close>
    33c4:	bf5d                	j	337a <iref+0x6a>
    33c6:	03300493          	li	s1,51
    chdir("..");
    33ca:	00004997          	auipc	s3,0x4
    33ce:	a8e98993          	addi	s3,s3,-1394 # 6e58 <malloc+0x12d2>
    unlink("irefd");
    33d2:	00004917          	auipc	s2,0x4
    33d6:	26690913          	addi	s2,s2,614 # 7638 <malloc+0x1ab2>
    chdir("..");
    33da:	854e                	mv	a0,s3
    33dc:	316020ef          	jal	56f2 <chdir>
    unlink("irefd");
    33e0:	854a                	mv	a0,s2
    33e2:	2f0020ef          	jal	56d2 <unlink>
  for (i = 0; i < NINODE + 1; i++) {
    33e6:	34fd                	addiw	s1,s1,-1
    33e8:	f8ed                	bnez	s1,33da <iref+0xca>
  chdir("/");
    33ea:	00004517          	auipc	a0,0x4
    33ee:	a1650513          	addi	a0,a0,-1514 # 6e00 <malloc+0x127a>
    33f2:	300020ef          	jal	56f2 <chdir>
}
    33f6:	70e2                	ld	ra,56(sp)
    33f8:	7442                	ld	s0,48(sp)
    33fa:	74a2                	ld	s1,40(sp)
    33fc:	7902                	ld	s2,32(sp)
    33fe:	69e2                	ld	s3,24(sp)
    3400:	6a42                	ld	s4,16(sp)
    3402:	6aa2                	ld	s5,8(sp)
    3404:	6b02                	ld	s6,0(sp)
    3406:	6121                	addi	sp,sp,64
    3408:	8082                	ret

000000000000340a <unlinkcwd>:
{
    340a:	1101                	addi	sp,sp,-32
    340c:	ec06                	sd	ra,24(sp)
    340e:	e822                	sd	s0,16(sp)
    3410:	e426                	sd	s1,8(sp)
    3412:	1000                	addi	s0,sp,32
    3414:	84aa                	mv	s1,a0
  if (mkdir("/a") < 0) {
    3416:	00004517          	auipc	a0,0x4
    341a:	25a50513          	addi	a0,a0,602 # 7670 <malloc+0x1aea>
    341e:	2cc020ef          	jal	56ea <mkdir>
    3422:	06054a63          	bltz	a0,3496 <unlinkcwd+0x8c>
  if (mkdir("/a/b") < 0) {
    3426:	00004517          	auipc	a0,0x4
    342a:	26a50513          	addi	a0,a0,618 # 7690 <malloc+0x1b0a>
    342e:	2bc020ef          	jal	56ea <mkdir>
    3432:	06054c63          	bltz	a0,34aa <unlinkcwd+0xa0>
  if (chdir("/a/b") < 0) {
    3436:	00004517          	auipc	a0,0x4
    343a:	25a50513          	addi	a0,a0,602 # 7690 <malloc+0x1b0a>
    343e:	2b4020ef          	jal	56f2 <chdir>
    3442:	06054e63          	bltz	a0,34be <unlinkcwd+0xb4>
  if (unlink("/a/b") < 0) {
    3446:	00004517          	auipc	a0,0x4
    344a:	24a50513          	addi	a0,a0,586 # 7690 <malloc+0x1b0a>
    344e:	284020ef          	jal	56d2 <unlink>
    3452:	08054063          	bltz	a0,34d2 <unlinkcwd+0xc8>
  if (unlink("/a") < 0) {
    3456:	00004517          	auipc	a0,0x4
    345a:	21a50513          	addi	a0,a0,538 # 7670 <malloc+0x1aea>
    345e:	274020ef          	jal	56d2 <unlink>
    3462:	08054263          	bltz	a0,34e6 <unlinkcwd+0xdc>
  if (open("../", O_RDONLY) > 0) {
    3466:	4581                	li	a1,0
    3468:	00004517          	auipc	a0,0x4
    346c:	29050513          	addi	a0,a0,656 # 76f8 <malloc+0x1b72>
    3470:	252020ef          	jal	56c2 <open>
    3474:	08a04363          	bgtz	a0,34fa <unlinkcwd+0xf0>
  if (open("../c", O_CREATE) > 0) {
    3478:	20000593          	li	a1,512
    347c:	00004517          	auipc	a0,0x4
    3480:	2ac50513          	addi	a0,a0,684 # 7728 <malloc+0x1ba2>
    3484:	23e020ef          	jal	56c2 <open>
    3488:	08a04163          	bgtz	a0,350a <unlinkcwd+0x100>
}
    348c:	60e2                	ld	ra,24(sp)
    348e:	6442                	ld	s0,16(sp)
    3490:	64a2                	ld	s1,8(sp)
    3492:	6105                	addi	sp,sp,32
    3494:	8082                	ret
    printf("%s: mkdir /a failed\n", s);
    3496:	85a6                	mv	a1,s1
    3498:	00004517          	auipc	a0,0x4
    349c:	1e050513          	addi	a0,a0,480 # 7678 <malloc+0x1af2>
    34a0:	632020ef          	jal	5ad2 <printf>
    exit(1);
    34a4:	4505                	li	a0,1
    34a6:	1dc020ef          	jal	5682 <exit>
    printf("%s: mkdir /a/b failed\n", s);
    34aa:	85a6                	mv	a1,s1
    34ac:	00004517          	auipc	a0,0x4
    34b0:	1ec50513          	addi	a0,a0,492 # 7698 <malloc+0x1b12>
    34b4:	61e020ef          	jal	5ad2 <printf>
    exit(1);
    34b8:	4505                	li	a0,1
    34ba:	1c8020ef          	jal	5682 <exit>
    printf("%s: chdir failed\n", s);
    34be:	85a6                	mv	a1,s1
    34c0:	00004517          	auipc	a0,0x4
    34c4:	1f050513          	addi	a0,a0,496 # 76b0 <malloc+0x1b2a>
    34c8:	60a020ef          	jal	5ad2 <printf>
    exit(1);
    34cc:	4505                	li	a0,1
    34ce:	1b4020ef          	jal	5682 <exit>
    printf("%s: unlink /a/b failed\n", s);
    34d2:	85a6                	mv	a1,s1
    34d4:	00004517          	auipc	a0,0x4
    34d8:	1f450513          	addi	a0,a0,500 # 76c8 <malloc+0x1b42>
    34dc:	5f6020ef          	jal	5ad2 <printf>
    exit(1);
    34e0:	4505                	li	a0,1
    34e2:	1a0020ef          	jal	5682 <exit>
    printf("%s: unlink /a failed\n", s);
    34e6:	85a6                	mv	a1,s1
    34e8:	00004517          	auipc	a0,0x4
    34ec:	1f850513          	addi	a0,a0,504 # 76e0 <malloc+0x1b5a>
    34f0:	5e2020ef          	jal	5ad2 <printf>
    exit(1);
    34f4:	4505                	li	a0,1
    34f6:	18c020ef          	jal	5682 <exit>
    printf("%s: open ../ non-existing directory\n", s);
    34fa:	85a6                	mv	a1,s1
    34fc:	00004517          	auipc	a0,0x4
    3500:	20450513          	addi	a0,a0,516 # 7700 <malloc+0x1b7a>
    3504:	5ce020ef          	jal	5ad2 <printf>
    3508:	bf85                	j	3478 <unlinkcwd+0x6e>
    printf("%s: create ../c non-existing file\n", s);
    350a:	85a6                	mv	a1,s1
    350c:	00004517          	auipc	a0,0x4
    3510:	22450513          	addi	a0,a0,548 # 7730 <malloc+0x1baa>
    3514:	5be020ef          	jal	5ad2 <printf>
}
    3518:	bf95                	j	348c <unlinkcwd+0x82>

000000000000351a <openiputtest>:
{
    351a:	7179                	addi	sp,sp,-48
    351c:	f406                	sd	ra,40(sp)
    351e:	f022                	sd	s0,32(sp)
    3520:	ec26                	sd	s1,24(sp)
    3522:	1800                	addi	s0,sp,48
    3524:	84aa                	mv	s1,a0
  if (mkdir("oidir") < 0) {
    3526:	00004517          	auipc	a0,0x4
    352a:	23250513          	addi	a0,a0,562 # 7758 <malloc+0x1bd2>
    352e:	1bc020ef          	jal	56ea <mkdir>
    3532:	02054a63          	bltz	a0,3566 <openiputtest+0x4c>
  pid = fork();
    3536:	144020ef          	jal	567a <fork>
  if (pid < 0) {
    353a:	04054063          	bltz	a0,357a <openiputtest+0x60>
  if (pid == 0) {
    353e:	e939                	bnez	a0,3594 <openiputtest+0x7a>
    int fd = open("oidir", O_RDWR);
    3540:	4589                	li	a1,2
    3542:	00004517          	auipc	a0,0x4
    3546:	21650513          	addi	a0,a0,534 # 7758 <malloc+0x1bd2>
    354a:	178020ef          	jal	56c2 <open>
    if (fd >= 0) {
    354e:	04054063          	bltz	a0,358e <openiputtest+0x74>
      printf("%s: open directory for write succeeded\n", s);
    3552:	85a6                	mv	a1,s1
    3554:	00004517          	auipc	a0,0x4
    3558:	22450513          	addi	a0,a0,548 # 7778 <malloc+0x1bf2>
    355c:	576020ef          	jal	5ad2 <printf>
      exit(1);
    3560:	4505                	li	a0,1
    3562:	120020ef          	jal	5682 <exit>
    printf("%s: mkdir oidir failed\n", s);
    3566:	85a6                	mv	a1,s1
    3568:	00004517          	auipc	a0,0x4
    356c:	1f850513          	addi	a0,a0,504 # 7760 <malloc+0x1bda>
    3570:	562020ef          	jal	5ad2 <printf>
    exit(1);
    3574:	4505                	li	a0,1
    3576:	10c020ef          	jal	5682 <exit>
    printf("%s: fork failed\n", s);
    357a:	85a6                	mv	a1,s1
    357c:	00003517          	auipc	a0,0x3
    3580:	fcc50513          	addi	a0,a0,-52 # 6548 <malloc+0x9c2>
    3584:	54e020ef          	jal	5ad2 <printf>
    exit(1);
    3588:	4505                	li	a0,1
    358a:	0f8020ef          	jal	5682 <exit>
    exit(0);
    358e:	4501                	li	a0,0
    3590:	0f2020ef          	jal	5682 <exit>
  pause(1);
    3594:	4505                	li	a0,1
    3596:	17c020ef          	jal	5712 <pause>
  if (unlink("oidir") != 0) {
    359a:	00004517          	auipc	a0,0x4
    359e:	1be50513          	addi	a0,a0,446 # 7758 <malloc+0x1bd2>
    35a2:	130020ef          	jal	56d2 <unlink>
    35a6:	c919                	beqz	a0,35bc <openiputtest+0xa2>
    printf("%s: unlink failed\n", s);
    35a8:	85a6                	mv	a1,s1
    35aa:	00003517          	auipc	a0,0x3
    35ae:	12650513          	addi	a0,a0,294 # 66d0 <malloc+0xb4a>
    35b2:	520020ef          	jal	5ad2 <printf>
    exit(1);
    35b6:	4505                	li	a0,1
    35b8:	0ca020ef          	jal	5682 <exit>
  wait(&xstatus);
    35bc:	fdc40513          	addi	a0,s0,-36
    35c0:	0ca020ef          	jal	568a <wait>
  exit(xstatus);
    35c4:	fdc42503          	lw	a0,-36(s0)
    35c8:	0ba020ef          	jal	5682 <exit>

00000000000035cc <forkforkfork>:
{
    35cc:	1101                	addi	sp,sp,-32
    35ce:	ec06                	sd	ra,24(sp)
    35d0:	e822                	sd	s0,16(sp)
    35d2:	e426                	sd	s1,8(sp)
    35d4:	1000                	addi	s0,sp,32
    35d6:	84aa                	mv	s1,a0
  unlink("stopforking");
    35d8:	00004517          	auipc	a0,0x4
    35dc:	1c850513          	addi	a0,a0,456 # 77a0 <malloc+0x1c1a>
    35e0:	0f2020ef          	jal	56d2 <unlink>
  int pid = fork();
    35e4:	096020ef          	jal	567a <fork>
  if (pid < 0) {
    35e8:	02054b63          	bltz	a0,361e <forkforkfork+0x52>
  if (pid == 0) {
    35ec:	c139                	beqz	a0,3632 <forkforkfork+0x66>
  pause(20); // two seconds
    35ee:	4551                	li	a0,20
    35f0:	122020ef          	jal	5712 <pause>
  close(open("stopforking", O_CREATE | O_RDWR));
    35f4:	20200593          	li	a1,514
    35f8:	00004517          	auipc	a0,0x4
    35fc:	1a850513          	addi	a0,a0,424 # 77a0 <malloc+0x1c1a>
    3600:	0c2020ef          	jal	56c2 <open>
    3604:	0a6020ef          	jal	56aa <close>
  wait(0);
    3608:	4501                	li	a0,0
    360a:	080020ef          	jal	568a <wait>
  pause(10); // one second
    360e:	4529                	li	a0,10
    3610:	102020ef          	jal	5712 <pause>
}
    3614:	60e2                	ld	ra,24(sp)
    3616:	6442                	ld	s0,16(sp)
    3618:	64a2                	ld	s1,8(sp)
    361a:	6105                	addi	sp,sp,32
    361c:	8082                	ret
    printf("%s: fork failed", s);
    361e:	85a6                	mv	a1,s1
    3620:	00003517          	auipc	a0,0x3
    3624:	06850513          	addi	a0,a0,104 # 6688 <malloc+0xb02>
    3628:	4aa020ef          	jal	5ad2 <printf>
    exit(1);
    362c:	4505                	li	a0,1
    362e:	054020ef          	jal	5682 <exit>
      int fd = open("stopforking", 0);
    3632:	00004497          	auipc	s1,0x4
    3636:	16e48493          	addi	s1,s1,366 # 77a0 <malloc+0x1c1a>
    363a:	4581                	li	a1,0
    363c:	8526                	mv	a0,s1
    363e:	084020ef          	jal	56c2 <open>
      if (fd >= 0) {
    3642:	02055163          	bgez	a0,3664 <forkforkfork+0x98>
      if (fork() < 0) {
    3646:	034020ef          	jal	567a <fork>
    364a:	fe0558e3          	bgez	a0,363a <forkforkfork+0x6e>
        close(open("stopforking", O_CREATE | O_RDWR));
    364e:	20200593          	li	a1,514
    3652:	00004517          	auipc	a0,0x4
    3656:	14e50513          	addi	a0,a0,334 # 77a0 <malloc+0x1c1a>
    365a:	068020ef          	jal	56c2 <open>
    365e:	04c020ef          	jal	56aa <close>
    3662:	bfe1                	j	363a <forkforkfork+0x6e>
        exit(0);
    3664:	4501                	li	a0,0
    3666:	01c020ef          	jal	5682 <exit>

000000000000366a <exectest>:
{
    366a:	711d                	addi	sp,sp,-96
    366c:	ec86                	sd	ra,88(sp)
    366e:	e8a2                	sd	s0,80(sp)
    3670:	e0ca                	sd	s2,64(sp)
    3672:	1080                	addi	s0,sp,96
    3674:	892a                	mv	s2,a0
  char *echoargv[] = {"echo", "OK", 0};
    3676:	00002797          	auipc	a5,0x2
    367a:	64278793          	addi	a5,a5,1602 # 5cb8 <malloc+0x132>
    367e:	faf43823          	sd	a5,-80(s0)
    3682:	00004797          	auipc	a5,0x4
    3686:	12e78793          	addi	a5,a5,302 # 77b0 <malloc+0x1c2a>
    368a:	faf43c23          	sd	a5,-72(s0)
    368e:	fc043023          	sd	zero,-64(s0)
  unlink("echo-ok");
    3692:	00004517          	auipc	a0,0x4
    3696:	12650513          	addi	a0,a0,294 # 77b8 <malloc+0x1c32>
    369a:	038020ef          	jal	56d2 <unlink>
  pid = fork();
    369e:	7dd010ef          	jal	567a <fork>
  if (pid < 0) {
    36a2:	04054763          	bltz	a0,36f0 <exectest+0x86>
    36a6:	e4a6                	sd	s1,72(sp)
    36a8:	fc4e                	sd	s3,56(sp)
    36aa:	84aa                	mv	s1,a0
  if (pid == 0) {
    36ac:	ed49                	bnez	a0,3746 <exectest+0xdc>
    int errfd = dup(1);
    36ae:	4505                	li	a0,1
    36b0:	04a020ef          	jal	56fa <dup>
    36b4:	89aa                	mv	s3,a0
    if (errfd < 0) {
    36b6:	04054963          	bltz	a0,3708 <exectest+0x9e>
    close(1);
    36ba:	4505                	li	a0,1
    36bc:	7ef010ef          	jal	56aa <close>
    fd = open("echo-ok", O_CREATE | O_WRONLY);
    36c0:	20100593          	li	a1,513
    36c4:	00004517          	auipc	a0,0x4
    36c8:	0f450513          	addi	a0,a0,244 # 77b8 <malloc+0x1c32>
    36cc:	7f7010ef          	jal	56c2 <open>
    if (fd < 0) {
    36d0:	04054663          	bltz	a0,371c <exectest+0xb2>
    if (fd != 1) {
    36d4:	4785                	li	a5,1
    36d6:	04f50e63          	beq	a0,a5,3732 <exectest+0xc8>
      fprintf(errfd, "%s: wrong fd\n", s);
    36da:	864a                	mv	a2,s2
    36dc:	00004597          	auipc	a1,0x4
    36e0:	0f458593          	addi	a1,a1,244 # 77d0 <malloc+0x1c4a>
    36e4:	854e                	mv	a0,s3
    36e6:	3c2020ef          	jal	5aa8 <fprintf>
      exit(1);
    36ea:	4505                	li	a0,1
    36ec:	797010ef          	jal	5682 <exit>
    36f0:	e4a6                	sd	s1,72(sp)
    36f2:	fc4e                	sd	s3,56(sp)
    printf("%s: fork failed\n", s);
    36f4:	85ca                	mv	a1,s2
    36f6:	00003517          	auipc	a0,0x3
    36fa:	e5250513          	addi	a0,a0,-430 # 6548 <malloc+0x9c2>
    36fe:	3d4020ef          	jal	5ad2 <printf>
    exit(1);
    3702:	4505                	li	a0,1
    3704:	77f010ef          	jal	5682 <exit>
      printf("%s: dup failed\n", s);
    3708:	85ca                	mv	a1,s2
    370a:	00004517          	auipc	a0,0x4
    370e:	0b650513          	addi	a0,a0,182 # 77c0 <malloc+0x1c3a>
    3712:	3c0020ef          	jal	5ad2 <printf>
      exit(1);
    3716:	4505                	li	a0,1
    3718:	76b010ef          	jal	5682 <exit>
      fprintf(errfd, "%s: create failed\n", s);
    371c:	864a                	mv	a2,s2
    371e:	00003597          	auipc	a1,0x3
    3722:	f9a58593          	addi	a1,a1,-102 # 66b8 <malloc+0xb32>
    3726:	854e                	mv	a0,s3
    3728:	380020ef          	jal	5aa8 <fprintf>
      exit(1);
    372c:	4505                	li	a0,1
    372e:	755010ef          	jal	5682 <exit>
    if (exec("echo", echoargv) < 0) {
    3732:	fb040593          	addi	a1,s0,-80
    3736:	00002517          	auipc	a0,0x2
    373a:	58250513          	addi	a0,a0,1410 # 5cb8 <malloc+0x132>
    373e:	77d010ef          	jal	56ba <exec>
    3742:	02054563          	bltz	a0,376c <exectest+0x102>
  if (wait(&xstatus) != pid) {
    3746:	fcc40513          	addi	a0,s0,-52
    374a:	741010ef          	jal	568a <wait>
    374e:	02951a63          	bne	a0,s1,3782 <exectest+0x118>
  if (xstatus != 0) {
    3752:	fcc42603          	lw	a2,-52(s0)
    3756:	ce15                	beqz	a2,3792 <exectest+0x128>
    printf("%s: nonzero wait status %d\n", s, xstatus);
    3758:	85ca                	mv	a1,s2
    375a:	00004517          	auipc	a0,0x4
    375e:	0b650513          	addi	a0,a0,182 # 7810 <malloc+0x1c8a>
    3762:	370020ef          	jal	5ad2 <printf>
    exit(1);
    3766:	4505                	li	a0,1
    3768:	71b010ef          	jal	5682 <exit>
      fprintf(errfd, "%s: exec echo failed\n", s);
    376c:	864a                	mv	a2,s2
    376e:	00004597          	auipc	a1,0x4
    3772:	07258593          	addi	a1,a1,114 # 77e0 <malloc+0x1c5a>
    3776:	854e                	mv	a0,s3
    3778:	330020ef          	jal	5aa8 <fprintf>
      exit(1);
    377c:	4505                	li	a0,1
    377e:	705010ef          	jal	5682 <exit>
    printf("%s: wait failed!\n", s);
    3782:	85ca                	mv	a1,s2
    3784:	00004517          	auipc	a0,0x4
    3788:	07450513          	addi	a0,a0,116 # 77f8 <malloc+0x1c72>
    378c:	346020ef          	jal	5ad2 <printf>
    3790:	b7c9                	j	3752 <exectest+0xe8>
  fd = open("echo-ok", O_RDONLY);
    3792:	4581                	li	a1,0
    3794:	00004517          	auipc	a0,0x4
    3798:	02450513          	addi	a0,a0,36 # 77b8 <malloc+0x1c32>
    379c:	727010ef          	jal	56c2 <open>
  if (fd < 0) {
    37a0:	02054463          	bltz	a0,37c8 <exectest+0x15e>
  if (read(fd, buf, 2) != 2) {
    37a4:	4609                	li	a2,2
    37a6:	fa840593          	addi	a1,s0,-88
    37aa:	6f1010ef          	jal	569a <read>
    37ae:	4789                	li	a5,2
    37b0:	02f50663          	beq	a0,a5,37dc <exectest+0x172>
    printf("%s: read failed\n", s);
    37b4:	85ca                	mv	a1,s2
    37b6:	00003517          	auipc	a0,0x3
    37ba:	8d250513          	addi	a0,a0,-1838 # 6088 <malloc+0x502>
    37be:	314020ef          	jal	5ad2 <printf>
    exit(1);
    37c2:	4505                	li	a0,1
    37c4:	6bf010ef          	jal	5682 <exit>
    printf("%s: open failed\n", s);
    37c8:	85ca                	mv	a1,s2
    37ca:	00003517          	auipc	a0,0x3
    37ce:	d9650513          	addi	a0,a0,-618 # 6560 <malloc+0x9da>
    37d2:	300020ef          	jal	5ad2 <printf>
    exit(1);
    37d6:	4505                	li	a0,1
    37d8:	6ab010ef          	jal	5682 <exit>
  unlink("echo-ok");
    37dc:	00004517          	auipc	a0,0x4
    37e0:	fdc50513          	addi	a0,a0,-36 # 77b8 <malloc+0x1c32>
    37e4:	6ef010ef          	jal	56d2 <unlink>
  if (buf[0] == 'O' && buf[1] == 'K')
    37e8:	fa844703          	lbu	a4,-88(s0)
    37ec:	04f00793          	li	a5,79
    37f0:	00f71863          	bne	a4,a5,3800 <exectest+0x196>
    37f4:	fa944703          	lbu	a4,-87(s0)
    37f8:	04b00793          	li	a5,75
    37fc:	00f70c63          	beq	a4,a5,3814 <exectest+0x1aa>
    printf("%s: wrong output\n", s);
    3800:	85ca                	mv	a1,s2
    3802:	00004517          	auipc	a0,0x4
    3806:	02e50513          	addi	a0,a0,46 # 7830 <malloc+0x1caa>
    380a:	2c8020ef          	jal	5ad2 <printf>
    exit(1);
    380e:	4505                	li	a0,1
    3810:	673010ef          	jal	5682 <exit>
    exit(0);
    3814:	4501                	li	a0,0
    3816:	66d010ef          	jal	5682 <exit>

000000000000381a <pipezero>:
{
    381a:	715d                	addi	sp,sp,-80
    381c:	e486                	sd	ra,72(sp)
    381e:	e0a2                	sd	s0,64(sp)
    3820:	fc26                	sd	s1,56(sp)
    3822:	f84a                	sd	s2,48(sp)
    3824:	f44e                	sd	s3,40(sp)
    3826:	f052                	sd	s4,32(sp)
    3828:	0880                	addi	s0,sp,80
    382a:	8a2a                	mv	s4,a0
  if ((reader = fork()) < 0) {
    382c:	64f010ef          	jal	567a <fork>
    3830:	04054663          	bltz	a0,387c <pipezero+0x62>
    3834:	892a                	mv	s2,a0
  if (reader == 0) {
    3836:	cd29                	beqz	a0,3890 <pipezero+0x76>
  if ((timer = fork()) < 0) {
    3838:	643010ef          	jal	567a <fork>
    383c:	84aa                	mv	s1,a0
    383e:	12054463          	bltz	a0,3966 <pipezero+0x14c>
  if (timer == 0) {
    3842:	14050263          	beqz	a0,3986 <pipezero+0x16c>
  pid = wait(&status);
    3846:	fcc40513          	addi	a0,s0,-52
    384a:	641010ef          	jal	568a <wait>
    384e:	89aa                	mv	s3,a0
  if (pid == timer) {
    3850:	14a48263          	beq	s1,a0,3994 <pipezero+0x17a>
  kill(timer);
    3854:	8526                	mv	a0,s1
    3856:	65d010ef          	jal	56b2 <kill>
  wait(0);
    385a:	4501                	li	a0,0
    385c:	62f010ef          	jal	568a <wait>
  if (pid != reader || status != 0)
    3860:	15391a63          	bne	s2,s3,39b4 <pipezero+0x19a>
    3864:	fcc42783          	lw	a5,-52(s0)
    3868:	14079663          	bnez	a5,39b4 <pipezero+0x19a>
}
    386c:	60a6                	ld	ra,72(sp)
    386e:	6406                	ld	s0,64(sp)
    3870:	74e2                	ld	s1,56(sp)
    3872:	7942                	ld	s2,48(sp)
    3874:	79a2                	ld	s3,40(sp)
    3876:	7a02                	ld	s4,32(sp)
    3878:	6161                	addi	sp,sp,80
    387a:	8082                	ret
    printf("%s: fork failed\n", s);
    387c:	85d2                	mv	a1,s4
    387e:	00003517          	auipc	a0,0x3
    3882:	cca50513          	addi	a0,a0,-822 # 6548 <malloc+0x9c2>
    3886:	24c020ef          	jal	5ad2 <printf>
    exit(1);
    388a:	4505                	li	a0,1
    388c:	5f7010ef          	jal	5682 <exit>
  char c = 'z';
    3890:	07a00793          	li	a5,122
    3894:	faf40fa3          	sb	a5,-65(s0)
  if (pipe(fds) < 0) {
    3898:	fc040513          	addi	a0,s0,-64
    389c:	5f7010ef          	jal	5692 <pipe>
    38a0:	08054563          	bltz	a0,392a <pipezero+0x110>
  if (read(fds[0], &c, 0) != 0 || c != 'z') {
    38a4:	4601                	li	a2,0
    38a6:	fbf40593          	addi	a1,s0,-65
    38aa:	fc042503          	lw	a0,-64(s0)
    38ae:	5ed010ef          	jal	569a <read>
    38b2:	e551                	bnez	a0,393e <pipezero+0x124>
    38b4:	fbf44703          	lbu	a4,-65(s0)
    38b8:	07a00793          	li	a5,122
    38bc:	08f71163          	bne	a4,a5,393e <pipezero+0x124>
  if (write(fds[1], "x", 1) != 1 || read(fds[0], &c, 0) != 0 || c != 'z' ||
    38c0:	4605                	li	a2,1
    38c2:	00002597          	auipc	a1,0x2
    38c6:	46658593          	addi	a1,a1,1126 # 5d28 <malloc+0x1a2>
    38ca:	fc442503          	lw	a0,-60(s0)
    38ce:	5d5010ef          	jal	56a2 <write>
    38d2:	4785                	li	a5,1
    38d4:	06f51f63          	bne	a0,a5,3952 <pipezero+0x138>
    38d8:	4601                	li	a2,0
    38da:	fbf40593          	addi	a1,s0,-65
    38de:	fc042503          	lw	a0,-64(s0)
    38e2:	5b9010ef          	jal	569a <read>
    38e6:	e535                	bnez	a0,3952 <pipezero+0x138>
    38e8:	fbf44703          	lbu	a4,-65(s0)
    38ec:	07a00793          	li	a5,122
    38f0:	06f71163          	bne	a4,a5,3952 <pipezero+0x138>
      read(fds[0], &c, 1) != 1 || c != 'x') {
    38f4:	4605                	li	a2,1
    38f6:	fbf40593          	addi	a1,s0,-65
    38fa:	fc042503          	lw	a0,-64(s0)
    38fe:	59d010ef          	jal	569a <read>
  if (write(fds[1], "x", 1) != 1 || read(fds[0], &c, 0) != 0 || c != 'z' ||
    3902:	4785                	li	a5,1
    3904:	04f51763          	bne	a0,a5,3952 <pipezero+0x138>
      read(fds[0], &c, 1) != 1 || c != 'x') {
    3908:	fbf44703          	lbu	a4,-65(s0)
    390c:	07800793          	li	a5,120
    3910:	04f71163          	bne	a4,a5,3952 <pipezero+0x138>
  close(fds[0]);
    3914:	fc042503          	lw	a0,-64(s0)
    3918:	593010ef          	jal	56aa <close>
  close(fds[1]);
    391c:	fc442503          	lw	a0,-60(s0)
    3920:	58b010ef          	jal	56aa <close>
    exit(0);
    3924:	4501                	li	a0,0
    3926:	55d010ef          	jal	5682 <exit>
    printf("%s: pipe failed\n", s);
    392a:	85d2                	mv	a1,s4
    392c:	00004517          	auipc	a0,0x4
    3930:	f1c50513          	addi	a0,a0,-228 # 7848 <malloc+0x1cc2>
    3934:	19e020ef          	jal	5ad2 <printf>
    exit(1);
    3938:	4505                	li	a0,1
    393a:	549010ef          	jal	5682 <exit>
    printf("%s: zero-length read on empty pipe failed\n", s);
    393e:	85d2                	mv	a1,s4
    3940:	00004517          	auipc	a0,0x4
    3944:	f2050513          	addi	a0,a0,-224 # 7860 <malloc+0x1cda>
    3948:	18a020ef          	jal	5ad2 <printf>
    exit(1);
    394c:	4505                	li	a0,1
    394e:	535010ef          	jal	5682 <exit>
    printf("%s: zero-length read consumed data\n", s);
    3952:	85d2                	mv	a1,s4
    3954:	00004517          	auipc	a0,0x4
    3958:	f3c50513          	addi	a0,a0,-196 # 7890 <malloc+0x1d0a>
    395c:	176020ef          	jal	5ad2 <printf>
    exit(1);
    3960:	4505                	li	a0,1
    3962:	521010ef          	jal	5682 <exit>
    kill(reader);
    3966:	854a                	mv	a0,s2
    3968:	54b010ef          	jal	56b2 <kill>
    wait(0);
    396c:	4501                	li	a0,0
    396e:	51d010ef          	jal	568a <wait>
    printf("%s: fork failed\n", s);
    3972:	85d2                	mv	a1,s4
    3974:	00003517          	auipc	a0,0x3
    3978:	bd450513          	addi	a0,a0,-1068 # 6548 <malloc+0x9c2>
    397c:	156020ef          	jal	5ad2 <printf>
    exit(1);
    3980:	4505                	li	a0,1
    3982:	501010ef          	jal	5682 <exit>
    pause(50);
    3986:	03200513          	li	a0,50
    398a:	589010ef          	jal	5712 <pause>
    exit(0);
    398e:	4501                	li	a0,0
    3990:	4f3010ef          	jal	5682 <exit>
    kill(reader);
    3994:	854a                	mv	a0,s2
    3996:	51d010ef          	jal	56b2 <kill>
    wait(0);
    399a:	4501                	li	a0,0
    399c:	4ef010ef          	jal	568a <wait>
    printf("%s: zero-length read timed out\n", s);
    39a0:	85d2                	mv	a1,s4
    39a2:	00004517          	auipc	a0,0x4
    39a6:	f1650513          	addi	a0,a0,-234 # 78b8 <malloc+0x1d32>
    39aa:	128020ef          	jal	5ad2 <printf>
    exit(1);
    39ae:	4505                	li	a0,1
    39b0:	4d3010ef          	jal	5682 <exit>
    exit(1);
    39b4:	4505                	li	a0,1
    39b6:	4cd010ef          	jal	5682 <exit>

00000000000039ba <killzero>:
{
    39ba:	7179                	addi	sp,sp,-48
    39bc:	f406                	sd	ra,40(sp)
    39be:	f022                	sd	s0,32(sp)
    39c0:	e84a                	sd	s2,16(sp)
    39c2:	1800                	addi	s0,sp,48
    39c4:	892a                	mv	s2,a0
  kill(0);
    39c6:	4501                	li	a0,0
    39c8:	4eb010ef          	jal	56b2 <kill>
  pid = fork();
    39cc:	4af010ef          	jal	567a <fork>
  if (pid < 0) {
    39d0:	00054863          	bltz	a0,39e0 <killzero+0x26>
    39d4:	ec26                	sd	s1,24(sp)
    39d6:	84aa                	mv	s1,a0
  if (pid == 0) {
    39d8:	ed19                	bnez	a0,39f6 <killzero+0x3c>
    exit(7);
    39da:	451d                	li	a0,7
    39dc:	4a7010ef          	jal	5682 <exit>
    39e0:	ec26                	sd	s1,24(sp)
    printf("%s: fork failed\n", s);
    39e2:	85ca                	mv	a1,s2
    39e4:	00003517          	auipc	a0,0x3
    39e8:	b6450513          	addi	a0,a0,-1180 # 6548 <malloc+0x9c2>
    39ec:	0e6020ef          	jal	5ad2 <printf>
    exit(1);
    39f0:	4505                	li	a0,1
    39f2:	491010ef          	jal	5682 <exit>
  if (wait(&xst) != pid) {
    39f6:	fdc40513          	addi	a0,s0,-36
    39fa:	491010ef          	jal	568a <wait>
    39fe:	02951163          	bne	a0,s1,3a20 <killzero+0x66>
  if (xst != 7) {
    3a02:	fdc42603          	lw	a2,-36(s0)
    3a06:	479d                	li	a5,7
    3a08:	02f60663          	beq	a2,a5,3a34 <killzero+0x7a>
    printf("%s: child exited with status %d, expected 7\n", s, xst);
    3a0c:	85ca                	mv	a1,s2
    3a0e:	00004517          	auipc	a0,0x4
    3a12:	eca50513          	addi	a0,a0,-310 # 78d8 <malloc+0x1d52>
    3a16:	0bc020ef          	jal	5ad2 <printf>
    exit(1);
    3a1a:	4505                	li	a0,1
    3a1c:	467010ef          	jal	5682 <exit>
    printf("%s: wait wrong pid\n", s);
    3a20:	85ca                	mv	a1,s2
    3a22:	00003517          	auipc	a0,0x3
    3a26:	c2e50513          	addi	a0,a0,-978 # 6650 <malloc+0xaca>
    3a2a:	0a8020ef          	jal	5ad2 <printf>
    exit(1);
    3a2e:	4505                	li	a0,1
    3a30:	453010ef          	jal	5682 <exit>
  exit(0);
    3a34:	4501                	li	a0,0
    3a36:	44d010ef          	jal	5682 <exit>

0000000000003a3a <preempt>:
{
    3a3a:	7139                	addi	sp,sp,-64
    3a3c:	fc06                	sd	ra,56(sp)
    3a3e:	f822                	sd	s0,48(sp)
    3a40:	f426                	sd	s1,40(sp)
    3a42:	f04a                	sd	s2,32(sp)
    3a44:	ec4e                	sd	s3,24(sp)
    3a46:	e852                	sd	s4,16(sp)
    3a48:	0080                	addi	s0,sp,64
    3a4a:	892a                	mv	s2,a0
  pid1 = fork();
    3a4c:	42f010ef          	jal	567a <fork>
  if (pid1 < 0) {
    3a50:	00054563          	bltz	a0,3a5a <preempt+0x20>
    3a54:	84aa                	mv	s1,a0
  if (pid1 == 0)
    3a56:	ed01                	bnez	a0,3a6e <preempt+0x34>
    for (;;)
    3a58:	a001                	j	3a58 <preempt+0x1e>
    printf("%s: fork failed", s);
    3a5a:	85ca                	mv	a1,s2
    3a5c:	00003517          	auipc	a0,0x3
    3a60:	c2c50513          	addi	a0,a0,-980 # 6688 <malloc+0xb02>
    3a64:	06e020ef          	jal	5ad2 <printf>
    exit(1);
    3a68:	4505                	li	a0,1
    3a6a:	419010ef          	jal	5682 <exit>
  pid2 = fork();
    3a6e:	40d010ef          	jal	567a <fork>
    3a72:	89aa                	mv	s3,a0
  if (pid2 < 0) {
    3a74:	00054463          	bltz	a0,3a7c <preempt+0x42>
  if (pid2 == 0)
    3a78:	ed01                	bnez	a0,3a90 <preempt+0x56>
    for (;;)
    3a7a:	a001                	j	3a7a <preempt+0x40>
    printf("%s: fork failed\n", s);
    3a7c:	85ca                	mv	a1,s2
    3a7e:	00003517          	auipc	a0,0x3
    3a82:	aca50513          	addi	a0,a0,-1334 # 6548 <malloc+0x9c2>
    3a86:	04c020ef          	jal	5ad2 <printf>
    exit(1);
    3a8a:	4505                	li	a0,1
    3a8c:	3f7010ef          	jal	5682 <exit>
  pipe(pfds);
    3a90:	fc840513          	addi	a0,s0,-56
    3a94:	3ff010ef          	jal	5692 <pipe>
  pid3 = fork();
    3a98:	3e3010ef          	jal	567a <fork>
    3a9c:	8a2a                	mv	s4,a0
  if (pid3 < 0) {
    3a9e:	02054863          	bltz	a0,3ace <preempt+0x94>
  if (pid3 == 0) {
    3aa2:	e921                	bnez	a0,3af2 <preempt+0xb8>
    close(pfds[0]);
    3aa4:	fc842503          	lw	a0,-56(s0)
    3aa8:	403010ef          	jal	56aa <close>
    if (write(pfds[1], "x", 1) != 1)
    3aac:	4605                	li	a2,1
    3aae:	00002597          	auipc	a1,0x2
    3ab2:	27a58593          	addi	a1,a1,634 # 5d28 <malloc+0x1a2>
    3ab6:	fcc42503          	lw	a0,-52(s0)
    3aba:	3e9010ef          	jal	56a2 <write>
    3abe:	4785                	li	a5,1
    3ac0:	02f51163          	bne	a0,a5,3ae2 <preempt+0xa8>
    close(pfds[1]);
    3ac4:	fcc42503          	lw	a0,-52(s0)
    3ac8:	3e3010ef          	jal	56aa <close>
    for (;;)
    3acc:	a001                	j	3acc <preempt+0x92>
    printf("%s: fork failed\n", s);
    3ace:	85ca                	mv	a1,s2
    3ad0:	00003517          	auipc	a0,0x3
    3ad4:	a7850513          	addi	a0,a0,-1416 # 6548 <malloc+0x9c2>
    3ad8:	7fb010ef          	jal	5ad2 <printf>
    exit(1);
    3adc:	4505                	li	a0,1
    3ade:	3a5010ef          	jal	5682 <exit>
      printf("%s: preempt write error", s);
    3ae2:	85ca                	mv	a1,s2
    3ae4:	00004517          	auipc	a0,0x4
    3ae8:	e2450513          	addi	a0,a0,-476 # 7908 <malloc+0x1d82>
    3aec:	7e7010ef          	jal	5ad2 <printf>
    3af0:	bfd1                	j	3ac4 <preempt+0x8a>
  close(pfds[1]);
    3af2:	fcc42503          	lw	a0,-52(s0)
    3af6:	3b5010ef          	jal	56aa <close>
  if (read(pfds[0], buf, sizeof(buf)) != 1) {
    3afa:	660d                	lui	a2,0x3
    3afc:	0000a597          	auipc	a1,0xa
    3b00:	20c58593          	addi	a1,a1,524 # dd08 <buf>
    3b04:	fc842503          	lw	a0,-56(s0)
    3b08:	393010ef          	jal	569a <read>
    3b0c:	4785                	li	a5,1
    3b0e:	02f50163          	beq	a0,a5,3b30 <preempt+0xf6>
    printf("%s: preempt read error", s);
    3b12:	85ca                	mv	a1,s2
    3b14:	00004517          	auipc	a0,0x4
    3b18:	e0c50513          	addi	a0,a0,-500 # 7920 <malloc+0x1d9a>
    3b1c:	7b7010ef          	jal	5ad2 <printf>
}
    3b20:	70e2                	ld	ra,56(sp)
    3b22:	7442                	ld	s0,48(sp)
    3b24:	74a2                	ld	s1,40(sp)
    3b26:	7902                	ld	s2,32(sp)
    3b28:	69e2                	ld	s3,24(sp)
    3b2a:	6a42                	ld	s4,16(sp)
    3b2c:	6121                	addi	sp,sp,64
    3b2e:	8082                	ret
  close(pfds[0]);
    3b30:	fc842503          	lw	a0,-56(s0)
    3b34:	377010ef          	jal	56aa <close>
  printf("kill... ");
    3b38:	00004517          	auipc	a0,0x4
    3b3c:	e0050513          	addi	a0,a0,-512 # 7938 <malloc+0x1db2>
    3b40:	793010ef          	jal	5ad2 <printf>
  kill(pid1);
    3b44:	8526                	mv	a0,s1
    3b46:	36d010ef          	jal	56b2 <kill>
  kill(pid2);
    3b4a:	854e                	mv	a0,s3
    3b4c:	367010ef          	jal	56b2 <kill>
  kill(pid3);
    3b50:	8552                	mv	a0,s4
    3b52:	361010ef          	jal	56b2 <kill>
  printf("wait... ");
    3b56:	00004517          	auipc	a0,0x4
    3b5a:	df250513          	addi	a0,a0,-526 # 7948 <malloc+0x1dc2>
    3b5e:	775010ef          	jal	5ad2 <printf>
  wait(0);
    3b62:	4501                	li	a0,0
    3b64:	327010ef          	jal	568a <wait>
  wait(0);
    3b68:	4501                	li	a0,0
    3b6a:	321010ef          	jal	568a <wait>
  wait(0);
    3b6e:	4501                	li	a0,0
    3b70:	31b010ef          	jal	568a <wait>
    3b74:	b775                	j	3b20 <preempt+0xe6>

0000000000003b76 <sbrkfail>:
{
    3b76:	7175                	addi	sp,sp,-144
    3b78:	e506                	sd	ra,136(sp)
    3b7a:	e122                	sd	s0,128(sp)
    3b7c:	fca6                	sd	s1,120(sp)
    3b7e:	f8ca                	sd	s2,112(sp)
    3b80:	f4ce                	sd	s3,104(sp)
    3b82:	f0d2                	sd	s4,96(sp)
    3b84:	ecd6                	sd	s5,88(sp)
    3b86:	e8da                	sd	s6,80(sp)
    3b88:	e4de                	sd	s7,72(sp)
    3b8a:	0900                	addi	s0,sp,144
    3b8c:	8b2a                	mv	s6,a0
  if (pipe(fds) != 0) {
    3b8e:	fa040513          	addi	a0,s0,-96
    3b92:	301010ef          	jal	5692 <pipe>
    3b96:	e919                	bnez	a0,3bac <sbrkfail+0x36>
    3b98:	8aaa                	mv	s5,a0
    3b9a:	f7040493          	addi	s1,s0,-144
    3b9e:	f9840993          	addi	s3,s0,-104
    3ba2:	8926                	mv	s2,s1
    if (pids[i] != -1) {
    3ba4:	5a7d                	li	s4,-1
      if (scratch == '0')
    3ba6:	03000b93          	li	s7,48
    3baa:	a08d                	j	3c0c <sbrkfail+0x96>
    printf("%s: pipe() failed\n", s);
    3bac:	85da                	mv	a1,s6
    3bae:	00003517          	auipc	a0,0x3
    3bb2:	a2250513          	addi	a0,a0,-1502 # 65d0 <malloc+0xa4a>
    3bb6:	71d010ef          	jal	5ad2 <printf>
    exit(1);
    3bba:	4505                	li	a0,1
    3bbc:	2c7010ef          	jal	5682 <exit>
      if (sbrk(BIG - (uint64)sbrk(0)) == (char *)SBRK_ERROR)
    3bc0:	28f010ef          	jal	564e <sbrk>
    3bc4:	064007b7          	lui	a5,0x6400
    3bc8:	40a7853b          	subw	a0,a5,a0
    3bcc:	283010ef          	jal	564e <sbrk>
    3bd0:	57fd                	li	a5,-1
    3bd2:	02f50063          	beq	a0,a5,3bf2 <sbrkfail+0x7c>
        write(fds[1], "1", 1);
    3bd6:	4605                	li	a2,1
    3bd8:	00004597          	auipc	a1,0x4
    3bdc:	76858593          	addi	a1,a1,1896 # 8340 <malloc+0x27ba>
    3be0:	fa442503          	lw	a0,-92(s0)
    3be4:	2bf010ef          	jal	56a2 <write>
        pause(1000);
    3be8:	3e800513          	li	a0,1000
    3bec:	327010ef          	jal	5712 <pause>
      for (;;)
    3bf0:	bfe5                	j	3be8 <sbrkfail+0x72>
        write(fds[1], "0", 1);
    3bf2:	4605                	li	a2,1
    3bf4:	00004597          	auipc	a1,0x4
    3bf8:	d6458593          	addi	a1,a1,-668 # 7958 <malloc+0x1dd2>
    3bfc:	fa442503          	lw	a0,-92(s0)
    3c00:	2a3010ef          	jal	56a2 <write>
    3c04:	b7d5                	j	3be8 <sbrkfail+0x72>
  for (i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
    3c06:	0911                	addi	s2,s2,4
    3c08:	03390663          	beq	s2,s3,3c34 <sbrkfail+0xbe>
    if ((pids[i] = fork()) == 0) {
    3c0c:	26f010ef          	jal	567a <fork>
    3c10:	00a92023          	sw	a0,0(s2)
    3c14:	d555                	beqz	a0,3bc0 <sbrkfail+0x4a>
    if (pids[i] != -1) {
    3c16:	ff4508e3          	beq	a0,s4,3c06 <sbrkfail+0x90>
      read(fds[0], &scratch, 1);
    3c1a:	4605                	li	a2,1
    3c1c:	f9f40593          	addi	a1,s0,-97
    3c20:	fa042503          	lw	a0,-96(s0)
    3c24:	277010ef          	jal	569a <read>
      if (scratch == '0')
    3c28:	f9f44783          	lbu	a5,-97(s0)
    3c2c:	fd779de3          	bne	a5,s7,3c06 <sbrkfail+0x90>
        failed = 1;
    3c30:	4a85                	li	s5,1
    3c32:	bfd1                	j	3c06 <sbrkfail+0x90>
  if (!failed) {
    3c34:	000a8863          	beqz	s5,3c44 <sbrkfail+0xce>
  c = sbrk(PGSIZE);
    3c38:	6505                	lui	a0,0x1
    3c3a:	215010ef          	jal	564e <sbrk>
    3c3e:	8a2a                	mv	s4,a0
    if (pids[i] == -1)
    3c40:	597d                	li	s2,-1
    3c42:	a821                	j	3c5a <sbrkfail+0xe4>
    printf("%s: no allocation failed; allocate more?\n", s);
    3c44:	85da                	mv	a1,s6
    3c46:	00004517          	auipc	a0,0x4
    3c4a:	d1a50513          	addi	a0,a0,-742 # 7960 <malloc+0x1dda>
    3c4e:	685010ef          	jal	5ad2 <printf>
    3c52:	b7dd                	j	3c38 <sbrkfail+0xc2>
  for (i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
    3c54:	0491                	addi	s1,s1,4
    3c56:	01348b63          	beq	s1,s3,3c6c <sbrkfail+0xf6>
    if (pids[i] == -1)
    3c5a:	4088                	lw	a0,0(s1)
    3c5c:	ff250ce3          	beq	a0,s2,3c54 <sbrkfail+0xde>
    kill(pids[i]);
    3c60:	253010ef          	jal	56b2 <kill>
    wait(0);
    3c64:	4501                	li	a0,0
    3c66:	225010ef          	jal	568a <wait>
    3c6a:	b7ed                	j	3c54 <sbrkfail+0xde>
  if (c == (char *)SBRK_ERROR) {
    3c6c:	57fd                	li	a5,-1
    3c6e:	02fa0a63          	beq	s4,a5,3ca2 <sbrkfail+0x12c>
  pid = fork();
    3c72:	209010ef          	jal	567a <fork>
  if (pid < 0) {
    3c76:	04054063          	bltz	a0,3cb6 <sbrkfail+0x140>
  if (pid == 0) {
    3c7a:	e939                	bnez	a0,3cd0 <sbrkfail+0x15a>
    a = sbrk(10 * BIG);
    3c7c:	3e800537          	lui	a0,0x3e800
    3c80:	1cf010ef          	jal	564e <sbrk>
    if (a == (char *)SBRK_ERROR) {
    3c84:	57fd                	li	a5,-1
    3c86:	04f50263          	beq	a0,a5,3cca <sbrkfail+0x154>
    printf("%s: allocate a lot of memory succeeded %d\n", s, 10 * BIG);
    3c8a:	3e800637          	lui	a2,0x3e800
    3c8e:	85da                	mv	a1,s6
    3c90:	00004517          	auipc	a0,0x4
    3c94:	d2050513          	addi	a0,a0,-736 # 79b0 <malloc+0x1e2a>
    3c98:	63b010ef          	jal	5ad2 <printf>
    exit(1);
    3c9c:	4505                	li	a0,1
    3c9e:	1e5010ef          	jal	5682 <exit>
    printf("%s: failed sbrk leaked memory\n", s);
    3ca2:	85da                	mv	a1,s6
    3ca4:	00004517          	auipc	a0,0x4
    3ca8:	cec50513          	addi	a0,a0,-788 # 7990 <malloc+0x1e0a>
    3cac:	627010ef          	jal	5ad2 <printf>
    exit(1);
    3cb0:	4505                	li	a0,1
    3cb2:	1d1010ef          	jal	5682 <exit>
    printf("%s: fork failed\n", s);
    3cb6:	85da                	mv	a1,s6
    3cb8:	00003517          	auipc	a0,0x3
    3cbc:	89050513          	addi	a0,a0,-1904 # 6548 <malloc+0x9c2>
    3cc0:	613010ef          	jal	5ad2 <printf>
    exit(1);
    3cc4:	4505                	li	a0,1
    3cc6:	1bd010ef          	jal	5682 <exit>
      exit(0);
    3cca:	4501                	li	a0,0
    3ccc:	1b7010ef          	jal	5682 <exit>
  wait(&xstatus);
    3cd0:	fac40513          	addi	a0,s0,-84
    3cd4:	1b7010ef          	jal	568a <wait>
  if (xstatus != 0)
    3cd8:	fac42783          	lw	a5,-84(s0)
    3cdc:	ef81                	bnez	a5,3cf4 <sbrkfail+0x17e>
}
    3cde:	60aa                	ld	ra,136(sp)
    3ce0:	640a                	ld	s0,128(sp)
    3ce2:	74e6                	ld	s1,120(sp)
    3ce4:	7946                	ld	s2,112(sp)
    3ce6:	79a6                	ld	s3,104(sp)
    3ce8:	7a06                	ld	s4,96(sp)
    3cea:	6ae6                	ld	s5,88(sp)
    3cec:	6b46                	ld	s6,80(sp)
    3cee:	6ba6                	ld	s7,72(sp)
    3cf0:	6149                	addi	sp,sp,144
    3cf2:	8082                	ret
    exit(1);
    3cf4:	4505                	li	a0,1
    3cf6:	18d010ef          	jal	5682 <exit>

0000000000003cfa <killstatus>:
{
    3cfa:	7139                	addi	sp,sp,-64
    3cfc:	fc06                	sd	ra,56(sp)
    3cfe:	f822                	sd	s0,48(sp)
    3d00:	f426                	sd	s1,40(sp)
    3d02:	f04a                	sd	s2,32(sp)
    3d04:	ec4e                	sd	s3,24(sp)
    3d06:	e852                	sd	s4,16(sp)
    3d08:	0080                	addi	s0,sp,64
    3d0a:	8a2a                	mv	s4,a0
    3d0c:	06400913          	li	s2,100
    if (xst != -1) {
    3d10:	59fd                	li	s3,-1
    int pid1 = fork();
    3d12:	169010ef          	jal	567a <fork>
    3d16:	84aa                	mv	s1,a0
    if (pid1 < 0) {
    3d18:	02054763          	bltz	a0,3d46 <killstatus+0x4c>
    if (pid1 == 0) {
    3d1c:	cd1d                	beqz	a0,3d5a <killstatus+0x60>
    pause(1);
    3d1e:	4505                	li	a0,1
    3d20:	1f3010ef          	jal	5712 <pause>
    kill(pid1);
    3d24:	8526                	mv	a0,s1
    3d26:	18d010ef          	jal	56b2 <kill>
    wait(&xst);
    3d2a:	fcc40513          	addi	a0,s0,-52
    3d2e:	15d010ef          	jal	568a <wait>
    if (xst != -1) {
    3d32:	fcc42783          	lw	a5,-52(s0)
    3d36:	03379563          	bne	a5,s3,3d60 <killstatus+0x66>
  for (int i = 0; i < 100; i++) {
    3d3a:	397d                	addiw	s2,s2,-1
    3d3c:	fc091be3          	bnez	s2,3d12 <killstatus+0x18>
  exit(0);
    3d40:	4501                	li	a0,0
    3d42:	141010ef          	jal	5682 <exit>
      printf("%s: fork failed\n", s);
    3d46:	85d2                	mv	a1,s4
    3d48:	00003517          	auipc	a0,0x3
    3d4c:	80050513          	addi	a0,a0,-2048 # 6548 <malloc+0x9c2>
    3d50:	583010ef          	jal	5ad2 <printf>
      exit(1);
    3d54:	4505                	li	a0,1
    3d56:	12d010ef          	jal	5682 <exit>
        getpid();
    3d5a:	1a9010ef          	jal	5702 <getpid>
      while (1) {
    3d5e:	bff5                	j	3d5a <killstatus+0x60>
      printf("%s: status should be -1\n", s);
    3d60:	85d2                	mv	a1,s4
    3d62:	00004517          	auipc	a0,0x4
    3d66:	c7e50513          	addi	a0,a0,-898 # 79e0 <malloc+0x1e5a>
    3d6a:	569010ef          	jal	5ad2 <printf>
      exit(1);
    3d6e:	4505                	li	a0,1
    3d70:	113010ef          	jal	5682 <exit>

0000000000003d74 <reparent>:
{
    3d74:	7179                	addi	sp,sp,-48
    3d76:	f406                	sd	ra,40(sp)
    3d78:	f022                	sd	s0,32(sp)
    3d7a:	ec26                	sd	s1,24(sp)
    3d7c:	e84a                	sd	s2,16(sp)
    3d7e:	e44e                	sd	s3,8(sp)
    3d80:	e052                	sd	s4,0(sp)
    3d82:	1800                	addi	s0,sp,48
    3d84:	89aa                	mv	s3,a0
  int master_pid = getpid();
    3d86:	17d010ef          	jal	5702 <getpid>
    3d8a:	8a2a                	mv	s4,a0
    3d8c:	0c800913          	li	s2,200
    int pid = fork();
    3d90:	0eb010ef          	jal	567a <fork>
    3d94:	84aa                	mv	s1,a0
    if (pid < 0) {
    3d96:	00054e63          	bltz	a0,3db2 <reparent+0x3e>
    if (pid) {
    3d9a:	c121                	beqz	a0,3dda <reparent+0x66>
      if (wait(0) != pid) {
    3d9c:	4501                	li	a0,0
    3d9e:	0ed010ef          	jal	568a <wait>
    3da2:	02951263          	bne	a0,s1,3dc6 <reparent+0x52>
  for (int i = 0; i < 200; i++) {
    3da6:	397d                	addiw	s2,s2,-1
    3da8:	fe0914e3          	bnez	s2,3d90 <reparent+0x1c>
  exit(0);
    3dac:	4501                	li	a0,0
    3dae:	0d5010ef          	jal	5682 <exit>
      printf("%s: fork failed\n", s);
    3db2:	85ce                	mv	a1,s3
    3db4:	00002517          	auipc	a0,0x2
    3db8:	79450513          	addi	a0,a0,1940 # 6548 <malloc+0x9c2>
    3dbc:	517010ef          	jal	5ad2 <printf>
      exit(1);
    3dc0:	4505                	li	a0,1
    3dc2:	0c1010ef          	jal	5682 <exit>
        printf("%s: wait wrong pid\n", s);
    3dc6:	85ce                	mv	a1,s3
    3dc8:	00003517          	auipc	a0,0x3
    3dcc:	88850513          	addi	a0,a0,-1912 # 6650 <malloc+0xaca>
    3dd0:	503010ef          	jal	5ad2 <printf>
        exit(1);
    3dd4:	4505                	li	a0,1
    3dd6:	0ad010ef          	jal	5682 <exit>
      int pid2 = fork();
    3dda:	0a1010ef          	jal	567a <fork>
      if (pid2 < 0) {
    3dde:	00054563          	bltz	a0,3de8 <reparent+0x74>
      exit(0);
    3de2:	4501                	li	a0,0
    3de4:	09f010ef          	jal	5682 <exit>
        kill(master_pid);
    3de8:	8552                	mv	a0,s4
    3dea:	0c9010ef          	jal	56b2 <kill>
        exit(1);
    3dee:	4505                	li	a0,1
    3df0:	093010ef          	jal	5682 <exit>

0000000000003df4 <mem>:
{
    3df4:	7139                	addi	sp,sp,-64
    3df6:	fc06                	sd	ra,56(sp)
    3df8:	f822                	sd	s0,48(sp)
    3dfa:	f426                	sd	s1,40(sp)
    3dfc:	f04a                	sd	s2,32(sp)
    3dfe:	ec4e                	sd	s3,24(sp)
    3e00:	0080                	addi	s0,sp,64
    3e02:	89aa                	mv	s3,a0
  if ((pid = fork()) == 0) {
    3e04:	077010ef          	jal	567a <fork>
    m1 = 0;
    3e08:	4481                	li	s1,0
    while ((m2 = malloc(10001)) != 0) {
    3e0a:	6909                	lui	s2,0x2
    3e0c:	71190913          	addi	s2,s2,1809 # 2711 <diskfull+0xd1>
  if ((pid = fork()) == 0) {
    3e10:	cd11                	beqz	a0,3e2c <mem+0x38>
    wait(&xstatus);
    3e12:	fcc40513          	addi	a0,s0,-52
    3e16:	075010ef          	jal	568a <wait>
    if (xstatus == -1) {
    3e1a:	fcc42503          	lw	a0,-52(s0)
    3e1e:	57fd                	li	a5,-1
    3e20:	04f50363          	beq	a0,a5,3e66 <mem+0x72>
    exit(xstatus);
    3e24:	05f010ef          	jal	5682 <exit>
      *(char **)m2 = m1;
    3e28:	e104                	sd	s1,0(a0)
      m1 = m2;
    3e2a:	84aa                	mv	s1,a0
    while ((m2 = malloc(10001)) != 0) {
    3e2c:	854a                	mv	a0,s2
    3e2e:	559010ef          	jal	5b86 <malloc>
    3e32:	f97d                	bnez	a0,3e28 <mem+0x34>
    while (m1) {
    3e34:	c491                	beqz	s1,3e40 <mem+0x4c>
      m2 = *(char **)m1;
    3e36:	8526                	mv	a0,s1
    3e38:	6084                	ld	s1,0(s1)
      free(m1);
    3e3a:	4cb010ef          	jal	5b04 <free>
    while (m1) {
    3e3e:	fce5                	bnez	s1,3e36 <mem+0x42>
    m1 = malloc(1024 * 20);
    3e40:	6515                	lui	a0,0x5
    3e42:	545010ef          	jal	5b86 <malloc>
    if (m1 == 0) {
    3e46:	c511                	beqz	a0,3e52 <mem+0x5e>
    free(m1);
    3e48:	4bd010ef          	jal	5b04 <free>
    exit(0);
    3e4c:	4501                	li	a0,0
    3e4e:	035010ef          	jal	5682 <exit>
      printf("%s: couldn't allocate mem?!!\n", s);
    3e52:	85ce                	mv	a1,s3
    3e54:	00004517          	auipc	a0,0x4
    3e58:	bac50513          	addi	a0,a0,-1108 # 7a00 <malloc+0x1e7a>
    3e5c:	477010ef          	jal	5ad2 <printf>
      exit(1);
    3e60:	4505                	li	a0,1
    3e62:	021010ef          	jal	5682 <exit>
      exit(0);
    3e66:	4501                	li	a0,0
    3e68:	01b010ef          	jal	5682 <exit>

0000000000003e6c <sharedfd>:
{
    3e6c:	7159                	addi	sp,sp,-112
    3e6e:	f486                	sd	ra,104(sp)
    3e70:	f0a2                	sd	s0,96(sp)
    3e72:	e0d2                	sd	s4,64(sp)
    3e74:	1880                	addi	s0,sp,112
    3e76:	8a2a                	mv	s4,a0
  unlink("sharedfd");
    3e78:	00004517          	auipc	a0,0x4
    3e7c:	ba850513          	addi	a0,a0,-1112 # 7a20 <malloc+0x1e9a>
    3e80:	053010ef          	jal	56d2 <unlink>
  fd = open("sharedfd", O_CREATE | O_RDWR);
    3e84:	20200593          	li	a1,514
    3e88:	00004517          	auipc	a0,0x4
    3e8c:	b9850513          	addi	a0,a0,-1128 # 7a20 <malloc+0x1e9a>
    3e90:	033010ef          	jal	56c2 <open>
  if (fd < 0) {
    3e94:	04054863          	bltz	a0,3ee4 <sharedfd+0x78>
    3e98:	eca6                	sd	s1,88(sp)
    3e9a:	e8ca                	sd	s2,80(sp)
    3e9c:	e4ce                	sd	s3,72(sp)
    3e9e:	fc56                	sd	s5,56(sp)
    3ea0:	f85a                	sd	s6,48(sp)
    3ea2:	f45e                	sd	s7,40(sp)
    3ea4:	892a                	mv	s2,a0
  pid = fork();
    3ea6:	7d4010ef          	jal	567a <fork>
    3eaa:	89aa                	mv	s3,a0
  memset(buf, pid == 0 ? 'c' : 'p', sizeof(buf));
    3eac:	07000593          	li	a1,112
    3eb0:	e119                	bnez	a0,3eb6 <sharedfd+0x4a>
    3eb2:	06300593          	li	a1,99
    3eb6:	4629                	li	a2,10
    3eb8:	fa040513          	addi	a0,s0,-96
    3ebc:	5b4010ef          	jal	5470 <memset>
    3ec0:	3e800493          	li	s1,1000
    if (write(fd, buf, sizeof(buf)) != sizeof(buf)) {
    3ec4:	4629                	li	a2,10
    3ec6:	fa040593          	addi	a1,s0,-96
    3eca:	854a                	mv	a0,s2
    3ecc:	7d6010ef          	jal	56a2 <write>
    3ed0:	47a9                	li	a5,10
    3ed2:	02f51963          	bne	a0,a5,3f04 <sharedfd+0x98>
  for (i = 0; i < N; i++) {
    3ed6:	34fd                	addiw	s1,s1,-1
    3ed8:	f4f5                	bnez	s1,3ec4 <sharedfd+0x58>
  if (pid == 0) {
    3eda:	02099f63          	bnez	s3,3f18 <sharedfd+0xac>
    exit(0);
    3ede:	4501                	li	a0,0
    3ee0:	7a2010ef          	jal	5682 <exit>
    3ee4:	eca6                	sd	s1,88(sp)
    3ee6:	e8ca                	sd	s2,80(sp)
    3ee8:	e4ce                	sd	s3,72(sp)
    3eea:	fc56                	sd	s5,56(sp)
    3eec:	f85a                	sd	s6,48(sp)
    3eee:	f45e                	sd	s7,40(sp)
    printf("%s: cannot open sharedfd for writing", s);
    3ef0:	85d2                	mv	a1,s4
    3ef2:	00004517          	auipc	a0,0x4
    3ef6:	b3e50513          	addi	a0,a0,-1218 # 7a30 <malloc+0x1eaa>
    3efa:	3d9010ef          	jal	5ad2 <printf>
    exit(1);
    3efe:	4505                	li	a0,1
    3f00:	782010ef          	jal	5682 <exit>
      printf("%s: write sharedfd failed\n", s);
    3f04:	85d2                	mv	a1,s4
    3f06:	00004517          	auipc	a0,0x4
    3f0a:	b5250513          	addi	a0,a0,-1198 # 7a58 <malloc+0x1ed2>
    3f0e:	3c5010ef          	jal	5ad2 <printf>
      exit(1);
    3f12:	4505                	li	a0,1
    3f14:	76e010ef          	jal	5682 <exit>
    wait(&xstatus);
    3f18:	f9c40513          	addi	a0,s0,-100
    3f1c:	76e010ef          	jal	568a <wait>
    if (xstatus != 0)
    3f20:	f9c42983          	lw	s3,-100(s0)
    3f24:	00098563          	beqz	s3,3f2e <sharedfd+0xc2>
      exit(xstatus);
    3f28:	854e                	mv	a0,s3
    3f2a:	758010ef          	jal	5682 <exit>
  close(fd);
    3f2e:	854a                	mv	a0,s2
    3f30:	77a010ef          	jal	56aa <close>
  fd = open("sharedfd", 0);
    3f34:	4581                	li	a1,0
    3f36:	00004517          	auipc	a0,0x4
    3f3a:	aea50513          	addi	a0,a0,-1302 # 7a20 <malloc+0x1e9a>
    3f3e:	784010ef          	jal	56c2 <open>
    3f42:	8baa                	mv	s7,a0
  nc = np = 0;
    3f44:	8ace                	mv	s5,s3
  if (fd < 0) {
    3f46:	02054363          	bltz	a0,3f6c <sharedfd+0x100>
    3f4a:	faa40913          	addi	s2,s0,-86
      if (buf[i] == 'c')
    3f4e:	06300493          	li	s1,99
      if (buf[i] == 'p')
    3f52:	07000b13          	li	s6,112
  while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3f56:	4629                	li	a2,10
    3f58:	fa040593          	addi	a1,s0,-96
    3f5c:	855e                	mv	a0,s7
    3f5e:	73c010ef          	jal	569a <read>
    3f62:	02a05b63          	blez	a0,3f98 <sharedfd+0x12c>
    3f66:	fa040793          	addi	a5,s0,-96
    3f6a:	a839                	j	3f88 <sharedfd+0x11c>
    printf("%s: cannot open sharedfd for reading\n", s);
    3f6c:	85d2                	mv	a1,s4
    3f6e:	00004517          	auipc	a0,0x4
    3f72:	b0a50513          	addi	a0,a0,-1270 # 7a78 <malloc+0x1ef2>
    3f76:	35d010ef          	jal	5ad2 <printf>
    exit(1);
    3f7a:	4505                	li	a0,1
    3f7c:	706010ef          	jal	5682 <exit>
        nc++;
    3f80:	2985                	addiw	s3,s3,1
    for (i = 0; i < sizeof(buf); i++) {
    3f82:	0785                	addi	a5,a5,1 # 6400001 <base+0x63ef2f9>
    3f84:	fd2789e3          	beq	a5,s2,3f56 <sharedfd+0xea>
      if (buf[i] == 'c')
    3f88:	0007c703          	lbu	a4,0(a5)
    3f8c:	fe970ae3          	beq	a4,s1,3f80 <sharedfd+0x114>
      if (buf[i] == 'p')
    3f90:	ff6719e3          	bne	a4,s6,3f82 <sharedfd+0x116>
        np++;
    3f94:	2a85                	addiw	s5,s5,1
    3f96:	b7f5                	j	3f82 <sharedfd+0x116>
  close(fd);
    3f98:	855e                	mv	a0,s7
    3f9a:	710010ef          	jal	56aa <close>
  unlink("sharedfd");
    3f9e:	00004517          	auipc	a0,0x4
    3fa2:	a8250513          	addi	a0,a0,-1406 # 7a20 <malloc+0x1e9a>
    3fa6:	72c010ef          	jal	56d2 <unlink>
  if (nc == N * SZ && np == N * SZ) {
    3faa:	6789                	lui	a5,0x2
    3fac:	71078793          	addi	a5,a5,1808 # 2710 <diskfull+0xd0>
    3fb0:	00f99763          	bne	s3,a5,3fbe <sharedfd+0x152>
    3fb4:	6789                	lui	a5,0x2
    3fb6:	71078793          	addi	a5,a5,1808 # 2710 <diskfull+0xd0>
    3fba:	00fa8c63          	beq	s5,a5,3fd2 <sharedfd+0x166>
    printf("%s: nc/np test fails\n", s);
    3fbe:	85d2                	mv	a1,s4
    3fc0:	00004517          	auipc	a0,0x4
    3fc4:	ae050513          	addi	a0,a0,-1312 # 7aa0 <malloc+0x1f1a>
    3fc8:	30b010ef          	jal	5ad2 <printf>
    exit(1);
    3fcc:	4505                	li	a0,1
    3fce:	6b4010ef          	jal	5682 <exit>
    exit(0);
    3fd2:	4501                	li	a0,0
    3fd4:	6ae010ef          	jal	5682 <exit>

0000000000003fd8 <fourfiles>:
{
    3fd8:	7135                	addi	sp,sp,-160
    3fda:	ed06                	sd	ra,152(sp)
    3fdc:	e922                	sd	s0,144(sp)
    3fde:	e526                	sd	s1,136(sp)
    3fe0:	e14a                	sd	s2,128(sp)
    3fe2:	fcce                	sd	s3,120(sp)
    3fe4:	f8d2                	sd	s4,112(sp)
    3fe6:	f4d6                	sd	s5,104(sp)
    3fe8:	f0da                	sd	s6,96(sp)
    3fea:	ecde                	sd	s7,88(sp)
    3fec:	e8e2                	sd	s8,80(sp)
    3fee:	e4e6                	sd	s9,72(sp)
    3ff0:	e0ea                	sd	s10,64(sp)
    3ff2:	fc6e                	sd	s11,56(sp)
    3ff4:	1100                	addi	s0,sp,160
    3ff6:	8caa                	mv	s9,a0
  char *names[] = {"f0", "f1", "f2", "f3"};
    3ff8:	00004797          	auipc	a5,0x4
    3ffc:	ac078793          	addi	a5,a5,-1344 # 7ab8 <malloc+0x1f32>
    4000:	f6f43823          	sd	a5,-144(s0)
    4004:	00004797          	auipc	a5,0x4
    4008:	abc78793          	addi	a5,a5,-1348 # 7ac0 <malloc+0x1f3a>
    400c:	f6f43c23          	sd	a5,-136(s0)
    4010:	00004797          	auipc	a5,0x4
    4014:	ab878793          	addi	a5,a5,-1352 # 7ac8 <malloc+0x1f42>
    4018:	f8f43023          	sd	a5,-128(s0)
    401c:	00004797          	auipc	a5,0x4
    4020:	ab478793          	addi	a5,a5,-1356 # 7ad0 <malloc+0x1f4a>
    4024:	f8f43423          	sd	a5,-120(s0)
  for (pi = 0; pi < NCHILD; pi++) {
    4028:	f7040b93          	addi	s7,s0,-144
  char *names[] = {"f0", "f1", "f2", "f3"};
    402c:	895e                	mv	s2,s7
  for (pi = 0; pi < NCHILD; pi++) {
    402e:	4481                	li	s1,0
    4030:	4a11                	li	s4,4
    fname = names[pi];
    4032:	00093983          	ld	s3,0(s2)
    unlink(fname);
    4036:	854e                	mv	a0,s3
    4038:	69a010ef          	jal	56d2 <unlink>
    pid = fork();
    403c:	63e010ef          	jal	567a <fork>
    if (pid < 0) {
    4040:	02054e63          	bltz	a0,407c <fourfiles+0xa4>
    if (pid == 0) {
    4044:	c531                	beqz	a0,4090 <fourfiles+0xb8>
  for (pi = 0; pi < NCHILD; pi++) {
    4046:	2485                	addiw	s1,s1,1
    4048:	0921                	addi	s2,s2,8
    404a:	ff4494e3          	bne	s1,s4,4032 <fourfiles+0x5a>
    404e:	4491                	li	s1,4
    wait(&xstatus);
    4050:	f6c40513          	addi	a0,s0,-148
    4054:	636010ef          	jal	568a <wait>
    if (xstatus != 0)
    4058:	f6c42a83          	lw	s5,-148(s0)
    405c:	0a0a9463          	bnez	s5,4104 <fourfiles+0x12c>
  for (pi = 0; pi < NCHILD; pi++) {
    4060:	34fd                	addiw	s1,s1,-1
    4062:	f4fd                	bnez	s1,4050 <fourfiles+0x78>
    4064:	03000b13          	li	s6,48
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    4068:	0000aa17          	auipc	s4,0xa
    406c:	ca0a0a13          	addi	s4,s4,-864 # dd08 <buf>
    if (total != N * SZ) {
    4070:	6d05                	lui	s10,0x1
    4072:	770d0d13          	addi	s10,s10,1904 # 1770 <createdelete+0xb6>
  for (i = 0; i < NCHILD; i++) {
    4076:	03400d93          	li	s11,52
    407a:	a0ed                	j	4164 <fourfiles+0x18c>
      printf("%s: fork failed\n", s);
    407c:	85e6                	mv	a1,s9
    407e:	00002517          	auipc	a0,0x2
    4082:	4ca50513          	addi	a0,a0,1226 # 6548 <malloc+0x9c2>
    4086:	24d010ef          	jal	5ad2 <printf>
      exit(1);
    408a:	4505                	li	a0,1
    408c:	5f6010ef          	jal	5682 <exit>
      fd = open(fname, O_CREATE | O_RDWR);
    4090:	20200593          	li	a1,514
    4094:	854e                	mv	a0,s3
    4096:	62c010ef          	jal	56c2 <open>
    409a:	892a                	mv	s2,a0
      if (fd < 0) {
    409c:	04054163          	bltz	a0,40de <fourfiles+0x106>
      memset(buf, '0' + pi, SZ);
    40a0:	1f400613          	li	a2,500
    40a4:	0304859b          	addiw	a1,s1,48
    40a8:	0000a517          	auipc	a0,0xa
    40ac:	c6050513          	addi	a0,a0,-928 # dd08 <buf>
    40b0:	3c0010ef          	jal	5470 <memset>
    40b4:	44b1                	li	s1,12
        if ((n = write(fd, buf, SZ)) != SZ) {
    40b6:	0000a997          	auipc	s3,0xa
    40ba:	c5298993          	addi	s3,s3,-942 # dd08 <buf>
    40be:	1f400613          	li	a2,500
    40c2:	85ce                	mv	a1,s3
    40c4:	854a                	mv	a0,s2
    40c6:	5dc010ef          	jal	56a2 <write>
    40ca:	85aa                	mv	a1,a0
    40cc:	1f400793          	li	a5,500
    40d0:	02f51163          	bne	a0,a5,40f2 <fourfiles+0x11a>
      for (i = 0; i < N; i++) {
    40d4:	34fd                	addiw	s1,s1,-1
    40d6:	f4e5                	bnez	s1,40be <fourfiles+0xe6>
      exit(0);
    40d8:	4501                	li	a0,0
    40da:	5a8010ef          	jal	5682 <exit>
        printf("%s: create failed\n", s);
    40de:	85e6                	mv	a1,s9
    40e0:	00002517          	auipc	a0,0x2
    40e4:	5d850513          	addi	a0,a0,1496 # 66b8 <malloc+0xb32>
    40e8:	1eb010ef          	jal	5ad2 <printf>
        exit(1);
    40ec:	4505                	li	a0,1
    40ee:	594010ef          	jal	5682 <exit>
          printf("write failed %d\n", n);
    40f2:	00004517          	auipc	a0,0x4
    40f6:	9e650513          	addi	a0,a0,-1562 # 7ad8 <malloc+0x1f52>
    40fa:	1d9010ef          	jal	5ad2 <printf>
          exit(1);
    40fe:	4505                	li	a0,1
    4100:	582010ef          	jal	5682 <exit>
      exit(xstatus);
    4104:	8556                	mv	a0,s5
    4106:	57c010ef          	jal	5682 <exit>
          printf("%s: wrong char\n", s);
    410a:	85e6                	mv	a1,s9
    410c:	00004517          	auipc	a0,0x4
    4110:	9e450513          	addi	a0,a0,-1564 # 7af0 <malloc+0x1f6a>
    4114:	1bf010ef          	jal	5ad2 <printf>
          exit(1);
    4118:	4505                	li	a0,1
    411a:	568010ef          	jal	5682 <exit>
      total += n;
    411e:	00a9093b          	addw	s2,s2,a0
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    4122:	660d                	lui	a2,0x3
    4124:	85d2                	mv	a1,s4
    4126:	854e                	mv	a0,s3
    4128:	572010ef          	jal	569a <read>
    412c:	02a05063          	blez	a0,414c <fourfiles+0x174>
    4130:	0000a797          	auipc	a5,0xa
    4134:	bd878793          	addi	a5,a5,-1064 # dd08 <buf>
    4138:	00f506b3          	add	a3,a0,a5
        if (buf[j] != '0' + i) {
    413c:	0007c703          	lbu	a4,0(a5)
    4140:	fc9715e3          	bne	a4,s1,410a <fourfiles+0x132>
      for (j = 0; j < n; j++) {
    4144:	0785                	addi	a5,a5,1
    4146:	fed79be3          	bne	a5,a3,413c <fourfiles+0x164>
    414a:	bfd1                	j	411e <fourfiles+0x146>
    close(fd);
    414c:	854e                	mv	a0,s3
    414e:	55c010ef          	jal	56aa <close>
    if (total != N * SZ) {
    4152:	03a91463          	bne	s2,s10,417a <fourfiles+0x1a2>
    unlink(fname);
    4156:	8562                	mv	a0,s8
    4158:	57a010ef          	jal	56d2 <unlink>
  for (i = 0; i < NCHILD; i++) {
    415c:	0ba1                	addi	s7,s7,8
    415e:	2b05                	addiw	s6,s6,1
    4160:	03bb0763          	beq	s6,s11,418e <fourfiles+0x1b6>
    fname = names[i];
    4164:	000bbc03          	ld	s8,0(s7)
    fd = open(fname, 0);
    4168:	4581                	li	a1,0
    416a:	8562                	mv	a0,s8
    416c:	556010ef          	jal	56c2 <open>
    4170:	89aa                	mv	s3,a0
    total = 0;
    4172:	8956                	mv	s2,s5
        if (buf[j] != '0' + i) {
    4174:	000b049b          	sext.w	s1,s6
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    4178:	b76d                	j	4122 <fourfiles+0x14a>
      printf("wrong length %d\n", total);
    417a:	85ca                	mv	a1,s2
    417c:	00004517          	auipc	a0,0x4
    4180:	98450513          	addi	a0,a0,-1660 # 7b00 <malloc+0x1f7a>
    4184:	14f010ef          	jal	5ad2 <printf>
      exit(1);
    4188:	4505                	li	a0,1
    418a:	4f8010ef          	jal	5682 <exit>
}
    418e:	60ea                	ld	ra,152(sp)
    4190:	644a                	ld	s0,144(sp)
    4192:	64aa                	ld	s1,136(sp)
    4194:	690a                	ld	s2,128(sp)
    4196:	79e6                	ld	s3,120(sp)
    4198:	7a46                	ld	s4,112(sp)
    419a:	7aa6                	ld	s5,104(sp)
    419c:	7b06                	ld	s6,96(sp)
    419e:	6be6                	ld	s7,88(sp)
    41a0:	6c46                	ld	s8,80(sp)
    41a2:	6ca6                	ld	s9,72(sp)
    41a4:	6d06                	ld	s10,64(sp)
    41a6:	7de2                	ld	s11,56(sp)
    41a8:	610d                	addi	sp,sp,160
    41aa:	8082                	ret

00000000000041ac <concreate>:
{
    41ac:	7135                	addi	sp,sp,-160
    41ae:	ed06                	sd	ra,152(sp)
    41b0:	e922                	sd	s0,144(sp)
    41b2:	e526                	sd	s1,136(sp)
    41b4:	e14a                	sd	s2,128(sp)
    41b6:	fcce                	sd	s3,120(sp)
    41b8:	f8d2                	sd	s4,112(sp)
    41ba:	f4d6                	sd	s5,104(sp)
    41bc:	f0da                	sd	s6,96(sp)
    41be:	ecde                	sd	s7,88(sp)
    41c0:	1100                	addi	s0,sp,160
    41c2:	89aa                	mv	s3,a0
  file[0] = 'C';
    41c4:	04300793          	li	a5,67
    41c8:	faf40423          	sb	a5,-88(s0)
  file[2] = '\0';
    41cc:	fa040523          	sb	zero,-86(s0)
  for (i = 0; i < N; i++) {
    41d0:	4901                	li	s2,0
    if (pid && (i % 3) == 1) {
    41d2:	4b0d                	li	s6,3
    41d4:	4a85                	li	s5,1
      link("C0", file);
    41d6:	00004b97          	auipc	s7,0x4
    41da:	942b8b93          	addi	s7,s7,-1726 # 7b18 <malloc+0x1f92>
  for (i = 0; i < N; i++) {
    41de:	02800a13          	li	s4,40
    41e2:	a41d                	j	4408 <concreate+0x25c>
      link("C0", file);
    41e4:	fa840593          	addi	a1,s0,-88
    41e8:	855e                	mv	a0,s7
    41ea:	4f8010ef          	jal	56e2 <link>
    if (pid == 0) {
    41ee:	a411                	j	43f2 <concreate+0x246>
    } else if (pid == 0 && (i % 5) == 1) {
    41f0:	4795                	li	a5,5
    41f2:	02f9693b          	remw	s2,s2,a5
    41f6:	4785                	li	a5,1
    41f8:	02f90563          	beq	s2,a5,4222 <concreate+0x76>
      fd = open(file, O_CREATE | O_RDWR);
    41fc:	20200593          	li	a1,514
    4200:	fa840513          	addi	a0,s0,-88
    4204:	4be010ef          	jal	56c2 <open>
      if (fd < 0) {
    4208:	1e055063          	bgez	a0,43e8 <concreate+0x23c>
        printf("concreate create %s failed\n", file);
    420c:	fa840593          	addi	a1,s0,-88
    4210:	00004517          	auipc	a0,0x4
    4214:	91050513          	addi	a0,a0,-1776 # 7b20 <malloc+0x1f9a>
    4218:	0bb010ef          	jal	5ad2 <printf>
        exit(1);
    421c:	4505                	li	a0,1
    421e:	464010ef          	jal	5682 <exit>
      link("C0", file);
    4222:	fa840593          	addi	a1,s0,-88
    4226:	00004517          	auipc	a0,0x4
    422a:	8f250513          	addi	a0,a0,-1806 # 7b18 <malloc+0x1f92>
    422e:	4b4010ef          	jal	56e2 <link>
      exit(0);
    4232:	4501                	li	a0,0
    4234:	44e010ef          	jal	5682 <exit>
        exit(1);
    4238:	4505                	li	a0,1
    423a:	448010ef          	jal	5682 <exit>
  memset(fa, 0, sizeof(fa));
    423e:	02800613          	li	a2,40
    4242:	4581                	li	a1,0
    4244:	f8040513          	addi	a0,s0,-128
    4248:	228010ef          	jal	5470 <memset>
  fd = open(".", 0);
    424c:	4581                	li	a1,0
    424e:	00002517          	auipc	a0,0x2
    4252:	15250513          	addi	a0,a0,338 # 63a0 <malloc+0x81a>
    4256:	46c010ef          	jal	56c2 <open>
    425a:	892a                	mv	s2,a0
  n = 0;
    425c:	8aa6                	mv	s5,s1
    if (de.name[0] == 'C' && de.name[2] == '\0') {
    425e:	04300a13          	li	s4,67
      if (i < 0 || i >= sizeof(fa)) {
    4262:	02700b13          	li	s6,39
      fa[i] = 1;
    4266:	4b85                	li	s7,1
  while (read(fd, &de, sizeof(de)) > 0) {
    4268:	4641                	li	a2,16
    426a:	f7040593          	addi	a1,s0,-144
    426e:	854a                	mv	a0,s2
    4270:	42a010ef          	jal	569a <read>
    4274:	06a05a63          	blez	a0,42e8 <concreate+0x13c>
    if (de.inum == 0)
    4278:	f7045783          	lhu	a5,-144(s0)
    427c:	d7f5                	beqz	a5,4268 <concreate+0xbc>
    if (de.name[0] == 'C' && de.name[2] == '\0') {
    427e:	f7244783          	lbu	a5,-142(s0)
    4282:	ff4793e3          	bne	a5,s4,4268 <concreate+0xbc>
    4286:	f7444783          	lbu	a5,-140(s0)
    428a:	fff9                	bnez	a5,4268 <concreate+0xbc>
      i = de.name[1] - '0';
    428c:	f7344783          	lbu	a5,-141(s0)
    4290:	fd07879b          	addiw	a5,a5,-48
    4294:	0007871b          	sext.w	a4,a5
      if (i < 0 || i >= sizeof(fa)) {
    4298:	02eb6063          	bltu	s6,a4,42b8 <concreate+0x10c>
      if (fa[i]) {
    429c:	fb070793          	addi	a5,a4,-80
    42a0:	97a2                	add	a5,a5,s0
    42a2:	fd07c783          	lbu	a5,-48(a5)
    42a6:	e78d                	bnez	a5,42d0 <concreate+0x124>
      fa[i] = 1;
    42a8:	fb070793          	addi	a5,a4,-80
    42ac:	00878733          	add	a4,a5,s0
    42b0:	fd770823          	sb	s7,-48(a4)
      n++;
    42b4:	2a85                	addiw	s5,s5,1
    42b6:	bf4d                	j	4268 <concreate+0xbc>
        printf("%s: concreate weird file %s\n", s, de.name);
    42b8:	f7240613          	addi	a2,s0,-142
    42bc:	85ce                	mv	a1,s3
    42be:	00004517          	auipc	a0,0x4
    42c2:	88250513          	addi	a0,a0,-1918 # 7b40 <malloc+0x1fba>
    42c6:	00d010ef          	jal	5ad2 <printf>
        exit(1);
    42ca:	4505                	li	a0,1
    42cc:	3b6010ef          	jal	5682 <exit>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    42d0:	f7240613          	addi	a2,s0,-142
    42d4:	85ce                	mv	a1,s3
    42d6:	00004517          	auipc	a0,0x4
    42da:	88a50513          	addi	a0,a0,-1910 # 7b60 <malloc+0x1fda>
    42de:	7f4010ef          	jal	5ad2 <printf>
        exit(1);
    42e2:	4505                	li	a0,1
    42e4:	39e010ef          	jal	5682 <exit>
  close(fd);
    42e8:	854a                	mv	a0,s2
    42ea:	3c0010ef          	jal	56aa <close>
  if (n != N) {
    42ee:	02800793          	li	a5,40
    42f2:	00fa9763          	bne	s5,a5,4300 <concreate+0x154>
    if (((i % 3) == 0 && pid == 0) || ((i % 3) == 1 && pid != 0)) {
    42f6:	4a8d                	li	s5,3
    42f8:	4b05                	li	s6,1
  for (i = 0; i < N; i++) {
    42fa:	02800a13          	li	s4,40
    42fe:	a079                	j	438c <concreate+0x1e0>
    printf("%s: concreate not enough files in directory listing\n", s);
    4300:	85ce                	mv	a1,s3
    4302:	00004517          	auipc	a0,0x4
    4306:	88650513          	addi	a0,a0,-1914 # 7b88 <malloc+0x2002>
    430a:	7c8010ef          	jal	5ad2 <printf>
    exit(1);
    430e:	4505                	li	a0,1
    4310:	372010ef          	jal	5682 <exit>
      printf("%s: fork failed\n", s);
    4314:	85ce                	mv	a1,s3
    4316:	00002517          	auipc	a0,0x2
    431a:	23250513          	addi	a0,a0,562 # 6548 <malloc+0x9c2>
    431e:	7b4010ef          	jal	5ad2 <printf>
      exit(1);
    4322:	4505                	li	a0,1
    4324:	35e010ef          	jal	5682 <exit>
      close(open(file, 0));
    4328:	4581                	li	a1,0
    432a:	fa840513          	addi	a0,s0,-88
    432e:	394010ef          	jal	56c2 <open>
    4332:	378010ef          	jal	56aa <close>
      close(open(file, 0));
    4336:	4581                	li	a1,0
    4338:	fa840513          	addi	a0,s0,-88
    433c:	386010ef          	jal	56c2 <open>
    4340:	36a010ef          	jal	56aa <close>
      close(open(file, 0));
    4344:	4581                	li	a1,0
    4346:	fa840513          	addi	a0,s0,-88
    434a:	378010ef          	jal	56c2 <open>
    434e:	35c010ef          	jal	56aa <close>
      close(open(file, 0));
    4352:	4581                	li	a1,0
    4354:	fa840513          	addi	a0,s0,-88
    4358:	36a010ef          	jal	56c2 <open>
    435c:	34e010ef          	jal	56aa <close>
      close(open(file, 0));
    4360:	4581                	li	a1,0
    4362:	fa840513          	addi	a0,s0,-88
    4366:	35c010ef          	jal	56c2 <open>
    436a:	340010ef          	jal	56aa <close>
      close(open(file, 0));
    436e:	4581                	li	a1,0
    4370:	fa840513          	addi	a0,s0,-88
    4374:	34e010ef          	jal	56c2 <open>
    4378:	332010ef          	jal	56aa <close>
    if (pid == 0)
    437c:	06090363          	beqz	s2,43e2 <concreate+0x236>
      wait(0);
    4380:	4501                	li	a0,0
    4382:	308010ef          	jal	568a <wait>
  for (i = 0; i < N; i++) {
    4386:	2485                	addiw	s1,s1,1
    4388:	0b448963          	beq	s1,s4,443a <concreate+0x28e>
    file[1] = '0' + i;
    438c:	0304879b          	addiw	a5,s1,48
    4390:	faf404a3          	sb	a5,-87(s0)
    pid = fork();
    4394:	2e6010ef          	jal	567a <fork>
    4398:	892a                	mv	s2,a0
    if (pid < 0) {
    439a:	f6054de3          	bltz	a0,4314 <concreate+0x168>
    if (((i % 3) == 0 && pid == 0) || ((i % 3) == 1 && pid != 0)) {
    439e:	0354e73b          	remw	a4,s1,s5
    43a2:	00a767b3          	or	a5,a4,a0
    43a6:	2781                	sext.w	a5,a5
    43a8:	d3c1                	beqz	a5,4328 <concreate+0x17c>
    43aa:	01671363          	bne	a4,s6,43b0 <concreate+0x204>
    43ae:	fd2d                	bnez	a0,4328 <concreate+0x17c>
      unlink(file);
    43b0:	fa840513          	addi	a0,s0,-88
    43b4:	31e010ef          	jal	56d2 <unlink>
      unlink(file);
    43b8:	fa840513          	addi	a0,s0,-88
    43bc:	316010ef          	jal	56d2 <unlink>
      unlink(file);
    43c0:	fa840513          	addi	a0,s0,-88
    43c4:	30e010ef          	jal	56d2 <unlink>
      unlink(file);
    43c8:	fa840513          	addi	a0,s0,-88
    43cc:	306010ef          	jal	56d2 <unlink>
      unlink(file);
    43d0:	fa840513          	addi	a0,s0,-88
    43d4:	2fe010ef          	jal	56d2 <unlink>
      unlink(file);
    43d8:	fa840513          	addi	a0,s0,-88
    43dc:	2f6010ef          	jal	56d2 <unlink>
    43e0:	bf71                	j	437c <concreate+0x1d0>
      exit(0);
    43e2:	4501                	li	a0,0
    43e4:	29e010ef          	jal	5682 <exit>
      close(fd);
    43e8:	2c2010ef          	jal	56aa <close>
    if (pid == 0) {
    43ec:	b599                	j	4232 <concreate+0x86>
      close(fd);
    43ee:	2bc010ef          	jal	56aa <close>
      wait(&xstatus);
    43f2:	f6c40513          	addi	a0,s0,-148
    43f6:	294010ef          	jal	568a <wait>
      if (xstatus != 0)
    43fa:	f6c42483          	lw	s1,-148(s0)
    43fe:	e2049de3          	bnez	s1,4238 <concreate+0x8c>
  for (i = 0; i < N; i++) {
    4402:	2905                	addiw	s2,s2,1
    4404:	e3490de3          	beq	s2,s4,423e <concreate+0x92>
    file[1] = '0' + i;
    4408:	0309079b          	addiw	a5,s2,48
    440c:	faf404a3          	sb	a5,-87(s0)
    unlink(file);
    4410:	fa840513          	addi	a0,s0,-88
    4414:	2be010ef          	jal	56d2 <unlink>
    pid = fork();
    4418:	262010ef          	jal	567a <fork>
    if (pid && (i % 3) == 1) {
    441c:	dc050ae3          	beqz	a0,41f0 <concreate+0x44>
    4420:	036967bb          	remw	a5,s2,s6
    4424:	dd5780e3          	beq	a5,s5,41e4 <concreate+0x38>
      fd = open(file, O_CREATE | O_RDWR);
    4428:	20200593          	li	a1,514
    442c:	fa840513          	addi	a0,s0,-88
    4430:	292010ef          	jal	56c2 <open>
      if (fd < 0) {
    4434:	fa055de3          	bgez	a0,43ee <concreate+0x242>
    4438:	bbd1                	j	420c <concreate+0x60>
}
    443a:	60ea                	ld	ra,152(sp)
    443c:	644a                	ld	s0,144(sp)
    443e:	64aa                	ld	s1,136(sp)
    4440:	690a                	ld	s2,128(sp)
    4442:	79e6                	ld	s3,120(sp)
    4444:	7a46                	ld	s4,112(sp)
    4446:	7aa6                	ld	s5,104(sp)
    4448:	7b06                	ld	s6,96(sp)
    444a:	6be6                	ld	s7,88(sp)
    444c:	610d                	addi	sp,sp,160
    444e:	8082                	ret

0000000000004450 <bigfile>:
{
    4450:	7139                	addi	sp,sp,-64
    4452:	fc06                	sd	ra,56(sp)
    4454:	f822                	sd	s0,48(sp)
    4456:	f426                	sd	s1,40(sp)
    4458:	f04a                	sd	s2,32(sp)
    445a:	ec4e                	sd	s3,24(sp)
    445c:	e852                	sd	s4,16(sp)
    445e:	e456                	sd	s5,8(sp)
    4460:	0080                	addi	s0,sp,64
    4462:	8aaa                	mv	s5,a0
  unlink("bigfile.dat");
    4464:	00003517          	auipc	a0,0x3
    4468:	75c50513          	addi	a0,a0,1884 # 7bc0 <malloc+0x203a>
    446c:	266010ef          	jal	56d2 <unlink>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    4470:	20200593          	li	a1,514
    4474:	00003517          	auipc	a0,0x3
    4478:	74c50513          	addi	a0,a0,1868 # 7bc0 <malloc+0x203a>
    447c:	246010ef          	jal	56c2 <open>
    4480:	89aa                	mv	s3,a0
  for (i = 0; i < N; i++) {
    4482:	4481                	li	s1,0
    memset(buf, i, SZ);
    4484:	0000a917          	auipc	s2,0xa
    4488:	88490913          	addi	s2,s2,-1916 # dd08 <buf>
  for (i = 0; i < N; i++) {
    448c:	4a51                	li	s4,20
  if (fd < 0) {
    448e:	08054663          	bltz	a0,451a <bigfile+0xca>
    memset(buf, i, SZ);
    4492:	25800613          	li	a2,600
    4496:	85a6                	mv	a1,s1
    4498:	854a                	mv	a0,s2
    449a:	7d7000ef          	jal	5470 <memset>
    if (write(fd, buf, SZ) != SZ) {
    449e:	25800613          	li	a2,600
    44a2:	85ca                	mv	a1,s2
    44a4:	854e                	mv	a0,s3
    44a6:	1fc010ef          	jal	56a2 <write>
    44aa:	25800793          	li	a5,600
    44ae:	08f51063          	bne	a0,a5,452e <bigfile+0xde>
  for (i = 0; i < N; i++) {
    44b2:	2485                	addiw	s1,s1,1
    44b4:	fd449fe3          	bne	s1,s4,4492 <bigfile+0x42>
  close(fd);
    44b8:	854e                	mv	a0,s3
    44ba:	1f0010ef          	jal	56aa <close>
  fd = open("bigfile.dat", 0);
    44be:	4581                	li	a1,0
    44c0:	00003517          	auipc	a0,0x3
    44c4:	70050513          	addi	a0,a0,1792 # 7bc0 <malloc+0x203a>
    44c8:	1fa010ef          	jal	56c2 <open>
    44cc:	8a2a                	mv	s4,a0
  total = 0;
    44ce:	4981                	li	s3,0
  for (i = 0;; i++) {
    44d0:	4481                	li	s1,0
    cc = read(fd, buf, SZ / 2);
    44d2:	0000a917          	auipc	s2,0xa
    44d6:	83690913          	addi	s2,s2,-1994 # dd08 <buf>
  if (fd < 0) {
    44da:	06054463          	bltz	a0,4542 <bigfile+0xf2>
    cc = read(fd, buf, SZ / 2);
    44de:	12c00613          	li	a2,300
    44e2:	85ca                	mv	a1,s2
    44e4:	8552                	mv	a0,s4
    44e6:	1b4010ef          	jal	569a <read>
    if (cc < 0) {
    44ea:	06054663          	bltz	a0,4556 <bigfile+0x106>
    if (cc == 0)
    44ee:	c155                	beqz	a0,4592 <bigfile+0x142>
    if (cc != SZ / 2) {
    44f0:	12c00793          	li	a5,300
    44f4:	06f51b63          	bne	a0,a5,456a <bigfile+0x11a>
    if (buf[0] != i / 2 || buf[SZ / 2 - 1] != i / 2) {
    44f8:	01f4d79b          	srliw	a5,s1,0x1f
    44fc:	9fa5                	addw	a5,a5,s1
    44fe:	4017d79b          	sraiw	a5,a5,0x1
    4502:	00094703          	lbu	a4,0(s2)
    4506:	06f71c63          	bne	a4,a5,457e <bigfile+0x12e>
    450a:	12b94703          	lbu	a4,299(s2)
    450e:	06f71863          	bne	a4,a5,457e <bigfile+0x12e>
    total += cc;
    4512:	12c9899b          	addiw	s3,s3,300
  for (i = 0;; i++) {
    4516:	2485                	addiw	s1,s1,1
    cc = read(fd, buf, SZ / 2);
    4518:	b7d9                	j	44de <bigfile+0x8e>
    printf("%s: cannot create bigfile", s);
    451a:	85d6                	mv	a1,s5
    451c:	00003517          	auipc	a0,0x3
    4520:	6b450513          	addi	a0,a0,1716 # 7bd0 <malloc+0x204a>
    4524:	5ae010ef          	jal	5ad2 <printf>
    exit(1);
    4528:	4505                	li	a0,1
    452a:	158010ef          	jal	5682 <exit>
      printf("%s: write bigfile failed\n", s);
    452e:	85d6                	mv	a1,s5
    4530:	00003517          	auipc	a0,0x3
    4534:	6c050513          	addi	a0,a0,1728 # 7bf0 <malloc+0x206a>
    4538:	59a010ef          	jal	5ad2 <printf>
      exit(1);
    453c:	4505                	li	a0,1
    453e:	144010ef          	jal	5682 <exit>
    printf("%s: cannot open bigfile\n", s);
    4542:	85d6                	mv	a1,s5
    4544:	00003517          	auipc	a0,0x3
    4548:	6cc50513          	addi	a0,a0,1740 # 7c10 <malloc+0x208a>
    454c:	586010ef          	jal	5ad2 <printf>
    exit(1);
    4550:	4505                	li	a0,1
    4552:	130010ef          	jal	5682 <exit>
      printf("%s: read bigfile failed\n", s);
    4556:	85d6                	mv	a1,s5
    4558:	00003517          	auipc	a0,0x3
    455c:	6d850513          	addi	a0,a0,1752 # 7c30 <malloc+0x20aa>
    4560:	572010ef          	jal	5ad2 <printf>
      exit(1);
    4564:	4505                	li	a0,1
    4566:	11c010ef          	jal	5682 <exit>
      printf("%s: short read bigfile\n", s);
    456a:	85d6                	mv	a1,s5
    456c:	00003517          	auipc	a0,0x3
    4570:	6e450513          	addi	a0,a0,1764 # 7c50 <malloc+0x20ca>
    4574:	55e010ef          	jal	5ad2 <printf>
      exit(1);
    4578:	4505                	li	a0,1
    457a:	108010ef          	jal	5682 <exit>
      printf("%s: read bigfile wrong data\n", s);
    457e:	85d6                	mv	a1,s5
    4580:	00003517          	auipc	a0,0x3
    4584:	6e850513          	addi	a0,a0,1768 # 7c68 <malloc+0x20e2>
    4588:	54a010ef          	jal	5ad2 <printf>
      exit(1);
    458c:	4505                	li	a0,1
    458e:	0f4010ef          	jal	5682 <exit>
  close(fd);
    4592:	8552                	mv	a0,s4
    4594:	116010ef          	jal	56aa <close>
  if (total != N * SZ) {
    4598:	678d                	lui	a5,0x3
    459a:	ee078793          	addi	a5,a5,-288 # 2ee0 <subdir+0x494>
    459e:	02f99163          	bne	s3,a5,45c0 <bigfile+0x170>
  unlink("bigfile.dat");
    45a2:	00003517          	auipc	a0,0x3
    45a6:	61e50513          	addi	a0,a0,1566 # 7bc0 <malloc+0x203a>
    45aa:	128010ef          	jal	56d2 <unlink>
}
    45ae:	70e2                	ld	ra,56(sp)
    45b0:	7442                	ld	s0,48(sp)
    45b2:	74a2                	ld	s1,40(sp)
    45b4:	7902                	ld	s2,32(sp)
    45b6:	69e2                	ld	s3,24(sp)
    45b8:	6a42                	ld	s4,16(sp)
    45ba:	6aa2                	ld	s5,8(sp)
    45bc:	6121                	addi	sp,sp,64
    45be:	8082                	ret
    printf("%s: read bigfile wrong total\n", s);
    45c0:	85d6                	mv	a1,s5
    45c2:	00003517          	auipc	a0,0x3
    45c6:	6c650513          	addi	a0,a0,1734 # 7c88 <malloc+0x2102>
    45ca:	508010ef          	jal	5ad2 <printf>
    exit(1);
    45ce:	4505                	li	a0,1
    45d0:	0b2010ef          	jal	5682 <exit>

00000000000045d4 <bigargtest>:
{
    45d4:	7121                	addi	sp,sp,-448
    45d6:	ff06                	sd	ra,440(sp)
    45d8:	fb22                	sd	s0,432(sp)
    45da:	f726                	sd	s1,424(sp)
    45dc:	0380                	addi	s0,sp,448
    45de:	84aa                	mv	s1,a0
  unlink("bigarg-ok");
    45e0:	00003517          	auipc	a0,0x3
    45e4:	6c850513          	addi	a0,a0,1736 # 7ca8 <malloc+0x2122>
    45e8:	0ea010ef          	jal	56d2 <unlink>
  pid = fork();
    45ec:	08e010ef          	jal	567a <fork>
  if (pid == 0) {
    45f0:	c915                	beqz	a0,4624 <bigargtest+0x50>
  } else if (pid < 0) {
    45f2:	08054a63          	bltz	a0,4686 <bigargtest+0xb2>
  wait(&xstatus);
    45f6:	fdc40513          	addi	a0,s0,-36
    45fa:	090010ef          	jal	568a <wait>
  if (xstatus != 0)
    45fe:	fdc42503          	lw	a0,-36(s0)
    4602:	ed41                	bnez	a0,469a <bigargtest+0xc6>
  fd = open("bigarg-ok", 0);
    4604:	4581                	li	a1,0
    4606:	00003517          	auipc	a0,0x3
    460a:	6a250513          	addi	a0,a0,1698 # 7ca8 <malloc+0x2122>
    460e:	0b4010ef          	jal	56c2 <open>
  if (fd < 0) {
    4612:	08054663          	bltz	a0,469e <bigargtest+0xca>
  close(fd);
    4616:	094010ef          	jal	56aa <close>
}
    461a:	70fa                	ld	ra,440(sp)
    461c:	745a                	ld	s0,432(sp)
    461e:	74ba                	ld	s1,424(sp)
    4620:	6139                	addi	sp,sp,448
    4622:	8082                	ret
    memset(big, ' ', sizeof(big));
    4624:	19000613          	li	a2,400
    4628:	02000593          	li	a1,32
    462c:	e4840513          	addi	a0,s0,-440
    4630:	641000ef          	jal	5470 <memset>
    big[sizeof(big) - 1] = '\0';
    4634:	fc040ba3          	sb	zero,-41(s0)
    for (i = 0; i < MAXARG - 1; i++)
    4638:	00006797          	auipc	a5,0x6
    463c:	eb878793          	addi	a5,a5,-328 # a4f0 <args.1>
    4640:	00006697          	auipc	a3,0x6
    4644:	fa868693          	addi	a3,a3,-88 # a5e8 <args.1+0xf8>
      args[i] = big;
    4648:	e4840713          	addi	a4,s0,-440
    464c:	e398                	sd	a4,0(a5)
    for (i = 0; i < MAXARG - 1; i++)
    464e:	07a1                	addi	a5,a5,8
    4650:	fed79ee3          	bne	a5,a3,464c <bigargtest+0x78>
    args[MAXARG - 1] = 0;
    4654:	00006597          	auipc	a1,0x6
    4658:	e9c58593          	addi	a1,a1,-356 # a4f0 <args.1>
    465c:	0e05bc23          	sd	zero,248(a1)
    exec("echo", args);
    4660:	00001517          	auipc	a0,0x1
    4664:	65850513          	addi	a0,a0,1624 # 5cb8 <malloc+0x132>
    4668:	052010ef          	jal	56ba <exec>
    fd = open("bigarg-ok", O_CREATE);
    466c:	20000593          	li	a1,512
    4670:	00003517          	auipc	a0,0x3
    4674:	63850513          	addi	a0,a0,1592 # 7ca8 <malloc+0x2122>
    4678:	04a010ef          	jal	56c2 <open>
    close(fd);
    467c:	02e010ef          	jal	56aa <close>
    exit(0);
    4680:	4501                	li	a0,0
    4682:	000010ef          	jal	5682 <exit>
    printf("%s: bigargtest: fork failed\n", s);
    4686:	85a6                	mv	a1,s1
    4688:	00003517          	auipc	a0,0x3
    468c:	63050513          	addi	a0,a0,1584 # 7cb8 <malloc+0x2132>
    4690:	442010ef          	jal	5ad2 <printf>
    exit(1);
    4694:	4505                	li	a0,1
    4696:	7ed000ef          	jal	5682 <exit>
    exit(xstatus);
    469a:	7e9000ef          	jal	5682 <exit>
    printf("%s: bigarg test failed!\n", s);
    469e:	85a6                	mv	a1,s1
    46a0:	00003517          	auipc	a0,0x3
    46a4:	63850513          	addi	a0,a0,1592 # 7cd8 <malloc+0x2152>
    46a8:	42a010ef          	jal	5ad2 <printf>
    exit(1);
    46ac:	4505                	li	a0,1
    46ae:	7d5000ef          	jal	5682 <exit>

00000000000046b2 <partial_write>:
{
    46b2:	bc010113          	addi	sp,sp,-1088
    46b6:	42113c23          	sd	ra,1080(sp)
    46ba:	42813823          	sd	s0,1072(sp)
    46be:	42913423          	sd	s1,1064(sp)
    46c2:	43213023          	sd	s2,1056(sp)
    46c6:	41313c23          	sd	s3,1048(sp)
    46ca:	44010413          	addi	s0,sp,1088
    46ce:	89aa                	mv	s3,a0
  unlink("testfile");
    46d0:	00003517          	auipc	a0,0x3
    46d4:	62850513          	addi	a0,a0,1576 # 7cf8 <malloc+0x2172>
    46d8:	7fb000ef          	jal	56d2 <unlink>
  int fd = open("testfile", O_CREATE | O_RDWR);
    46dc:	20200593          	li	a1,514
    46e0:	00003517          	auipc	a0,0x3
    46e4:	61850513          	addi	a0,a0,1560 # 7cf8 <malloc+0x2172>
    46e8:	7db000ef          	jal	56c2 <open>
  if (fd < 0) {
    46ec:	14054c63          	bltz	a0,4844 <partial_write+0x192>
    46f0:	84aa                	mv	s1,a0
  int cc = write(fd, "A", 1);
    46f2:	4605                	li	a2,1
    46f4:	00003597          	auipc	a1,0x3
    46f8:	63458593          	addi	a1,a1,1588 # 7d28 <malloc+0x21a2>
    46fc:	7a7000ef          	jal	56a2 <write>
  if (cc != 1) {
    4700:	4785                	li	a5,1
    4702:	14f51b63          	bne	a0,a5,4858 <partial_write+0x1a6>
  close(fd);
    4706:	8526                	mv	a0,s1
    4708:	7a3000ef          	jal	56aa <close>
  fd = open("testfile", O_RDWR);
    470c:	4589                	li	a1,2
    470e:	00003517          	auipc	a0,0x3
    4712:	5ea50513          	addi	a0,a0,1514 # 7cf8 <malloc+0x2172>
    4716:	7ad000ef          	jal	56c2 <open>
    471a:	892a                	mv	s2,a0
  if (fd < 0) {
    471c:	14054863          	bltz	a0,486c <partial_write+0x1ba>
  char *p = sbrk(0);
    4720:	4501                	li	a0,0
    4722:	72d000ef          	jal	564e <sbrk>
  sbrk(PGSIZE - ((uint64)p % PGSIZE));
    4726:	6485                	lui	s1,0x1
    4728:	14fd                	addi	s1,s1,-1 # fff <pgbug+0x2b>
    472a:	009577b3          	and	a5,a0,s1
    472e:	6505                	lui	a0,0x1
    4730:	9d1d                	subw	a0,a0,a5
    4732:	71d000ef          	jal	564e <sbrk>
  p = sbrk(0);
    4736:	4501                	li	a0,0
    4738:	717000ef          	jal	564e <sbrk>
  if ((uint64)p % PGSIZE != 0) {
    473c:	8ce9                	and	s1,s1,a0
    473e:	14049163          	bnez	s1,4880 <partial_write+0x1ce>
  p[-1] = 'X';
    4742:	05800793          	li	a5,88
    4746:	fef50fa3          	sb	a5,-1(a0) # fff <pgbug+0x2b>
  cc = write(fd, p - 1, 2);
    474a:	4609                	li	a2,2
    474c:	fff50593          	addi	a1,a0,-1
    4750:	854a                	mv	a0,s2
    4752:	751000ef          	jal	56a2 <write>
  if (cc != -1) {
    4756:	57fd                	li	a5,-1
    4758:	12f51e63          	bne	a0,a5,4894 <partial_write+0x1e2>
  close(fd);
    475c:	854a                	mv	a0,s2
    475e:	74d000ef          	jal	56aa <close>
  fd = open("testfile", O_RDONLY);
    4762:	4581                	li	a1,0
    4764:	00003517          	auipc	a0,0x3
    4768:	59450513          	addi	a0,a0,1428 # 7cf8 <malloc+0x2172>
    476c:	757000ef          	jal	56c2 <open>
    4770:	84aa                	mv	s1,a0
  if (fd < 0) {
    4772:	12054b63          	bltz	a0,48a8 <partial_write+0x1f6>
  cc = read(fd, &b, 1);
    4776:	4605                	li	a2,1
    4778:	fcf40593          	addi	a1,s0,-49
    477c:	71f000ef          	jal	569a <read>
  if (cc != 1) {
    4780:	4785                	li	a5,1
    4782:	12f51d63          	bne	a0,a5,48bc <partial_write+0x20a>
  close(fd);
    4786:	8526                	mv	a0,s1
    4788:	723000ef          	jal	56aa <close>
  if (b != 'X') {
    478c:	fcf44603          	lbu	a2,-49(s0)
    4790:	05800793          	li	a5,88
    4794:	12f61e63          	bne	a2,a5,48d0 <partial_write+0x21e>
  fd = open("bigfile", O_CREATE | O_RDWR);
    4798:	20200593          	li	a1,514
    479c:	00003517          	auipc	a0,0x3
    47a0:	65c50513          	addi	a0,a0,1628 # 7df8 <malloc+0x2272>
    47a4:	71f000ef          	jal	56c2 <open>
    47a8:	892a                	mv	s2,a0
    47aa:	04000493          	li	s1,64
    memset(buf, 0, sizeof(buf));
    47ae:	40000613          	li	a2,1024
    47b2:	4581                	li	a1,0
    47b4:	bc840513          	addi	a0,s0,-1080
    47b8:	4b9000ef          	jal	5470 <memset>
    cc = write(fd, buf, sizeof(buf));
    47bc:	40000613          	li	a2,1024
    47c0:	bc840593          	addi	a1,s0,-1080
    47c4:	854a                	mv	a0,s2
    47c6:	6dd000ef          	jal	56a2 <write>
    if (cc != sizeof(buf)) {
    47ca:	40000793          	li	a5,1024
    47ce:	10f51b63          	bne	a0,a5,48e4 <partial_write+0x232>
  for (int i = 0; i < 64; i++) {
    47d2:	34fd                	addiw	s1,s1,-1
    47d4:	fce9                	bnez	s1,47ae <partial_write+0xfc>
  close(fd);
    47d6:	854a                	mv	a0,s2
    47d8:	6d3000ef          	jal	56aa <close>
  unlink("bigfile");
    47dc:	00003517          	auipc	a0,0x3
    47e0:	61c50513          	addi	a0,a0,1564 # 7df8 <malloc+0x2272>
    47e4:	6ef000ef          	jal	56d2 <unlink>
  fd = open("testfile", O_RDONLY);
    47e8:	4581                	li	a1,0
    47ea:	00003517          	auipc	a0,0x3
    47ee:	50e50513          	addi	a0,a0,1294 # 7cf8 <malloc+0x2172>
    47f2:	6d1000ef          	jal	56c2 <open>
    47f6:	84aa                	mv	s1,a0
  if (fd < 0) {
    47f8:	10054063          	bltz	a0,48f8 <partial_write+0x246>
  cc = read(fd, &b, 1);
    47fc:	4605                	li	a2,1
    47fe:	fcf40593          	addi	a1,s0,-49
    4802:	699000ef          	jal	569a <read>
  if (cc != 1) {
    4806:	4785                	li	a5,1
    4808:	10f51263          	bne	a0,a5,490c <partial_write+0x25a>
  close(fd);
    480c:	8526                	mv	a0,s1
    480e:	69d000ef          	jal	56aa <close>
  if (b != 'X') {
    4812:	fcf44603          	lbu	a2,-49(s0)
    4816:	05800793          	li	a5,88
    481a:	10f61363          	bne	a2,a5,4920 <partial_write+0x26e>
  unlink("testfile");
    481e:	00003517          	auipc	a0,0x3
    4822:	4da50513          	addi	a0,a0,1242 # 7cf8 <malloc+0x2172>
    4826:	6ad000ef          	jal	56d2 <unlink>
}
    482a:	43813083          	ld	ra,1080(sp)
    482e:	43013403          	ld	s0,1072(sp)
    4832:	42813483          	ld	s1,1064(sp)
    4836:	42013903          	ld	s2,1056(sp)
    483a:	41813983          	ld	s3,1048(sp)
    483e:	44010113          	addi	sp,sp,1088
    4842:	8082                	ret
    printf("%s: cannot create testfile\n", s);
    4844:	85ce                	mv	a1,s3
    4846:	00003517          	auipc	a0,0x3
    484a:	4c250513          	addi	a0,a0,1218 # 7d08 <malloc+0x2182>
    484e:	284010ef          	jal	5ad2 <printf>
    exit(1);
    4852:	4505                	li	a0,1
    4854:	62f000ef          	jal	5682 <exit>
    printf("%s: could not write A\n", s);
    4858:	85ce                	mv	a1,s3
    485a:	00003517          	auipc	a0,0x3
    485e:	4d650513          	addi	a0,a0,1238 # 7d30 <malloc+0x21aa>
    4862:	270010ef          	jal	5ad2 <printf>
    exit(1);
    4866:	4505                	li	a0,1
    4868:	61b000ef          	jal	5682 <exit>
    printf("%s: cannot re-open testfile\n", s);
    486c:	85ce                	mv	a1,s3
    486e:	00003517          	auipc	a0,0x3
    4872:	4da50513          	addi	a0,a0,1242 # 7d48 <malloc+0x21c2>
    4876:	25c010ef          	jal	5ad2 <printf>
    exit(1);
    487a:	4505                	li	a0,1
    487c:	607000ef          	jal	5682 <exit>
    printf("%s: sbrk did not align\n", s);
    4880:	85ce                	mv	a1,s3
    4882:	00003517          	auipc	a0,0x3
    4886:	4e650513          	addi	a0,a0,1254 # 7d68 <malloc+0x21e2>
    488a:	248010ef          	jal	5ad2 <printf>
    exit(1);
    488e:	4505                	li	a0,1
    4890:	5f3000ef          	jal	5682 <exit>
    printf("%s: write succeeded, should have failed\n", s);
    4894:	85ce                	mv	a1,s3
    4896:	00003517          	auipc	a0,0x3
    489a:	4ea50513          	addi	a0,a0,1258 # 7d80 <malloc+0x21fa>
    489e:	234010ef          	jal	5ad2 <printf>
    exit(1);
    48a2:	4505                	li	a0,1
    48a4:	5df000ef          	jal	5682 <exit>
    printf("%s: cannot re-open testfile\n", s);
    48a8:	85ce                	mv	a1,s3
    48aa:	00003517          	auipc	a0,0x3
    48ae:	49e50513          	addi	a0,a0,1182 # 7d48 <malloc+0x21c2>
    48b2:	220010ef          	jal	5ad2 <printf>
    exit(1);
    48b6:	4505                	li	a0,1
    48b8:	5cb000ef          	jal	5682 <exit>
    printf("%s: cannot read testfile\n", s);
    48bc:	85ce                	mv	a1,s3
    48be:	00003517          	auipc	a0,0x3
    48c2:	4f250513          	addi	a0,a0,1266 # 7db0 <malloc+0x222a>
    48c6:	20c010ef          	jal	5ad2 <printf>
    exit(1);
    48ca:	4505                	li	a0,1
    48cc:	5b7000ef          	jal	5682 <exit>
    printf("%s: read returned %c, expected X\n", s, b);
    48d0:	85ce                	mv	a1,s3
    48d2:	00003517          	auipc	a0,0x3
    48d6:	4fe50513          	addi	a0,a0,1278 # 7dd0 <malloc+0x224a>
    48da:	1f8010ef          	jal	5ad2 <printf>
    exit(1);
    48de:	4505                	li	a0,1
    48e0:	5a3000ef          	jal	5682 <exit>
      printf("%s: could not write to bigfile\n", s);
    48e4:	85ce                	mv	a1,s3
    48e6:	00003517          	auipc	a0,0x3
    48ea:	51a50513          	addi	a0,a0,1306 # 7e00 <malloc+0x227a>
    48ee:	1e4010ef          	jal	5ad2 <printf>
      exit(-1);
    48f2:	557d                	li	a0,-1
    48f4:	58f000ef          	jal	5682 <exit>
    printf("%s: cannot re-open testfile\n", s);
    48f8:	85ce                	mv	a1,s3
    48fa:	00003517          	auipc	a0,0x3
    48fe:	44e50513          	addi	a0,a0,1102 # 7d48 <malloc+0x21c2>
    4902:	1d0010ef          	jal	5ad2 <printf>
    exit(1);
    4906:	4505                	li	a0,1
    4908:	57b000ef          	jal	5682 <exit>
    printf("%s: cannot read testfile\n", s);
    490c:	85ce                	mv	a1,s3
    490e:	00003517          	auipc	a0,0x3
    4912:	4a250513          	addi	a0,a0,1186 # 7db0 <malloc+0x222a>
    4916:	1bc010ef          	jal	5ad2 <printf>
    exit(1);
    491a:	4505                	li	a0,1
    491c:	567000ef          	jal	5682 <exit>
    printf("%s: read returned %c, expected X\n", s, b);
    4920:	85ce                	mv	a1,s3
    4922:	00003517          	auipc	a0,0x3
    4926:	4ae50513          	addi	a0,a0,1198 # 7dd0 <malloc+0x224a>
    492a:	1a8010ef          	jal	5ad2 <printf>
    exit(1);
    492e:	4505                	li	a0,1
    4930:	553000ef          	jal	5682 <exit>

0000000000004934 <lazy_alloc>:
{
    4934:	1141                	addi	sp,sp,-16
    4936:	e406                	sd	ra,8(sp)
    4938:	e022                	sd	s0,0(sp)
    493a:	0800                	addi	s0,sp,16
  prev_end = sbrklazy(REGION_SZ);
    493c:	40000537          	lui	a0,0x40000
    4940:	525000ef          	jal	5664 <sbrklazy>
  if (prev_end == (char *)SBRK_ERROR) {
    4944:	57fd                	li	a5,-1
    4946:	02f50a63          	beq	a0,a5,497a <lazy_alloc+0x46>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    494a:	6605                	lui	a2,0x1
    494c:	962a                	add	a2,a2,a0
    494e:	400017b7          	lui	a5,0x40001
    4952:	00f50733          	add	a4,a0,a5
    4956:	87b2                	mv	a5,a2
    4958:	000406b7          	lui	a3,0x40
    *(char **)i = i;
    495c:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    495e:	97b6                	add	a5,a5,a3
    4960:	fee79ee3          	bne	a5,a4,495c <lazy_alloc+0x28>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    4964:	000406b7          	lui	a3,0x40
    if (*(char **)i != i) {
    4968:	621c                	ld	a5,0(a2)
    496a:	02c79163          	bne	a5,a2,498c <lazy_alloc+0x58>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    496e:	9636                	add	a2,a2,a3
    4970:	fee61ce3          	bne	a2,a4,4968 <lazy_alloc+0x34>
  exit(0);
    4974:	4501                	li	a0,0
    4976:	50d000ef          	jal	5682 <exit>
    printf("sbrklazy() failed\n");
    497a:	00003517          	auipc	a0,0x3
    497e:	4a650513          	addi	a0,a0,1190 # 7e20 <malloc+0x229a>
    4982:	150010ef          	jal	5ad2 <printf>
    exit(1);
    4986:	4505                	li	a0,1
    4988:	4fb000ef          	jal	5682 <exit>
      printf("failed to read value from memory\n");
    498c:	00003517          	auipc	a0,0x3
    4990:	4ac50513          	addi	a0,a0,1196 # 7e38 <malloc+0x22b2>
    4994:	13e010ef          	jal	5ad2 <printf>
      exit(1);
    4998:	4505                	li	a0,1
    499a:	4e9000ef          	jal	5682 <exit>

000000000000499e <lazy_unmap>:
{
    499e:	7139                	addi	sp,sp,-64
    49a0:	fc06                	sd	ra,56(sp)
    49a2:	f822                	sd	s0,48(sp)
    49a4:	0080                	addi	s0,sp,64
  prev_end = sbrklazy(REGION_SZ);
    49a6:	40000537          	lui	a0,0x40000
    49aa:	4bb000ef          	jal	5664 <sbrklazy>
  if (prev_end == (char *)SBRK_ERROR) {
    49ae:	57fd                	li	a5,-1
    49b0:	04f50663          	beq	a0,a5,49fc <lazy_unmap+0x5e>
    49b4:	f426                	sd	s1,40(sp)
    49b6:	f04a                	sd	s2,32(sp)
    49b8:	ec4e                	sd	s3,24(sp)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    49ba:	6905                	lui	s2,0x1
    49bc:	992a                	add	s2,s2,a0
    49be:	400017b7          	lui	a5,0x40001
    49c2:	00f504b3          	add	s1,a0,a5
    49c6:	87ca                	mv	a5,s2
    49c8:	01000737          	lui	a4,0x1000
    *(char **)i = i;
    49cc:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    49ce:	97ba                	add	a5,a5,a4
    49d0:	fe979ee3          	bne	a5,s1,49cc <lazy_unmap+0x2e>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    49d4:	010009b7          	lui	s3,0x1000
    pid = fork();
    49d8:	4a3000ef          	jal	567a <fork>
    if (pid < 0) {
    49dc:	02054c63          	bltz	a0,4a14 <lazy_unmap+0x76>
    } else if (pid == 0) {
    49e0:	c139                	beqz	a0,4a26 <lazy_unmap+0x88>
      wait(&status);
    49e2:	fcc40513          	addi	a0,s0,-52
    49e6:	4a5000ef          	jal	568a <wait>
      if (status == 0) {
    49ea:	fcc42783          	lw	a5,-52(s0)
    49ee:	c7a9                	beqz	a5,4a38 <lazy_unmap+0x9a>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    49f0:	994e                	add	s2,s2,s3
    49f2:	fe9913e3          	bne	s2,s1,49d8 <lazy_unmap+0x3a>
  exit(0);
    49f6:	4501                	li	a0,0
    49f8:	48b000ef          	jal	5682 <exit>
    49fc:	f426                	sd	s1,40(sp)
    49fe:	f04a                	sd	s2,32(sp)
    4a00:	ec4e                	sd	s3,24(sp)
    printf("sbrklazy() failed\n");
    4a02:	00003517          	auipc	a0,0x3
    4a06:	41e50513          	addi	a0,a0,1054 # 7e20 <malloc+0x229a>
    4a0a:	0c8010ef          	jal	5ad2 <printf>
    exit(1);
    4a0e:	4505                	li	a0,1
    4a10:	473000ef          	jal	5682 <exit>
      printf("error forking\n");
    4a14:	00003517          	auipc	a0,0x3
    4a18:	44c50513          	addi	a0,a0,1100 # 7e60 <malloc+0x22da>
    4a1c:	0b6010ef          	jal	5ad2 <printf>
      exit(1);
    4a20:	4505                	li	a0,1
    4a22:	461000ef          	jal	5682 <exit>
      sbrklazy(-1L * REGION_SZ);
    4a26:	c0000537          	lui	a0,0xc0000
    4a2a:	43b000ef          	jal	5664 <sbrklazy>
      *(char **)i = i;
    4a2e:	01293023          	sd	s2,0(s2) # 1000 <badarg>
      exit(0);
    4a32:	4501                	li	a0,0
    4a34:	44f000ef          	jal	5682 <exit>
        printf("memory not unmapped\n");
    4a38:	00003517          	auipc	a0,0x3
    4a3c:	43850513          	addi	a0,a0,1080 # 7e70 <malloc+0x22ea>
    4a40:	092010ef          	jal	5ad2 <printf>
        exit(1);
    4a44:	4505                	li	a0,1
    4a46:	43d000ef          	jal	5682 <exit>

0000000000004a4a <lazy_copy>:
{
    4a4a:	7159                	addi	sp,sp,-112
    4a4c:	f486                	sd	ra,104(sp)
    4a4e:	f0a2                	sd	s0,96(sp)
    4a50:	eca6                	sd	s1,88(sp)
    4a52:	e8ca                	sd	s2,80(sp)
    4a54:	e4ce                	sd	s3,72(sp)
    4a56:	e0d2                	sd	s4,64(sp)
    4a58:	fc56                	sd	s5,56(sp)
    4a5a:	f85a                	sd	s6,48(sp)
    4a5c:	1880                	addi	s0,sp,112
    char *p = sbrk(0);
    4a5e:	4501                	li	a0,0
    4a60:	3ef000ef          	jal	564e <sbrk>
    4a64:	84aa                	mv	s1,a0
    sbrklazy(4 * PGSIZE);
    4a66:	6511                	lui	a0,0x4
    4a68:	3fd000ef          	jal	5664 <sbrklazy>
    open(p + 8192, 0);
    4a6c:	4581                	li	a1,0
    4a6e:	6509                	lui	a0,0x2
    4a70:	9526                	add	a0,a0,s1
    4a72:	451000ef          	jal	56c2 <open>
    void *xx = sbrk(0);
    4a76:	4501                	li	a0,0
    4a78:	3d7000ef          	jal	564e <sbrk>
    4a7c:	84aa                	mv	s1,a0
    void *ret = sbrk(-(((uint64)xx) + 1));
    4a7e:	fff54513          	not	a0,a0
    4a82:	2501                	sext.w	a0,a0
    4a84:	3cb000ef          	jal	564e <sbrk>
    if (ret != xx) {
    4a88:	00a48c63          	beq	s1,a0,4aa0 <lazy_copy+0x56>
    4a8c:	85aa                	mv	a1,a0
      printf("sbrk(sbrk(0)+1) returned %p, not old sz\n", ret);
    4a8e:	00003517          	auipc	a0,0x3
    4a92:	3fa50513          	addi	a0,a0,1018 # 7e88 <malloc+0x2302>
    4a96:	03c010ef          	jal	5ad2 <printf>
      exit(1);
    4a9a:	4505                	li	a0,1
    4a9c:	3e7000ef          	jal	5682 <exit>
  unsigned long bad[] = {
    4aa0:	00004797          	auipc	a5,0x4
    4aa4:	bd078793          	addi	a5,a5,-1072 # 8670 <malloc+0x2aea>
    4aa8:	7fa8                	ld	a0,120(a5)
    4aaa:	63cc                	ld	a1,128(a5)
    4aac:	67d0                	ld	a2,136(a5)
    4aae:	6bd4                	ld	a3,144(a5)
    4ab0:	6fd8                	ld	a4,152(a5)
    4ab2:	73dc                	ld	a5,160(a5)
    4ab4:	f8a43823          	sd	a0,-112(s0)
    4ab8:	f8b43c23          	sd	a1,-104(s0)
    4abc:	fac43023          	sd	a2,-96(s0)
    4ac0:	fad43423          	sd	a3,-88(s0)
    4ac4:	fae43823          	sd	a4,-80(s0)
    4ac8:	faf43c23          	sd	a5,-72(s0)
  for (int i = 0; i < sizeof(bad) / sizeof(bad[0]); i++) {
    4acc:	f9040913          	addi	s2,s0,-112
    4ad0:	fc040b13          	addi	s6,s0,-64
    int fd = open("README", 0);
    4ad4:	00001a17          	auipc	s4,0x1
    4ad8:	3bca0a13          	addi	s4,s4,956 # 5e90 <malloc+0x30a>
    fd = open("junk", O_CREATE | O_RDWR | O_TRUNC);
    4adc:	00001a97          	auipc	s5,0x1
    4ae0:	2c4a8a93          	addi	s5,s5,708 # 5da0 <malloc+0x21a>
    int fd = open("README", 0);
    4ae4:	4581                	li	a1,0
    4ae6:	8552                	mv	a0,s4
    4ae8:	3db000ef          	jal	56c2 <open>
    4aec:	84aa                	mv	s1,a0
    if (fd < 0) {
    4aee:	04054663          	bltz	a0,4b3a <lazy_copy+0xf0>
    if (read(fd, (char *)bad[i], 512) >= 0) {
    4af2:	00093983          	ld	s3,0(s2)
    4af6:	20000613          	li	a2,512
    4afa:	85ce                	mv	a1,s3
    4afc:	39f000ef          	jal	569a <read>
    4b00:	04055663          	bgez	a0,4b4c <lazy_copy+0x102>
    close(fd);
    4b04:	8526                	mv	a0,s1
    4b06:	3a5000ef          	jal	56aa <close>
    fd = open("junk", O_CREATE | O_RDWR | O_TRUNC);
    4b0a:	60200593          	li	a1,1538
    4b0e:	8556                	mv	a0,s5
    4b10:	3b3000ef          	jal	56c2 <open>
    4b14:	84aa                	mv	s1,a0
    if (fd < 0) {
    4b16:	04054463          	bltz	a0,4b5e <lazy_copy+0x114>
    if (write(fd, (char *)bad[i], 512) >= 0) {
    4b1a:	20000613          	li	a2,512
    4b1e:	85ce                	mv	a1,s3
    4b20:	383000ef          	jal	56a2 <write>
    4b24:	04055663          	bgez	a0,4b70 <lazy_copy+0x126>
    close(fd);
    4b28:	8526                	mv	a0,s1
    4b2a:	381000ef          	jal	56aa <close>
  for (int i = 0; i < sizeof(bad) / sizeof(bad[0]); i++) {
    4b2e:	0921                	addi	s2,s2,8
    4b30:	fb691ae3          	bne	s2,s6,4ae4 <lazy_copy+0x9a>
  exit(0);
    4b34:	4501                	li	a0,0
    4b36:	34d000ef          	jal	5682 <exit>
      printf("cannot open README\n");
    4b3a:	00003517          	auipc	a0,0x3
    4b3e:	37e50513          	addi	a0,a0,894 # 7eb8 <malloc+0x2332>
    4b42:	791000ef          	jal	5ad2 <printf>
      exit(1);
    4b46:	4505                	li	a0,1
    4b48:	33b000ef          	jal	5682 <exit>
      printf("read succeeded\n");
    4b4c:	00003517          	auipc	a0,0x3
    4b50:	38450513          	addi	a0,a0,900 # 7ed0 <malloc+0x234a>
    4b54:	77f000ef          	jal	5ad2 <printf>
      exit(1);
    4b58:	4505                	li	a0,1
    4b5a:	329000ef          	jal	5682 <exit>
      printf("cannot open junk\n");
    4b5e:	00003517          	auipc	a0,0x3
    4b62:	38250513          	addi	a0,a0,898 # 7ee0 <malloc+0x235a>
    4b66:	76d000ef          	jal	5ad2 <printf>
      exit(1);
    4b6a:	4505                	li	a0,1
    4b6c:	317000ef          	jal	5682 <exit>
      printf("write succeeded\n");
    4b70:	00003517          	auipc	a0,0x3
    4b74:	38850513          	addi	a0,a0,904 # 7ef8 <malloc+0x2372>
    4b78:	75b000ef          	jal	5ad2 <printf>
      exit(1);
    4b7c:	4505                	li	a0,1
    4b7e:	305000ef          	jal	5682 <exit>

0000000000004b82 <lazy_sbrk>:
{
    4b82:	7179                	addi	sp,sp,-48
    4b84:	f406                	sd	ra,40(sp)
    4b86:	f022                	sd	s0,32(sp)
    4b88:	ec26                	sd	s1,24(sp)
    4b8a:	e84a                	sd	s2,16(sp)
    4b8c:	e44e                	sd	s3,8(sp)
    4b8e:	1800                	addi	s0,sp,48
  char *p = sbrk(0);
    4b90:	4501                	li	a0,0
    4b92:	2bd000ef          	jal	564e <sbrk>
    4b96:	84aa                	mv	s1,a0
  while ((uint64)p < MAXVA - (1 << 30)) {
    4b98:	0ff00793          	li	a5,255
    4b9c:	07fa                	slli	a5,a5,0x1e
    4b9e:	02f57063          	bgeu	a0,a5,4bbe <lazy_sbrk+0x3c>
    if (p == SBRK_ERROR) {
    4ba2:	59fd                	li	s3,-1
  while ((uint64)p < MAXVA - (1 << 30)) {
    4ba4:	893e                	mv	s2,a5
    p = sbrklazy(1 << 30);
    4ba6:	40000537          	lui	a0,0x40000
    4baa:	2bb000ef          	jal	5664 <sbrklazy>
    if (p == SBRK_ERROR) {
    4bae:	03350f63          	beq	a0,s3,4bec <lazy_sbrk+0x6a>
    p = sbrklazy(0);
    4bb2:	4501                	li	a0,0
    4bb4:	2b1000ef          	jal	5664 <sbrklazy>
    4bb8:	84aa                	mv	s1,a0
  while ((uint64)p < MAXVA - (1 << 30)) {
    4bba:	ff2566e3          	bltu	a0,s2,4ba6 <lazy_sbrk+0x24>
  int n = TRAPFRAME - PGSIZE - (uint64)p;
    4bbe:	7975                	lui	s2,0xffffd
    4bc0:	4099093b          	subw	s2,s2,s1
  char *p1 = sbrklazy(n);
    4bc4:	854a                	mv	a0,s2
    4bc6:	29f000ef          	jal	5664 <sbrklazy>
    4bca:	862a                	mv	a2,a0
  if (p1 == SBRK_ERROR || p1 != p) {
    4bcc:	57fd                	li	a5,-1
    4bce:	00f50463          	beq	a0,a5,4bd6 <lazy_sbrk+0x54>
    4bd2:	02950963          	beq	a0,s1,4c04 <lazy_sbrk+0x82>
    printf("sbrklazy(%d) returned %p, not expected %p\n", n, p1, p);
    4bd6:	86a6                	mv	a3,s1
    4bd8:	85ca                	mv	a1,s2
    4bda:	00003517          	auipc	a0,0x3
    4bde:	35650513          	addi	a0,a0,854 # 7f30 <malloc+0x23aa>
    4be2:	6f1000ef          	jal	5ad2 <printf>
    exit(1);
    4be6:	4505                	li	a0,1
    4be8:	29b000ef          	jal	5682 <exit>
      printf("sbrklazy(%d) returned %p\n", 1 << 30, p);
    4bec:	567d                	li	a2,-1
    4bee:	400005b7          	lui	a1,0x40000
    4bf2:	00003517          	auipc	a0,0x3
    4bf6:	31e50513          	addi	a0,a0,798 # 7f10 <malloc+0x238a>
    4bfa:	6d9000ef          	jal	5ad2 <printf>
      exit(1);
    4bfe:	4505                	li	a0,1
    4c00:	283000ef          	jal	5682 <exit>
  p = sbrk(PGSIZE);
    4c04:	6505                	lui	a0,0x1
    4c06:	249000ef          	jal	564e <sbrk>
    4c0a:	862a                	mv	a2,a0
  if (p == SBRK_ERROR || (uint64)p != TRAPFRAME - PGSIZE) {
    4c0c:	040007b7          	lui	a5,0x4000
    4c10:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3fef2f5>
    4c12:	07b2                	slli	a5,a5,0xc
    4c14:	00f50c63          	beq	a0,a5,4c2c <lazy_sbrk+0xaa>
    printf("sbrk(%d) returned %p, not expected TRAPFRAME-PGSIZE\n", PGSIZE, p);
    4c18:	6585                	lui	a1,0x1
    4c1a:	00003517          	auipc	a0,0x3
    4c1e:	34650513          	addi	a0,a0,838 # 7f60 <malloc+0x23da>
    4c22:	6b1000ef          	jal	5ad2 <printf>
    exit(1);
    4c26:	4505                	li	a0,1
    4c28:	25b000ef          	jal	5682 <exit>
  p[0] = 1;
    4c2c:	040007b7          	lui	a5,0x4000
    4c30:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3fef2f5>
    4c32:	07b2                	slli	a5,a5,0xc
    4c34:	4705                	li	a4,1
    4c36:	00e78023          	sb	a4,0(a5)
  if (p[1] != 0) {
    4c3a:	0017c783          	lbu	a5,1(a5)
    4c3e:	cb91                	beqz	a5,4c52 <lazy_sbrk+0xd0>
    printf("sbrk() returned non-zero-filled memory\n");
    4c40:	00003517          	auipc	a0,0x3
    4c44:	35850513          	addi	a0,a0,856 # 7f98 <malloc+0x2412>
    4c48:	68b000ef          	jal	5ad2 <printf>
    exit(1);
    4c4c:	4505                	li	a0,1
    4c4e:	235000ef          	jal	5682 <exit>
  p = sbrk(1);
    4c52:	4505                	li	a0,1
    4c54:	1fb000ef          	jal	564e <sbrk>
    4c58:	85aa                	mv	a1,a0
  if ((uint64)p != -1) {
    4c5a:	57fd                	li	a5,-1
    4c5c:	00f50b63          	beq	a0,a5,4c72 <lazy_sbrk+0xf0>
    printf("sbrk(1) returned %p, expected error\n", p);
    4c60:	00003517          	auipc	a0,0x3
    4c64:	36050513          	addi	a0,a0,864 # 7fc0 <malloc+0x243a>
    4c68:	66b000ef          	jal	5ad2 <printf>
    exit(1);
    4c6c:	4505                	li	a0,1
    4c6e:	215000ef          	jal	5682 <exit>
  p = sbrklazy(1);
    4c72:	4505                	li	a0,1
    4c74:	1f1000ef          	jal	5664 <sbrklazy>
    4c78:	85aa                	mv	a1,a0
  if ((uint64)p != -1) {
    4c7a:	57fd                	li	a5,-1
    4c7c:	00f50b63          	beq	a0,a5,4c92 <lazy_sbrk+0x110>
    printf("sbrklazy(1) returned %p, expected error\n", p);
    4c80:	00003517          	auipc	a0,0x3
    4c84:	36850513          	addi	a0,a0,872 # 7fe8 <malloc+0x2462>
    4c88:	64b000ef          	jal	5ad2 <printf>
    exit(1);
    4c8c:	4505                	li	a0,1
    4c8e:	1f5000ef          	jal	5682 <exit>
  exit(0);
    4c92:	4501                	li	a0,0
    4c94:	1ef000ef          	jal	5682 <exit>

0000000000004c98 <lazy_copyinstr>:
{
    4c98:	715d                	addi	sp,sp,-80
    4c9a:	e486                	sd	ra,72(sp)
    4c9c:	e0a2                	sd	s0,64(sp)
    4c9e:	fc26                	sd	s1,56(sp)
    4ca0:	f84a                	sd	s2,48(sp)
    4ca2:	f44e                	sd	s3,40(sp)
    4ca4:	0880                	addi	s0,sp,80
    4ca6:	89aa                	mv	s3,a0
  char *p = sbrk(0);
    4ca8:	4501                	li	a0,0
    4caa:	1a5000ef          	jal	564e <sbrk>
  sbrk(PGSIZE - ((uint64)p % PGSIZE));
    4cae:	6485                	lui	s1,0x1
    4cb0:	14fd                	addi	s1,s1,-1 # fff <pgbug+0x2b>
    4cb2:	009577b3          	and	a5,a0,s1
    4cb6:	6505                	lui	a0,0x1
    4cb8:	9d1d                	subw	a0,a0,a5
    4cba:	195000ef          	jal	564e <sbrk>
  p = sbrk(0);
    4cbe:	4501                	li	a0,0
    4cc0:	18f000ef          	jal	564e <sbrk>
  if ((uint64)p % PGSIZE != 0) {
    4cc4:	8ce9                	and	s1,s1,a0
    4cc6:	e8a9                	bnez	s1,4d18 <lazy_copyinstr+0x80>
    4cc8:	892a                	mv	s2,a0
  sbrklazy(2 * PGSIZE);
    4cca:	6509                	lui	a0,0x2
    4ccc:	199000ef          	jal	5664 <sbrklazy>
  p[4095] = '/';
    4cd0:	6505                	lui	a0,0x1
    4cd2:	00a907b3          	add	a5,s2,a0
    4cd6:	02f00713          	li	a4,47
    4cda:	fee78fa3          	sb	a4,-1(a5)
  int fd = open(&p[4095], O_RDONLY);
    4cde:	157d                	addi	a0,a0,-1 # fff <pgbug+0x2b>
    4ce0:	4581                	li	a1,0
    4ce2:	954a                	add	a0,a0,s2
    4ce4:	1df000ef          	jal	56c2 <open>
    4ce8:	84aa                	mv	s1,a0
  if (fd < 0) {
    4cea:	04054163          	bltz	a0,4d2c <lazy_copyinstr+0x94>
  int r = fstat(fd, &st);
    4cee:	fb840593          	addi	a1,s0,-72
    4cf2:	1e9000ef          	jal	56da <fstat>
  if (r < 0) {
    4cf6:	04054463          	bltz	a0,4d3e <lazy_copyinstr+0xa6>
  if (st.type != T_DIR) {
    4cfa:	fc041703          	lh	a4,-64(s0)
    4cfe:	4785                	li	a5,1
    4d00:	04f71863          	bne	a4,a5,4d50 <lazy_copyinstr+0xb8>
  close(fd);
    4d04:	8526                	mv	a0,s1
    4d06:	1a5000ef          	jal	56aa <close>
}
    4d0a:	60a6                	ld	ra,72(sp)
    4d0c:	6406                	ld	s0,64(sp)
    4d0e:	74e2                	ld	s1,56(sp)
    4d10:	7942                	ld	s2,48(sp)
    4d12:	79a2                	ld	s3,40(sp)
    4d14:	6161                	addi	sp,sp,80
    4d16:	8082                	ret
    printf("%s: sbrk did not align\n", s);
    4d18:	85ce                	mv	a1,s3
    4d1a:	00003517          	auipc	a0,0x3
    4d1e:	04e50513          	addi	a0,a0,78 # 7d68 <malloc+0x21e2>
    4d22:	5b1000ef          	jal	5ad2 <printf>
    exit(1);
    4d26:	4505                	li	a0,1
    4d28:	15b000ef          	jal	5682 <exit>
    printf("could not open /");
    4d2c:	00003517          	auipc	a0,0x3
    4d30:	2ec50513          	addi	a0,a0,748 # 8018 <malloc+0x2492>
    4d34:	59f000ef          	jal	5ad2 <printf>
    exit(1);
    4d38:	4505                	li	a0,1
    4d3a:	149000ef          	jal	5682 <exit>
    printf("could not stat /");
    4d3e:	00003517          	auipc	a0,0x3
    4d42:	2f250513          	addi	a0,a0,754 # 8030 <malloc+0x24aa>
    4d46:	58d000ef          	jal	5ad2 <printf>
    exit(1);
    4d4a:	4505                	li	a0,1
    4d4c:	137000ef          	jal	5682 <exit>
    printf("/ is not T_DIR");
    4d50:	00003517          	auipc	a0,0x3
    4d54:	2f850513          	addi	a0,a0,760 # 8048 <malloc+0x24c2>
    4d58:	57b000ef          	jal	5ad2 <printf>
    exit(1);
    4d5c:	4505                	li	a0,1
    4d5e:	125000ef          	jal	5682 <exit>

0000000000004d62 <fsfull>:
{
    4d62:	7171                	addi	sp,sp,-176
    4d64:	f506                	sd	ra,168(sp)
    4d66:	f122                	sd	s0,160(sp)
    4d68:	ed26                	sd	s1,152(sp)
    4d6a:	e94a                	sd	s2,144(sp)
    4d6c:	e54e                	sd	s3,136(sp)
    4d6e:	e152                	sd	s4,128(sp)
    4d70:	fcd6                	sd	s5,120(sp)
    4d72:	f8da                	sd	s6,112(sp)
    4d74:	f4de                	sd	s7,104(sp)
    4d76:	f0e2                	sd	s8,96(sp)
    4d78:	ece6                	sd	s9,88(sp)
    4d7a:	e8ea                	sd	s10,80(sp)
    4d7c:	e4ee                	sd	s11,72(sp)
    4d7e:	1900                	addi	s0,sp,176
  printf("fsfull test\n");
    4d80:	00003517          	auipc	a0,0x3
    4d84:	2d850513          	addi	a0,a0,728 # 8058 <malloc+0x24d2>
    4d88:	54b000ef          	jal	5ad2 <printf>
  int fsblocks = 0;
    4d8c:	4a81                	li	s5,0
  for (nfiles = 0;; nfiles++) {
    4d8e:	4481                	li	s1,0
    name[0] = 'f';
    4d90:	06600d93          	li	s11,102
    name[1] = '0' + nfiles / 1000;
    4d94:	3e800c93          	li	s9,1000
    name[2] = '0' + (nfiles % 1000) / 100;
    4d98:	06400c13          	li	s8,100
    name[3] = '0' + (nfiles % 100) / 10;
    4d9c:	4ba9                	li	s7,10
    printf("writing %s\n", name);
    4d9e:	00003d17          	auipc	s10,0x3
    4da2:	2cad0d13          	addi	s10,s10,714 # 8068 <malloc+0x24e2>
    name[0] = 'f';
    4da6:	f5b40823          	sb	s11,-176(s0)
    name[1] = '0' + nfiles / 1000;
    4daa:	0394c7bb          	divw	a5,s1,s9
    4dae:	0307879b          	addiw	a5,a5,48
    4db2:	f4f408a3          	sb	a5,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4db6:	0394e7bb          	remw	a5,s1,s9
    4dba:	0387c7bb          	divw	a5,a5,s8
    4dbe:	0307879b          	addiw	a5,a5,48
    4dc2:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4dc6:	0384e7bb          	remw	a5,s1,s8
    4dca:	0377c7bb          	divw	a5,a5,s7
    4dce:	0307879b          	addiw	a5,a5,48
    4dd2:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    4dd6:	0374e7bb          	remw	a5,s1,s7
    4dda:	0307879b          	addiw	a5,a5,48
    4dde:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4de2:	f4040aa3          	sb	zero,-171(s0)
    printf("writing %s\n", name);
    4de6:	f5040593          	addi	a1,s0,-176
    4dea:	856a                	mv	a0,s10
    4dec:	4e7000ef          	jal	5ad2 <printf>
    int fd = open(name, O_CREATE | O_RDWR);
    4df0:	20200593          	li	a1,514
    4df4:	f5040513          	addi	a0,s0,-176
    4df8:	0cb000ef          	jal	56c2 <open>
    4dfc:	892a                	mv	s2,a0
    if (fd < 0) {
    4dfe:	0a055163          	bgez	a0,4ea0 <fsfull+0x13e>
      printf("open %s failed\n", name);
    4e02:	f5040593          	addi	a1,s0,-176
    4e06:	00003517          	auipc	a0,0x3
    4e0a:	27250513          	addi	a0,a0,626 # 8078 <malloc+0x24f2>
    4e0e:	4c5000ef          	jal	5ad2 <printf>
  while (nfiles >= 0) {
    4e12:	0604c163          	bltz	s1,4e74 <fsfull+0x112>
    name[0] = 'f';
    4e16:	06600b93          	li	s7,102
    name[1] = '0' + nfiles / 1000;
    4e1a:	3e800a13          	li	s4,1000
    name[2] = '0' + (nfiles % 1000) / 100;
    4e1e:	06400993          	li	s3,100
    name[3] = '0' + (nfiles % 100) / 10;
    4e22:	4929                	li	s2,10
  while (nfiles >= 0) {
    4e24:	5b7d                	li	s6,-1
    name[0] = 'f';
    4e26:	f5740823          	sb	s7,-176(s0)
    name[1] = '0' + nfiles / 1000;
    4e2a:	0344c7bb          	divw	a5,s1,s4
    4e2e:	0307879b          	addiw	a5,a5,48
    4e32:	f4f408a3          	sb	a5,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4e36:	0344e7bb          	remw	a5,s1,s4
    4e3a:	0337c7bb          	divw	a5,a5,s3
    4e3e:	0307879b          	addiw	a5,a5,48
    4e42:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4e46:	0334e7bb          	remw	a5,s1,s3
    4e4a:	0327c7bb          	divw	a5,a5,s2
    4e4e:	0307879b          	addiw	a5,a5,48
    4e52:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    4e56:	0324e7bb          	remw	a5,s1,s2
    4e5a:	0307879b          	addiw	a5,a5,48
    4e5e:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4e62:	f4040aa3          	sb	zero,-171(s0)
    unlink(name);
    4e66:	f5040513          	addi	a0,s0,-176
    4e6a:	069000ef          	jal	56d2 <unlink>
    nfiles--;
    4e6e:	34fd                	addiw	s1,s1,-1
  while (nfiles >= 0) {
    4e70:	fb649be3          	bne	s1,s6,4e26 <fsfull+0xc4>
  printf("fsfull test finished, %d blocks\n", fsblocks);
    4e74:	85d6                	mv	a1,s5
    4e76:	00003517          	auipc	a0,0x3
    4e7a:	22250513          	addi	a0,a0,546 # 8098 <malloc+0x2512>
    4e7e:	455000ef          	jal	5ad2 <printf>
}
    4e82:	70aa                	ld	ra,168(sp)
    4e84:	740a                	ld	s0,160(sp)
    4e86:	64ea                	ld	s1,152(sp)
    4e88:	694a                	ld	s2,144(sp)
    4e8a:	69aa                	ld	s3,136(sp)
    4e8c:	6a0a                	ld	s4,128(sp)
    4e8e:	7ae6                	ld	s5,120(sp)
    4e90:	7b46                	ld	s6,112(sp)
    4e92:	7ba6                	ld	s7,104(sp)
    4e94:	7c06                	ld	s8,96(sp)
    4e96:	6ce6                	ld	s9,88(sp)
    4e98:	6d46                	ld	s10,80(sp)
    4e9a:	6da6                	ld	s11,72(sp)
    4e9c:	614d                	addi	sp,sp,176
    4e9e:	8082                	ret
    int total = 0;
    4ea0:	4981                	li	s3,0
      int cc = write(fd, buf, BSIZE);
    4ea2:	00009b17          	auipc	s6,0x9
    4ea6:	e66b0b13          	addi	s6,s6,-410 # dd08 <buf>
      if (cc < BSIZE)
    4eaa:	3ff00a13          	li	s4,1023
      int cc = write(fd, buf, BSIZE);
    4eae:	40000613          	li	a2,1024
    4eb2:	85da                	mv	a1,s6
    4eb4:	854a                	mv	a0,s2
    4eb6:	7ec000ef          	jal	56a2 <write>
      if (cc < BSIZE)
    4eba:	00aa5663          	bge	s4,a0,4ec6 <fsfull+0x164>
      total += cc;
    4ebe:	00a989bb          	addw	s3,s3,a0
      fsblocks++;
    4ec2:	2a85                	addiw	s5,s5,1
    while (1) {
    4ec4:	b7ed                	j	4eae <fsfull+0x14c>
    printf("wrote %d bytes\n", total);
    4ec6:	85ce                	mv	a1,s3
    4ec8:	00003517          	auipc	a0,0x3
    4ecc:	1c050513          	addi	a0,a0,448 # 8088 <malloc+0x2502>
    4ed0:	403000ef          	jal	5ad2 <printf>
    close(fd);
    4ed4:	854a                	mv	a0,s2
    4ed6:	7d4000ef          	jal	56aa <close>
    if (total == 0)
    4eda:	f2098ce3          	beqz	s3,4e12 <fsfull+0xb0>
  for (nfiles = 0;; nfiles++) {
    4ede:	2485                	addiw	s1,s1,1
    4ee0:	b5d9                	j	4da6 <fsfull+0x44>

0000000000004ee2 <linkoverflow>:

void
linkoverflow(char *s)
{
    4ee2:	7175                	addi	sp,sp,-144
    4ee4:	e506                	sd	ra,136(sp)
    4ee6:	e122                	sd	s0,128(sp)
    4ee8:	fca6                	sd	s1,120(sp)
    4eea:	f8ca                	sd	s2,112(sp)
    4eec:	f4ce                	sd	s3,104(sp)
    4eee:	f0d2                	sd	s4,96(sp)
    4ef0:	ecd6                	sd	s5,88(sp)
    4ef2:	e8da                	sd	s6,80(sp)
    4ef4:	e4de                	sd	s7,72(sp)
    4ef6:	e0e2                	sd	s8,64(sp)
    4ef8:	fc66                	sd	s9,56(sp)
    4efa:	f86a                	sd	s10,48(sp)
    4efc:	0900                	addi	s0,sp,144
    4efe:	8caa                	mv	s9,a0
  enum { TARGET = 32768 };
  enum { DIRS = 64 };
  struct stat st;
  int i;

  unlink("/lof");
    4f00:	00003517          	auipc	a0,0x3
    4f04:	1c050513          	addi	a0,a0,448 # 80c0 <malloc+0x253a>
    4f08:	7ca000ef          	jal	56d2 <unlink>
  int fd = open("/lof", O_CREATE | O_RDWR);
    4f0c:	20200593          	li	a1,514
    4f10:	00003517          	auipc	a0,0x3
    4f14:	1b050513          	addi	a0,a0,432 # 80c0 <malloc+0x253a>
    4f18:	7aa000ef          	jal	56c2 <open>
  if (fd < 0) {
    4f1c:	02054863          	bltz	a0,4f4c <linkoverflow+0x6a>
    printf("%s: cannot create /lof\n", s);
    exit(1);
  }
  close(fd);
    4f20:	78a000ef          	jal	56aa <close>

  for (i = 0; i < TARGET; i++) {
    4f24:	4901                	li	s2,0
    int d = i % DIRS;
    int f = i / DIRS;

    char pn[16];
    pn[0] = '/';
    4f26:	02f00993          	li	s3,47
    pn[1] = 'd';
    4f2a:	06400a93          	li	s5,100
    pn[2] = '_';
    4f2e:	05f00a13          	li	s4,95
      printf("%s: mkdir(%s) failed\n", s, pn);
      exit(1);
    }

    pn[5] = '/';
    pn[6] = 'l';
    4f32:	06c00b93          	li	s7,108
    pn[7] = 'a' + (f / 256);
    pn[8] = 'a' + ((f / 16) % 16);
    pn[9] = 'a' + (f % 16);
    pn[10] = '\0';

    if (link("/lof", pn) < 0) {
    4f36:	00003b17          	auipc	s6,0x3
    4f3a:	18ab0b13          	addi	s6,s6,394 # 80c0 <malloc+0x253a>
      }
      printf("%s: link failed after %d links (nlink=%d)\n", s, i, st.nlink);
      exit(1);
    }

    if (i % 100 == 0) {
    4f3e:	06400c13          	li	s8,100
      printf("%s: i=%d, pn=%s\n", s, i, pn);
    4f42:	00003d17          	auipc	s10,0x3
    4f46:	1fed0d13          	addi	s10,s10,510 # 8140 <malloc+0x25ba>
    4f4a:	a061                	j	4fd2 <linkoverflow+0xf0>
    printf("%s: cannot create /lof\n", s);
    4f4c:	85e6                	mv	a1,s9
    4f4e:	00003517          	auipc	a0,0x3
    4f52:	17a50513          	addi	a0,a0,378 # 80c8 <malloc+0x2542>
    4f56:	37d000ef          	jal	5ad2 <printf>
    exit(1);
    4f5a:	4505                	li	a0,1
    4f5c:	726000ef          	jal	5682 <exit>
    pn[5] = '/';
    4f60:	f7340ea3          	sb	s3,-131(s0)
    pn[6] = 'l';
    4f64:	f7740f23          	sb	s7,-130(s0)
    pn[7] = 'a' + (f / 256);
    4f68:	41f9579b          	sraiw	a5,s2,0x1f
    4f6c:	0127d79b          	srliw	a5,a5,0x12
    4f70:	012787bb          	addw	a5,a5,s2
    4f74:	40e7d79b          	sraiw	a5,a5,0xe
    4f78:	0617879b          	addiw	a5,a5,97
    4f7c:	f6f40fa3          	sb	a5,-129(s0)
    pn[8] = 'a' + ((f / 16) % 16);
    4f80:	41f4d71b          	sraiw	a4,s1,0x1f
    4f84:	01c7571b          	srliw	a4,a4,0x1c
    4f88:	9cb9                	addw	s1,s1,a4
    4f8a:	4044d79b          	sraiw	a5,s1,0x4
    4f8e:	41f4d69b          	sraiw	a3,s1,0x1f
    4f92:	01c6d69b          	srliw	a3,a3,0x1c
    4f96:	9fb5                	addw	a5,a5,a3
    4f98:	8bbd                	andi	a5,a5,15
    4f9a:	9f95                	subw	a5,a5,a3
    4f9c:	0617879b          	addiw	a5,a5,97
    4fa0:	f8f40023          	sb	a5,-128(s0)
    pn[9] = 'a' + (f % 16);
    4fa4:	88bd                	andi	s1,s1,15
    4fa6:	9c99                	subw	s1,s1,a4
    4fa8:	0614849b          	addiw	s1,s1,97
    4fac:	f89400a3          	sb	s1,-127(s0)
    pn[10] = '\0';
    4fb0:	f8040123          	sb	zero,-126(s0)
    if (link("/lof", pn) < 0) {
    4fb4:	f7840593          	addi	a1,s0,-136
    4fb8:	855a                	mv	a0,s6
    4fba:	728000ef          	jal	56e2 <link>
    4fbe:	08054363          	bltz	a0,5044 <linkoverflow+0x162>
    if (i % 100 == 0) {
    4fc2:	038967bb          	remw	a5,s2,s8
    4fc6:	10078663          	beqz	a5,50d2 <linkoverflow+0x1f0>
  for (i = 0; i < TARGET; i++) {
    4fca:	2905                	addiw	s2,s2,1 # ffffffffffffd001 <base+0xfffffffffffec2f9>
    4fcc:	67a1                	lui	a5,0x8
    4fce:	08f90b63          	beq	s2,a5,5064 <linkoverflow+0x182>
    int d = i % DIRS;
    4fd2:	41f9571b          	sraiw	a4,s2,0x1f
    4fd6:	01a7571b          	srliw	a4,a4,0x1a
    4fda:	012704bb          	addw	s1,a4,s2
    4fde:	03f4f793          	andi	a5,s1,63
    4fe2:	9f99                	subw	a5,a5,a4
    int f = i / DIRS;
    4fe4:	4064d49b          	sraiw	s1,s1,0x6
    4fe8:	0004861b          	sext.w	a2,s1
    pn[0] = '/';
    4fec:	f7340c23          	sb	s3,-136(s0)
    pn[1] = 'd';
    4ff0:	f7540ca3          	sb	s5,-135(s0)
    pn[2] = '_';
    4ff4:	f7440d23          	sb	s4,-134(s0)
    pn[3] = 'a' + (d / 16);
    4ff8:	41f7d71b          	sraiw	a4,a5,0x1f
    4ffc:	01c7571b          	srliw	a4,a4,0x1c
    5000:	9fb9                	addw	a5,a5,a4
    5002:	4047d69b          	sraiw	a3,a5,0x4
    5006:	0616869b          	addiw	a3,a3,97 # 40061 <base+0x2f359>
    500a:	f6d40da3          	sb	a3,-133(s0)
    pn[4] = 'a' + (d % 16);
    500e:	8bbd                	andi	a5,a5,15
    5010:	9f99                	subw	a5,a5,a4
    5012:	0617879b          	addiw	a5,a5,97 # 8061 <malloc+0x24db>
    5016:	f6f40e23          	sb	a5,-132(s0)
    pn[5] = '\0';
    501a:	f6040ea3          	sb	zero,-131(s0)
    if (f == 0 && mkdir(pn) < 0) {
    501e:	f229                	bnez	a2,4f60 <linkoverflow+0x7e>
    5020:	f7840513          	addi	a0,s0,-136
    5024:	6c6000ef          	jal	56ea <mkdir>
    5028:	f2055ce3          	bgez	a0,4f60 <linkoverflow+0x7e>
      printf("%s: mkdir(%s) failed\n", s, pn);
    502c:	f7840613          	addi	a2,s0,-136
    5030:	85e6                	mv	a1,s9
    5032:	00003517          	auipc	a0,0x3
    5036:	0ae50513          	addi	a0,a0,174 # 80e0 <malloc+0x255a>
    503a:	299000ef          	jal	5ad2 <printf>
      exit(1);
    503e:	4505                	li	a0,1
    5040:	642000ef          	jal	5682 <exit>
      if (stat("/lof", &st) < 0) {
    5044:	f8840593          	addi	a1,s0,-120
    5048:	00003517          	auipc	a0,0x3
    504c:	07850513          	addi	a0,a0,120 # 80c0 <malloc+0x253a>
    5050:	4d6000ef          	jal	5526 <stat>
    5054:	04054a63          	bltz	a0,50a8 <linkoverflow+0x1c6>
      if (st.nlink >= 32767) {
    5058:	f9241683          	lh	a3,-110(s0)
    505c:	67a1                	lui	a5,0x8
    505e:	17fd                	addi	a5,a5,-1 # 7fff <malloc+0x2479>
    5060:	04f69e63          	bne	a3,a5,50bc <linkoverflow+0x1da>
    }
  }

  if (stat("/lof", &st) < 0) {
    5064:	f8840593          	addi	a1,s0,-120
    5068:	00003517          	auipc	a0,0x3
    506c:	05850513          	addi	a0,a0,88 # 80c0 <malloc+0x253a>
    5070:	4b6000ef          	jal	5526 <stat>
    5074:	06054763          	bltz	a0,50e2 <linkoverflow+0x200>
    printf("%s: stat(/lof) failed\n", s);
    exit(1);
  }

  unlink("/lof");
    5078:	00003517          	auipc	a0,0x3
    507c:	04850513          	addi	a0,a0,72 # 80c0 <malloc+0x253a>
    5080:	652000ef          	jal	56d2 <unlink>

  if (st.nlink < 0) {
    5084:	f9241603          	lh	a2,-110(s0)
    5088:	06064763          	bltz	a2,50f6 <linkoverflow+0x214>
    printf("%s: negative link count: %d\n", s, st.nlink);
    exit(1);
  }
}
    508c:	60aa                	ld	ra,136(sp)
    508e:	640a                	ld	s0,128(sp)
    5090:	74e6                	ld	s1,120(sp)
    5092:	7946                	ld	s2,112(sp)
    5094:	79a6                	ld	s3,104(sp)
    5096:	7a06                	ld	s4,96(sp)
    5098:	6ae6                	ld	s5,88(sp)
    509a:	6b46                	ld	s6,80(sp)
    509c:	6ba6                	ld	s7,72(sp)
    509e:	6c06                	ld	s8,64(sp)
    50a0:	7ce2                	ld	s9,56(sp)
    50a2:	7d42                	ld	s10,48(sp)
    50a4:	6149                	addi	sp,sp,144
    50a6:	8082                	ret
        printf("%s: stat(/lof) failed\n", s);
    50a8:	85e6                	mv	a1,s9
    50aa:	00003517          	auipc	a0,0x3
    50ae:	04e50513          	addi	a0,a0,78 # 80f8 <malloc+0x2572>
    50b2:	221000ef          	jal	5ad2 <printf>
        exit(1);
    50b6:	4505                	li	a0,1
    50b8:	5ca000ef          	jal	5682 <exit>
      printf("%s: link failed after %d links (nlink=%d)\n", s, i, st.nlink);
    50bc:	864a                	mv	a2,s2
    50be:	85e6                	mv	a1,s9
    50c0:	00003517          	auipc	a0,0x3
    50c4:	05050513          	addi	a0,a0,80 # 8110 <malloc+0x258a>
    50c8:	20b000ef          	jal	5ad2 <printf>
      exit(1);
    50cc:	4505                	li	a0,1
    50ce:	5b4000ef          	jal	5682 <exit>
      printf("%s: i=%d, pn=%s\n", s, i, pn);
    50d2:	f7840693          	addi	a3,s0,-136
    50d6:	864a                	mv	a2,s2
    50d8:	85e6                	mv	a1,s9
    50da:	856a                	mv	a0,s10
    50dc:	1f7000ef          	jal	5ad2 <printf>
    50e0:	b5ed                	j	4fca <linkoverflow+0xe8>
    printf("%s: stat(/lof) failed\n", s);
    50e2:	85e6                	mv	a1,s9
    50e4:	00003517          	auipc	a0,0x3
    50e8:	01450513          	addi	a0,a0,20 # 80f8 <malloc+0x2572>
    50ec:	1e7000ef          	jal	5ad2 <printf>
    exit(1);
    50f0:	4505                	li	a0,1
    50f2:	590000ef          	jal	5682 <exit>
    printf("%s: negative link count: %d\n", s, st.nlink);
    50f6:	85e6                	mv	a1,s9
    50f8:	00003517          	auipc	a0,0x3
    50fc:	06050513          	addi	a0,a0,96 # 8158 <malloc+0x25d2>
    5100:	1d3000ef          	jal	5ad2 <printf>
    exit(1);
    5104:	4505                	li	a0,1
    5106:	57c000ef          	jal	5682 <exit>

000000000000510a <run>:

// run each test in its own process. run returns 1 if child's exit()
// indicates success.
int
run(void f(char *), char *s)
{
    510a:	7179                	addi	sp,sp,-48
    510c:	f406                	sd	ra,40(sp)
    510e:	f022                	sd	s0,32(sp)
    5110:	ec26                	sd	s1,24(sp)
    5112:	e84a                	sd	s2,16(sp)
    5114:	1800                	addi	s0,sp,48
    5116:	84aa                	mv	s1,a0
    5118:	892e                	mv	s2,a1
  int pid;
  int xstatus;

  printf("test %s: ", s);
    511a:	00003517          	auipc	a0,0x3
    511e:	05e50513          	addi	a0,a0,94 # 8178 <malloc+0x25f2>
    5122:	1b1000ef          	jal	5ad2 <printf>
  if ((pid = fork()) < 0) {
    5126:	554000ef          	jal	567a <fork>
    512a:	02054a63          	bltz	a0,515e <run+0x54>
    printf("runtest: fork error\n");
    exit(1);
  }
  if (pid == 0) {
    512e:	c129                	beqz	a0,5170 <run+0x66>
    f(s);
    exit(0);
  } else {
    wait(&xstatus);
    5130:	fdc40513          	addi	a0,s0,-36
    5134:	556000ef          	jal	568a <wait>
    if (xstatus != 0)
    5138:	fdc42783          	lw	a5,-36(s0)
    513c:	cf9d                	beqz	a5,517a <run+0x70>
      printf("FAILED\n");
    513e:	00003517          	auipc	a0,0x3
    5142:	06250513          	addi	a0,a0,98 # 81a0 <malloc+0x261a>
    5146:	18d000ef          	jal	5ad2 <printf>
    else
      printf("OK\n");
    return xstatus == 0;
    514a:	fdc42503          	lw	a0,-36(s0)
  }
}
    514e:	00153513          	seqz	a0,a0
    5152:	70a2                	ld	ra,40(sp)
    5154:	7402                	ld	s0,32(sp)
    5156:	64e2                	ld	s1,24(sp)
    5158:	6942                	ld	s2,16(sp)
    515a:	6145                	addi	sp,sp,48
    515c:	8082                	ret
    printf("runtest: fork error\n");
    515e:	00003517          	auipc	a0,0x3
    5162:	02a50513          	addi	a0,a0,42 # 8188 <malloc+0x2602>
    5166:	16d000ef          	jal	5ad2 <printf>
    exit(1);
    516a:	4505                	li	a0,1
    516c:	516000ef          	jal	5682 <exit>
    f(s);
    5170:	854a                	mv	a0,s2
    5172:	9482                	jalr	s1
    exit(0);
    5174:	4501                	li	a0,0
    5176:	50c000ef          	jal	5682 <exit>
      printf("OK\n");
    517a:	00003517          	auipc	a0,0x3
    517e:	02e50513          	addi	a0,a0,46 # 81a8 <malloc+0x2622>
    5182:	151000ef          	jal	5ad2 <printf>
    5186:	b7d1                	j	514a <run+0x40>

0000000000005188 <runtests>:

int
runtests(struct test *tests, char *justone, int continuous)
{
    5188:	7139                	addi	sp,sp,-64
    518a:	fc06                	sd	ra,56(sp)
    518c:	f822                	sd	s0,48(sp)
    518e:	f426                	sd	s1,40(sp)
    5190:	ec4e                	sd	s3,24(sp)
    5192:	0080                	addi	s0,sp,64
    5194:	84aa                	mv	s1,a0
  int ntests = 0;
  for (struct test *t = tests; t->s != 0; t++) {
    5196:	6508                	ld	a0,8(a0)
    5198:	cd39                	beqz	a0,51f6 <runtests+0x6e>
    519a:	f04a                	sd	s2,32(sp)
    519c:	e852                	sd	s4,16(sp)
    519e:	e456                	sd	s5,8(sp)
    51a0:	892e                	mv	s2,a1
    51a2:	8a32                	mv	s4,a2
  int ntests = 0;
    51a4:	4981                	li	s3,0
    if ((justone == 0) || strcmp(t->s, justone) == 0) {
      ntests++;
      if (!run(t->f, t->s)) {
        if (continuous != 2) {
    51a6:	4a89                	li	s5,2
    51a8:	a021                	j	51b0 <runtests+0x28>
  for (struct test *t = tests; t->s != 0; t++) {
    51aa:	04c1                	addi	s1,s1,16
    51ac:	6488                	ld	a0,8(s1)
    51ae:	c915                	beqz	a0,51e2 <runtests+0x5a>
    if ((justone == 0) || strcmp(t->s, justone) == 0) {
    51b0:	00090663          	beqz	s2,51bc <runtests+0x34>
    51b4:	85ca                	mv	a1,s2
    51b6:	264000ef          	jal	541a <strcmp>
    51ba:	f965                	bnez	a0,51aa <runtests+0x22>
      ntests++;
    51bc:	2985                	addiw	s3,s3,1 # 1000001 <base+0xfef2f9>
      if (!run(t->f, t->s)) {
    51be:	648c                	ld	a1,8(s1)
    51c0:	6088                	ld	a0,0(s1)
    51c2:	f49ff0ef          	jal	510a <run>
    51c6:	f175                	bnez	a0,51aa <runtests+0x22>
        if (continuous != 2) {
    51c8:	ff5a01e3          	beq	s4,s5,51aa <runtests+0x22>
          printf("SOME TESTS FAILED\n");
    51cc:	00003517          	auipc	a0,0x3
    51d0:	fe450513          	addi	a0,a0,-28 # 81b0 <malloc+0x262a>
    51d4:	0ff000ef          	jal	5ad2 <printf>
          return -1;
    51d8:	59fd                	li	s3,-1
    51da:	7902                	ld	s2,32(sp)
    51dc:	6a42                	ld	s4,16(sp)
    51de:	6aa2                	ld	s5,8(sp)
    51e0:	a021                	j	51e8 <runtests+0x60>
    51e2:	7902                	ld	s2,32(sp)
    51e4:	6a42                	ld	s4,16(sp)
    51e6:	6aa2                	ld	s5,8(sp)
        }
      }
    }
  }
  return ntests;
}
    51e8:	854e                	mv	a0,s3
    51ea:	70e2                	ld	ra,56(sp)
    51ec:	7442                	ld	s0,48(sp)
    51ee:	74a2                	ld	s1,40(sp)
    51f0:	69e2                	ld	s3,24(sp)
    51f2:	6121                	addi	sp,sp,64
    51f4:	8082                	ret
  return ntests;
    51f6:	4981                	li	s3,0
    51f8:	bfc5                	j	51e8 <runtests+0x60>

00000000000051fa <countfree>:

// use sbrk() to count how many free physical memory pages there are.
int
countfree()
{
    51fa:	7179                	addi	sp,sp,-48
    51fc:	f406                	sd	ra,40(sp)
    51fe:	f022                	sd	s0,32(sp)
    5200:	ec26                	sd	s1,24(sp)
    5202:	e84a                	sd	s2,16(sp)
    5204:	e44e                	sd	s3,8(sp)
    5206:	1800                	addi	s0,sp,48
  int n = 0;
  uint64 sz0 = (uint64)sbrk(0);
    5208:	4501                	li	a0,0
    520a:	444000ef          	jal	564e <sbrk>
    520e:	89aa                	mv	s3,a0
  int n = 0;
    5210:	4481                	li	s1,0
  while (1) {
    char *a = sbrk(PGSIZE);
    if (a == SBRK_ERROR) {
    5212:	597d                	li	s2,-1
    5214:	a011                	j	5218 <countfree+0x1e>
      break;
    }
    n += 1;
    5216:	2485                	addiw	s1,s1,1
    char *a = sbrk(PGSIZE);
    5218:	6505                	lui	a0,0x1
    521a:	434000ef          	jal	564e <sbrk>
    if (a == SBRK_ERROR) {
    521e:	ff251ce3          	bne	a0,s2,5216 <countfree+0x1c>
  }
  sbrk(-((uint64)sbrk(0) - sz0));
    5222:	4501                	li	a0,0
    5224:	42a000ef          	jal	564e <sbrk>
    5228:	40a9853b          	subw	a0,s3,a0
    522c:	422000ef          	jal	564e <sbrk>
  return n;
}
    5230:	8526                	mv	a0,s1
    5232:	70a2                	ld	ra,40(sp)
    5234:	7402                	ld	s0,32(sp)
    5236:	64e2                	ld	s1,24(sp)
    5238:	6942                	ld	s2,16(sp)
    523a:	69a2                	ld	s3,8(sp)
    523c:	6145                	addi	sp,sp,48
    523e:	8082                	ret

0000000000005240 <drivetests>:

int
drivetests(int quick, int continuous, char *justone)
{
    5240:	7159                	addi	sp,sp,-112
    5242:	f486                	sd	ra,104(sp)
    5244:	f0a2                	sd	s0,96(sp)
    5246:	eca6                	sd	s1,88(sp)
    5248:	e8ca                	sd	s2,80(sp)
    524a:	e4ce                	sd	s3,72(sp)
    524c:	e0d2                	sd	s4,64(sp)
    524e:	fc56                	sd	s5,56(sp)
    5250:	f85a                	sd	s6,48(sp)
    5252:	f45e                	sd	s7,40(sp)
    5254:	f062                	sd	s8,32(sp)
    5256:	ec66                	sd	s9,24(sp)
    5258:	e86a                	sd	s10,16(sp)
    525a:	e46e                	sd	s11,8(sp)
    525c:	1880                	addi	s0,sp,112
    525e:	8aaa                	mv	s5,a0
    5260:	89ae                	mv	s3,a1
    5262:	8a32                	mv	s4,a2
  do {
    printf("usertests starting\n");
    5264:	00003c17          	auipc	s8,0x3
    5268:	f64c0c13          	addi	s8,s8,-156 # 81c8 <malloc+0x2642>
    int free0 = countfree();
    int free1 = 0;
    int ntests = 0;
    int n;
    n = runtests(quicktests, justone, continuous);
    526c:	00005b97          	auipc	s7,0x5
    5270:	da4b8b93          	addi	s7,s7,-604 # a010 <quicktests>
    if (n < 0) {
      if (continuous != 2) {
    5274:	4b09                	li	s6,2
      ntests += n;
    }
    if (!quick) {
      if (justone == 0)
        printf("usertests slow tests starting\n");
      n = runtests(slowtests, justone, continuous);
    5276:	00005c97          	auipc	s9,0x5
    527a:	1fac8c93          	addi	s9,s9,506 # a470 <slowtests>
        printf("usertests slow tests starting\n");
    527e:	00003d97          	auipc	s11,0x3
    5282:	f62d8d93          	addi	s11,s11,-158 # 81e0 <malloc+0x265a>
      } else {
        ntests += n;
      }
    }
    if ((free1 = countfree()) < free0) {
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    5286:	00003d17          	auipc	s10,0x3
    528a:	f7ad0d13          	addi	s10,s10,-134 # 8200 <malloc+0x267a>
    528e:	a025                	j	52b6 <drivetests+0x76>
      if (continuous != 2) {
    5290:	09699063          	bne	s3,s6,5310 <drivetests+0xd0>
    int ntests = 0;
    5294:	4481                	li	s1,0
    5296:	a835                	j	52d2 <drivetests+0x92>
        printf("usertests slow tests starting\n");
    5298:	856e                	mv	a0,s11
    529a:	039000ef          	jal	5ad2 <printf>
    529e:	a835                	j	52da <drivetests+0x9a>
        if (continuous != 2) {
    52a0:	07699a63          	bne	s3,s6,5314 <drivetests+0xd4>
    if ((free1 = countfree()) < free0) {
    52a4:	f57ff0ef          	jal	51fa <countfree>
    52a8:	05254263          	blt	a0,s2,52ec <drivetests+0xac>
      if (continuous != 2) {
        return 1;
      }
    }
    if (justone != 0 && ntests == 0) {
    52ac:	000a0363          	beqz	s4,52b2 <drivetests+0x72>
    52b0:	c8a1                	beqz	s1,5300 <drivetests+0xc0>
      printf("NO TESTS EXECUTED\n");
      return 1;
    }
  } while (continuous);
    52b2:	06098563          	beqz	s3,531c <drivetests+0xdc>
    printf("usertests starting\n");
    52b6:	8562                	mv	a0,s8
    52b8:	01b000ef          	jal	5ad2 <printf>
    int free0 = countfree();
    52bc:	f3fff0ef          	jal	51fa <countfree>
    52c0:	892a                	mv	s2,a0
    n = runtests(quicktests, justone, continuous);
    52c2:	864e                	mv	a2,s3
    52c4:	85d2                	mv	a1,s4
    52c6:	855e                	mv	a0,s7
    52c8:	ec1ff0ef          	jal	5188 <runtests>
    52cc:	84aa                	mv	s1,a0
    if (n < 0) {
    52ce:	fc0541e3          	bltz	a0,5290 <drivetests+0x50>
    if (!quick) {
    52d2:	fc0a99e3          	bnez	s5,52a4 <drivetests+0x64>
      if (justone == 0)
    52d6:	fc0a01e3          	beqz	s4,5298 <drivetests+0x58>
      n = runtests(slowtests, justone, continuous);
    52da:	864e                	mv	a2,s3
    52dc:	85d2                	mv	a1,s4
    52de:	8566                	mv	a0,s9
    52e0:	ea9ff0ef          	jal	5188 <runtests>
      if (n < 0) {
    52e4:	fa054ee3          	bltz	a0,52a0 <drivetests+0x60>
        ntests += n;
    52e8:	9ca9                	addw	s1,s1,a0
    52ea:	bf6d                	j	52a4 <drivetests+0x64>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    52ec:	864a                	mv	a2,s2
    52ee:	85aa                	mv	a1,a0
    52f0:	856a                	mv	a0,s10
    52f2:	7e0000ef          	jal	5ad2 <printf>
      if (continuous != 2) {
    52f6:	03699163          	bne	s3,s6,5318 <drivetests+0xd8>
    if (justone != 0 && ntests == 0) {
    52fa:	fa0a1be3          	bnez	s4,52b0 <drivetests+0x70>
    52fe:	bf65                	j	52b6 <drivetests+0x76>
      printf("NO TESTS EXECUTED\n");
    5300:	00003517          	auipc	a0,0x3
    5304:	f3050513          	addi	a0,a0,-208 # 8230 <malloc+0x26aa>
    5308:	7ca000ef          	jal	5ad2 <printf>
      return 1;
    530c:	4505                	li	a0,1
    530e:	a801                	j	531e <drivetests+0xde>
        return 1;
    5310:	4505                	li	a0,1
    5312:	a031                	j	531e <drivetests+0xde>
          return 1;
    5314:	4505                	li	a0,1
    5316:	a021                	j	531e <drivetests+0xde>
        return 1;
    5318:	4505                	li	a0,1
    531a:	a011                	j	531e <drivetests+0xde>
  return 0;
    531c:	854e                	mv	a0,s3
}
    531e:	70a6                	ld	ra,104(sp)
    5320:	7406                	ld	s0,96(sp)
    5322:	64e6                	ld	s1,88(sp)
    5324:	6946                	ld	s2,80(sp)
    5326:	69a6                	ld	s3,72(sp)
    5328:	6a06                	ld	s4,64(sp)
    532a:	7ae2                	ld	s5,56(sp)
    532c:	7b42                	ld	s6,48(sp)
    532e:	7ba2                	ld	s7,40(sp)
    5330:	7c02                	ld	s8,32(sp)
    5332:	6ce2                	ld	s9,24(sp)
    5334:	6d42                	ld	s10,16(sp)
    5336:	6da2                	ld	s11,8(sp)
    5338:	6165                	addi	sp,sp,112
    533a:	8082                	ret

000000000000533c <main>:

int
main(int argc, char *argv[])
{
    533c:	1101                	addi	sp,sp,-32
    533e:	ec06                	sd	ra,24(sp)
    5340:	e822                	sd	s0,16(sp)
    5342:	e426                	sd	s1,8(sp)
    5344:	e04a                	sd	s2,0(sp)
    5346:	1000                	addi	s0,sp,32
    5348:	84aa                	mv	s1,a0
  int continuous = 0;
  int quick = 0;
  char *justone = 0;

  if (argc == 2 && strcmp(argv[1], "-q") == 0) {
    534a:	4789                	li	a5,2
    534c:	00f50e63          	beq	a0,a5,5368 <main+0x2c>
    continuous = 1;
  } else if (argc == 2 && strcmp(argv[1], "-C") == 0) {
    continuous = 2;
  } else if (argc == 2 && argv[1][0] != '-') {
    justone = argv[1];
  } else if (argc > 1) {
    5350:	4785                	li	a5,1
    5352:	06a7c663          	blt	a5,a0,53be <main+0x82>
  char *justone = 0;
    5356:	4601                	li	a2,0
  int quick = 0;
    5358:	4501                	li	a0,0
  int continuous = 0;
    535a:	4581                	li	a1,0
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    exit(1);
  }
  if (drivetests(quick, continuous, justone)) {
    535c:	ee5ff0ef          	jal	5240 <drivetests>
    5360:	cd35                	beqz	a0,53dc <main+0xa0>
    exit(1);
    5362:	4505                	li	a0,1
    5364:	31e000ef          	jal	5682 <exit>
    5368:	892e                	mv	s2,a1
  if (argc == 2 && strcmp(argv[1], "-q") == 0) {
    536a:	00003597          	auipc	a1,0x3
    536e:	ede58593          	addi	a1,a1,-290 # 8248 <malloc+0x26c2>
    5372:	00893503          	ld	a0,8(s2)
    5376:	0a4000ef          	jal	541a <strcmp>
    537a:	85aa                	mv	a1,a0
    537c:	e501                	bnez	a0,5384 <main+0x48>
  char *justone = 0;
    537e:	4601                	li	a2,0
    quick = 1;
    5380:	4505                	li	a0,1
    5382:	bfe9                	j	535c <main+0x20>
  } else if (argc == 2 && strcmp(argv[1], "-c") == 0) {
    5384:	00003597          	auipc	a1,0x3
    5388:	ecc58593          	addi	a1,a1,-308 # 8250 <malloc+0x26ca>
    538c:	00893503          	ld	a0,8(s2)
    5390:	08a000ef          	jal	541a <strcmp>
    5394:	cd15                	beqz	a0,53d0 <main+0x94>
  } else if (argc == 2 && strcmp(argv[1], "-C") == 0) {
    5396:	00003597          	auipc	a1,0x3
    539a:	f0a58593          	addi	a1,a1,-246 # 82a0 <malloc+0x271a>
    539e:	00893503          	ld	a0,8(s2)
    53a2:	078000ef          	jal	541a <strcmp>
    53a6:	c905                	beqz	a0,53d6 <main+0x9a>
  } else if (argc == 2 && argv[1][0] != '-') {
    53a8:	00893603          	ld	a2,8(s2)
    53ac:	00064703          	lbu	a4,0(a2) # 1000 <badarg>
    53b0:	02d00793          	li	a5,45
    53b4:	00f70563          	beq	a4,a5,53be <main+0x82>
  int quick = 0;
    53b8:	4501                	li	a0,0
  int continuous = 0;
    53ba:	4581                	li	a1,0
    53bc:	b745                	j	535c <main+0x20>
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    53be:	00003517          	auipc	a0,0x3
    53c2:	e9a50513          	addi	a0,a0,-358 # 8258 <malloc+0x26d2>
    53c6:	70c000ef          	jal	5ad2 <printf>
    exit(1);
    53ca:	4505                	li	a0,1
    53cc:	2b6000ef          	jal	5682 <exit>
  char *justone = 0;
    53d0:	4601                	li	a2,0
    continuous = 1;
    53d2:	4585                	li	a1,1
    53d4:	b761                	j	535c <main+0x20>
    continuous = 2;
    53d6:	85a6                	mv	a1,s1
  char *justone = 0;
    53d8:	4601                	li	a2,0
    53da:	b749                	j	535c <main+0x20>
  }
  printf("ALL TESTS PASSED\n");
    53dc:	00003517          	auipc	a0,0x3
    53e0:	eac50513          	addi	a0,a0,-340 # 8288 <malloc+0x2702>
    53e4:	6ee000ef          	jal	5ad2 <printf>
  exit(0);
    53e8:	4501                	li	a0,0
    53ea:	298000ef          	jal	5682 <exit>

00000000000053ee <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
    53ee:	1141                	addi	sp,sp,-16
    53f0:	e406                	sd	ra,8(sp)
    53f2:	e022                	sd	s0,0(sp)
    53f4:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
    53f6:	f47ff0ef          	jal	533c <main>
  exit(r);
    53fa:	288000ef          	jal	5682 <exit>

00000000000053fe <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
    53fe:	1141                	addi	sp,sp,-16
    5400:	e422                	sd	s0,8(sp)
    5402:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
    5404:	87aa                	mv	a5,a0
    5406:	0585                	addi	a1,a1,1
    5408:	0785                	addi	a5,a5,1
    540a:	fff5c703          	lbu	a4,-1(a1)
    540e:	fee78fa3          	sb	a4,-1(a5)
    5412:	fb75                	bnez	a4,5406 <strcpy+0x8>
    ;
  return os;
}
    5414:	6422                	ld	s0,8(sp)
    5416:	0141                	addi	sp,sp,16
    5418:	8082                	ret

000000000000541a <strcmp>:

int
strcmp(const char *p, const char *q)
{
    541a:	1141                	addi	sp,sp,-16
    541c:	e422                	sd	s0,8(sp)
    541e:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
    5420:	00054783          	lbu	a5,0(a0)
    5424:	cb91                	beqz	a5,5438 <strcmp+0x1e>
    5426:	0005c703          	lbu	a4,0(a1)
    542a:	00f71763          	bne	a4,a5,5438 <strcmp+0x1e>
    p++, q++;
    542e:	0505                	addi	a0,a0,1
    5430:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
    5432:	00054783          	lbu	a5,0(a0)
    5436:	fbe5                	bnez	a5,5426 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
    5438:	0005c503          	lbu	a0,0(a1)
}
    543c:	40a7853b          	subw	a0,a5,a0
    5440:	6422                	ld	s0,8(sp)
    5442:	0141                	addi	sp,sp,16
    5444:	8082                	ret

0000000000005446 <strlen>:

uint
strlen(const char *s)
{
    5446:	1141                	addi	sp,sp,-16
    5448:	e422                	sd	s0,8(sp)
    544a:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    544c:	00054783          	lbu	a5,0(a0)
    5450:	cf91                	beqz	a5,546c <strlen+0x26>
    5452:	0505                	addi	a0,a0,1
    5454:	87aa                	mv	a5,a0
    5456:	86be                	mv	a3,a5
    5458:	0785                	addi	a5,a5,1
    545a:	fff7c703          	lbu	a4,-1(a5)
    545e:	ff65                	bnez	a4,5456 <strlen+0x10>
    5460:	40a6853b          	subw	a0,a3,a0
    5464:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    5466:	6422                	ld	s0,8(sp)
    5468:	0141                	addi	sp,sp,16
    546a:	8082                	ret
  for (n = 0; s[n]; n++)
    546c:	4501                	li	a0,0
    546e:	bfe5                	j	5466 <strlen+0x20>

0000000000005470 <memset>:

void *
memset(void *dst, int c, uint n)
{
    5470:	1141                	addi	sp,sp,-16
    5472:	e422                	sd	s0,8(sp)
    5474:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    5476:	ca19                	beqz	a2,548c <memset+0x1c>
    5478:	87aa                	mv	a5,a0
    547a:	1602                	slli	a2,a2,0x20
    547c:	9201                	srli	a2,a2,0x20
    547e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    5482:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    5486:	0785                	addi	a5,a5,1
    5488:	fee79de3          	bne	a5,a4,5482 <memset+0x12>
  }
  return dst;
}
    548c:	6422                	ld	s0,8(sp)
    548e:	0141                	addi	sp,sp,16
    5490:	8082                	ret

0000000000005492 <strchr>:

char *
strchr(const char *s, char c)
{
    5492:	1141                	addi	sp,sp,-16
    5494:	e422                	sd	s0,8(sp)
    5496:	0800                	addi	s0,sp,16
  for (; *s; s++)
    5498:	00054783          	lbu	a5,0(a0)
    549c:	cb99                	beqz	a5,54b2 <strchr+0x20>
    if (*s == c)
    549e:	00f58763          	beq	a1,a5,54ac <strchr+0x1a>
  for (; *s; s++)
    54a2:	0505                	addi	a0,a0,1
    54a4:	00054783          	lbu	a5,0(a0)
    54a8:	fbfd                	bnez	a5,549e <strchr+0xc>
      return (char *)s;
  return 0;
    54aa:	4501                	li	a0,0
}
    54ac:	6422                	ld	s0,8(sp)
    54ae:	0141                	addi	sp,sp,16
    54b0:	8082                	ret
  return 0;
    54b2:	4501                	li	a0,0
    54b4:	bfe5                	j	54ac <strchr+0x1a>

00000000000054b6 <gets>:

char *
gets(char *buf, int max)
{
    54b6:	711d                	addi	sp,sp,-96
    54b8:	ec86                	sd	ra,88(sp)
    54ba:	e8a2                	sd	s0,80(sp)
    54bc:	e4a6                	sd	s1,72(sp)
    54be:	e0ca                	sd	s2,64(sp)
    54c0:	fc4e                	sd	s3,56(sp)
    54c2:	f852                	sd	s4,48(sp)
    54c4:	f456                	sd	s5,40(sp)
    54c6:	f05a                	sd	s6,32(sp)
    54c8:	ec5e                	sd	s7,24(sp)
    54ca:	1080                	addi	s0,sp,96
    54cc:	8baa                	mv	s7,a0
    54ce:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
    54d0:	892a                	mv	s2,a0
    54d2:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if (cc < 1)
      break;
    buf[i++] = c;
    if (c == '\n' || c == '\r')
    54d4:	4aa9                	li	s5,10
    54d6:	4b35                	li	s6,13
  for (i = 0; i + 1 < max;) {
    54d8:	89a6                	mv	s3,s1
    54da:	2485                	addiw	s1,s1,1
    54dc:	0344d663          	bge	s1,s4,5508 <gets+0x52>
    cc = read(0, &c, 1);
    54e0:	4605                	li	a2,1
    54e2:	faf40593          	addi	a1,s0,-81
    54e6:	4501                	li	a0,0
    54e8:	1b2000ef          	jal	569a <read>
    if (cc < 1)
    54ec:	00a05e63          	blez	a0,5508 <gets+0x52>
    buf[i++] = c;
    54f0:	faf44783          	lbu	a5,-81(s0)
    54f4:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
    54f8:	01578763          	beq	a5,s5,5506 <gets+0x50>
    54fc:	0905                	addi	s2,s2,1
    54fe:	fd679de3          	bne	a5,s6,54d8 <gets+0x22>
    buf[i++] = c;
    5502:	89a6                	mv	s3,s1
    5504:	a011                	j	5508 <gets+0x52>
    5506:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
    5508:	99de                	add	s3,s3,s7
    550a:	00098023          	sb	zero,0(s3)
  return buf;
}
    550e:	855e                	mv	a0,s7
    5510:	60e6                	ld	ra,88(sp)
    5512:	6446                	ld	s0,80(sp)
    5514:	64a6                	ld	s1,72(sp)
    5516:	6906                	ld	s2,64(sp)
    5518:	79e2                	ld	s3,56(sp)
    551a:	7a42                	ld	s4,48(sp)
    551c:	7aa2                	ld	s5,40(sp)
    551e:	7b02                	ld	s6,32(sp)
    5520:	6be2                	ld	s7,24(sp)
    5522:	6125                	addi	sp,sp,96
    5524:	8082                	ret

0000000000005526 <stat>:

int
stat(const char *n, struct stat *st)
{
    5526:	1101                	addi	sp,sp,-32
    5528:	ec06                	sd	ra,24(sp)
    552a:	e822                	sd	s0,16(sp)
    552c:	e04a                	sd	s2,0(sp)
    552e:	1000                	addi	s0,sp,32
    5530:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    5532:	4581                	li	a1,0
    5534:	18e000ef          	jal	56c2 <open>
  if (fd < 0)
    5538:	02054263          	bltz	a0,555c <stat+0x36>
    553c:	e426                	sd	s1,8(sp)
    553e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
    5540:	85ca                	mv	a1,s2
    5542:	198000ef          	jal	56da <fstat>
    5546:	892a                	mv	s2,a0
  close(fd);
    5548:	8526                	mv	a0,s1
    554a:	160000ef          	jal	56aa <close>
  return r;
    554e:	64a2                	ld	s1,8(sp)
}
    5550:	854a                	mv	a0,s2
    5552:	60e2                	ld	ra,24(sp)
    5554:	6442                	ld	s0,16(sp)
    5556:	6902                	ld	s2,0(sp)
    5558:	6105                	addi	sp,sp,32
    555a:	8082                	ret
    return -1;
    555c:	597d                	li	s2,-1
    555e:	bfcd                	j	5550 <stat+0x2a>

0000000000005560 <atoi>:

int
atoi(const char *s)
{
    5560:	1141                	addi	sp,sp,-16
    5562:	e422                	sd	s0,8(sp)
    5564:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
    5566:	00054683          	lbu	a3,0(a0)
    556a:	fd06879b          	addiw	a5,a3,-48
    556e:	0ff7f793          	zext.b	a5,a5
    5572:	4625                	li	a2,9
    5574:	02f66863          	bltu	a2,a5,55a4 <atoi+0x44>
    5578:	872a                	mv	a4,a0
  n = 0;
    557a:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
    557c:	0705                	addi	a4,a4,1 # 1000001 <base+0xfef2f9>
    557e:	0025179b          	slliw	a5,a0,0x2
    5582:	9fa9                	addw	a5,a5,a0
    5584:	0017979b          	slliw	a5,a5,0x1
    5588:	9fb5                	addw	a5,a5,a3
    558a:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
    558e:	00074683          	lbu	a3,0(a4)
    5592:	fd06879b          	addiw	a5,a3,-48
    5596:	0ff7f793          	zext.b	a5,a5
    559a:	fef671e3          	bgeu	a2,a5,557c <atoi+0x1c>
  return n;
}
    559e:	6422                	ld	s0,8(sp)
    55a0:	0141                	addi	sp,sp,16
    55a2:	8082                	ret
  n = 0;
    55a4:	4501                	li	a0,0
    55a6:	bfe5                	j	559e <atoi+0x3e>

00000000000055a8 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
    55a8:	1141                	addi	sp,sp,-16
    55aa:	e422                	sd	s0,8(sp)
    55ac:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    55ae:	02b57463          	bgeu	a0,a1,55d6 <memmove+0x2e>
    while (n-- > 0)
    55b2:	00c05f63          	blez	a2,55d0 <memmove+0x28>
    55b6:	1602                	slli	a2,a2,0x20
    55b8:	9201                	srli	a2,a2,0x20
    55ba:	00c507b3          	add	a5,a0,a2
  dst = vdst;
    55be:	872a                	mv	a4,a0
      *dst++ = *src++;
    55c0:	0585                	addi	a1,a1,1
    55c2:	0705                	addi	a4,a4,1
    55c4:	fff5c683          	lbu	a3,-1(a1)
    55c8:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    55cc:	fef71ae3          	bne	a4,a5,55c0 <memmove+0x18>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
    55d0:	6422                	ld	s0,8(sp)
    55d2:	0141                	addi	sp,sp,16
    55d4:	8082                	ret
    dst += n;
    55d6:	00c50733          	add	a4,a0,a2
    src += n;
    55da:	95b2                	add	a1,a1,a2
    while (n-- > 0)
    55dc:	fec05ae3          	blez	a2,55d0 <memmove+0x28>
    55e0:	fff6079b          	addiw	a5,a2,-1
    55e4:	1782                	slli	a5,a5,0x20
    55e6:	9381                	srli	a5,a5,0x20
    55e8:	fff7c793          	not	a5,a5
    55ec:	97ba                	add	a5,a5,a4
      *--dst = *--src;
    55ee:	15fd                	addi	a1,a1,-1
    55f0:	177d                	addi	a4,a4,-1
    55f2:	0005c683          	lbu	a3,0(a1)
    55f6:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
    55fa:	fee79ae3          	bne	a5,a4,55ee <memmove+0x46>
    55fe:	bfc9                	j	55d0 <memmove+0x28>

0000000000005600 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
    5600:	1141                	addi	sp,sp,-16
    5602:	e422                	sd	s0,8(sp)
    5604:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    5606:	ca05                	beqz	a2,5636 <memcmp+0x36>
    5608:	fff6069b          	addiw	a3,a2,-1
    560c:	1682                	slli	a3,a3,0x20
    560e:	9281                	srli	a3,a3,0x20
    5610:	0685                	addi	a3,a3,1
    5612:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
    5614:	00054783          	lbu	a5,0(a0)
    5618:	0005c703          	lbu	a4,0(a1)
    561c:	00e79863          	bne	a5,a4,562c <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
    5620:	0505                	addi	a0,a0,1
    p2++;
    5622:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    5624:	fed518e3          	bne	a0,a3,5614 <memcmp+0x14>
  }
  return 0;
    5628:	4501                	li	a0,0
    562a:	a019                	j	5630 <memcmp+0x30>
      return *p1 - *p2;
    562c:	40e7853b          	subw	a0,a5,a4
}
    5630:	6422                	ld	s0,8(sp)
    5632:	0141                	addi	sp,sp,16
    5634:	8082                	ret
  return 0;
    5636:	4501                	li	a0,0
    5638:	bfe5                	j	5630 <memcmp+0x30>

000000000000563a <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
    563a:	1141                	addi	sp,sp,-16
    563c:	e406                	sd	ra,8(sp)
    563e:	e022                	sd	s0,0(sp)
    5640:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    5642:	f67ff0ef          	jal	55a8 <memmove>
}
    5646:	60a2                	ld	ra,8(sp)
    5648:	6402                	ld	s0,0(sp)
    564a:	0141                	addi	sp,sp,16
    564c:	8082                	ret

000000000000564e <sbrk>:

char *
sbrk(int n)
{
    564e:	1141                	addi	sp,sp,-16
    5650:	e406                	sd	ra,8(sp)
    5652:	e022                	sd	s0,0(sp)
    5654:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
    5656:	4585                	li	a1,1
    5658:	0b2000ef          	jal	570a <sys_sbrk>
}
    565c:	60a2                	ld	ra,8(sp)
    565e:	6402                	ld	s0,0(sp)
    5660:	0141                	addi	sp,sp,16
    5662:	8082                	ret

0000000000005664 <sbrklazy>:

char *
sbrklazy(int n)
{
    5664:	1141                	addi	sp,sp,-16
    5666:	e406                	sd	ra,8(sp)
    5668:	e022                	sd	s0,0(sp)
    566a:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
    566c:	4589                	li	a1,2
    566e:	09c000ef          	jal	570a <sys_sbrk>
}
    5672:	60a2                	ld	ra,8(sp)
    5674:	6402                	ld	s0,0(sp)
    5676:	0141                	addi	sp,sp,16
    5678:	8082                	ret

000000000000567a <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
    567a:	4885                	li	a7,1
 ecall
    567c:	00000073          	ecall
 ret
    5680:	8082                	ret

0000000000005682 <exit>:
.global exit
exit:
 li a7, SYS_exit
    5682:	4889                	li	a7,2
 ecall
    5684:	00000073          	ecall
 ret
    5688:	8082                	ret

000000000000568a <wait>:
.global wait
wait:
 li a7, SYS_wait
    568a:	488d                	li	a7,3
 ecall
    568c:	00000073          	ecall
 ret
    5690:	8082                	ret

0000000000005692 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
    5692:	4891                	li	a7,4
 ecall
    5694:	00000073          	ecall
 ret
    5698:	8082                	ret

000000000000569a <read>:
.global read
read:
 li a7, SYS_read
    569a:	4895                	li	a7,5
 ecall
    569c:	00000073          	ecall
 ret
    56a0:	8082                	ret

00000000000056a2 <write>:
.global write
write:
 li a7, SYS_write
    56a2:	48c1                	li	a7,16
 ecall
    56a4:	00000073          	ecall
 ret
    56a8:	8082                	ret

00000000000056aa <close>:
.global close
close:
 li a7, SYS_close
    56aa:	48d5                	li	a7,21
 ecall
    56ac:	00000073          	ecall
 ret
    56b0:	8082                	ret

00000000000056b2 <kill>:
.global kill
kill:
 li a7, SYS_kill
    56b2:	4899                	li	a7,6
 ecall
    56b4:	00000073          	ecall
 ret
    56b8:	8082                	ret

00000000000056ba <exec>:
.global exec
exec:
 li a7, SYS_exec
    56ba:	489d                	li	a7,7
 ecall
    56bc:	00000073          	ecall
 ret
    56c0:	8082                	ret

00000000000056c2 <open>:
.global open
open:
 li a7, SYS_open
    56c2:	48bd                	li	a7,15
 ecall
    56c4:	00000073          	ecall
 ret
    56c8:	8082                	ret

00000000000056ca <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
    56ca:	48c5                	li	a7,17
 ecall
    56cc:	00000073          	ecall
 ret
    56d0:	8082                	ret

00000000000056d2 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
    56d2:	48c9                	li	a7,18
 ecall
    56d4:	00000073          	ecall
 ret
    56d8:	8082                	ret

00000000000056da <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
    56da:	48a1                	li	a7,8
 ecall
    56dc:	00000073          	ecall
 ret
    56e0:	8082                	ret

00000000000056e2 <link>:
.global link
link:
 li a7, SYS_link
    56e2:	48cd                	li	a7,19
 ecall
    56e4:	00000073          	ecall
 ret
    56e8:	8082                	ret

00000000000056ea <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
    56ea:	48d1                	li	a7,20
 ecall
    56ec:	00000073          	ecall
 ret
    56f0:	8082                	ret

00000000000056f2 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
    56f2:	48a5                	li	a7,9
 ecall
    56f4:	00000073          	ecall
 ret
    56f8:	8082                	ret

00000000000056fa <dup>:
.global dup
dup:
 li a7, SYS_dup
    56fa:	48a9                	li	a7,10
 ecall
    56fc:	00000073          	ecall
 ret
    5700:	8082                	ret

0000000000005702 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
    5702:	48ad                	li	a7,11
 ecall
    5704:	00000073          	ecall
 ret
    5708:	8082                	ret

000000000000570a <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
    570a:	48b1                	li	a7,12
 ecall
    570c:	00000073          	ecall
 ret
    5710:	8082                	ret

0000000000005712 <pause>:
.global pause
pause:
 li a7, SYS_pause
    5712:	48b5                	li	a7,13
 ecall
    5714:	00000073          	ecall
 ret
    5718:	8082                	ret

000000000000571a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
    571a:	48b9                	li	a7,14
 ecall
    571c:	00000073          	ecall
 ret
    5720:	8082                	ret

0000000000005722 <sync>:
.global sync
sync:
 li a7, SYS_sync
    5722:	48d9                	li	a7,22
 ecall
    5724:	00000073          	ecall
 ret
    5728:	8082                	ret

000000000000572a <kallocstats>:
.global kallocstats
kallocstats:
 li a7, SYS_kallocstats
    572a:	48dd                	li	a7,23
 ecall
    572c:	00000073          	ecall
 ret
    5730:	8082                	ret

0000000000005732 <vtop>:
.global vtop
vtop:
 li a7, SYS_vtop
    5732:	48e1                	li	a7,24
 ecall
    5734:	00000073          	ecall
 ret
    5738:	8082                	ret

000000000000573a <pageinfo>:
.global pageinfo
pageinfo:
 li a7, SYS_pageinfo
    573a:	48e5                	li	a7,25
 ecall
    573c:	00000073          	ecall
 ret
    5740:	8082                	ret

0000000000005742 <setreadonly>:
.global setreadonly
setreadonly:
 li a7, SYS_setreadonly
    5742:	48e9                	li	a7,26
 ecall
    5744:	00000073          	ecall
 ret
    5748:	8082                	ret

000000000000574a <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
    574a:	1101                	addi	sp,sp,-32
    574c:	ec06                	sd	ra,24(sp)
    574e:	e822                	sd	s0,16(sp)
    5750:	1000                	addi	s0,sp,32
    5752:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
    5756:	4605                	li	a2,1
    5758:	fef40593          	addi	a1,s0,-17
    575c:	f47ff0ef          	jal	56a2 <write>
}
    5760:	60e2                	ld	ra,24(sp)
    5762:	6442                	ld	s0,16(sp)
    5764:	6105                	addi	sp,sp,32
    5766:	8082                	ret

0000000000005768 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
    5768:	715d                	addi	sp,sp,-80
    576a:	e486                	sd	ra,72(sp)
    576c:	e0a2                	sd	s0,64(sp)
    576e:	f84a                	sd	s2,48(sp)
    5770:	0880                	addi	s0,sp,80
    5772:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
    5774:	c299                	beqz	a3,577a <printint+0x12>
    5776:	0805c363          	bltz	a1,57fc <printint+0x94>
  neg = 0;
    577a:	4881                	li	a7,0
    577c:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
    5780:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    5782:	00003517          	auipc	a0,0x3
    5786:	f9650513          	addi	a0,a0,-106 # 8718 <digits>
    578a:	883e                	mv	a6,a5
    578c:	2785                	addiw	a5,a5,1
    578e:	02c5f733          	remu	a4,a1,a2
    5792:	972a                	add	a4,a4,a0
    5794:	00074703          	lbu	a4,0(a4)
    5798:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
    579c:	872e                	mv	a4,a1
    579e:	02c5d5b3          	divu	a1,a1,a2
    57a2:	0685                	addi	a3,a3,1
    57a4:	fec773e3          	bgeu	a4,a2,578a <printint+0x22>
  if (neg)
    57a8:	00088b63          	beqz	a7,57be <printint+0x56>
    buf[i++] = '-';
    57ac:	fd078793          	addi	a5,a5,-48
    57b0:	97a2                	add	a5,a5,s0
    57b2:	02d00713          	li	a4,45
    57b6:	fee78423          	sb	a4,-24(a5)
    57ba:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
    57be:	02f05a63          	blez	a5,57f2 <printint+0x8a>
    57c2:	fc26                	sd	s1,56(sp)
    57c4:	f44e                	sd	s3,40(sp)
    57c6:	fb840713          	addi	a4,s0,-72
    57ca:	00f704b3          	add	s1,a4,a5
    57ce:	fff70993          	addi	s3,a4,-1
    57d2:	99be                	add	s3,s3,a5
    57d4:	37fd                	addiw	a5,a5,-1
    57d6:	1782                	slli	a5,a5,0x20
    57d8:	9381                	srli	a5,a5,0x20
    57da:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
    57de:	fff4c583          	lbu	a1,-1(s1)
    57e2:	854a                	mv	a0,s2
    57e4:	f67ff0ef          	jal	574a <putc>
  while (--i >= 0)
    57e8:	14fd                	addi	s1,s1,-1
    57ea:	ff349ae3          	bne	s1,s3,57de <printint+0x76>
    57ee:	74e2                	ld	s1,56(sp)
    57f0:	79a2                	ld	s3,40(sp)
}
    57f2:	60a6                	ld	ra,72(sp)
    57f4:	6406                	ld	s0,64(sp)
    57f6:	7942                	ld	s2,48(sp)
    57f8:	6161                	addi	sp,sp,80
    57fa:	8082                	ret
    x = -xx;
    57fc:	40b005b3          	neg	a1,a1
    neg = 1;
    5800:	4885                	li	a7,1
    x = -xx;
    5802:	bfad                	j	577c <printint+0x14>

0000000000005804 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
    5804:	711d                	addi	sp,sp,-96
    5806:	ec86                	sd	ra,88(sp)
    5808:	e8a2                	sd	s0,80(sp)
    580a:	e0ca                	sd	s2,64(sp)
    580c:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
    580e:	0005c903          	lbu	s2,0(a1)
    5812:	28090663          	beqz	s2,5a9e <vprintf+0x29a>
    5816:	e4a6                	sd	s1,72(sp)
    5818:	fc4e                	sd	s3,56(sp)
    581a:	f852                	sd	s4,48(sp)
    581c:	f456                	sd	s5,40(sp)
    581e:	f05a                	sd	s6,32(sp)
    5820:	ec5e                	sd	s7,24(sp)
    5822:	e862                	sd	s8,16(sp)
    5824:	e466                	sd	s9,8(sp)
    5826:	8b2a                	mv	s6,a0
    5828:	8a2e                	mv	s4,a1
    582a:	8bb2                	mv	s7,a2
  state = 0;
    582c:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
    582e:	4481                	li	s1,0
    5830:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
    5832:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
    5836:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
    583a:	06c00c93          	li	s9,108
    583e:	a005                	j	585e <vprintf+0x5a>
        putc(fd, c0);
    5840:	85ca                	mv	a1,s2
    5842:	855a                	mv	a0,s6
    5844:	f07ff0ef          	jal	574a <putc>
    5848:	a019                	j	584e <vprintf+0x4a>
    } else if (state == '%') {
    584a:	03598263          	beq	s3,s5,586e <vprintf+0x6a>
  for (i = 0; fmt[i]; i++) {
    584e:	2485                	addiw	s1,s1,1
    5850:	8726                	mv	a4,s1
    5852:	009a07b3          	add	a5,s4,s1
    5856:	0007c903          	lbu	s2,0(a5)
    585a:	22090a63          	beqz	s2,5a8e <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
    585e:	0009079b          	sext.w	a5,s2
    if (state == 0) {
    5862:	fe0994e3          	bnez	s3,584a <vprintf+0x46>
      if (c0 == '%') {
    5866:	fd579de3          	bne	a5,s5,5840 <vprintf+0x3c>
        state = '%';
    586a:	89be                	mv	s3,a5
    586c:	b7cd                	j	584e <vprintf+0x4a>
        c1 = fmt[i + 1] & 0xff;
    586e:	00ea06b3          	add	a3,s4,a4
    5872:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
    5876:	8636                	mv	a2,a3
      if (c1)
    5878:	c681                	beqz	a3,5880 <vprintf+0x7c>
        c2 = fmt[i + 2] & 0xff;
    587a:	9752                	add	a4,a4,s4
    587c:	00274603          	lbu	a2,2(a4)
      if (c0 == 'd') {
    5880:	05878363          	beq	a5,s8,58c6 <vprintf+0xc2>
      } else if (c0 == 'l' && c1 == 'd') {
    5884:	05978d63          	beq	a5,s9,58de <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
    5888:	07500713          	li	a4,117
    588c:	0ee78763          	beq	a5,a4,597a <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
    5890:	07800713          	li	a4,120
    5894:	12e78963          	beq	a5,a4,59c6 <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
    5898:	07000713          	li	a4,112
    589c:	14e78e63          	beq	a5,a4,59f8 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
    58a0:	06300713          	li	a4,99
    58a4:	18e78e63          	beq	a5,a4,5a40 <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
    58a8:	07300713          	li	a4,115
    58ac:	1ae78463          	beq	a5,a4,5a54 <vprintf+0x250>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
    58b0:	02500713          	li	a4,37
    58b4:	04e79563          	bne	a5,a4,58fe <vprintf+0xfa>
        putc(fd, '%');
    58b8:	02500593          	li	a1,37
    58bc:	855a                	mv	a0,s6
    58be:	e8dff0ef          	jal	574a <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
    58c2:	4981                	li	s3,0
    58c4:	b769                	j	584e <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
    58c6:	008b8913          	addi	s2,s7,8
    58ca:	4685                	li	a3,1
    58cc:	4629                	li	a2,10
    58ce:	000ba583          	lw	a1,0(s7)
    58d2:	855a                	mv	a0,s6
    58d4:	e95ff0ef          	jal	5768 <printint>
    58d8:	8bca                	mv	s7,s2
      state = 0;
    58da:	4981                	li	s3,0
    58dc:	bf8d                	j	584e <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'd') {
    58de:	06400793          	li	a5,100
    58e2:	02f68963          	beq	a3,a5,5914 <vprintf+0x110>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    58e6:	06c00793          	li	a5,108
    58ea:	04f68263          	beq	a3,a5,592e <vprintf+0x12a>
      } else if (c0 == 'l' && c1 == 'u') {
    58ee:	07500793          	li	a5,117
    58f2:	0af68063          	beq	a3,a5,5992 <vprintf+0x18e>
      } else if (c0 == 'l' && c1 == 'x') {
    58f6:	07800793          	li	a5,120
    58fa:	0ef68263          	beq	a3,a5,59de <vprintf+0x1da>
        putc(fd, '%');
    58fe:	02500593          	li	a1,37
    5902:	855a                	mv	a0,s6
    5904:	e47ff0ef          	jal	574a <putc>
        putc(fd, c0);
    5908:	85ca                	mv	a1,s2
    590a:	855a                	mv	a0,s6
    590c:	e3fff0ef          	jal	574a <putc>
      state = 0;
    5910:	4981                	li	s3,0
    5912:	bf35                	j	584e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
    5914:	008b8913          	addi	s2,s7,8
    5918:	4685                	li	a3,1
    591a:	4629                	li	a2,10
    591c:	000bb583          	ld	a1,0(s7)
    5920:	855a                	mv	a0,s6
    5922:	e47ff0ef          	jal	5768 <printint>
        i += 1;
    5926:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
    5928:	8bca                	mv	s7,s2
      state = 0;
    592a:	4981                	li	s3,0
        i += 1;
    592c:	b70d                	j	584e <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    592e:	06400793          	li	a5,100
    5932:	02f60763          	beq	a2,a5,5960 <vprintf+0x15c>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    5936:	07500793          	li	a5,117
    593a:	06f60963          	beq	a2,a5,59ac <vprintf+0x1a8>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    593e:	07800793          	li	a5,120
    5942:	faf61ee3          	bne	a2,a5,58fe <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
    5946:	008b8913          	addi	s2,s7,8
    594a:	4681                	li	a3,0
    594c:	4641                	li	a2,16
    594e:	000bb583          	ld	a1,0(s7)
    5952:	855a                	mv	a0,s6
    5954:	e15ff0ef          	jal	5768 <printint>
        i += 2;
    5958:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
    595a:	8bca                	mv	s7,s2
      state = 0;
    595c:	4981                	li	s3,0
        i += 2;
    595e:	bdc5                	j	584e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
    5960:	008b8913          	addi	s2,s7,8
    5964:	4685                	li	a3,1
    5966:	4629                	li	a2,10
    5968:	000bb583          	ld	a1,0(s7)
    596c:	855a                	mv	a0,s6
    596e:	dfbff0ef          	jal	5768 <printint>
        i += 2;
    5972:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
    5974:	8bca                	mv	s7,s2
      state = 0;
    5976:	4981                	li	s3,0
        i += 2;
    5978:	bdd9                	j	584e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
    597a:	008b8913          	addi	s2,s7,8
    597e:	4681                	li	a3,0
    5980:	4629                	li	a2,10
    5982:	000be583          	lwu	a1,0(s7)
    5986:	855a                	mv	a0,s6
    5988:	de1ff0ef          	jal	5768 <printint>
    598c:	8bca                	mv	s7,s2
      state = 0;
    598e:	4981                	li	s3,0
    5990:	bd7d                	j	584e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
    5992:	008b8913          	addi	s2,s7,8
    5996:	4681                	li	a3,0
    5998:	4629                	li	a2,10
    599a:	000bb583          	ld	a1,0(s7)
    599e:	855a                	mv	a0,s6
    59a0:	dc9ff0ef          	jal	5768 <printint>
        i += 1;
    59a4:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
    59a6:	8bca                	mv	s7,s2
      state = 0;
    59a8:	4981                	li	s3,0
        i += 1;
    59aa:	b555                	j	584e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
    59ac:	008b8913          	addi	s2,s7,8
    59b0:	4681                	li	a3,0
    59b2:	4629                	li	a2,10
    59b4:	000bb583          	ld	a1,0(s7)
    59b8:	855a                	mv	a0,s6
    59ba:	dafff0ef          	jal	5768 <printint>
        i += 2;
    59be:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
    59c0:	8bca                	mv	s7,s2
      state = 0;
    59c2:	4981                	li	s3,0
        i += 2;
    59c4:	b569                	j	584e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
    59c6:	008b8913          	addi	s2,s7,8
    59ca:	4681                	li	a3,0
    59cc:	4641                	li	a2,16
    59ce:	000be583          	lwu	a1,0(s7)
    59d2:	855a                	mv	a0,s6
    59d4:	d95ff0ef          	jal	5768 <printint>
    59d8:	8bca                	mv	s7,s2
      state = 0;
    59da:	4981                	li	s3,0
    59dc:	bd8d                	j	584e <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
    59de:	008b8913          	addi	s2,s7,8
    59e2:	4681                	li	a3,0
    59e4:	4641                	li	a2,16
    59e6:	000bb583          	ld	a1,0(s7)
    59ea:	855a                	mv	a0,s6
    59ec:	d7dff0ef          	jal	5768 <printint>
        i += 1;
    59f0:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
    59f2:	8bca                	mv	s7,s2
      state = 0;
    59f4:	4981                	li	s3,0
        i += 1;
    59f6:	bda1                	j	584e <vprintf+0x4a>
    59f8:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
    59fa:	008b8d13          	addi	s10,s7,8
    59fe:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
    5a02:	03000593          	li	a1,48
    5a06:	855a                	mv	a0,s6
    5a08:	d43ff0ef          	jal	574a <putc>
  putc(fd, 'x');
    5a0c:	07800593          	li	a1,120
    5a10:	855a                	mv	a0,s6
    5a12:	d39ff0ef          	jal	574a <putc>
    5a16:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    5a18:	00003b97          	auipc	s7,0x3
    5a1c:	d00b8b93          	addi	s7,s7,-768 # 8718 <digits>
    5a20:	03c9d793          	srli	a5,s3,0x3c
    5a24:	97de                	add	a5,a5,s7
    5a26:	0007c583          	lbu	a1,0(a5)
    5a2a:	855a                	mv	a0,s6
    5a2c:	d1fff0ef          	jal	574a <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    5a30:	0992                	slli	s3,s3,0x4
    5a32:	397d                	addiw	s2,s2,-1
    5a34:	fe0916e3          	bnez	s2,5a20 <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
    5a38:	8bea                	mv	s7,s10
      state = 0;
    5a3a:	4981                	li	s3,0
    5a3c:	6d02                	ld	s10,0(sp)
    5a3e:	bd01                	j	584e <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
    5a40:	008b8913          	addi	s2,s7,8
    5a44:	000bc583          	lbu	a1,0(s7)
    5a48:	855a                	mv	a0,s6
    5a4a:	d01ff0ef          	jal	574a <putc>
    5a4e:	8bca                	mv	s7,s2
      state = 0;
    5a50:	4981                	li	s3,0
    5a52:	bbf5                	j	584e <vprintf+0x4a>
        if ((s = va_arg(ap, char *)) == 0)
    5a54:	008b8993          	addi	s3,s7,8
    5a58:	000bb903          	ld	s2,0(s7)
    5a5c:	00090f63          	beqz	s2,5a7a <vprintf+0x276>
        for (; *s; s++)
    5a60:	00094583          	lbu	a1,0(s2)
    5a64:	c195                	beqz	a1,5a88 <vprintf+0x284>
          putc(fd, *s);
    5a66:	855a                	mv	a0,s6
    5a68:	ce3ff0ef          	jal	574a <putc>
        for (; *s; s++)
    5a6c:	0905                	addi	s2,s2,1
    5a6e:	00094583          	lbu	a1,0(s2)
    5a72:	f9f5                	bnez	a1,5a66 <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
    5a74:	8bce                	mv	s7,s3
      state = 0;
    5a76:	4981                	li	s3,0
    5a78:	bbd9                	j	584e <vprintf+0x4a>
          s = "(null)";
    5a7a:	00003917          	auipc	s2,0x3
    5a7e:	bee90913          	addi	s2,s2,-1042 # 8668 <malloc+0x2ae2>
        for (; *s; s++)
    5a82:	02800593          	li	a1,40
    5a86:	b7c5                	j	5a66 <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
    5a88:	8bce                	mv	s7,s3
      state = 0;
    5a8a:	4981                	li	s3,0
    5a8c:	b3c9                	j	584e <vprintf+0x4a>
    5a8e:	64a6                	ld	s1,72(sp)
    5a90:	79e2                	ld	s3,56(sp)
    5a92:	7a42                	ld	s4,48(sp)
    5a94:	7aa2                	ld	s5,40(sp)
    5a96:	7b02                	ld	s6,32(sp)
    5a98:	6be2                	ld	s7,24(sp)
    5a9a:	6c42                	ld	s8,16(sp)
    5a9c:	6ca2                	ld	s9,8(sp)
    }
  }
}
    5a9e:	60e6                	ld	ra,88(sp)
    5aa0:	6446                	ld	s0,80(sp)
    5aa2:	6906                	ld	s2,64(sp)
    5aa4:	6125                	addi	sp,sp,96
    5aa6:	8082                	ret

0000000000005aa8 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    5aa8:	715d                	addi	sp,sp,-80
    5aaa:	ec06                	sd	ra,24(sp)
    5aac:	e822                	sd	s0,16(sp)
    5aae:	1000                	addi	s0,sp,32
    5ab0:	e010                	sd	a2,0(s0)
    5ab2:	e414                	sd	a3,8(s0)
    5ab4:	e818                	sd	a4,16(s0)
    5ab6:	ec1c                	sd	a5,24(s0)
    5ab8:	03043023          	sd	a6,32(s0)
    5abc:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    5ac0:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    5ac4:	8622                	mv	a2,s0
    5ac6:	d3fff0ef          	jal	5804 <vprintf>
}
    5aca:	60e2                	ld	ra,24(sp)
    5acc:	6442                	ld	s0,16(sp)
    5ace:	6161                	addi	sp,sp,80
    5ad0:	8082                	ret

0000000000005ad2 <printf>:

void
printf(const char *fmt, ...)
{
    5ad2:	711d                	addi	sp,sp,-96
    5ad4:	ec06                	sd	ra,24(sp)
    5ad6:	e822                	sd	s0,16(sp)
    5ad8:	1000                	addi	s0,sp,32
    5ada:	e40c                	sd	a1,8(s0)
    5adc:	e810                	sd	a2,16(s0)
    5ade:	ec14                	sd	a3,24(s0)
    5ae0:	f018                	sd	a4,32(s0)
    5ae2:	f41c                	sd	a5,40(s0)
    5ae4:	03043823          	sd	a6,48(s0)
    5ae8:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    5aec:	00840613          	addi	a2,s0,8
    5af0:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    5af4:	85aa                	mv	a1,a0
    5af6:	4505                	li	a0,1
    5af8:	d0dff0ef          	jal	5804 <vprintf>
}
    5afc:	60e2                	ld	ra,24(sp)
    5afe:	6442                	ld	s0,16(sp)
    5b00:	6125                	addi	sp,sp,96
    5b02:	8082                	ret

0000000000005b04 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    5b04:	1141                	addi	sp,sp,-16
    5b06:	e422                	sd	s0,8(sp)
    5b08:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
    5b0a:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    5b0e:	00005797          	auipc	a5,0x5
    5b12:	9d27b783          	ld	a5,-1582(a5) # a4e0 <freep>
    5b16:	a02d                	j	5b40 <free+0x3c>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
    bp->s.size += p->s.ptr->s.size;
    5b18:	4618                	lw	a4,8(a2)
    5b1a:	9f2d                	addw	a4,a4,a1
    5b1c:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    5b20:	6398                	ld	a4,0(a5)
    5b22:	6310                	ld	a2,0(a4)
    5b24:	a83d                	j	5b62 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
    p->s.size += bp->s.size;
    5b26:	ff852703          	lw	a4,-8(a0)
    5b2a:	9f31                	addw	a4,a4,a2
    5b2c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    5b2e:	ff053683          	ld	a3,-16(a0)
    5b32:	a091                	j	5b76 <free+0x72>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    5b34:	6398                	ld	a4,0(a5)
    5b36:	00e7e463          	bltu	a5,a4,5b3e <free+0x3a>
    5b3a:	00e6ea63          	bltu	a3,a4,5b4e <free+0x4a>
{
    5b3e:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    5b40:	fed7fae3          	bgeu	a5,a3,5b34 <free+0x30>
    5b44:	6398                	ld	a4,0(a5)
    5b46:	00e6e463          	bltu	a3,a4,5b4e <free+0x4a>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    5b4a:	fee7eae3          	bltu	a5,a4,5b3e <free+0x3a>
  if (bp + bp->s.size == p->s.ptr) {
    5b4e:	ff852583          	lw	a1,-8(a0)
    5b52:	6390                	ld	a2,0(a5)
    5b54:	02059813          	slli	a6,a1,0x20
    5b58:	01c85713          	srli	a4,a6,0x1c
    5b5c:	9736                	add	a4,a4,a3
    5b5e:	fae60de3          	beq	a2,a4,5b18 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
    5b62:	fec53823          	sd	a2,-16(a0)
  if (p + p->s.size == bp) {
    5b66:	4790                	lw	a2,8(a5)
    5b68:	02061593          	slli	a1,a2,0x20
    5b6c:	01c5d713          	srli	a4,a1,0x1c
    5b70:	973e                	add	a4,a4,a5
    5b72:	fae68ae3          	beq	a3,a4,5b26 <free+0x22>
    p->s.ptr = bp->s.ptr;
    5b76:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    5b78:	00005717          	auipc	a4,0x5
    5b7c:	96f73423          	sd	a5,-1688(a4) # a4e0 <freep>
}
    5b80:	6422                	ld	s0,8(sp)
    5b82:	0141                	addi	sp,sp,16
    5b84:	8082                	ret

0000000000005b86 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
    5b86:	7139                	addi	sp,sp,-64
    5b88:	fc06                	sd	ra,56(sp)
    5b8a:	f822                	sd	s0,48(sp)
    5b8c:	f426                	sd	s1,40(sp)
    5b8e:	ec4e                	sd	s3,24(sp)
    5b90:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
    5b92:	02051493          	slli	s1,a0,0x20
    5b96:	9081                	srli	s1,s1,0x20
    5b98:	04bd                	addi	s1,s1,15
    5b9a:	8091                	srli	s1,s1,0x4
    5b9c:	0014899b          	addiw	s3,s1,1
    5ba0:	0485                	addi	s1,s1,1
  if ((prevp = freep) == 0) {
    5ba2:	00005517          	auipc	a0,0x5
    5ba6:	93e53503          	ld	a0,-1730(a0) # a4e0 <freep>
    5baa:	c915                	beqz	a0,5bde <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    5bac:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    5bae:	4798                	lw	a4,8(a5)
    5bb0:	08977a63          	bgeu	a4,s1,5c44 <malloc+0xbe>
    5bb4:	f04a                	sd	s2,32(sp)
    5bb6:	e852                	sd	s4,16(sp)
    5bb8:	e456                	sd	s5,8(sp)
    5bba:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
    5bbc:	8a4e                	mv	s4,s3
    5bbe:	0009871b          	sext.w	a4,s3
    5bc2:	6685                	lui	a3,0x1
    5bc4:	00d77363          	bgeu	a4,a3,5bca <malloc+0x44>
    5bc8:	6a05                	lui	s4,0x1
    5bca:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    5bce:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
    5bd2:	00005917          	auipc	s2,0x5
    5bd6:	90e90913          	addi	s2,s2,-1778 # a4e0 <freep>
  if (p == SBRK_ERROR)
    5bda:	5afd                	li	s5,-1
    5bdc:	a081                	j	5c1c <malloc+0x96>
    5bde:	f04a                	sd	s2,32(sp)
    5be0:	e852                	sd	s4,16(sp)
    5be2:	e456                	sd	s5,8(sp)
    5be4:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    5be6:	0000b797          	auipc	a5,0xb
    5bea:	12278793          	addi	a5,a5,290 # 10d08 <base>
    5bee:	00005717          	auipc	a4,0x5
    5bf2:	8ef73923          	sd	a5,-1806(a4) # a4e0 <freep>
    5bf6:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    5bf8:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
    5bfc:	b7c1                	j	5bbc <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
    5bfe:	6398                	ld	a4,0(a5)
    5c00:	e118                	sd	a4,0(a0)
    5c02:	a8a9                	j	5c5c <malloc+0xd6>
  hp->s.size = nu;
    5c04:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
    5c08:	0541                	addi	a0,a0,16
    5c0a:	efbff0ef          	jal	5b04 <free>
  return freep;
    5c0e:	00093503          	ld	a0,0(s2)
      if ((p = morecore(nunits)) == 0)
    5c12:	c12d                	beqz	a0,5c74 <malloc+0xee>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    5c14:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    5c16:	4798                	lw	a4,8(a5)
    5c18:	02977263          	bgeu	a4,s1,5c3c <malloc+0xb6>
    if (p == freep)
    5c1c:	00093703          	ld	a4,0(s2)
    5c20:	853e                	mv	a0,a5
    5c22:	fef719e3          	bne	a4,a5,5c14 <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
    5c26:	8552                	mv	a0,s4
    5c28:	a27ff0ef          	jal	564e <sbrk>
  if (p == SBRK_ERROR)
    5c2c:	fd551ce3          	bne	a0,s5,5c04 <malloc+0x7e>
        return 0;
    5c30:	4501                	li	a0,0
    5c32:	7902                	ld	s2,32(sp)
    5c34:	6a42                	ld	s4,16(sp)
    5c36:	6aa2                	ld	s5,8(sp)
    5c38:	6b02                	ld	s6,0(sp)
    5c3a:	a03d                	j	5c68 <malloc+0xe2>
    5c3c:	7902                	ld	s2,32(sp)
    5c3e:	6a42                	ld	s4,16(sp)
    5c40:	6aa2                	ld	s5,8(sp)
    5c42:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
    5c44:	fae48de3          	beq	s1,a4,5bfe <malloc+0x78>
        p->s.size -= nunits;
    5c48:	4137073b          	subw	a4,a4,s3
    5c4c:	c798                	sw	a4,8(a5)
        p += p->s.size;
    5c4e:	02071693          	slli	a3,a4,0x20
    5c52:	01c6d713          	srli	a4,a3,0x1c
    5c56:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    5c58:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    5c5c:	00005717          	auipc	a4,0x5
    5c60:	88a73223          	sd	a0,-1916(a4) # a4e0 <freep>
      return (void *)(p + 1);
    5c64:	01078513          	addi	a0,a5,16
  }
}
    5c68:	70e2                	ld	ra,56(sp)
    5c6a:	7442                	ld	s0,48(sp)
    5c6c:	74a2                	ld	s1,40(sp)
    5c6e:	69e2                	ld	s3,24(sp)
    5c70:	6121                	addi	sp,sp,64
    5c72:	8082                	ret
    5c74:	7902                	ld	s2,32(sp)
    5c76:	6a42                	ld	s4,16(sp)
    5c78:	6aa2                	ld	s5,8(sp)
    5c7a:	6b02                	ld	s6,0(sp)
    5c7c:	b7f5                	j	5c68 <malloc+0xe2>
