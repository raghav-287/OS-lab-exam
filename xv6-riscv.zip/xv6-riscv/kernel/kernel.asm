
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000a117          	auipc	sp,0xa
    80000004:	30813103          	ld	sp,776(sp) # 8000a308 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	03e000ef          	jal	80000054 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000022:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000026:	577d                	li	a4,-1
    80000028:	177e                	slli	a4,a4,0x3f
    8000002a:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002c:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000030:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000034:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    80000038:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003c:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000040:	000f4737          	lui	a4,0xf4
    80000044:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000048:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004a:	14d79073          	csrw	stimecmp,a5
}
    8000004e:	6422                	ld	s0,8(sp)
    80000050:	0141                	addi	sp,sp,16
    80000052:	8082                	ret

0000000080000054 <start>:
{
    80000054:	1141                	addi	sp,sp,-16
    80000056:	e406                	sd	ra,8(sp)
    80000058:	e022                	sd	s0,0(sp)
    8000005a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    8000005c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000060:	7779                	lui	a4,0xffffe
    80000062:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdb17f>
    80000066:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000068:	6705                	lui	a4,0x1
    8000006a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000006e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000070:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000074:	00001797          	auipc	a5,0x1
    80000078:	e6078793          	addi	a5,a5,-416 # 80000ed4 <main>
    8000007c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000080:	4781                	li	a5,0
    80000082:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    80000086:	67c1                	lui	a5,0x10
    80000088:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    8000008e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000092:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    80000096:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009a:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    8000009e:	57fd                	li	a5,-1
    800000a0:	83a9                	srli	a5,a5,0xa
    800000a2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000a6:	47bd                	li	a5,15
    800000a8:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000ac:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b0:	4705                	li	a4,1
    800000b2:	1776                	slli	a4,a4,0x3d
    800000b4:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000b6:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000ba:	f63ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000be:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c2:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c4:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c6:	30200073          	mret
}
    800000ca:	60a2                	ld	ra,8(sp)
    800000cc:	6402                	ld	s0,0(sp)
    800000ce:	0141                	addi	sp,sp,16
    800000d0:	8082                	ret

00000000800000d2 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d2:	7119                	addi	sp,sp,-128
    800000d4:	fc86                	sd	ra,120(sp)
    800000d6:	f8a2                	sd	s0,112(sp)
    800000d8:	f4a6                	sd	s1,104(sp)
    800000da:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000dc:	06c05a63          	blez	a2,80000150 <consolewrite+0x7e>
    800000e0:	f0ca                	sd	s2,96(sp)
    800000e2:	ecce                	sd	s3,88(sp)
    800000e4:	e8d2                	sd	s4,80(sp)
    800000e6:	e4d6                	sd	s5,72(sp)
    800000e8:	e0da                	sd	s6,64(sp)
    800000ea:	fc5e                	sd	s7,56(sp)
    800000ec:	f862                	sd	s8,48(sp)
    800000ee:	f466                	sd	s9,40(sp)
    800000f0:	8aaa                	mv	s5,a0
    800000f2:	8b2e                	mv	s6,a1
    800000f4:	8a32                	mv	s4,a2
  int i = 0;
    800000f6:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000f8:	02000c13          	li	s8,32
    800000fc:	02000c93          	li	s9,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000100:	5bfd                	li	s7,-1
    80000102:	a035                	j	8000012e <consolewrite+0x5c>
    if (nn > n - i)
    80000104:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000108:	86ce                	mv	a3,s3
    8000010a:	01648633          	add	a2,s1,s6
    8000010e:	85d6                	mv	a1,s5
    80000110:	f8040513          	addi	a0,s0,-128
    80000114:	294020ef          	jal	800023a8 <either_copyin>
    80000118:	03750e63          	beq	a0,s7,80000154 <consolewrite+0x82>
      break;
    uartwrite(buf, nn);
    8000011c:	85ce                	mv	a1,s3
    8000011e:	f8040513          	addi	a0,s0,-128
    80000122:	786000ef          	jal	800008a8 <uartwrite>
    i += nn;
    80000126:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    8000012a:	0144da63          	bge	s1,s4,8000013e <consolewrite+0x6c>
    if (nn > n - i)
    8000012e:	409a093b          	subw	s2,s4,s1
    80000132:	0009079b          	sext.w	a5,s2
    80000136:	fcfc57e3          	bge	s8,a5,80000104 <consolewrite+0x32>
    8000013a:	8966                	mv	s2,s9
    8000013c:	b7e1                	j	80000104 <consolewrite+0x32>
    8000013e:	7906                	ld	s2,96(sp)
    80000140:	69e6                	ld	s3,88(sp)
    80000142:	6a46                	ld	s4,80(sp)
    80000144:	6aa6                	ld	s5,72(sp)
    80000146:	6b06                	ld	s6,64(sp)
    80000148:	7be2                	ld	s7,56(sp)
    8000014a:	7c42                	ld	s8,48(sp)
    8000014c:	7ca2                	ld	s9,40(sp)
    8000014e:	a819                	j	80000164 <consolewrite+0x92>
  int i = 0;
    80000150:	4481                	li	s1,0
    80000152:	a809                	j	80000164 <consolewrite+0x92>
    80000154:	7906                	ld	s2,96(sp)
    80000156:	69e6                	ld	s3,88(sp)
    80000158:	6a46                	ld	s4,80(sp)
    8000015a:	6aa6                	ld	s5,72(sp)
    8000015c:	6b06                	ld	s6,64(sp)
    8000015e:	7be2                	ld	s7,56(sp)
    80000160:	7c42                	ld	s8,48(sp)
    80000162:	7ca2                	ld	s9,40(sp)
  }

  return i;
}
    80000164:	8526                	mv	a0,s1
    80000166:	70e6                	ld	ra,120(sp)
    80000168:	7446                	ld	s0,112(sp)
    8000016a:	74a6                	ld	s1,104(sp)
    8000016c:	6109                	addi	sp,sp,128
    8000016e:	8082                	ret

0000000080000170 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000170:	711d                	addi	sp,sp,-96
    80000172:	ec86                	sd	ra,88(sp)
    80000174:	e8a2                	sd	s0,80(sp)
    80000176:	e4a6                	sd	s1,72(sp)
    80000178:	e0ca                	sd	s2,64(sp)
    8000017a:	fc4e                	sd	s3,56(sp)
    8000017c:	f852                	sd	s4,48(sp)
    8000017e:	f456                	sd	s5,40(sp)
    80000180:	f05a                	sd	s6,32(sp)
    80000182:	1080                	addi	s0,sp,96
    80000184:	8aaa                	mv	s5,a0
    80000186:	8a2e                	mv	s4,a1
    80000188:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    8000018a:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018e:	00012517          	auipc	a0,0x12
    80000192:	1c250513          	addi	a0,a0,450 # 80012350 <cons>
    80000196:	2e1000ef          	jal	80000c76 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    8000019a:	00012497          	auipc	s1,0x12
    8000019e:	1b648493          	addi	s1,s1,438 # 80012350 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a2:	00012917          	auipc	s2,0x12
    800001a6:	24690913          	addi	s2,s2,582 # 800123e8 <cons+0x98>
  while (n > 0) {
    800001aa:	0d305463          	blez	s3,80000272 <consoleread+0x102>
    while (cons.r == cons.w) {
    800001ae:	0984a783          	lw	a5,152(s1)
    800001b2:	09c4a703          	lw	a4,156(s1)
    800001b6:	0af71963          	bne	a4,a5,80000268 <consoleread+0xf8>
      if (killed(myproc())) {
    800001ba:	00b010ef          	jal	800019c4 <myproc>
    800001be:	064020ef          	jal	80002222 <killed>
    800001c2:	e925                	bnez	a0,80000232 <consoleread+0xc2>
      sleep_prepare(&cons.r);
    800001c4:	854a                	mv	a0,s2
    800001c6:	603010ef          	jal	80001fc8 <sleep_prepare>
      release(&cons.lock);
    800001ca:	8526                	mv	a0,s1
    800001cc:	337000ef          	jal	80000d02 <release>
      sleep();
    800001d0:	635010ef          	jal	80002004 <sleep>
      acquire(&cons.lock);
    800001d4:	8526                	mv	a0,s1
    800001d6:	2a1000ef          	jal	80000c76 <acquire>
    while (cons.r == cons.w) {
    800001da:	0984a783          	lw	a5,152(s1)
    800001de:	09c4a703          	lw	a4,156(s1)
    800001e2:	fcf70ce3          	beq	a4,a5,800001ba <consoleread+0x4a>
    800001e6:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001e8:	00012717          	auipc	a4,0x12
    800001ec:	16870713          	addi	a4,a4,360 # 80012350 <cons>
    800001f0:	0017869b          	addiw	a3,a5,1
    800001f4:	08d72c23          	sw	a3,152(a4)
    800001f8:	07f7f693          	andi	a3,a5,127
    800001fc:	9736                	add	a4,a4,a3
    800001fe:	01874703          	lbu	a4,24(a4)
    80000202:	00070b9b          	sext.w	s7,a4

    if (c == C('D')) { // end-of-file
    80000206:	4691                	li	a3,4
    80000208:	04db8663          	beq	s7,a3,80000254 <consoleread+0xe4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    8000020c:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000210:	4685                	li	a3,1
    80000212:	faf40613          	addi	a2,s0,-81
    80000216:	85d2                	mv	a1,s4
    80000218:	8556                	mv	a0,s5
    8000021a:	142020ef          	jal	8000235c <either_copyout>
    8000021e:	57fd                	li	a5,-1
    80000220:	04f50863          	beq	a0,a5,80000270 <consoleread+0x100>
      break;

    dst++;
    80000224:	0a05                	addi	s4,s4,1
    --n;
    80000226:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    80000228:	47a9                	li	a5,10
    8000022a:	04fb8d63          	beq	s7,a5,80000284 <consoleread+0x114>
    8000022e:	6be2                	ld	s7,24(sp)
    80000230:	bfad                	j	800001aa <consoleread+0x3a>
        release(&cons.lock);
    80000232:	00012517          	auipc	a0,0x12
    80000236:	11e50513          	addi	a0,a0,286 # 80012350 <cons>
    8000023a:	2c9000ef          	jal	80000d02 <release>
        return -1;
    8000023e:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000240:	60e6                	ld	ra,88(sp)
    80000242:	6446                	ld	s0,80(sp)
    80000244:	64a6                	ld	s1,72(sp)
    80000246:	6906                	ld	s2,64(sp)
    80000248:	79e2                	ld	s3,56(sp)
    8000024a:	7a42                	ld	s4,48(sp)
    8000024c:	7aa2                	ld	s5,40(sp)
    8000024e:	7b02                	ld	s6,32(sp)
    80000250:	6125                	addi	sp,sp,96
    80000252:	8082                	ret
      if (n < target) {
    80000254:	0009871b          	sext.w	a4,s3
    80000258:	01677a63          	bgeu	a4,s6,8000026c <consoleread+0xfc>
        cons.r--;
    8000025c:	00012717          	auipc	a4,0x12
    80000260:	18f72623          	sw	a5,396(a4) # 800123e8 <cons+0x98>
    80000264:	6be2                	ld	s7,24(sp)
    80000266:	a031                	j	80000272 <consoleread+0x102>
    80000268:	ec5e                	sd	s7,24(sp)
    8000026a:	bfbd                	j	800001e8 <consoleread+0x78>
    8000026c:	6be2                	ld	s7,24(sp)
    8000026e:	a011                	j	80000272 <consoleread+0x102>
    80000270:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80000272:	00012517          	auipc	a0,0x12
    80000276:	0de50513          	addi	a0,a0,222 # 80012350 <cons>
    8000027a:	289000ef          	jal	80000d02 <release>
  return target - n;
    8000027e:	413b053b          	subw	a0,s6,s3
    80000282:	bf7d                	j	80000240 <consoleread+0xd0>
    80000284:	6be2                	ld	s7,24(sp)
    80000286:	b7f5                	j	80000272 <consoleread+0x102>

0000000080000288 <consputc>:
{
    80000288:	1141                	addi	sp,sp,-16
    8000028a:	e406                	sd	ra,8(sp)
    8000028c:	e022                	sd	s0,0(sp)
    8000028e:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000290:	10000793          	li	a5,256
    80000294:	00f50863          	beq	a0,a5,800002a4 <consputc+0x1c>
    uartputc_sync(c);
    80000298:	6b6000ef          	jal	8000094e <uartputc_sync>
}
    8000029c:	60a2                	ld	ra,8(sp)
    8000029e:	6402                	ld	s0,0(sp)
    800002a0:	0141                	addi	sp,sp,16
    800002a2:	8082                	ret
    uartputc_sync('\b');
    800002a4:	4521                	li	a0,8
    800002a6:	6a8000ef          	jal	8000094e <uartputc_sync>
    uartputc_sync(' ');
    800002aa:	02000513          	li	a0,32
    800002ae:	6a0000ef          	jal	8000094e <uartputc_sync>
    uartputc_sync('\b');
    800002b2:	4521                	li	a0,8
    800002b4:	69a000ef          	jal	8000094e <uartputc_sync>
    800002b8:	b7d5                	j	8000029c <consputc+0x14>

00000000800002ba <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ba:	1101                	addi	sp,sp,-32
    800002bc:	ec06                	sd	ra,24(sp)
    800002be:	e822                	sd	s0,16(sp)
    800002c0:	e426                	sd	s1,8(sp)
    800002c2:	1000                	addi	s0,sp,32
    800002c4:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c6:	00012517          	auipc	a0,0x12
    800002ca:	08a50513          	addi	a0,a0,138 # 80012350 <cons>
    800002ce:	1a9000ef          	jal	80000c76 <acquire>

  switch (c) {
    800002d2:	47d5                	li	a5,21
    800002d4:	08f48f63          	beq	s1,a5,80000372 <consoleintr+0xb8>
    800002d8:	0297c563          	blt	a5,s1,80000302 <consoleintr+0x48>
    800002dc:	47a1                	li	a5,8
    800002de:	0ef48463          	beq	s1,a5,800003c6 <consoleintr+0x10c>
    800002e2:	47c1                	li	a5,16
    800002e4:	10f49563          	bne	s1,a5,800003ee <consoleintr+0x134>
  case C('P'): // Print process list.
    procdump();
    800002e8:	10c020ef          	jal	800023f4 <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ec:	00012517          	auipc	a0,0x12
    800002f0:	06450513          	addi	a0,a0,100 # 80012350 <cons>
    800002f4:	20f000ef          	jal	80000d02 <release>
}
    800002f8:	60e2                	ld	ra,24(sp)
    800002fa:	6442                	ld	s0,16(sp)
    800002fc:	64a2                	ld	s1,8(sp)
    800002fe:	6105                	addi	sp,sp,32
    80000300:	8082                	ret
  switch (c) {
    80000302:	07f00793          	li	a5,127
    80000306:	0cf48063          	beq	s1,a5,800003c6 <consoleintr+0x10c>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    8000030a:	00012717          	auipc	a4,0x12
    8000030e:	04670713          	addi	a4,a4,70 # 80012350 <cons>
    80000312:	0a072783          	lw	a5,160(a4)
    80000316:	09872703          	lw	a4,152(a4)
    8000031a:	9f99                	subw	a5,a5,a4
    8000031c:	07f00713          	li	a4,127
    80000320:	fcf766e3          	bltu	a4,a5,800002ec <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000324:	47b5                	li	a5,13
    80000326:	0cf48763          	beq	s1,a5,800003f4 <consoleintr+0x13a>
      consputc(c);
    8000032a:	8526                	mv	a0,s1
    8000032c:	f5dff0ef          	jal	80000288 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000330:	00012797          	auipc	a5,0x12
    80000334:	02078793          	addi	a5,a5,32 # 80012350 <cons>
    80000338:	0a07a683          	lw	a3,160(a5)
    8000033c:	0016871b          	addiw	a4,a3,1
    80000340:	0007061b          	sext.w	a2,a4
    80000344:	0ae7a023          	sw	a4,160(a5)
    80000348:	07f6f693          	andi	a3,a3,127
    8000034c:	97b6                	add	a5,a5,a3
    8000034e:	00978c23          	sb	s1,24(a5)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000352:	47a9                	li	a5,10
    80000354:	0cf48563          	beq	s1,a5,8000041e <consoleintr+0x164>
    80000358:	4791                	li	a5,4
    8000035a:	0cf48263          	beq	s1,a5,8000041e <consoleintr+0x164>
    8000035e:	00012797          	auipc	a5,0x12
    80000362:	08a7a783          	lw	a5,138(a5) # 800123e8 <cons+0x98>
    80000366:	9f1d                	subw	a4,a4,a5
    80000368:	08000793          	li	a5,128
    8000036c:	f8f710e3          	bne	a4,a5,800002ec <consoleintr+0x32>
    80000370:	a07d                	j	8000041e <consoleintr+0x164>
    80000372:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    80000374:	00012717          	auipc	a4,0x12
    80000378:	fdc70713          	addi	a4,a4,-36 # 80012350 <cons>
    8000037c:	0a072783          	lw	a5,160(a4)
    80000380:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000384:	00012497          	auipc	s1,0x12
    80000388:	fcc48493          	addi	s1,s1,-52 # 80012350 <cons>
    while (cons.e != cons.w &&
    8000038c:	4929                	li	s2,10
    8000038e:	02f70863          	beq	a4,a5,800003be <consoleintr+0x104>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000392:	37fd                	addiw	a5,a5,-1
    80000394:	07f7f713          	andi	a4,a5,127
    80000398:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    8000039a:	01874703          	lbu	a4,24(a4)
    8000039e:	03270263          	beq	a4,s2,800003c2 <consoleintr+0x108>
      cons.e--;
    800003a2:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003a6:	10000513          	li	a0,256
    800003aa:	edfff0ef          	jal	80000288 <consputc>
    while (cons.e != cons.w &&
    800003ae:	0a04a783          	lw	a5,160(s1)
    800003b2:	09c4a703          	lw	a4,156(s1)
    800003b6:	fcf71ee3          	bne	a4,a5,80000392 <consoleintr+0xd8>
    800003ba:	6902                	ld	s2,0(sp)
    800003bc:	bf05                	j	800002ec <consoleintr+0x32>
    800003be:	6902                	ld	s2,0(sp)
    800003c0:	b735                	j	800002ec <consoleintr+0x32>
    800003c2:	6902                	ld	s2,0(sp)
    800003c4:	b725                	j	800002ec <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003c6:	00012717          	auipc	a4,0x12
    800003ca:	f8a70713          	addi	a4,a4,-118 # 80012350 <cons>
    800003ce:	0a072783          	lw	a5,160(a4)
    800003d2:	09c72703          	lw	a4,156(a4)
    800003d6:	f0f70be3          	beq	a4,a5,800002ec <consoleintr+0x32>
      cons.e--;
    800003da:	37fd                	addiw	a5,a5,-1
    800003dc:	00012717          	auipc	a4,0x12
    800003e0:	00f72a23          	sw	a5,20(a4) # 800123f0 <cons+0xa0>
      consputc(BACKSPACE);
    800003e4:	10000513          	li	a0,256
    800003e8:	ea1ff0ef          	jal	80000288 <consputc>
    800003ec:	b701                	j	800002ec <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003ee:	ee048fe3          	beqz	s1,800002ec <consoleintr+0x32>
    800003f2:	bf21                	j	8000030a <consoleintr+0x50>
      consputc(c);
    800003f4:	4529                	li	a0,10
    800003f6:	e93ff0ef          	jal	80000288 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003fa:	00012797          	auipc	a5,0x12
    800003fe:	f5678793          	addi	a5,a5,-170 # 80012350 <cons>
    80000402:	0a07a703          	lw	a4,160(a5)
    80000406:	0017069b          	addiw	a3,a4,1
    8000040a:	0006861b          	sext.w	a2,a3
    8000040e:	0ad7a023          	sw	a3,160(a5)
    80000412:	07f77713          	andi	a4,a4,127
    80000416:	97ba                	add	a5,a5,a4
    80000418:	4729                	li	a4,10
    8000041a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000041e:	00012797          	auipc	a5,0x12
    80000422:	fcc7a723          	sw	a2,-50(a5) # 800123ec <cons+0x9c>
        wakeup(&cons.r);
    80000426:	00012517          	auipc	a0,0x12
    8000042a:	fc250513          	addi	a0,a0,-62 # 800123e8 <cons+0x98>
    8000042e:	407010ef          	jal	80002034 <wakeup>
    80000432:	bd6d                	j	800002ec <consoleintr+0x32>

0000000080000434 <consoleinit>:

void
consoleinit(void)
{
    80000434:	1141                	addi	sp,sp,-16
    80000436:	e406                	sd	ra,8(sp)
    80000438:	e022                	sd	s0,0(sp)
    8000043a:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000043c:	00007597          	auipc	a1,0x7
    80000440:	bc458593          	addi	a1,a1,-1084 # 80007000 <etext>
    80000444:	00012517          	auipc	a0,0x12
    80000448:	f0c50513          	addi	a0,a0,-244 # 80012350 <cons>
    8000044c:	7b4000ef          	jal	80000c00 <initlock>

  uartinit();
    80000450:	400000ef          	jal	80000850 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000454:	00022797          	auipc	a5,0x22
    80000458:	09478793          	addi	a5,a5,148 # 800224e8 <devsw>
    8000045c:	00000717          	auipc	a4,0x0
    80000460:	d1470713          	addi	a4,a4,-748 # 80000170 <consoleread>
    80000464:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000466:	00000717          	auipc	a4,0x0
    8000046a:	c6c70713          	addi	a4,a4,-916 # 800000d2 <consolewrite>
    8000046e:	ef98                	sd	a4,24(a5)
}
    80000470:	60a2                	ld	ra,8(sp)
    80000472:	6402                	ld	s0,0(sp)
    80000474:	0141                	addi	sp,sp,16
    80000476:	8082                	ret

0000000080000478 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000478:	7139                	addi	sp,sp,-64
    8000047a:	fc06                	sd	ra,56(sp)
    8000047c:	f822                	sd	s0,48(sp)
    8000047e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    80000480:	c219                	beqz	a2,80000486 <printint+0xe>
    80000482:	08054063          	bltz	a0,80000502 <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000486:	4881                	li	a7,0
    80000488:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000048c:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000048e:	00007617          	auipc	a2,0x7
    80000492:	2a260613          	addi	a2,a2,674 # 80007730 <digits>
    80000496:	883e                	mv	a6,a5
    80000498:	2785                	addiw	a5,a5,1
    8000049a:	02b57733          	remu	a4,a0,a1
    8000049e:	9732                	add	a4,a4,a2
    800004a0:	00074703          	lbu	a4,0(a4)
    800004a4:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
    800004a8:	872a                	mv	a4,a0
    800004aa:	02b55533          	divu	a0,a0,a1
    800004ae:	0685                	addi	a3,a3,1
    800004b0:	feb773e3          	bgeu	a4,a1,80000496 <printint+0x1e>

  if (sign)
    800004b4:	00088a63          	beqz	a7,800004c8 <printint+0x50>
    buf[i++] = '-';
    800004b8:	1781                	addi	a5,a5,-32
    800004ba:	97a2                	add	a5,a5,s0
    800004bc:	02d00713          	li	a4,45
    800004c0:	fee78423          	sb	a4,-24(a5)
    800004c4:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
    800004c8:	02f05963          	blez	a5,800004fa <printint+0x82>
    800004cc:	f426                	sd	s1,40(sp)
    800004ce:	f04a                	sd	s2,32(sp)
    800004d0:	fc840713          	addi	a4,s0,-56
    800004d4:	00f704b3          	add	s1,a4,a5
    800004d8:	fff70913          	addi	s2,a4,-1
    800004dc:	993e                	add	s2,s2,a5
    800004de:	37fd                	addiw	a5,a5,-1
    800004e0:	1782                	slli	a5,a5,0x20
    800004e2:	9381                	srli	a5,a5,0x20
    800004e4:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004e8:	fff4c503          	lbu	a0,-1(s1)
    800004ec:	d9dff0ef          	jal	80000288 <consputc>
  while (--i >= 0)
    800004f0:	14fd                	addi	s1,s1,-1
    800004f2:	ff249be3          	bne	s1,s2,800004e8 <printint+0x70>
    800004f6:	74a2                	ld	s1,40(sp)
    800004f8:	7902                	ld	s2,32(sp)
}
    800004fa:	70e2                	ld	ra,56(sp)
    800004fc:	7442                	ld	s0,48(sp)
    800004fe:	6121                	addi	sp,sp,64
    80000500:	8082                	ret
    x = -xx;
    80000502:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    80000506:	4885                	li	a7,1
    x = -xx;
    80000508:	b741                	j	80000488 <printint+0x10>

000000008000050a <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    8000050a:	7131                	addi	sp,sp,-192
    8000050c:	fc86                	sd	ra,120(sp)
    8000050e:	f8a2                	sd	s0,112(sp)
    80000510:	e8d2                	sd	s4,80(sp)
    80000512:	0100                	addi	s0,sp,128
    80000514:	8a2a                	mv	s4,a0
    80000516:	e40c                	sd	a1,8(s0)
    80000518:	e810                	sd	a2,16(s0)
    8000051a:	ec14                	sd	a3,24(s0)
    8000051c:	f018                	sd	a4,32(s0)
    8000051e:	f41c                	sd	a5,40(s0)
    80000520:	03043823          	sd	a6,48(s0)
    80000524:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    80000528:	0000a797          	auipc	a5,0xa
    8000052c:	dfc7a783          	lw	a5,-516(a5) # 8000a324 <panicking>
    80000530:	c3a1                	beqz	a5,80000570 <printk+0x66>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000532:	00840793          	addi	a5,s0,8
    80000536:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    8000053a:	000a4503          	lbu	a0,0(s4)
    8000053e:	28050763          	beqz	a0,800007cc <printk+0x2c2>
    80000542:	f4a6                	sd	s1,104(sp)
    80000544:	f0ca                	sd	s2,96(sp)
    80000546:	ecce                	sd	s3,88(sp)
    80000548:	e4d6                	sd	s5,72(sp)
    8000054a:	e0da                	sd	s6,64(sp)
    8000054c:	f862                	sd	s8,48(sp)
    8000054e:	f466                	sd	s9,40(sp)
    80000550:	f06a                	sd	s10,32(sp)
    80000552:	ec6e                	sd	s11,24(sp)
    80000554:	4981                	li	s3,0
    if (cx != '%') {
    80000556:	02500a93          	li	s5,37
    c1 = c2 = 0;
    if (c0)
      c1 = fmt[i + 1] & 0xff;
    if (c1)
      c2 = fmt[i + 2] & 0xff;
    if (c0 == 'd') {
    8000055a:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if (c0 == 'l' && c1 == 'd') {
    8000055e:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    80000562:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    80000566:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    8000056a:	07000d93          	li	s11,112
    8000056e:	a01d                	j	80000594 <printk+0x8a>
    acquire(&pr.lock);
    80000570:	00012517          	auipc	a0,0x12
    80000574:	e8850513          	addi	a0,a0,-376 # 800123f8 <pr>
    80000578:	6fe000ef          	jal	80000c76 <acquire>
    8000057c:	bf5d                	j	80000532 <printk+0x28>
      consputc(cx);
    8000057e:	d0bff0ef          	jal	80000288 <consputc>
      continue;
    80000582:	84ce                	mv	s1,s3
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000584:	0014899b          	addiw	s3,s1,1
    80000588:	013a07b3          	add	a5,s4,s3
    8000058c:	0007c503          	lbu	a0,0(a5)
    80000590:	20050b63          	beqz	a0,800007a6 <printk+0x29c>
    if (cx != '%') {
    80000594:	ff5515e3          	bne	a0,s5,8000057e <printk+0x74>
    i++;
    80000598:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i + 0] & 0xff;
    8000059c:	009a07b3          	add	a5,s4,s1
    800005a0:	0007c903          	lbu	s2,0(a5)
    if (c0)
    800005a4:	20090b63          	beqz	s2,800007ba <printk+0x2b0>
      c1 = fmt[i + 1] & 0xff;
    800005a8:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    800005ac:	86be                	mv	a3,a5
    if (c1)
    800005ae:	c789                	beqz	a5,800005b8 <printk+0xae>
      c2 = fmt[i + 2] & 0xff;
    800005b0:	009a0733          	add	a4,s4,s1
    800005b4:	00274683          	lbu	a3,2(a4)
    if (c0 == 'd') {
    800005b8:	03690963          	beq	s2,s6,800005ea <printk+0xe0>
    } else if (c0 == 'l' && c1 == 'd') {
    800005bc:	05890363          	beq	s2,s8,80000602 <printk+0xf8>
    } else if (c0 == 'u') {
    800005c0:	0d990663          	beq	s2,s9,8000068c <printk+0x182>
    } else if (c0 == 'x') {
    800005c4:	11a90d63          	beq	s2,s10,800006de <printk+0x1d4>
    } else if (c0 == 'p') {
    800005c8:	15b90663          	beq	s2,s11,80000714 <printk+0x20a>
      printptr(va_arg(ap, uint64));
    } else if (c0 == 'c') {
    800005cc:	06300793          	li	a5,99
    800005d0:	18f90563          	beq	s2,a5,8000075a <printk+0x250>
      consputc(va_arg(ap, uint));
    } else if (c0 == 's') {
    800005d4:	07300793          	li	a5,115
    800005d8:	18f90b63          	beq	s2,a5,8000076e <printk+0x264>
      if ((s = va_arg(ap, char *)) == 0)
        s = "(null)";
      for (; *s; s++)
        consputc(*s);
    } else if (c0 == '%') {
    800005dc:	03591b63          	bne	s2,s5,80000612 <printk+0x108>
      consputc('%');
    800005e0:	02500513          	li	a0,37
    800005e4:	ca5ff0ef          	jal	80000288 <consputc>
    800005e8:	bf71                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, int), 10, 1);
    800005ea:	f8843783          	ld	a5,-120(s0)
    800005ee:	00878713          	addi	a4,a5,8
    800005f2:	f8e43423          	sd	a4,-120(s0)
    800005f6:	4605                	li	a2,1
    800005f8:	45a9                	li	a1,10
    800005fa:	4388                	lw	a0,0(a5)
    800005fc:	e7dff0ef          	jal	80000478 <printint>
    80000600:	b751                	j	80000584 <printk+0x7a>
    } else if (c0 == 'l' && c1 == 'd') {
    80000602:	01678f63          	beq	a5,s6,80000620 <printk+0x116>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    80000606:	03878b63          	beq	a5,s8,8000063c <printk+0x132>
    } else if (c0 == 'l' && c1 == 'u') {
    8000060a:	09978e63          	beq	a5,s9,800006a6 <printk+0x19c>
    } else if (c0 == 'l' && c1 == 'x') {
    8000060e:	0fa78563          	beq	a5,s10,800006f8 <printk+0x1ee>
    } else if (c0 == 0) {
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    80000612:	8556                	mv	a0,s5
    80000614:	c75ff0ef          	jal	80000288 <consputc>
      consputc(c0);
    80000618:	854a                	mv	a0,s2
    8000061a:	c6fff0ef          	jal	80000288 <consputc>
    8000061e:	b79d                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000620:	f8843783          	ld	a5,-120(s0)
    80000624:	00878713          	addi	a4,a5,8
    80000628:	f8e43423          	sd	a4,-120(s0)
    8000062c:	4605                	li	a2,1
    8000062e:	45a9                	li	a1,10
    80000630:	6388                	ld	a0,0(a5)
    80000632:	e47ff0ef          	jal	80000478 <printint>
      i += 1;
    80000636:	0029849b          	addiw	s1,s3,2
    8000063a:	b7a9                	j	80000584 <printk+0x7a>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    8000063c:	06400793          	li	a5,100
    80000640:	02f68863          	beq	a3,a5,80000670 <printk+0x166>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    80000644:	07500793          	li	a5,117
    80000648:	06f68d63          	beq	a3,a5,800006c2 <printk+0x1b8>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    8000064c:	07800793          	li	a5,120
    80000650:	fcf691e3          	bne	a3,a5,80000612 <printk+0x108>
      printint(va_arg(ap, uint64), 16, 0);
    80000654:	f8843783          	ld	a5,-120(s0)
    80000658:	00878713          	addi	a4,a5,8
    8000065c:	f8e43423          	sd	a4,-120(s0)
    80000660:	4601                	li	a2,0
    80000662:	45c1                	li	a1,16
    80000664:	6388                	ld	a0,0(a5)
    80000666:	e13ff0ef          	jal	80000478 <printint>
      i += 2;
    8000066a:	0039849b          	addiw	s1,s3,3
    8000066e:	bf19                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000670:	f8843783          	ld	a5,-120(s0)
    80000674:	00878713          	addi	a4,a5,8
    80000678:	f8e43423          	sd	a4,-120(s0)
    8000067c:	4605                	li	a2,1
    8000067e:	45a9                	li	a1,10
    80000680:	6388                	ld	a0,0(a5)
    80000682:	df7ff0ef          	jal	80000478 <printint>
      i += 2;
    80000686:	0039849b          	addiw	s1,s3,3
    8000068a:	bded                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint32), 10, 0);
    8000068c:	f8843783          	ld	a5,-120(s0)
    80000690:	00878713          	addi	a4,a5,8
    80000694:	f8e43423          	sd	a4,-120(s0)
    80000698:	4601                	li	a2,0
    8000069a:	45a9                	li	a1,10
    8000069c:	0007e503          	lwu	a0,0(a5)
    800006a0:	dd9ff0ef          	jal	80000478 <printint>
    800006a4:	b5c5                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006a6:	f8843783          	ld	a5,-120(s0)
    800006aa:	00878713          	addi	a4,a5,8
    800006ae:	f8e43423          	sd	a4,-120(s0)
    800006b2:	4601                	li	a2,0
    800006b4:	45a9                	li	a1,10
    800006b6:	6388                	ld	a0,0(a5)
    800006b8:	dc1ff0ef          	jal	80000478 <printint>
      i += 1;
    800006bc:	0029849b          	addiw	s1,s3,2
    800006c0:	b5d1                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006c2:	f8843783          	ld	a5,-120(s0)
    800006c6:	00878713          	addi	a4,a5,8
    800006ca:	f8e43423          	sd	a4,-120(s0)
    800006ce:	4601                	li	a2,0
    800006d0:	45a9                	li	a1,10
    800006d2:	6388                	ld	a0,0(a5)
    800006d4:	da5ff0ef          	jal	80000478 <printint>
      i += 2;
    800006d8:	0039849b          	addiw	s1,s3,3
    800006dc:	b565                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint32), 16, 0);
    800006de:	f8843783          	ld	a5,-120(s0)
    800006e2:	00878713          	addi	a4,a5,8
    800006e6:	f8e43423          	sd	a4,-120(s0)
    800006ea:	4601                	li	a2,0
    800006ec:	45c1                	li	a1,16
    800006ee:	0007e503          	lwu	a0,0(a5)
    800006f2:	d87ff0ef          	jal	80000478 <printint>
    800006f6:	b579                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 16, 0);
    800006f8:	f8843783          	ld	a5,-120(s0)
    800006fc:	00878713          	addi	a4,a5,8
    80000700:	f8e43423          	sd	a4,-120(s0)
    80000704:	4601                	li	a2,0
    80000706:	45c1                	li	a1,16
    80000708:	6388                	ld	a0,0(a5)
    8000070a:	d6fff0ef          	jal	80000478 <printint>
      i += 1;
    8000070e:	0029849b          	addiw	s1,s3,2
    80000712:	bd8d                	j	80000584 <printk+0x7a>
    80000714:	fc5e                	sd	s7,56(sp)
      printptr(va_arg(ap, uint64));
    80000716:	f8843783          	ld	a5,-120(s0)
    8000071a:	00878713          	addi	a4,a5,8
    8000071e:	f8e43423          	sd	a4,-120(s0)
    80000722:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000726:	03000513          	li	a0,48
    8000072a:	b5fff0ef          	jal	80000288 <consputc>
  consputc('x');
    8000072e:	07800513          	li	a0,120
    80000732:	b57ff0ef          	jal	80000288 <consputc>
    80000736:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000738:	00007b97          	auipc	s7,0x7
    8000073c:	ff8b8b93          	addi	s7,s7,-8 # 80007730 <digits>
    80000740:	03c9d793          	srli	a5,s3,0x3c
    80000744:	97de                	add	a5,a5,s7
    80000746:	0007c503          	lbu	a0,0(a5)
    8000074a:	b3fff0ef          	jal	80000288 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000074e:	0992                	slli	s3,s3,0x4
    80000750:	397d                	addiw	s2,s2,-1
    80000752:	fe0917e3          	bnez	s2,80000740 <printk+0x236>
    80000756:	7be2                	ld	s7,56(sp)
    80000758:	b535                	j	80000584 <printk+0x7a>
      consputc(va_arg(ap, uint));
    8000075a:	f8843783          	ld	a5,-120(s0)
    8000075e:	00878713          	addi	a4,a5,8
    80000762:	f8e43423          	sd	a4,-120(s0)
    80000766:	4388                	lw	a0,0(a5)
    80000768:	b21ff0ef          	jal	80000288 <consputc>
    8000076c:	bd21                	j	80000584 <printk+0x7a>
      if ((s = va_arg(ap, char *)) == 0)
    8000076e:	f8843783          	ld	a5,-120(s0)
    80000772:	00878713          	addi	a4,a5,8
    80000776:	f8e43423          	sd	a4,-120(s0)
    8000077a:	0007b903          	ld	s2,0(a5)
    8000077e:	00090d63          	beqz	s2,80000798 <printk+0x28e>
      for (; *s; s++)
    80000782:	00094503          	lbu	a0,0(s2)
    80000786:	de050fe3          	beqz	a0,80000584 <printk+0x7a>
        consputc(*s);
    8000078a:	affff0ef          	jal	80000288 <consputc>
      for (; *s; s++)
    8000078e:	0905                	addi	s2,s2,1
    80000790:	00094503          	lbu	a0,0(s2)
    80000794:	f97d                	bnez	a0,8000078a <printk+0x280>
    80000796:	b3fd                	j	80000584 <printk+0x7a>
        s = "(null)";
    80000798:	00007917          	auipc	s2,0x7
    8000079c:	87090913          	addi	s2,s2,-1936 # 80007008 <etext+0x8>
      for (; *s; s++)
    800007a0:	02800513          	li	a0,40
    800007a4:	b7dd                	j	8000078a <printk+0x280>
    800007a6:	74a6                	ld	s1,104(sp)
    800007a8:	7906                	ld	s2,96(sp)
    800007aa:	69e6                	ld	s3,88(sp)
    800007ac:	6aa6                	ld	s5,72(sp)
    800007ae:	6b06                	ld	s6,64(sp)
    800007b0:	7c42                	ld	s8,48(sp)
    800007b2:	7ca2                	ld	s9,40(sp)
    800007b4:	7d02                	ld	s10,32(sp)
    800007b6:	6de2                	ld	s11,24(sp)
    800007b8:	a811                	j	800007cc <printk+0x2c2>
    800007ba:	74a6                	ld	s1,104(sp)
    800007bc:	7906                	ld	s2,96(sp)
    800007be:	69e6                	ld	s3,88(sp)
    800007c0:	6aa6                	ld	s5,72(sp)
    800007c2:	6b06                	ld	s6,64(sp)
    800007c4:	7c42                	ld	s8,48(sp)
    800007c6:	7ca2                	ld	s9,40(sp)
    800007c8:	7d02                	ld	s10,32(sp)
    800007ca:	6de2                	ld	s11,24(sp)
    }
  }
  va_end(ap);

  if (panicking == 0)
    800007cc:	0000a797          	auipc	a5,0xa
    800007d0:	b587a783          	lw	a5,-1192(a5) # 8000a324 <panicking>
    800007d4:	c799                	beqz	a5,800007e2 <printk+0x2d8>
    release(&pr.lock);

  return 0;
}
    800007d6:	4501                	li	a0,0
    800007d8:	70e6                	ld	ra,120(sp)
    800007da:	7446                	ld	s0,112(sp)
    800007dc:	6a46                	ld	s4,80(sp)
    800007de:	6129                	addi	sp,sp,192
    800007e0:	8082                	ret
    release(&pr.lock);
    800007e2:	00012517          	auipc	a0,0x12
    800007e6:	c1650513          	addi	a0,a0,-1002 # 800123f8 <pr>
    800007ea:	518000ef          	jal	80000d02 <release>
  return 0;
    800007ee:	b7e5                	j	800007d6 <printk+0x2cc>

00000000800007f0 <panic>:

void
panic(char *s)
{
    800007f0:	1101                	addi	sp,sp,-32
    800007f2:	ec06                	sd	ra,24(sp)
    800007f4:	e822                	sd	s0,16(sp)
    800007f6:	e426                	sd	s1,8(sp)
    800007f8:	e04a                	sd	s2,0(sp)
    800007fa:	1000                	addi	s0,sp,32
    800007fc:	84aa                	mv	s1,a0
  panicking = 1;
    800007fe:	4905                	li	s2,1
    80000800:	0000a797          	auipc	a5,0xa
    80000804:	b327a223          	sw	s2,-1244(a5) # 8000a324 <panicking>
  printk("panic: ");
    80000808:	00007517          	auipc	a0,0x7
    8000080c:	81050513          	addi	a0,a0,-2032 # 80007018 <etext+0x18>
    80000810:	cfbff0ef          	jal	8000050a <printk>
  printk("%s\n", s);
    80000814:	85a6                	mv	a1,s1
    80000816:	00007517          	auipc	a0,0x7
    8000081a:	80a50513          	addi	a0,a0,-2038 # 80007020 <etext+0x20>
    8000081e:	cedff0ef          	jal	8000050a <printk>
  panicked = 1; // freeze uart output from other CPUs
    80000822:	0000a797          	auipc	a5,0xa
    80000826:	af27af23          	sw	s2,-1282(a5) # 8000a320 <panicked>
  for (;;)
    8000082a:	a001                	j	8000082a <panic+0x3a>

000000008000082c <printkinit>:
    ;
}

void
printkinit(void)
{
    8000082c:	1141                	addi	sp,sp,-16
    8000082e:	e406                	sd	ra,8(sp)
    80000830:	e022                	sd	s0,0(sp)
    80000832:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000834:	00006597          	auipc	a1,0x6
    80000838:	7f458593          	addi	a1,a1,2036 # 80007028 <etext+0x28>
    8000083c:	00012517          	auipc	a0,0x12
    80000840:	bbc50513          	addi	a0,a0,-1092 # 800123f8 <pr>
    80000844:	3bc000ef          	jal	80000c00 <initlock>
}
    80000848:	60a2                	ld	ra,8(sp)
    8000084a:	6402                	ld	s0,0(sp)
    8000084c:	0141                	addi	sp,sp,16
    8000084e:	8082                	ret

0000000080000850 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    80000850:	1141                	addi	sp,sp,-16
    80000852:	e406                	sd	ra,8(sp)
    80000854:	e022                	sd	s0,0(sp)
    80000856:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000858:	100007b7          	lui	a5,0x10000
    8000085c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000860:	10000737          	lui	a4,0x10000
    80000864:	f8000693          	li	a3,-128
    80000868:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000086c:	468d                	li	a3,3
    8000086e:	10000637          	lui	a2,0x10000
    80000872:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000876:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000087a:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000087e:	10000737          	lui	a4,0x10000
    80000882:	461d                	li	a2,7
    80000884:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000888:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    8000088c:	00006597          	auipc	a1,0x6
    80000890:	7a458593          	addi	a1,a1,1956 # 80007030 <etext+0x30>
    80000894:	00012517          	auipc	a0,0x12
    80000898:	b7c50513          	addi	a0,a0,-1156 # 80012410 <tx_lock>
    8000089c:	364000ef          	jal	80000c00 <initlock>
}
    800008a0:	60a2                	ld	ra,8(sp)
    800008a2:	6402                	ld	s0,0(sp)
    800008a4:	0141                	addi	sp,sp,16
    800008a6:	8082                	ret

00000000800008a8 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008a8:	715d                	addi	sp,sp,-80
    800008aa:	e486                	sd	ra,72(sp)
    800008ac:	e0a2                	sd	s0,64(sp)
    800008ae:	fc26                	sd	s1,56(sp)
    800008b0:	ec56                	sd	s5,24(sp)
    800008b2:	0880                	addi	s0,sp,80
    800008b4:	8aaa                	mv	s5,a0
    800008b6:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008b8:	00012517          	auipc	a0,0x12
    800008bc:	b5850513          	addi	a0,a0,-1192 # 80012410 <tx_lock>
    800008c0:	3b6000ef          	jal	80000c76 <acquire>

  int i = 0;
  while (i < n) {
    800008c4:	06905963          	blez	s1,80000936 <uartwrite+0x8e>
    800008c8:	f84a                	sd	s2,48(sp)
    800008ca:	f44e                	sd	s3,40(sp)
    800008cc:	f052                	sd	s4,32(sp)
    800008ce:	e85a                	sd	s6,16(sp)
    800008d0:	e45e                	sd	s7,8(sp)
    800008d2:	8a56                	mv	s4,s5
    800008d4:	9aa6                	add	s5,s5,s1
    while (tx_busy != 0) {
    800008d6:	0000a917          	auipc	s2,0xa
    800008da:	a5690913          	addi	s2,s2,-1450 # 8000a32c <tx_busy>
      // wait for a UART interrupt to set tx_busy to 0.
      sleep_prepare(&tx_chan);
    800008de:	0000a997          	auipc	s3,0xa
    800008e2:	a4a98993          	addi	s3,s3,-1462 # 8000a328 <tx_chan>
      release(&tx_lock);
    800008e6:	00012497          	auipc	s1,0x12
    800008ea:	b2a48493          	addi	s1,s1,-1238 # 80012410 <tx_lock>
      sleep();
      acquire(&tx_lock);
    }
    WriteReg(THR, buf[i]);
    800008ee:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    800008f2:	4b05                	li	s6,1
    800008f4:	a805                	j	80000924 <uartwrite+0x7c>
      sleep_prepare(&tx_chan);
    800008f6:	854e                	mv	a0,s3
    800008f8:	6d0010ef          	jal	80001fc8 <sleep_prepare>
      release(&tx_lock);
    800008fc:	8526                	mv	a0,s1
    800008fe:	404000ef          	jal	80000d02 <release>
      sleep();
    80000902:	702010ef          	jal	80002004 <sleep>
      acquire(&tx_lock);
    80000906:	8526                	mv	a0,s1
    80000908:	36e000ef          	jal	80000c76 <acquire>
    while (tx_busy != 0) {
    8000090c:	00092783          	lw	a5,0(s2)
    80000910:	f3fd                	bnez	a5,800008f6 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000912:	000a4783          	lbu	a5,0(s4)
    80000916:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000091a:	01692023          	sw	s6,0(s2)
  while (i < n) {
    8000091e:	0a05                	addi	s4,s4,1
    80000920:	015a0663          	beq	s4,s5,8000092c <uartwrite+0x84>
    while (tx_busy != 0) {
    80000924:	00092783          	lw	a5,0(s2)
    80000928:	f7f9                	bnez	a5,800008f6 <uartwrite+0x4e>
    8000092a:	b7e5                	j	80000912 <uartwrite+0x6a>
    8000092c:	7942                	ld	s2,48(sp)
    8000092e:	79a2                	ld	s3,40(sp)
    80000930:	7a02                	ld	s4,32(sp)
    80000932:	6b42                	ld	s6,16(sp)
    80000934:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000936:	00012517          	auipc	a0,0x12
    8000093a:	ada50513          	addi	a0,a0,-1318 # 80012410 <tx_lock>
    8000093e:	3c4000ef          	jal	80000d02 <release>
}
    80000942:	60a6                	ld	ra,72(sp)
    80000944:	6406                	ld	s0,64(sp)
    80000946:	74e2                	ld	s1,56(sp)
    80000948:	6ae2                	ld	s5,24(sp)
    8000094a:	6161                	addi	sp,sp,80
    8000094c:	8082                	ret

000000008000094e <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000094e:	1101                	addi	sp,sp,-32
    80000950:	ec06                	sd	ra,24(sp)
    80000952:	e822                	sd	s0,16(sp)
    80000954:	e426                	sd	s1,8(sp)
    80000956:	1000                	addi	s0,sp,32
    80000958:	84aa                	mv	s1,a0
  if (panicking == 0)
    8000095a:	0000a797          	auipc	a5,0xa
    8000095e:	9ca7a783          	lw	a5,-1590(a5) # 8000a324 <panicking>
    80000962:	cf95                	beqz	a5,8000099e <uartputc_sync+0x50>
    push_off();

  if (panicked) {
    80000964:	0000a797          	auipc	a5,0xa
    80000968:	9bc7a783          	lw	a5,-1604(a5) # 8000a320 <panicked>
    8000096c:	ef85                	bnez	a5,800009a4 <uartputc_sync+0x56>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000096e:	10000737          	lui	a4,0x10000
    80000972:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000974:	00074783          	lbu	a5,0(a4)
    80000978:	0207f793          	andi	a5,a5,32
    8000097c:	dfe5                	beqz	a5,80000974 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000097e:	0ff4f513          	zext.b	a0,s1
    80000982:	100007b7          	lui	a5,0x10000
    80000986:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    8000098a:	0000a797          	auipc	a5,0xa
    8000098e:	99a7a783          	lw	a5,-1638(a5) # 8000a324 <panicking>
    80000992:	cb91                	beqz	a5,800009a6 <uartputc_sync+0x58>
    pop_off();
}
    80000994:	60e2                	ld	ra,24(sp)
    80000996:	6442                	ld	s0,16(sp)
    80000998:	64a2                	ld	s1,8(sp)
    8000099a:	6105                	addi	sp,sp,32
    8000099c:	8082                	ret
    push_off();
    8000099e:	2a2000ef          	jal	80000c40 <push_off>
    800009a2:	b7c9                	j	80000964 <uartputc_sync+0x16>
    for (;;)
    800009a4:	a001                	j	800009a4 <uartputc_sync+0x56>
    pop_off();
    800009a6:	310000ef          	jal	80000cb6 <pop_off>
}
    800009aa:	b7ed                	j	80000994 <uartputc_sync+0x46>

00000000800009ac <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009ac:	1101                	addi	sp,sp,-32
    800009ae:	ec06                	sd	ra,24(sp)
    800009b0:	e822                	sd	s0,16(sp)
    800009b2:	e426                	sd	s1,8(sp)
    800009b4:	e04a                	sd	s2,0(sp)
    800009b6:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009b8:	100007b7          	lui	a5,0x10000
    800009bc:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    800009be:	0007c783          	lbu	a5,0(a5)

  acquire(&tx_lock);
    800009c2:	00012517          	auipc	a0,0x12
    800009c6:	a4e50513          	addi	a0,a0,-1458 # 80012410 <tx_lock>
    800009ca:	2ac000ef          	jal	80000c76 <acquire>
  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009ce:	100007b7          	lui	a5,0x10000
    800009d2:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009d4:	0007c783          	lbu	a5,0(a5)
    800009d8:	0207f793          	andi	a5,a5,32
    800009dc:	e78d                	bnez	a5,80000a06 <uartintr+0x5a>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    800009de:	00012517          	auipc	a0,0x12
    800009e2:	a3250513          	addi	a0,a0,-1486 # 80012410 <tx_lock>
    800009e6:	31c000ef          	jal	80000d02 <release>
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009ea:	100004b7          	lui	s1,0x10000
    800009ee:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    800009f0:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009f4:	0004c783          	lbu	a5,0(s1)
    800009f8:	8b85                	andi	a5,a5,1
    800009fa:	c38d                	beqz	a5,80000a1c <uartintr+0x70>
    return ReadReg(RHR);
    800009fc:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    80000a00:	8bbff0ef          	jal	800002ba <consoleintr>
  while (1) {
    80000a04:	bfc5                	j	800009f4 <uartintr+0x48>
    tx_busy = 0;
    80000a06:	0000a797          	auipc	a5,0xa
    80000a0a:	9207a323          	sw	zero,-1754(a5) # 8000a32c <tx_busy>
    wakeup(&tx_chan);
    80000a0e:	0000a517          	auipc	a0,0xa
    80000a12:	91a50513          	addi	a0,a0,-1766 # 8000a328 <tx_chan>
    80000a16:	61e010ef          	jal	80002034 <wakeup>
    80000a1a:	b7d1                	j	800009de <uartintr+0x32>
  }
}
    80000a1c:	60e2                	ld	ra,24(sp)
    80000a1e:	6442                	ld	s0,16(sp)
    80000a20:	64a2                	ld	s1,8(sp)
    80000a22:	6902                	ld	s2,0(sp)
    80000a24:	6105                	addi	sp,sp,32
    80000a26:	8082                	ret

0000000080000a28 <kallocstats>:
  int initializing;
} kmem;

void
kallocstats(struct kalloc_stats *stats)
{
    80000a28:	1101                	addi	sp,sp,-32
    80000a2a:	ec06                	sd	ra,24(sp)
    80000a2c:	e822                	sd	s0,16(sp)
    80000a2e:	e426                	sd	s1,8(sp)
    80000a30:	e04a                	sd	s2,0(sp)
    80000a32:	1000                	addi	s0,sp,32
    80000a34:	892a                	mv	s2,a0
  acquire(&kmem.lock);
    80000a36:	00012497          	auipc	s1,0x12
    80000a3a:	9f248493          	addi	s1,s1,-1550 # 80012428 <kmem>
    80000a3e:	8526                	mv	a0,s1
    80000a40:	236000ef          	jal	80000c76 <acquire>
  stats->total_allocated_pages = kmem.total_allocated_pages;
    80000a44:	709c                	ld	a5,32(s1)
    80000a46:	00f93023          	sd	a5,0(s2)
  stats->total_freed_pages = kmem.total_freed_pages;
    80000a4a:	749c                	ld	a5,40(s1)
    80000a4c:	00f93423          	sd	a5,8(s2)
  stats->current_allocated_pages = kmem.current_allocated_pages;
    80000a50:	7898                	ld	a4,48(s1)
    80000a52:	00e93823          	sd	a4,16(s2)
  stats->available_pages = kmem.total_physical_pages - kmem.current_allocated_pages;
    80000a56:	7c9c                	ld	a5,56(s1)
    80000a58:	8f99                	sub	a5,a5,a4
    80000a5a:	00f93c23          	sd	a5,24(s2)
  release(&kmem.lock);
    80000a5e:	8526                	mv	a0,s1
    80000a60:	2a2000ef          	jal	80000d02 <release>
}
    80000a64:	60e2                	ld	ra,24(sp)
    80000a66:	6442                	ld	s0,16(sp)
    80000a68:	64a2                	ld	s1,8(sp)
    80000a6a:	6902                	ld	s2,0(sp)
    80000a6c:	6105                	addi	sp,sp,32
    80000a6e:	8082                	ret

0000000080000a70 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a70:	1101                	addi	sp,sp,-32
    80000a72:	ec06                	sd	ra,24(sp)
    80000a74:	e822                	sd	s0,16(sp)
    80000a76:	e426                	sd	s1,8(sp)
    80000a78:	e04a                	sd	s2,0(sp)
    80000a7a:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000a7c:	03451793          	slli	a5,a0,0x34
    80000a80:	e7b5                	bnez	a5,80000aec <kfree+0x7c>
    80000a82:	84aa                	mv	s1,a0
    80000a84:	00023797          	auipc	a5,0x23
    80000a88:	bfc78793          	addi	a5,a5,-1028 # 80023680 <end>
    80000a8c:	06f56063          	bltu	a0,a5,80000aec <kfree+0x7c>
    80000a90:	47c5                	li	a5,17
    80000a92:	07ee                	slli	a5,a5,0x1b
    80000a94:	04f57c63          	bgeu	a0,a5,80000aec <kfree+0x7c>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a98:	6605                	lui	a2,0x1
    80000a9a:	4585                	li	a1,1
    80000a9c:	29e000ef          	jal	80000d3a <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000aa0:	00012917          	auipc	s2,0x12
    80000aa4:	98890913          	addi	s2,s2,-1656 # 80012428 <kmem>
    80000aa8:	854a                	mv	a0,s2
    80000aaa:	1cc000ef          	jal	80000c76 <acquire>
  if (!kmem.initializing) {
    80000aae:	04092783          	lw	a5,64(s2)
    80000ab2:	ef91                	bnez	a5,80000ace <kfree+0x5e>
    kmem.total_freed_pages++;
    80000ab4:	02893703          	ld	a4,40(s2)
    80000ab8:	0705                	addi	a4,a4,1
    80000aba:	02e93423          	sd	a4,40(s2)
    if (kmem.current_allocated_pages > 0)
    80000abe:	03093783          	ld	a5,48(s2)
    80000ac2:	c791                	beqz	a5,80000ace <kfree+0x5e>
      kmem.current_allocated_pages--;
    80000ac4:	17fd                	addi	a5,a5,-1
    80000ac6:	00012717          	auipc	a4,0x12
    80000aca:	98f73923          	sd	a5,-1646(a4) # 80012458 <kmem+0x30>
  }
  r->next = kmem.freelist;
    80000ace:	00012517          	auipc	a0,0x12
    80000ad2:	95a50513          	addi	a0,a0,-1702 # 80012428 <kmem>
    80000ad6:	6d1c                	ld	a5,24(a0)
    80000ad8:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000ada:	ed04                	sd	s1,24(a0)
  release(&kmem.lock);
    80000adc:	226000ef          	jal	80000d02 <release>
}
    80000ae0:	60e2                	ld	ra,24(sp)
    80000ae2:	6442                	ld	s0,16(sp)
    80000ae4:	64a2                	ld	s1,8(sp)
    80000ae6:	6902                	ld	s2,0(sp)
    80000ae8:	6105                	addi	sp,sp,32
    80000aea:	8082                	ret
    panic("kfree");
    80000aec:	00006517          	auipc	a0,0x6
    80000af0:	54c50513          	addi	a0,a0,1356 # 80007038 <etext+0x38>
    80000af4:	cfdff0ef          	jal	800007f0 <panic>

0000000080000af8 <freerange>:
{
    80000af8:	7179                	addi	sp,sp,-48
    80000afa:	f406                	sd	ra,40(sp)
    80000afc:	f022                	sd	s0,32(sp)
    80000afe:	ec26                	sd	s1,24(sp)
    80000b00:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000b02:	6785                	lui	a5,0x1
    80000b04:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000b08:	00e504b3          	add	s1,a0,a4
    80000b0c:	777d                	lui	a4,0xfffff
    80000b0e:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000b10:	94be                	add	s1,s1,a5
    80000b12:	0295e263          	bltu	a1,s1,80000b36 <freerange+0x3e>
    80000b16:	e84a                	sd	s2,16(sp)
    80000b18:	e44e                	sd	s3,8(sp)
    80000b1a:	e052                	sd	s4,0(sp)
    80000b1c:	892e                	mv	s2,a1
    kfree(p);
    80000b1e:	7a7d                	lui	s4,0xfffff
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000b20:	6985                	lui	s3,0x1
    kfree(p);
    80000b22:	01448533          	add	a0,s1,s4
    80000b26:	f4bff0ef          	jal	80000a70 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000b2a:	94ce                	add	s1,s1,s3
    80000b2c:	fe997be3          	bgeu	s2,s1,80000b22 <freerange+0x2a>
    80000b30:	6942                	ld	s2,16(sp)
    80000b32:	69a2                	ld	s3,8(sp)
    80000b34:	6a02                	ld	s4,0(sp)
}
    80000b36:	70a2                	ld	ra,40(sp)
    80000b38:	7402                	ld	s0,32(sp)
    80000b3a:	64e2                	ld	s1,24(sp)
    80000b3c:	6145                	addi	sp,sp,48
    80000b3e:	8082                	ret

0000000080000b40 <kinit>:
{
    80000b40:	1101                	addi	sp,sp,-32
    80000b42:	ec06                	sd	ra,24(sp)
    80000b44:	e822                	sd	s0,16(sp)
    80000b46:	e426                	sd	s1,8(sp)
    80000b48:	1000                	addi	s0,sp,32
  initlock(&kmem.lock, "kmem");
    80000b4a:	00012497          	auipc	s1,0x12
    80000b4e:	8de48493          	addi	s1,s1,-1826 # 80012428 <kmem>
    80000b52:	00006597          	auipc	a1,0x6
    80000b56:	4ee58593          	addi	a1,a1,1262 # 80007040 <etext+0x40>
    80000b5a:	8526                	mv	a0,s1
    80000b5c:	0a4000ef          	jal	80000c00 <initlock>
  kmem.total_physical_pages = PHYSTOP / PGSIZE;
    80000b60:	000887b7          	lui	a5,0x88
    80000b64:	fc9c                	sd	a5,56(s1)
  kmem.total_allocated_pages = 0;
    80000b66:	0204b023          	sd	zero,32(s1)
  kmem.total_freed_pages = 0;
    80000b6a:	0204b423          	sd	zero,40(s1)
  kmem.current_allocated_pages = 0;
    80000b6e:	0204b823          	sd	zero,48(s1)
  kmem.initializing = 1;
    80000b72:	4785                	li	a5,1
    80000b74:	c0bc                	sw	a5,64(s1)
  freerange(end, (void *)PHYSTOP);
    80000b76:	45c5                	li	a1,17
    80000b78:	05ee                	slli	a1,a1,0x1b
    80000b7a:	00023517          	auipc	a0,0x23
    80000b7e:	b0650513          	addi	a0,a0,-1274 # 80023680 <end>
    80000b82:	f77ff0ef          	jal	80000af8 <freerange>
  kmem.initializing = 0;
    80000b86:	0404a023          	sw	zero,64(s1)
}
    80000b8a:	60e2                	ld	ra,24(sp)
    80000b8c:	6442                	ld	s0,16(sp)
    80000b8e:	64a2                	ld	s1,8(sp)
    80000b90:	6105                	addi	sp,sp,32
    80000b92:	8082                	ret

0000000080000b94 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be totalallocated.
void *
kalloc(void)
{
    80000b94:	1101                	addi	sp,sp,-32
    80000b96:	ec06                	sd	ra,24(sp)
    80000b98:	e822                	sd	s0,16(sp)
    80000b9a:	e426                	sd	s1,8(sp)
    80000b9c:	e04a                	sd	s2,0(sp)
    80000b9e:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000ba0:	00012497          	auipc	s1,0x12
    80000ba4:	88848493          	addi	s1,s1,-1912 # 80012428 <kmem>
    80000ba8:	8526                	mv	a0,s1
    80000baa:	0cc000ef          	jal	80000c76 <acquire>
  r = kmem.freelist;
    80000bae:	0184b903          	ld	s2,24(s1)
  if (r)
    80000bb2:	04090063          	beqz	s2,80000bf2 <kalloc+0x5e>
    kmem.freelist = r->next;
    80000bb6:	00093783          	ld	a5,0(s2)
    80000bba:	ec9c                	sd	a5,24(s1)
  release(&kmem.lock);
    80000bbc:	8526                	mv	a0,s1
    80000bbe:	144000ef          	jal	80000d02 <release>

  if (r) {
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000bc2:	6605                	lui	a2,0x1
    80000bc4:	4595                	li	a1,5
    80000bc6:	854a                	mv	a0,s2
    80000bc8:	172000ef          	jal	80000d3a <memset>
    acquire(&kmem.lock);
    80000bcc:	8526                	mv	a0,s1
    80000bce:	0a8000ef          	jal	80000c76 <acquire>
    kmem.total_allocated_pages++;
    80000bd2:	709c                	ld	a5,32(s1)
    80000bd4:	0785                	addi	a5,a5,1 # 88001 <_entry-0x7ff77fff>
    80000bd6:	f09c                	sd	a5,32(s1)
    kmem.current_allocated_pages++;
    80000bd8:	789c                	ld	a5,48(s1)
    80000bda:	0785                	addi	a5,a5,1
    80000bdc:	f89c                	sd	a5,48(s1)
    release(&kmem.lock);
    80000bde:	8526                	mv	a0,s1
    80000be0:	122000ef          	jal	80000d02 <release>
  }
  return (void *)r;
}
    80000be4:	854a                	mv	a0,s2
    80000be6:	60e2                	ld	ra,24(sp)
    80000be8:	6442                	ld	s0,16(sp)
    80000bea:	64a2                	ld	s1,8(sp)
    80000bec:	6902                	ld	s2,0(sp)
    80000bee:	6105                	addi	sp,sp,32
    80000bf0:	8082                	ret
  release(&kmem.lock);
    80000bf2:	00012517          	auipc	a0,0x12
    80000bf6:	83650513          	addi	a0,a0,-1994 # 80012428 <kmem>
    80000bfa:	108000ef          	jal	80000d02 <release>
  if (r) {
    80000bfe:	b7dd                	j	80000be4 <kalloc+0x50>

0000000080000c00 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000c00:	1141                	addi	sp,sp,-16
    80000c02:	e422                	sd	s0,8(sp)
    80000c04:	0800                	addi	s0,sp,16
  lk->name = name;
    80000c06:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000c08:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000c0c:	00053823          	sd	zero,16(a0)
}
    80000c10:	6422                	ld	s0,8(sp)
    80000c12:	0141                	addi	sp,sp,16
    80000c14:	8082                	ret

0000000080000c16 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000c16:	411c                	lw	a5,0(a0)
    80000c18:	e399                	bnez	a5,80000c1e <holding+0x8>
    80000c1a:	4501                	li	a0,0
  return r;
}
    80000c1c:	8082                	ret
{
    80000c1e:	1101                	addi	sp,sp,-32
    80000c20:	ec06                	sd	ra,24(sp)
    80000c22:	e822                	sd	s0,16(sp)
    80000c24:	e426                	sd	s1,8(sp)
    80000c26:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000c28:	6904                	ld	s1,16(a0)
    80000c2a:	57f000ef          	jal	800019a8 <mycpu>
    80000c2e:	40a48533          	sub	a0,s1,a0
    80000c32:	00153513          	seqz	a0,a0
}
    80000c36:	60e2                	ld	ra,24(sp)
    80000c38:	6442                	ld	s0,16(sp)
    80000c3a:	64a2                	ld	s1,8(sp)
    80000c3c:	6105                	addi	sp,sp,32
    80000c3e:	8082                	ret

0000000080000c40 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000c40:	1101                	addi	sp,sp,-32
    80000c42:	ec06                	sd	ra,24(sp)
    80000c44:	e822                	sd	s0,16(sp)
    80000c46:	e426                	sd	s1,8(sp)
    80000c48:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000c4a:	100174f3          	csrrci	s1,sstatus,2
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000c4e:	55b000ef          	jal	800019a8 <mycpu>
    80000c52:	5d3c                	lw	a5,120(a0)
    80000c54:	cb99                	beqz	a5,80000c6a <push_off+0x2a>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000c56:	553000ef          	jal	800019a8 <mycpu>
    80000c5a:	5d3c                	lw	a5,120(a0)
    80000c5c:	2785                	addiw	a5,a5,1
    80000c5e:	dd3c                	sw	a5,120(a0)
}
    80000c60:	60e2                	ld	ra,24(sp)
    80000c62:	6442                	ld	s0,16(sp)
    80000c64:	64a2                	ld	s1,8(sp)
    80000c66:	6105                	addi	sp,sp,32
    80000c68:	8082                	ret
    mycpu()->intena = old;
    80000c6a:	53f000ef          	jal	800019a8 <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000c6e:	8085                	srli	s1,s1,0x1
    80000c70:	8885                	andi	s1,s1,1
    mycpu()->intena = old;
    80000c72:	dd64                	sw	s1,124(a0)
    80000c74:	b7cd                	j	80000c56 <push_off+0x16>

0000000080000c76 <acquire>:
{
    80000c76:	1101                	addi	sp,sp,-32
    80000c78:	ec06                	sd	ra,24(sp)
    80000c7a:	e822                	sd	s0,16(sp)
    80000c7c:	e426                	sd	s1,8(sp)
    80000c7e:	1000                	addi	s0,sp,32
    80000c80:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c82:	fbfff0ef          	jal	80000c40 <push_off>
  if (holding(lk))
    80000c86:	8526                	mv	a0,s1
    80000c88:	f8fff0ef          	jal	80000c16 <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c8c:	4705                	li	a4,1
  if (holding(lk))
    80000c8e:	ed11                	bnez	a0,80000caa <acquire+0x34>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c90:	87ba                	mv	a5,a4
    80000c92:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c96:	2781                	sext.w	a5,a5
    80000c98:	ffe5                	bnez	a5,80000c90 <acquire+0x1a>
  lk->cpu = mycpu();
    80000c9a:	50f000ef          	jal	800019a8 <mycpu>
    80000c9e:	e888                	sd	a0,16(s1)
}
    80000ca0:	60e2                	ld	ra,24(sp)
    80000ca2:	6442                	ld	s0,16(sp)
    80000ca4:	64a2                	ld	s1,8(sp)
    80000ca6:	6105                	addi	sp,sp,32
    80000ca8:	8082                	ret
    panic("acquire");
    80000caa:	00006517          	auipc	a0,0x6
    80000cae:	39e50513          	addi	a0,a0,926 # 80007048 <etext+0x48>
    80000cb2:	b3fff0ef          	jal	800007f0 <panic>

0000000080000cb6 <pop_off>:

void
pop_off(void)
{
    80000cb6:	1141                	addi	sp,sp,-16
    80000cb8:	e406                	sd	ra,8(sp)
    80000cba:	e022                	sd	s0,0(sp)
    80000cbc:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000cbe:	4eb000ef          	jal	800019a8 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000cc2:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000cc6:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000cc8:	e38d                	bnez	a5,80000cea <pop_off+0x34>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000cca:	5d3c                	lw	a5,120(a0)
    80000ccc:	02f05563          	blez	a5,80000cf6 <pop_off+0x40>
    panic("pop_off");
  c->noff -= 1;
    80000cd0:	37fd                	addiw	a5,a5,-1
    80000cd2:	0007871b          	sext.w	a4,a5
    80000cd6:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000cd8:	e709                	bnez	a4,80000ce2 <pop_off+0x2c>
    80000cda:	5d7c                	lw	a5,124(a0)
    80000cdc:	c399                	beqz	a5,80000ce2 <pop_off+0x2c>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000cde:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000ce2:	60a2                	ld	ra,8(sp)
    80000ce4:	6402                	ld	s0,0(sp)
    80000ce6:	0141                	addi	sp,sp,16
    80000ce8:	8082                	ret
    panic("pop_off - interruptible");
    80000cea:	00006517          	auipc	a0,0x6
    80000cee:	36650513          	addi	a0,a0,870 # 80007050 <etext+0x50>
    80000cf2:	affff0ef          	jal	800007f0 <panic>
    panic("pop_off");
    80000cf6:	00006517          	auipc	a0,0x6
    80000cfa:	37250513          	addi	a0,a0,882 # 80007068 <etext+0x68>
    80000cfe:	af3ff0ef          	jal	800007f0 <panic>

0000000080000d02 <release>:
{
    80000d02:	1101                	addi	sp,sp,-32
    80000d04:	ec06                	sd	ra,24(sp)
    80000d06:	e822                	sd	s0,16(sp)
    80000d08:	e426                	sd	s1,8(sp)
    80000d0a:	1000                	addi	s0,sp,32
    80000d0c:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000d0e:	f09ff0ef          	jal	80000c16 <holding>
    80000d12:	cd11                	beqz	a0,80000d2e <release+0x2c>
  lk->cpu = 0;
    80000d14:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000d18:	0310000f          	fence	rw,w
    80000d1c:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000d20:	f97ff0ef          	jal	80000cb6 <pop_off>
}
    80000d24:	60e2                	ld	ra,24(sp)
    80000d26:	6442                	ld	s0,16(sp)
    80000d28:	64a2                	ld	s1,8(sp)
    80000d2a:	6105                	addi	sp,sp,32
    80000d2c:	8082                	ret
    panic("release");
    80000d2e:	00006517          	auipc	a0,0x6
    80000d32:	34250513          	addi	a0,a0,834 # 80007070 <etext+0x70>
    80000d36:	abbff0ef          	jal	800007f0 <panic>

0000000080000d3a <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000d3a:	1141                	addi	sp,sp,-16
    80000d3c:	e422                	sd	s0,8(sp)
    80000d3e:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000d40:	ca19                	beqz	a2,80000d56 <memset+0x1c>
    80000d42:	87aa                	mv	a5,a0
    80000d44:	1602                	slli	a2,a2,0x20
    80000d46:	9201                	srli	a2,a2,0x20
    80000d48:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d4c:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000d50:	0785                	addi	a5,a5,1
    80000d52:	fee79de3          	bne	a5,a4,80000d4c <memset+0x12>
  }
  return dst;
}
    80000d56:	6422                	ld	s0,8(sp)
    80000d58:	0141                	addi	sp,sp,16
    80000d5a:	8082                	ret

0000000080000d5c <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d5c:	1141                	addi	sp,sp,-16
    80000d5e:	e422                	sd	s0,8(sp)
    80000d60:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000d62:	ca05                	beqz	a2,80000d92 <memcmp+0x36>
    80000d64:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000d68:	1682                	slli	a3,a3,0x20
    80000d6a:	9281                	srli	a3,a3,0x20
    80000d6c:	0685                	addi	a3,a3,1
    80000d6e:	96aa                	add	a3,a3,a0
    if (*s1 != *s2)
    80000d70:	00054783          	lbu	a5,0(a0)
    80000d74:	0005c703          	lbu	a4,0(a1)
    80000d78:	00e79863          	bne	a5,a4,80000d88 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d7c:	0505                	addi	a0,a0,1
    80000d7e:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000d80:	fed518e3          	bne	a0,a3,80000d70 <memcmp+0x14>
  }

  return 0;
    80000d84:	4501                	li	a0,0
    80000d86:	a019                	j	80000d8c <memcmp+0x30>
      return *s1 - *s2;
    80000d88:	40e7853b          	subw	a0,a5,a4
}
    80000d8c:	6422                	ld	s0,8(sp)
    80000d8e:	0141                	addi	sp,sp,16
    80000d90:	8082                	ret
  return 0;
    80000d92:	4501                	li	a0,0
    80000d94:	bfe5                	j	80000d8c <memcmp+0x30>

0000000080000d96 <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000d96:	1141                	addi	sp,sp,-16
    80000d98:	e422                	sd	s0,8(sp)
    80000d9a:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000d9c:	c205                	beqz	a2,80000dbc <memmove+0x26>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000d9e:	02a5e263          	bltu	a1,a0,80000dc2 <memmove+0x2c>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000da2:	1602                	slli	a2,a2,0x20
    80000da4:	9201                	srli	a2,a2,0x20
    80000da6:	00c587b3          	add	a5,a1,a2
{
    80000daa:	872a                	mv	a4,a0
      *d++ = *s++;
    80000dac:	0585                	addi	a1,a1,1
    80000dae:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffdb981>
    80000db0:	fff5c683          	lbu	a3,-1(a1)
    80000db4:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000db8:	feb79ae3          	bne	a5,a1,80000dac <memmove+0x16>

  return dst;
}
    80000dbc:	6422                	ld	s0,8(sp)
    80000dbe:	0141                	addi	sp,sp,16
    80000dc0:	8082                	ret
  if (s < d && s + n > d) {
    80000dc2:	02061693          	slli	a3,a2,0x20
    80000dc6:	9281                	srli	a3,a3,0x20
    80000dc8:	00d58733          	add	a4,a1,a3
    80000dcc:	fce57be3          	bgeu	a0,a4,80000da2 <memmove+0xc>
    d += n;
    80000dd0:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000dd2:	fff6079b          	addiw	a5,a2,-1
    80000dd6:	1782                	slli	a5,a5,0x20
    80000dd8:	9381                	srli	a5,a5,0x20
    80000dda:	fff7c793          	not	a5,a5
    80000dde:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000de0:	177d                	addi	a4,a4,-1
    80000de2:	16fd                	addi	a3,a3,-1
    80000de4:	00074603          	lbu	a2,0(a4)
    80000de8:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000dec:	fef71ae3          	bne	a4,a5,80000de0 <memmove+0x4a>
    80000df0:	b7f1                	j	80000dbc <memmove+0x26>

0000000080000df2 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000df2:	1141                	addi	sp,sp,-16
    80000df4:	e406                	sd	ra,8(sp)
    80000df6:	e022                	sd	s0,0(sp)
    80000df8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000dfa:	f9dff0ef          	jal	80000d96 <memmove>
}
    80000dfe:	60a2                	ld	ra,8(sp)
    80000e00:	6402                	ld	s0,0(sp)
    80000e02:	0141                	addi	sp,sp,16
    80000e04:	8082                	ret

0000000080000e06 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000e06:	1141                	addi	sp,sp,-16
    80000e08:	e422                	sd	s0,8(sp)
    80000e0a:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000e0c:	ce11                	beqz	a2,80000e28 <strncmp+0x22>
    80000e0e:	00054783          	lbu	a5,0(a0)
    80000e12:	cf89                	beqz	a5,80000e2c <strncmp+0x26>
    80000e14:	0005c703          	lbu	a4,0(a1)
    80000e18:	00f71a63          	bne	a4,a5,80000e2c <strncmp+0x26>
    n--, p++, q++;
    80000e1c:	367d                	addiw	a2,a2,-1
    80000e1e:	0505                	addi	a0,a0,1
    80000e20:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000e22:	f675                	bnez	a2,80000e0e <strncmp+0x8>
  if (n == 0)
    return 0;
    80000e24:	4501                	li	a0,0
    80000e26:	a801                	j	80000e36 <strncmp+0x30>
    80000e28:	4501                	li	a0,0
    80000e2a:	a031                	j	80000e36 <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000e2c:	00054503          	lbu	a0,0(a0)
    80000e30:	0005c783          	lbu	a5,0(a1)
    80000e34:	9d1d                	subw	a0,a0,a5
}
    80000e36:	6422                	ld	s0,8(sp)
    80000e38:	0141                	addi	sp,sp,16
    80000e3a:	8082                	ret

0000000080000e3c <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000e3c:	1141                	addi	sp,sp,-16
    80000e3e:	e422                	sd	s0,8(sp)
    80000e40:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000e42:	87aa                	mv	a5,a0
    80000e44:	86b2                	mv	a3,a2
    80000e46:	367d                	addiw	a2,a2,-1
    80000e48:	02d05563          	blez	a3,80000e72 <strncpy+0x36>
    80000e4c:	0785                	addi	a5,a5,1
    80000e4e:	0005c703          	lbu	a4,0(a1)
    80000e52:	fee78fa3          	sb	a4,-1(a5)
    80000e56:	0585                	addi	a1,a1,1
    80000e58:	f775                	bnez	a4,80000e44 <strncpy+0x8>
    ;
  while (n-- > 0)
    80000e5a:	873e                	mv	a4,a5
    80000e5c:	9fb5                	addw	a5,a5,a3
    80000e5e:	37fd                	addiw	a5,a5,-1
    80000e60:	00c05963          	blez	a2,80000e72 <strncpy+0x36>
    *s++ = 0;
    80000e64:	0705                	addi	a4,a4,1
    80000e66:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000e6a:	40e786bb          	subw	a3,a5,a4
    80000e6e:	fed04be3          	bgtz	a3,80000e64 <strncpy+0x28>
  return os;
}
    80000e72:	6422                	ld	s0,8(sp)
    80000e74:	0141                	addi	sp,sp,16
    80000e76:	8082                	ret

0000000080000e78 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000e78:	1141                	addi	sp,sp,-16
    80000e7a:	e422                	sd	s0,8(sp)
    80000e7c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000e7e:	02c05363          	blez	a2,80000ea4 <safestrcpy+0x2c>
    80000e82:	fff6069b          	addiw	a3,a2,-1
    80000e86:	1682                	slli	a3,a3,0x20
    80000e88:	9281                	srli	a3,a3,0x20
    80000e8a:	96ae                	add	a3,a3,a1
    80000e8c:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000e8e:	00d58963          	beq	a1,a3,80000ea0 <safestrcpy+0x28>
    80000e92:	0585                	addi	a1,a1,1
    80000e94:	0785                	addi	a5,a5,1
    80000e96:	fff5c703          	lbu	a4,-1(a1)
    80000e9a:	fee78fa3          	sb	a4,-1(a5)
    80000e9e:	fb65                	bnez	a4,80000e8e <safestrcpy+0x16>
    ;
  *s = 0;
    80000ea0:	00078023          	sb	zero,0(a5)
  return os;
}
    80000ea4:	6422                	ld	s0,8(sp)
    80000ea6:	0141                	addi	sp,sp,16
    80000ea8:	8082                	ret

0000000080000eaa <strlen>:

int
strlen(const char *s)
{
    80000eaa:	1141                	addi	sp,sp,-16
    80000eac:	e422                	sd	s0,8(sp)
    80000eae:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000eb0:	00054783          	lbu	a5,0(a0)
    80000eb4:	cf91                	beqz	a5,80000ed0 <strlen+0x26>
    80000eb6:	0505                	addi	a0,a0,1
    80000eb8:	87aa                	mv	a5,a0
    80000eba:	86be                	mv	a3,a5
    80000ebc:	0785                	addi	a5,a5,1
    80000ebe:	fff7c703          	lbu	a4,-1(a5)
    80000ec2:	ff65                	bnez	a4,80000eba <strlen+0x10>
    80000ec4:	40a6853b          	subw	a0,a3,a0
    80000ec8:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000eca:	6422                	ld	s0,8(sp)
    80000ecc:	0141                	addi	sp,sp,16
    80000ece:	8082                	ret
  for (n = 0; s[n]; n++)
    80000ed0:	4501                	li	a0,0
    80000ed2:	bfe5                	j	80000eca <strlen+0x20>

0000000080000ed4 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000ed4:	1141                	addi	sp,sp,-16
    80000ed6:	e406                	sd	ra,8(sp)
    80000ed8:	e022                	sd	s0,0(sp)
    80000eda:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000edc:	2bd000ef          	jal	80001998 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000ee0:	00009717          	auipc	a4,0x9
    80000ee4:	45070713          	addi	a4,a4,1104 # 8000a330 <started>
  if (cpuid() == 0) {
    80000ee8:	c51d                	beqz	a0,80000f16 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000eea:	431c                	lw	a5,0(a4)
    80000eec:	0230000f          	fence	r,rw
    80000ef0:	2781                	sext.w	a5,a5
    80000ef2:	dfe5                	beqz	a5,80000eea <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000ef4:	2a5000ef          	jal	80001998 <cpuid>
    80000ef8:	85aa                	mv	a1,a0
    80000efa:	00006517          	auipc	a0,0x6
    80000efe:	19e50513          	addi	a0,a0,414 # 80007098 <etext+0x98>
    80000f02:	e08ff0ef          	jal	8000050a <printk>
    kvminithart();  // turn on paging
    80000f06:	082000ef          	jal	80000f88 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000f0a:	61c010ef          	jal	80002526 <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000f0e:	12b040ef          	jal	80005838 <plicinithart>
  }

  scheduler();
    80000f12:	71d000ef          	jal	80001e2e <scheduler>
    consoleinit();
    80000f16:	d1eff0ef          	jal	80000434 <consoleinit>
    printkinit();
    80000f1a:	913ff0ef          	jal	8000082c <printkinit>
    printk("\n");
    80000f1e:	00006517          	auipc	a0,0x6
    80000f22:	15a50513          	addi	a0,a0,346 # 80007078 <etext+0x78>
    80000f26:	de4ff0ef          	jal	8000050a <printk>
    printk("xv6 kernel is booting\n");
    80000f2a:	00006517          	auipc	a0,0x6
    80000f2e:	15650513          	addi	a0,a0,342 # 80007080 <etext+0x80>
    80000f32:	dd8ff0ef          	jal	8000050a <printk>
    printk("\n");
    80000f36:	00006517          	auipc	a0,0x6
    80000f3a:	14250513          	addi	a0,a0,322 # 80007078 <etext+0x78>
    80000f3e:	dccff0ef          	jal	8000050a <printk>
    kinit();            // physical page allocator
    80000f42:	bffff0ef          	jal	80000b40 <kinit>
    kvminit();          // create kernel page table
    80000f46:	2cc000ef          	jal	80001212 <kvminit>
    kvminithart();      // turn on paging
    80000f4a:	03e000ef          	jal	80000f88 <kvminithart>
    procinit();         // process table
    80000f4e:	195000ef          	jal	800018e2 <procinit>
    trapinit();         // trap vectors
    80000f52:	5b0010ef          	jal	80002502 <trapinit>
    trapinithart();     // install kernel trap vector
    80000f56:	5d0010ef          	jal	80002526 <trapinithart>
    plicinit();         // set up interrupt controller
    80000f5a:	0c5040ef          	jal	8000581e <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000f5e:	0db040ef          	jal	80005838 <plicinithart>
    binit();            // buffer cache
    80000f62:	5cb010ef          	jal	80002d2c <binit>
    iinit();            // inode table
    80000f66:	350020ef          	jal	800032b6 <iinit>
    fileinit();         // file table
    80000f6a:	342030ef          	jal	800042ac <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f6e:	1c3040ef          	jal	80005930 <virtio_disk_init>
    userinit();         // first user process
    80000f72:	511000ef          	jal	80001c82 <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000f76:	00009797          	auipc	a5,0x9
    80000f7a:	3ba78793          	addi	a5,a5,954 # 8000a330 <started>
    80000f7e:	4705                	li	a4,1
    80000f80:	0310000f          	fence	rw,w
    80000f84:	c398                	sw	a4,0(a5)
    80000f86:	b771                	j	80000f12 <main+0x3e>

0000000080000f88 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f88:	1141                	addi	sp,sp,-16
    80000f8a:	e422                	sd	s0,8(sp)
    80000f8c:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f8e:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f92:	00009797          	auipc	a5,0x9
    80000f96:	3a67b783          	ld	a5,934(a5) # 8000a338 <kernel_pagetable>
    80000f9a:	83b1                	srli	a5,a5,0xc
    80000f9c:	577d                	li	a4,-1
    80000f9e:	177e                	slli	a4,a4,0x3f
    80000fa0:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000fa2:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000fa6:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000faa:	6422                	ld	s0,8(sp)
    80000fac:	0141                	addi	sp,sp,16
    80000fae:	8082                	ret

0000000080000fb0 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000fb0:	7139                	addi	sp,sp,-64
    80000fb2:	fc06                	sd	ra,56(sp)
    80000fb4:	f822                	sd	s0,48(sp)
    80000fb6:	f426                	sd	s1,40(sp)
    80000fb8:	f04a                	sd	s2,32(sp)
    80000fba:	ec4e                	sd	s3,24(sp)
    80000fbc:	e852                	sd	s4,16(sp)
    80000fbe:	e456                	sd	s5,8(sp)
    80000fc0:	e05a                	sd	s6,0(sp)
    80000fc2:	0080                	addi	s0,sp,64
    80000fc4:	84aa                	mv	s1,a0
    80000fc6:	89ae                	mv	s3,a1
    80000fc8:	8ab2                	mv	s5,a2
  if (va >= MAXVA)
    80000fca:	57fd                	li	a5,-1
    80000fcc:	83e9                	srli	a5,a5,0x1a
    80000fce:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000fd0:	4b31                	li	s6,12
  if (va >= MAXVA)
    80000fd2:	02b7fc63          	bgeu	a5,a1,8000100a <walk+0x5a>
    panic("walk");
    80000fd6:	00006517          	auipc	a0,0x6
    80000fda:	0da50513          	addi	a0,a0,218 # 800070b0 <etext+0xb0>
    80000fde:	813ff0ef          	jal	800007f0 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if (*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000fe2:	060a8263          	beqz	s5,80001046 <walk+0x96>
    80000fe6:	bafff0ef          	jal	80000b94 <kalloc>
    80000fea:	84aa                	mv	s1,a0
    80000fec:	c139                	beqz	a0,80001032 <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000fee:	6605                	lui	a2,0x1
    80000ff0:	4581                	li	a1,0
    80000ff2:	d49ff0ef          	jal	80000d3a <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000ff6:	00c4d793          	srli	a5,s1,0xc
    80000ffa:	07aa                	slli	a5,a5,0xa
    80000ffc:	0017e793          	ori	a5,a5,1
    80001000:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--) {
    80001004:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffdb977>
    80001006:	036a0063          	beq	s4,s6,80001026 <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    8000100a:	0149d933          	srl	s2,s3,s4
    8000100e:	1ff97913          	andi	s2,s2,511
    80001012:	090e                	slli	s2,s2,0x3
    80001014:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80001016:	00093483          	ld	s1,0(s2)
    8000101a:	0014f793          	andi	a5,s1,1
    8000101e:	d3f1                	beqz	a5,80000fe2 <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80001020:	80a9                	srli	s1,s1,0xa
    80001022:	04b2                	slli	s1,s1,0xc
    80001024:	b7c5                	j	80001004 <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80001026:	00c9d513          	srli	a0,s3,0xc
    8000102a:	1ff57513          	andi	a0,a0,511
    8000102e:	050e                	slli	a0,a0,0x3
    80001030:	9526                	add	a0,a0,s1
}
    80001032:	70e2                	ld	ra,56(sp)
    80001034:	7442                	ld	s0,48(sp)
    80001036:	74a2                	ld	s1,40(sp)
    80001038:	7902                	ld	s2,32(sp)
    8000103a:	69e2                	ld	s3,24(sp)
    8000103c:	6a42                	ld	s4,16(sp)
    8000103e:	6aa2                	ld	s5,8(sp)
    80001040:	6b02                	ld	s6,0(sp)
    80001042:	6121                	addi	sp,sp,64
    80001044:	8082                	ret
        return 0;
    80001046:	4501                	li	a0,0
    80001048:	b7ed                	j	80001032 <walk+0x82>

000000008000104a <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    8000104a:	57fd                	li	a5,-1
    8000104c:	83e9                	srli	a5,a5,0x1a
    8000104e:	00b7f463          	bgeu	a5,a1,80001056 <walkaddr+0xc>
    return 0;
    80001052:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001054:	8082                	ret
{
    80001056:	1141                	addi	sp,sp,-16
    80001058:	e406                	sd	ra,8(sp)
    8000105a:	e022                	sd	s0,0(sp)
    8000105c:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000105e:	4601                	li	a2,0
    80001060:	f51ff0ef          	jal	80000fb0 <walk>
  if (pte == 0)
    80001064:	c105                	beqz	a0,80001084 <walkaddr+0x3a>
  if ((*pte & PTE_V) == 0)
    80001066:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    80001068:	0117f693          	andi	a3,a5,17
    8000106c:	4745                	li	a4,17
    return 0;
    8000106e:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    80001070:	00e68663          	beq	a3,a4,8000107c <walkaddr+0x32>
}
    80001074:	60a2                	ld	ra,8(sp)
    80001076:	6402                	ld	s0,0(sp)
    80001078:	0141                	addi	sp,sp,16
    8000107a:	8082                	ret
  pa = PTE2PA(*pte);
    8000107c:	83a9                	srli	a5,a5,0xa
    8000107e:	00c79513          	slli	a0,a5,0xc
  return pa;
    80001082:	bfcd                	j	80001074 <walkaddr+0x2a>
    return 0;
    80001084:	4501                	li	a0,0
    80001086:	b7fd                	j	80001074 <walkaddr+0x2a>

0000000080001088 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001088:	715d                	addi	sp,sp,-80
    8000108a:	e486                	sd	ra,72(sp)
    8000108c:	e0a2                	sd	s0,64(sp)
    8000108e:	fc26                	sd	s1,56(sp)
    80001090:	f84a                	sd	s2,48(sp)
    80001092:	f44e                	sd	s3,40(sp)
    80001094:	f052                	sd	s4,32(sp)
    80001096:	ec56                	sd	s5,24(sp)
    80001098:	e85a                	sd	s6,16(sp)
    8000109a:	e45e                	sd	s7,8(sp)
    8000109c:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    8000109e:	03459793          	slli	a5,a1,0x34
    800010a2:	e7a9                	bnez	a5,800010ec <mappages+0x64>
    800010a4:	8aaa                	mv	s5,a0
    800010a6:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    800010a8:	03461793          	slli	a5,a2,0x34
    800010ac:	e7b1                	bnez	a5,800010f8 <mappages+0x70>
    panic("mappages: size not aligned");

  if (size == 0)
    800010ae:	ca39                	beqz	a2,80001104 <mappages+0x7c>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    800010b0:	77fd                	lui	a5,0xfffff
    800010b2:	963e                	add	a2,a2,a5
    800010b4:	00b609b3          	add	s3,a2,a1
  a = va;
    800010b8:	892e                	mv	s2,a1
    800010ba:	40b68a33          	sub	s4,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    800010be:	6b85                	lui	s7,0x1
    800010c0:	014904b3          	add	s1,s2,s4
    if ((pte = walk(pagetable, a, 1)) == 0)
    800010c4:	4605                	li	a2,1
    800010c6:	85ca                	mv	a1,s2
    800010c8:	8556                	mv	a0,s5
    800010ca:	ee7ff0ef          	jal	80000fb0 <walk>
    800010ce:	c539                	beqz	a0,8000111c <mappages+0x94>
    if (*pte & PTE_V)
    800010d0:	611c                	ld	a5,0(a0)
    800010d2:	8b85                	andi	a5,a5,1
    800010d4:	ef95                	bnez	a5,80001110 <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010d6:	80b1                	srli	s1,s1,0xc
    800010d8:	04aa                	slli	s1,s1,0xa
    800010da:	0164e4b3          	or	s1,s1,s6
    800010de:	0014e493          	ori	s1,s1,1
    800010e2:	e104                	sd	s1,0(a0)
    if (a == last)
    800010e4:	05390863          	beq	s2,s3,80001134 <mappages+0xac>
    a += PGSIZE;
    800010e8:	995e                	add	s2,s2,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    800010ea:	bfd9                	j	800010c0 <mappages+0x38>
    panic("mappages: va not aligned");
    800010ec:	00006517          	auipc	a0,0x6
    800010f0:	fcc50513          	addi	a0,a0,-52 # 800070b8 <etext+0xb8>
    800010f4:	efcff0ef          	jal	800007f0 <panic>
    panic("mappages: size not aligned");
    800010f8:	00006517          	auipc	a0,0x6
    800010fc:	fe050513          	addi	a0,a0,-32 # 800070d8 <etext+0xd8>
    80001100:	ef0ff0ef          	jal	800007f0 <panic>
    panic("mappages: size");
    80001104:	00006517          	auipc	a0,0x6
    80001108:	ff450513          	addi	a0,a0,-12 # 800070f8 <etext+0xf8>
    8000110c:	ee4ff0ef          	jal	800007f0 <panic>
      panic("mappages: remap");
    80001110:	00006517          	auipc	a0,0x6
    80001114:	ff850513          	addi	a0,a0,-8 # 80007108 <etext+0x108>
    80001118:	ed8ff0ef          	jal	800007f0 <panic>
      return -1;
    8000111c:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    8000111e:	60a6                	ld	ra,72(sp)
    80001120:	6406                	ld	s0,64(sp)
    80001122:	74e2                	ld	s1,56(sp)
    80001124:	7942                	ld	s2,48(sp)
    80001126:	79a2                	ld	s3,40(sp)
    80001128:	7a02                	ld	s4,32(sp)
    8000112a:	6ae2                	ld	s5,24(sp)
    8000112c:	6b42                	ld	s6,16(sp)
    8000112e:	6ba2                	ld	s7,8(sp)
    80001130:	6161                	addi	sp,sp,80
    80001132:	8082                	ret
  return 0;
    80001134:	4501                	li	a0,0
    80001136:	b7e5                	j	8000111e <mappages+0x96>

0000000080001138 <kvmmap>:
{
    80001138:	1141                	addi	sp,sp,-16
    8000113a:	e406                	sd	ra,8(sp)
    8000113c:	e022                	sd	s0,0(sp)
    8000113e:	0800                	addi	s0,sp,16
    80001140:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001142:	86b2                	mv	a3,a2
    80001144:	863e                	mv	a2,a5
    80001146:	f43ff0ef          	jal	80001088 <mappages>
    8000114a:	e509                	bnez	a0,80001154 <kvmmap+0x1c>
}
    8000114c:	60a2                	ld	ra,8(sp)
    8000114e:	6402                	ld	s0,0(sp)
    80001150:	0141                	addi	sp,sp,16
    80001152:	8082                	ret
    panic("kvmmap");
    80001154:	00006517          	auipc	a0,0x6
    80001158:	fc450513          	addi	a0,a0,-60 # 80007118 <etext+0x118>
    8000115c:	e94ff0ef          	jal	800007f0 <panic>

0000000080001160 <kvmmake>:
{
    80001160:	1101                	addi	sp,sp,-32
    80001162:	ec06                	sd	ra,24(sp)
    80001164:	e822                	sd	s0,16(sp)
    80001166:	e426                	sd	s1,8(sp)
    80001168:	e04a                	sd	s2,0(sp)
    8000116a:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    8000116c:	a29ff0ef          	jal	80000b94 <kalloc>
    80001170:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001172:	6605                	lui	a2,0x1
    80001174:	4581                	li	a1,0
    80001176:	bc5ff0ef          	jal	80000d3a <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000117a:	4719                	li	a4,6
    8000117c:	6685                	lui	a3,0x1
    8000117e:	10000637          	lui	a2,0x10000
    80001182:	100005b7          	lui	a1,0x10000
    80001186:	8526                	mv	a0,s1
    80001188:	fb1ff0ef          	jal	80001138 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000118c:	4719                	li	a4,6
    8000118e:	6685                	lui	a3,0x1
    80001190:	10001637          	lui	a2,0x10001
    80001194:	100015b7          	lui	a1,0x10001
    80001198:	8526                	mv	a0,s1
    8000119a:	f9fff0ef          	jal	80001138 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000119e:	4719                	li	a4,6
    800011a0:	040006b7          	lui	a3,0x4000
    800011a4:	0c000637          	lui	a2,0xc000
    800011a8:	0c0005b7          	lui	a1,0xc000
    800011ac:	8526                	mv	a0,s1
    800011ae:	f8bff0ef          	jal	80001138 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    800011b2:	00006917          	auipc	s2,0x6
    800011b6:	e4e90913          	addi	s2,s2,-434 # 80007000 <etext>
    800011ba:	4729                	li	a4,10
    800011bc:	80006697          	auipc	a3,0x80006
    800011c0:	e4468693          	addi	a3,a3,-444 # 7000 <_entry-0x7fff9000>
    800011c4:	4605                	li	a2,1
    800011c6:	067e                	slli	a2,a2,0x1f
    800011c8:	85b2                	mv	a1,a2
    800011ca:	8526                	mv	a0,s1
    800011cc:	f6dff0ef          	jal	80001138 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    800011d0:	46c5                	li	a3,17
    800011d2:	06ee                	slli	a3,a3,0x1b
    800011d4:	4719                	li	a4,6
    800011d6:	412686b3          	sub	a3,a3,s2
    800011da:	864a                	mv	a2,s2
    800011dc:	85ca                	mv	a1,s2
    800011de:	8526                	mv	a0,s1
    800011e0:	f59ff0ef          	jal	80001138 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011e4:	4729                	li	a4,10
    800011e6:	6685                	lui	a3,0x1
    800011e8:	00005617          	auipc	a2,0x5
    800011ec:	e1860613          	addi	a2,a2,-488 # 80006000 <_trampoline>
    800011f0:	040005b7          	lui	a1,0x4000
    800011f4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011f6:	05b2                	slli	a1,a1,0xc
    800011f8:	8526                	mv	a0,s1
    800011fa:	f3fff0ef          	jal	80001138 <kvmmap>
  proc_mapstacks(kpgtbl);
    800011fe:	8526                	mv	a0,s1
    80001200:	64a000ef          	jal	8000184a <proc_mapstacks>
}
    80001204:	8526                	mv	a0,s1
    80001206:	60e2                	ld	ra,24(sp)
    80001208:	6442                	ld	s0,16(sp)
    8000120a:	64a2                	ld	s1,8(sp)
    8000120c:	6902                	ld	s2,0(sp)
    8000120e:	6105                	addi	sp,sp,32
    80001210:	8082                	ret

0000000080001212 <kvminit>:
{
    80001212:	1141                	addi	sp,sp,-16
    80001214:	e406                	sd	ra,8(sp)
    80001216:	e022                	sd	s0,0(sp)
    80001218:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000121a:	f47ff0ef          	jal	80001160 <kvmmake>
    8000121e:	00009797          	auipc	a5,0x9
    80001222:	10a7bd23          	sd	a0,282(a5) # 8000a338 <kernel_pagetable>
}
    80001226:	60a2                	ld	ra,8(sp)
    80001228:	6402                	ld	s0,0(sp)
    8000122a:	0141                	addi	sp,sp,16
    8000122c:	8082                	ret

000000008000122e <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000122e:	1101                	addi	sp,sp,-32
    80001230:	ec06                	sd	ra,24(sp)
    80001232:	e822                	sd	s0,16(sp)
    80001234:	e426                	sd	s1,8(sp)
    80001236:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    80001238:	95dff0ef          	jal	80000b94 <kalloc>
    8000123c:	84aa                	mv	s1,a0
  if (pagetable == 0)
    8000123e:	c509                	beqz	a0,80001248 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001240:	6605                	lui	a2,0x1
    80001242:	4581                	li	a1,0
    80001244:	af7ff0ef          	jal	80000d3a <memset>
  return pagetable;
}
    80001248:	8526                	mv	a0,s1
    8000124a:	60e2                	ld	ra,24(sp)
    8000124c:	6442                	ld	s0,16(sp)
    8000124e:	64a2                	ld	s1,8(sp)
    80001250:	6105                	addi	sp,sp,32
    80001252:	8082                	ret

0000000080001254 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001254:	7139                	addi	sp,sp,-64
    80001256:	fc06                	sd	ra,56(sp)
    80001258:	f822                	sd	s0,48(sp)
    8000125a:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    8000125c:	03459793          	slli	a5,a1,0x34
    80001260:	e38d                	bnez	a5,80001282 <uvmunmap+0x2e>
    80001262:	f04a                	sd	s2,32(sp)
    80001264:	ec4e                	sd	s3,24(sp)
    80001266:	e852                	sd	s4,16(sp)
    80001268:	e456                	sd	s5,8(sp)
    8000126a:	e05a                	sd	s6,0(sp)
    8000126c:	8a2a                	mv	s4,a0
    8000126e:	892e                	mv	s2,a1
    80001270:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80001272:	0632                	slli	a2,a2,0xc
    80001274:	00b609b3          	add	s3,a2,a1
    80001278:	6b05                	lui	s6,0x1
    8000127a:	0535f963          	bgeu	a1,s3,800012cc <uvmunmap+0x78>
    8000127e:	f426                	sd	s1,40(sp)
    80001280:	a015                	j	800012a4 <uvmunmap+0x50>
    80001282:	f426                	sd	s1,40(sp)
    80001284:	f04a                	sd	s2,32(sp)
    80001286:	ec4e                	sd	s3,24(sp)
    80001288:	e852                	sd	s4,16(sp)
    8000128a:	e456                	sd	s5,8(sp)
    8000128c:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    8000128e:	00006517          	auipc	a0,0x6
    80001292:	e9250513          	addi	a0,a0,-366 # 80007120 <etext+0x120>
    80001296:	d5aff0ef          	jal	800007f0 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    8000129a:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8000129e:	995a                	add	s2,s2,s6
    800012a0:	03397563          	bgeu	s2,s3,800012ca <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    800012a4:	4601                	li	a2,0
    800012a6:	85ca                	mv	a1,s2
    800012a8:	8552                	mv	a0,s4
    800012aa:	d07ff0ef          	jal	80000fb0 <walk>
    800012ae:	84aa                	mv	s1,a0
    800012b0:	d57d                	beqz	a0,8000129e <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    800012b2:	611c                	ld	a5,0(a0)
    800012b4:	0017f713          	andi	a4,a5,1
    800012b8:	d37d                	beqz	a4,8000129e <uvmunmap+0x4a>
    if (do_free) {
    800012ba:	fe0a80e3          	beqz	s5,8000129a <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    800012be:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    800012c0:	00c79513          	slli	a0,a5,0xc
    800012c4:	facff0ef          	jal	80000a70 <kfree>
    800012c8:	bfc9                	j	8000129a <uvmunmap+0x46>
    800012ca:	74a2                	ld	s1,40(sp)
    800012cc:	7902                	ld	s2,32(sp)
    800012ce:	69e2                	ld	s3,24(sp)
    800012d0:	6a42                	ld	s4,16(sp)
    800012d2:	6aa2                	ld	s5,8(sp)
    800012d4:	6b02                	ld	s6,0(sp)
  }
}
    800012d6:	70e2                	ld	ra,56(sp)
    800012d8:	7442                	ld	s0,48(sp)
    800012da:	6121                	addi	sp,sp,64
    800012dc:	8082                	ret

00000000800012de <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800012de:	1101                	addi	sp,sp,-32
    800012e0:	ec06                	sd	ra,24(sp)
    800012e2:	e822                	sd	s0,16(sp)
    800012e4:	e426                	sd	s1,8(sp)
    800012e6:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    800012e8:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    800012ea:	00b67d63          	bgeu	a2,a1,80001304 <uvmdealloc+0x26>
    800012ee:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    800012f0:	6785                	lui	a5,0x1
    800012f2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012f4:	00f60733          	add	a4,a2,a5
    800012f8:	76fd                	lui	a3,0xfffff
    800012fa:	8f75                	and	a4,a4,a3
    800012fc:	97ae                	add	a5,a5,a1
    800012fe:	8ff5                	and	a5,a5,a3
    80001300:	00f76863          	bltu	a4,a5,80001310 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001304:	8526                	mv	a0,s1
    80001306:	60e2                	ld	ra,24(sp)
    80001308:	6442                	ld	s0,16(sp)
    8000130a:	64a2                	ld	s1,8(sp)
    8000130c:	6105                	addi	sp,sp,32
    8000130e:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001310:	8f99                	sub	a5,a5,a4
    80001312:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001314:	4685                	li	a3,1
    80001316:	0007861b          	sext.w	a2,a5
    8000131a:	85ba                	mv	a1,a4
    8000131c:	f39ff0ef          	jal	80001254 <uvmunmap>
    80001320:	b7d5                	j	80001304 <uvmdealloc+0x26>

0000000080001322 <uvmalloc>:
  if (newsz < oldsz)
    80001322:	08b66f63          	bltu	a2,a1,800013c0 <uvmalloc+0x9e>
{
    80001326:	7139                	addi	sp,sp,-64
    80001328:	fc06                	sd	ra,56(sp)
    8000132a:	f822                	sd	s0,48(sp)
    8000132c:	ec4e                	sd	s3,24(sp)
    8000132e:	e852                	sd	s4,16(sp)
    80001330:	e456                	sd	s5,8(sp)
    80001332:	0080                	addi	s0,sp,64
    80001334:	8aaa                	mv	s5,a0
    80001336:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001338:	6785                	lui	a5,0x1
    8000133a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000133c:	95be                	add	a1,a1,a5
    8000133e:	77fd                	lui	a5,0xfffff
    80001340:	00f5f9b3          	and	s3,a1,a5
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001344:	08c9f063          	bgeu	s3,a2,800013c4 <uvmalloc+0xa2>
    80001348:	f426                	sd	s1,40(sp)
    8000134a:	f04a                	sd	s2,32(sp)
    8000134c:	e05a                	sd	s6,0(sp)
    8000134e:	894e                	mv	s2,s3
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    80001350:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001354:	841ff0ef          	jal	80000b94 <kalloc>
    80001358:	84aa                	mv	s1,a0
    if (mem == 0) {
    8000135a:	c515                	beqz	a0,80001386 <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    8000135c:	6605                	lui	a2,0x1
    8000135e:	4581                	li	a1,0
    80001360:	9dbff0ef          	jal	80000d3a <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    80001364:	875a                	mv	a4,s6
    80001366:	86a6                	mv	a3,s1
    80001368:	6605                	lui	a2,0x1
    8000136a:	85ca                	mv	a1,s2
    8000136c:	8556                	mv	a0,s5
    8000136e:	d1bff0ef          	jal	80001088 <mappages>
    80001372:	e915                	bnez	a0,800013a6 <uvmalloc+0x84>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001374:	6785                	lui	a5,0x1
    80001376:	993e                	add	s2,s2,a5
    80001378:	fd496ee3          	bltu	s2,s4,80001354 <uvmalloc+0x32>
  return newsz;
    8000137c:	8552                	mv	a0,s4
    8000137e:	74a2                	ld	s1,40(sp)
    80001380:	7902                	ld	s2,32(sp)
    80001382:	6b02                	ld	s6,0(sp)
    80001384:	a811                	j	80001398 <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    80001386:	864e                	mv	a2,s3
    80001388:	85ca                	mv	a1,s2
    8000138a:	8556                	mv	a0,s5
    8000138c:	f53ff0ef          	jal	800012de <uvmdealloc>
      return 0;
    80001390:	4501                	li	a0,0
    80001392:	74a2                	ld	s1,40(sp)
    80001394:	7902                	ld	s2,32(sp)
    80001396:	6b02                	ld	s6,0(sp)
}
    80001398:	70e2                	ld	ra,56(sp)
    8000139a:	7442                	ld	s0,48(sp)
    8000139c:	69e2                	ld	s3,24(sp)
    8000139e:	6a42                	ld	s4,16(sp)
    800013a0:	6aa2                	ld	s5,8(sp)
    800013a2:	6121                	addi	sp,sp,64
    800013a4:	8082                	ret
      kfree(mem);
    800013a6:	8526                	mv	a0,s1
    800013a8:	ec8ff0ef          	jal	80000a70 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800013ac:	864e                	mv	a2,s3
    800013ae:	85ca                	mv	a1,s2
    800013b0:	8556                	mv	a0,s5
    800013b2:	f2dff0ef          	jal	800012de <uvmdealloc>
      return 0;
    800013b6:	4501                	li	a0,0
    800013b8:	74a2                	ld	s1,40(sp)
    800013ba:	7902                	ld	s2,32(sp)
    800013bc:	6b02                	ld	s6,0(sp)
    800013be:	bfe9                	j	80001398 <uvmalloc+0x76>
    return oldsz;
    800013c0:	852e                	mv	a0,a1
}
    800013c2:	8082                	ret
  return newsz;
    800013c4:	8532                	mv	a0,a2
    800013c6:	bfc9                	j	80001398 <uvmalloc+0x76>

00000000800013c8 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800013c8:	7179                	addi	sp,sp,-48
    800013ca:	f406                	sd	ra,40(sp)
    800013cc:	f022                	sd	s0,32(sp)
    800013ce:	ec26                	sd	s1,24(sp)
    800013d0:	e84a                	sd	s2,16(sp)
    800013d2:	e44e                	sd	s3,8(sp)
    800013d4:	e052                	sd	s4,0(sp)
    800013d6:	1800                	addi	s0,sp,48
    800013d8:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    800013da:	84aa                	mv	s1,a0
    800013dc:	6905                	lui	s2,0x1
    800013de:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800013e0:	4985                	li	s3,1
    800013e2:	a819                	j	800013f8 <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    800013e4:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800013e6:	00c79513          	slli	a0,a5,0xc
    800013ea:	fdfff0ef          	jal	800013c8 <freewalk>
      pagetable[i] = 0;
    800013ee:	0004b023          	sd	zero,0(s1)
  for (int i = 0; i < 512; i++) {
    800013f2:	04a1                	addi	s1,s1,8
    800013f4:	01248f63          	beq	s1,s2,80001412 <freewalk+0x4a>
    pte_t pte = pagetable[i];
    800013f8:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800013fa:	00f7f713          	andi	a4,a5,15
    800013fe:	ff3703e3          	beq	a4,s3,800013e4 <freewalk+0x1c>
    } else if (pte & PTE_V) {
    80001402:	8b85                	andi	a5,a5,1
    80001404:	d7fd                	beqz	a5,800013f2 <freewalk+0x2a>
      panic("freewalk: leaf");
    80001406:	00006517          	auipc	a0,0x6
    8000140a:	d3250513          	addi	a0,a0,-718 # 80007138 <etext+0x138>
    8000140e:	be2ff0ef          	jal	800007f0 <panic>
    }
  }
  kfree((void *)pagetable);
    80001412:	8552                	mv	a0,s4
    80001414:	e5cff0ef          	jal	80000a70 <kfree>
}
    80001418:	70a2                	ld	ra,40(sp)
    8000141a:	7402                	ld	s0,32(sp)
    8000141c:	64e2                	ld	s1,24(sp)
    8000141e:	6942                	ld	s2,16(sp)
    80001420:	69a2                	ld	s3,8(sp)
    80001422:	6a02                	ld	s4,0(sp)
    80001424:	6145                	addi	sp,sp,48
    80001426:	8082                	ret

0000000080001428 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001428:	1101                	addi	sp,sp,-32
    8000142a:	ec06                	sd	ra,24(sp)
    8000142c:	e822                	sd	s0,16(sp)
    8000142e:	e426                	sd	s1,8(sp)
    80001430:	1000                	addi	s0,sp,32
    80001432:	84aa                	mv	s1,a0
  if (sz > 0)
    80001434:	e989                	bnez	a1,80001446 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    80001436:	8526                	mv	a0,s1
    80001438:	f91ff0ef          	jal	800013c8 <freewalk>
}
    8000143c:	60e2                	ld	ra,24(sp)
    8000143e:	6442                	ld	s0,16(sp)
    80001440:	64a2                	ld	s1,8(sp)
    80001442:	6105                	addi	sp,sp,32
    80001444:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80001446:	6785                	lui	a5,0x1
    80001448:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000144a:	95be                	add	a1,a1,a5
    8000144c:	4685                	li	a3,1
    8000144e:	00c5d613          	srli	a2,a1,0xc
    80001452:	4581                	li	a1,0
    80001454:	e01ff0ef          	jal	80001254 <uvmunmap>
    80001458:	bff9                	j	80001436 <uvmfree+0xe>

000000008000145a <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    8000145a:	ce49                	beqz	a2,800014f4 <uvmcopy+0x9a>
{
    8000145c:	715d                	addi	sp,sp,-80
    8000145e:	e486                	sd	ra,72(sp)
    80001460:	e0a2                	sd	s0,64(sp)
    80001462:	fc26                	sd	s1,56(sp)
    80001464:	f84a                	sd	s2,48(sp)
    80001466:	f44e                	sd	s3,40(sp)
    80001468:	f052                	sd	s4,32(sp)
    8000146a:	ec56                	sd	s5,24(sp)
    8000146c:	e85a                	sd	s6,16(sp)
    8000146e:	e45e                	sd	s7,8(sp)
    80001470:	0880                	addi	s0,sp,80
    80001472:	8aaa                	mv	s5,a0
    80001474:	8b2e                	mv	s6,a1
    80001476:	8a32                	mv	s4,a2
  for (i = 0; i < sz; i += PGSIZE) {
    80001478:	4481                	li	s1,0
    8000147a:	a029                	j	80001484 <uvmcopy+0x2a>
    8000147c:	6785                	lui	a5,0x1
    8000147e:	94be                	add	s1,s1,a5
    80001480:	0544fe63          	bgeu	s1,s4,800014dc <uvmcopy+0x82>
    if ((pte = walk(old, i, 0)) == 0)
    80001484:	4601                	li	a2,0
    80001486:	85a6                	mv	a1,s1
    80001488:	8556                	mv	a0,s5
    8000148a:	b27ff0ef          	jal	80000fb0 <walk>
    8000148e:	d57d                	beqz	a0,8000147c <uvmcopy+0x22>
      continue; // page table entry hasn't been allocated
    if ((*pte & PTE_V) == 0)
    80001490:	6118                	ld	a4,0(a0)
    80001492:	00177793          	andi	a5,a4,1
    80001496:	d3fd                	beqz	a5,8000147c <uvmcopy+0x22>
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    80001498:	00a75593          	srli	a1,a4,0xa
    8000149c:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800014a0:	3ff77913          	andi	s2,a4,1023
    if ((mem = kalloc()) == 0)
    800014a4:	ef0ff0ef          	jal	80000b94 <kalloc>
    800014a8:	89aa                	mv	s3,a0
    800014aa:	c105                	beqz	a0,800014ca <uvmcopy+0x70>
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    800014ac:	6605                	lui	a2,0x1
    800014ae:	85de                	mv	a1,s7
    800014b0:	8e7ff0ef          	jal	80000d96 <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    800014b4:	874a                	mv	a4,s2
    800014b6:	86ce                	mv	a3,s3
    800014b8:	6605                	lui	a2,0x1
    800014ba:	85a6                	mv	a1,s1
    800014bc:	855a                	mv	a0,s6
    800014be:	bcbff0ef          	jal	80001088 <mappages>
    800014c2:	dd4d                	beqz	a0,8000147c <uvmcopy+0x22>
      kfree(mem);
    800014c4:	854e                	mv	a0,s3
    800014c6:	daaff0ef          	jal	80000a70 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800014ca:	4685                	li	a3,1
    800014cc:	00c4d613          	srli	a2,s1,0xc
    800014d0:	4581                	li	a1,0
    800014d2:	855a                	mv	a0,s6
    800014d4:	d81ff0ef          	jal	80001254 <uvmunmap>
  return -1;
    800014d8:	557d                	li	a0,-1
    800014da:	a011                	j	800014de <uvmcopy+0x84>
  return 0;
    800014dc:	4501                	li	a0,0
}
    800014de:	60a6                	ld	ra,72(sp)
    800014e0:	6406                	ld	s0,64(sp)
    800014e2:	74e2                	ld	s1,56(sp)
    800014e4:	7942                	ld	s2,48(sp)
    800014e6:	79a2                	ld	s3,40(sp)
    800014e8:	7a02                	ld	s4,32(sp)
    800014ea:	6ae2                	ld	s5,24(sp)
    800014ec:	6b42                	ld	s6,16(sp)
    800014ee:	6ba2                	ld	s7,8(sp)
    800014f0:	6161                	addi	sp,sp,80
    800014f2:	8082                	ret
  return 0;
    800014f4:	4501                	li	a0,0
}
    800014f6:	8082                	ret

00000000800014f8 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014f8:	1141                	addi	sp,sp,-16
    800014fa:	e406                	sd	ra,8(sp)
    800014fc:	e022                	sd	s0,0(sp)
    800014fe:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    80001500:	4601                	li	a2,0
    80001502:	aafff0ef          	jal	80000fb0 <walk>
  if (pte == 0)
    80001506:	c901                	beqz	a0,80001516 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001508:	611c                	ld	a5,0(a0)
    8000150a:	9bbd                	andi	a5,a5,-17
    8000150c:	e11c                	sd	a5,0(a0)
}
    8000150e:	60a2                	ld	ra,8(sp)
    80001510:	6402                	ld	s0,0(sp)
    80001512:	0141                	addi	sp,sp,16
    80001514:	8082                	ret
    panic("uvmclear");
    80001516:	00006517          	auipc	a0,0x6
    8000151a:	c3250513          	addi	a0,a0,-974 # 80007148 <etext+0x148>
    8000151e:	ad2ff0ef          	jal	800007f0 <panic>

0000000080001522 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001522:	1141                	addi	sp,sp,-16
    80001524:	e406                	sd	ra,8(sp)
    80001526:	e022                	sd	s0,0(sp)
    80001528:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    8000152a:	4601                	li	a2,0
    8000152c:	a85ff0ef          	jal	80000fb0 <walk>
  if (pte == 0) {
    80001530:	c519                	beqz	a0,8000153e <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V) {
    80001532:	6108                	ld	a0,0(a0)
    80001534:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001536:	60a2                	ld	ra,8(sp)
    80001538:	6402                	ld	s0,0(sp)
    8000153a:	0141                	addi	sp,sp,16
    8000153c:	8082                	ret
    return 0;
    8000153e:	4501                	li	a0,0
    80001540:	bfdd                	j	80001536 <ismapped+0x14>

0000000080001542 <vmfault>:
{
    80001542:	7179                	addi	sp,sp,-48
    80001544:	f406                	sd	ra,40(sp)
    80001546:	f022                	sd	s0,32(sp)
    80001548:	e44e                	sd	s3,8(sp)
    8000154a:	1800                	addi	s0,sp,48
    return 0;
    8000154c:	4981                	li	s3,0
  if (va >= psz)
    8000154e:	00b66863          	bltu	a2,a1,8000155e <vmfault+0x1c>
}
    80001552:	854e                	mv	a0,s3
    80001554:	70a2                	ld	ra,40(sp)
    80001556:	7402                	ld	s0,32(sp)
    80001558:	69a2                	ld	s3,8(sp)
    8000155a:	6145                	addi	sp,sp,48
    8000155c:	8082                	ret
    8000155e:	ec26                	sd	s1,24(sp)
    80001560:	e84a                	sd	s2,16(sp)
    80001562:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    80001564:	77fd                	lui	a5,0xfffff
    80001566:	00f674b3          	and	s1,a2,a5
  if (ismapped(pagetable, va)) {
    8000156a:	85a6                	mv	a1,s1
    8000156c:	fb7ff0ef          	jal	80001522 <ismapped>
    return 0;
    80001570:	4981                	li	s3,0
  if (ismapped(pagetable, va)) {
    80001572:	c501                	beqz	a0,8000157a <vmfault+0x38>
    80001574:	64e2                	ld	s1,24(sp)
    80001576:	6942                	ld	s2,16(sp)
    80001578:	bfe9                	j	80001552 <vmfault+0x10>
    8000157a:	e052                	sd	s4,0(sp)
  mem = (uint64)kalloc();
    8000157c:	e18ff0ef          	jal	80000b94 <kalloc>
    80001580:	8a2a                	mv	s4,a0
  if (mem == 0)
    80001582:	c915                	beqz	a0,800015b6 <vmfault+0x74>
  mem = (uint64)kalloc();
    80001584:	89aa                	mv	s3,a0
  memset((void *)mem, 0, PGSIZE);
    80001586:	6605                	lui	a2,0x1
    80001588:	4581                	li	a1,0
    8000158a:	fb0ff0ef          	jal	80000d3a <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    8000158e:	4759                	li	a4,22
    80001590:	86d2                	mv	a3,s4
    80001592:	6605                	lui	a2,0x1
    80001594:	85a6                	mv	a1,s1
    80001596:	854a                	mv	a0,s2
    80001598:	af1ff0ef          	jal	80001088 <mappages>
    8000159c:	e509                	bnez	a0,800015a6 <vmfault+0x64>
    8000159e:	64e2                	ld	s1,24(sp)
    800015a0:	6942                	ld	s2,16(sp)
    800015a2:	6a02                	ld	s4,0(sp)
    800015a4:	b77d                	j	80001552 <vmfault+0x10>
    kfree((void *)mem);
    800015a6:	8552                	mv	a0,s4
    800015a8:	cc8ff0ef          	jal	80000a70 <kfree>
    return 0;
    800015ac:	4981                	li	s3,0
    800015ae:	64e2                	ld	s1,24(sp)
    800015b0:	6942                	ld	s2,16(sp)
    800015b2:	6a02                	ld	s4,0(sp)
    800015b4:	bf79                	j	80001552 <vmfault+0x10>
    800015b6:	64e2                	ld	s1,24(sp)
    800015b8:	6942                	ld	s2,16(sp)
    800015ba:	6a02                	ld	s4,0(sp)
    800015bc:	bf59                	j	80001552 <vmfault+0x10>

00000000800015be <copyout>:
  while (len > 0) {
    800015be:	c745                	beqz	a4,80001666 <copyout+0xa8>
{
    800015c0:	7159                	addi	sp,sp,-112
    800015c2:	f486                	sd	ra,104(sp)
    800015c4:	f0a2                	sd	s0,96(sp)
    800015c6:	eca6                	sd	s1,88(sp)
    800015c8:	e0d2                	sd	s4,64(sp)
    800015ca:	f85a                	sd	s6,48(sp)
    800015cc:	f45e                	sd	s7,40(sp)
    800015ce:	f062                	sd	s8,32(sp)
    800015d0:	e46e                	sd	s11,8(sp)
    800015d2:	1880                	addi	s0,sp,112
    800015d4:	8c2a                	mv	s8,a0
    800015d6:	8dae                	mv	s11,a1
    800015d8:	8b32                	mv	s6,a2
    800015da:	8bb6                	mv	s7,a3
    800015dc:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(dstva);
    800015de:	74fd                	lui	s1,0xfffff
    800015e0:	8cf1                	and	s1,s1,a2
    if (va0 >= MAXVA)
    800015e2:	57fd                	li	a5,-1
    800015e4:	83e9                	srli	a5,a5,0x1a
    800015e6:	0897e263          	bltu	a5,s1,8000166a <copyout+0xac>
    800015ea:	e8ca                	sd	s2,80(sp)
    800015ec:	e4ce                	sd	s3,72(sp)
    800015ee:	fc56                	sd	s5,56(sp)
    800015f0:	ec66                	sd	s9,24(sp)
    800015f2:	e86a                	sd	s10,16(sp)
    800015f4:	6d05                	lui	s10,0x1
    800015f6:	8cbe                	mv	s9,a5
    800015f8:	a015                	j	8000161c <copyout+0x5e>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    800015fa:	409b0533          	sub	a0,s6,s1
    800015fe:	0009861b          	sext.w	a2,s3
    80001602:	85de                	mv	a1,s7
    80001604:	954a                	add	a0,a0,s2
    80001606:	f90ff0ef          	jal	80000d96 <memmove>
    len -= n;
    8000160a:	413a0a33          	sub	s4,s4,s3
    src += n;
    8000160e:	9bce                	add	s7,s7,s3
  while (len > 0) {
    80001610:	040a0463          	beqz	s4,80001658 <copyout+0x9a>
    if (va0 >= MAXVA)
    80001614:	055ced63          	bltu	s9,s5,8000166e <copyout+0xb0>
    80001618:	84d6                	mv	s1,s5
    8000161a:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    8000161c:	85a6                	mv	a1,s1
    8000161e:	8562                	mv	a0,s8
    80001620:	a2bff0ef          	jal	8000104a <walkaddr>
    80001624:	892a                	mv	s2,a0
    if (pa0 == 0) {
    80001626:	e909                	bnez	a0,80001638 <copyout+0x7a>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    80001628:	4681                	li	a3,0
    8000162a:	8626                	mv	a2,s1
    8000162c:	85ee                	mv	a1,s11
    8000162e:	8562                	mv	a0,s8
    80001630:	f13ff0ef          	jal	80001542 <vmfault>
    80001634:	892a                	mv	s2,a0
    80001636:	c139                	beqz	a0,8000167c <copyout+0xbe>
    pte = walk(pagetable, va0, 0);
    80001638:	4601                	li	a2,0
    8000163a:	85a6                	mv	a1,s1
    8000163c:	8562                	mv	a0,s8
    8000163e:	973ff0ef          	jal	80000fb0 <walk>
    if ((*pte & PTE_W) == 0)
    80001642:	611c                	ld	a5,0(a0)
    80001644:	8b91                	andi	a5,a5,4
    80001646:	c3b1                	beqz	a5,8000168a <copyout+0xcc>
    n = PGSIZE - (dstva - va0);
    80001648:	01a48ab3          	add	s5,s1,s10
    8000164c:	416a89b3          	sub	s3,s5,s6
    if (n > len)
    80001650:	fb3a75e3          	bgeu	s4,s3,800015fa <copyout+0x3c>
    80001654:	89d2                	mv	s3,s4
    80001656:	b755                	j	800015fa <copyout+0x3c>
  return 0;
    80001658:	4501                	li	a0,0
    8000165a:	6946                	ld	s2,80(sp)
    8000165c:	69a6                	ld	s3,72(sp)
    8000165e:	7ae2                	ld	s5,56(sp)
    80001660:	6ce2                	ld	s9,24(sp)
    80001662:	6d42                	ld	s10,16(sp)
    80001664:	a80d                	j	80001696 <copyout+0xd8>
    80001666:	4501                	li	a0,0
}
    80001668:	8082                	ret
      return -1;
    8000166a:	557d                	li	a0,-1
    8000166c:	a02d                	j	80001696 <copyout+0xd8>
    8000166e:	557d                	li	a0,-1
    80001670:	6946                	ld	s2,80(sp)
    80001672:	69a6                	ld	s3,72(sp)
    80001674:	7ae2                	ld	s5,56(sp)
    80001676:	6ce2                	ld	s9,24(sp)
    80001678:	6d42                	ld	s10,16(sp)
    8000167a:	a831                	j	80001696 <copyout+0xd8>
        return -1;
    8000167c:	557d                	li	a0,-1
    8000167e:	6946                	ld	s2,80(sp)
    80001680:	69a6                	ld	s3,72(sp)
    80001682:	7ae2                	ld	s5,56(sp)
    80001684:	6ce2                	ld	s9,24(sp)
    80001686:	6d42                	ld	s10,16(sp)
    80001688:	a039                	j	80001696 <copyout+0xd8>
      return -1;
    8000168a:	557d                	li	a0,-1
    8000168c:	6946                	ld	s2,80(sp)
    8000168e:	69a6                	ld	s3,72(sp)
    80001690:	7ae2                	ld	s5,56(sp)
    80001692:	6ce2                	ld	s9,24(sp)
    80001694:	6d42                	ld	s10,16(sp)
}
    80001696:	70a6                	ld	ra,104(sp)
    80001698:	7406                	ld	s0,96(sp)
    8000169a:	64e6                	ld	s1,88(sp)
    8000169c:	6a06                	ld	s4,64(sp)
    8000169e:	7b42                	ld	s6,48(sp)
    800016a0:	7ba2                	ld	s7,40(sp)
    800016a2:	7c02                	ld	s8,32(sp)
    800016a4:	6da2                	ld	s11,8(sp)
    800016a6:	6165                	addi	sp,sp,112
    800016a8:	8082                	ret

00000000800016aa <copyin>:
  while (len > 0) {
    800016aa:	cb49                	beqz	a4,8000173c <copyin+0x92>
{
    800016ac:	711d                	addi	sp,sp,-96
    800016ae:	ec86                	sd	ra,88(sp)
    800016b0:	e8a2                	sd	s0,80(sp)
    800016b2:	e4a6                	sd	s1,72(sp)
    800016b4:	e0ca                	sd	s2,64(sp)
    800016b6:	fc4e                	sd	s3,56(sp)
    800016b8:	f852                	sd	s4,48(sp)
    800016ba:	f456                	sd	s5,40(sp)
    800016bc:	f05a                	sd	s6,32(sp)
    800016be:	ec5e                	sd	s7,24(sp)
    800016c0:	e862                	sd	s8,16(sp)
    800016c2:	e466                	sd	s9,8(sp)
    800016c4:	1080                	addi	s0,sp,96
    800016c6:	8baa                	mv	s7,a0
    800016c8:	8cae                	mv	s9,a1
    800016ca:	8ab2                	mv	s5,a2
    800016cc:	8936                	mv	s2,a3
    800016ce:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    800016d0:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800016d2:	6b05                	lui	s6,0x1
    800016d4:	a035                	j	80001700 <copyin+0x56>
    800016d6:	412984b3          	sub	s1,s3,s2
    800016da:	94da                	add	s1,s1,s6
    if (n > len)
    800016dc:	009a7363          	bgeu	s4,s1,800016e2 <copyin+0x38>
    800016e0:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800016e2:	413905b3          	sub	a1,s2,s3
    800016e6:	0004861b          	sext.w	a2,s1
    800016ea:	95aa                	add	a1,a1,a0
    800016ec:	8556                	mv	a0,s5
    800016ee:	ea8ff0ef          	jal	80000d96 <memmove>
    len -= n;
    800016f2:	409a0a33          	sub	s4,s4,s1
    dst += n;
    800016f6:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    800016f8:	01698933          	add	s2,s3,s6
  while (len > 0) {
    800016fc:	020a0263          	beqz	s4,80001720 <copyin+0x76>
    va0 = PGROUNDDOWN(srcva);
    80001700:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001704:	85ce                	mv	a1,s3
    80001706:	855e                	mv	a0,s7
    80001708:	943ff0ef          	jal	8000104a <walkaddr>
    if (pa0 == 0) {
    8000170c:	f569                	bnez	a0,800016d6 <copyin+0x2c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    8000170e:	4685                	li	a3,1
    80001710:	864e                	mv	a2,s3
    80001712:	85e6                	mv	a1,s9
    80001714:	855e                	mv	a0,s7
    80001716:	e2dff0ef          	jal	80001542 <vmfault>
    8000171a:	fd55                	bnez	a0,800016d6 <copyin+0x2c>
        return -1;
    8000171c:	557d                	li	a0,-1
    8000171e:	a011                	j	80001722 <copyin+0x78>
  return 0;
    80001720:	4501                	li	a0,0
}
    80001722:	60e6                	ld	ra,88(sp)
    80001724:	6446                	ld	s0,80(sp)
    80001726:	64a6                	ld	s1,72(sp)
    80001728:	6906                	ld	s2,64(sp)
    8000172a:	79e2                	ld	s3,56(sp)
    8000172c:	7a42                	ld	s4,48(sp)
    8000172e:	7aa2                	ld	s5,40(sp)
    80001730:	7b02                	ld	s6,32(sp)
    80001732:	6be2                	ld	s7,24(sp)
    80001734:	6c42                	ld	s8,16(sp)
    80001736:	6ca2                	ld	s9,8(sp)
    80001738:	6125                	addi	sp,sp,96
    8000173a:	8082                	ret
  return 0;
    8000173c:	4501                	li	a0,0
}
    8000173e:	8082                	ret

0000000080001740 <copyinstr>:
  while (got_null == 0 && max > 0) {
    80001740:	c371                	beqz	a4,80001804 <copyinstr+0xc4>
{
    80001742:	715d                	addi	sp,sp,-80
    80001744:	e486                	sd	ra,72(sp)
    80001746:	e0a2                	sd	s0,64(sp)
    80001748:	fc26                	sd	s1,56(sp)
    8000174a:	f84a                	sd	s2,48(sp)
    8000174c:	f44e                	sd	s3,40(sp)
    8000174e:	f052                	sd	s4,32(sp)
    80001750:	ec56                	sd	s5,24(sp)
    80001752:	e85a                	sd	s6,16(sp)
    80001754:	e45e                	sd	s7,8(sp)
    80001756:	e062                	sd	s8,0(sp)
    80001758:	0880                	addi	s0,sp,80
    8000175a:	8a2a                	mv	s4,a0
    8000175c:	8b2e                	mv	s6,a1
    8000175e:	8bb2                	mv	s7,a2
    80001760:	8c36                	mv	s8,a3
    80001762:	893a                	mv	s2,a4
    va0 = PGROUNDDOWN(srcva);
    80001764:	7afd                	lui	s5,0xfffff
    n = PGSIZE - (srcva - va0);
    80001766:	6985                	lui	s3,0x1
    80001768:	a0b1                	j	800017b4 <copyinstr+0x74>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    8000176a:	4685                	li	a3,1
    8000176c:	8626                	mv	a2,s1
    8000176e:	85da                	mv	a1,s6
    80001770:	8552                	mv	a0,s4
    80001772:	dd1ff0ef          	jal	80001542 <vmfault>
    80001776:	e531                	bnez	a0,800017c2 <copyinstr+0x82>
        return -1;
    80001778:	557d                	li	a0,-1
    8000177a:	a039                	j	80001788 <copyinstr+0x48>
        *dst = '\0';
    8000177c:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffdb980>
    80001780:	4785                	li	a5,1
  if (got_null) {
    80001782:	37fd                	addiw	a5,a5,-1
    80001784:	0007851b          	sext.w	a0,a5
}
    80001788:	60a6                	ld	ra,72(sp)
    8000178a:	6406                	ld	s0,64(sp)
    8000178c:	74e2                	ld	s1,56(sp)
    8000178e:	7942                	ld	s2,48(sp)
    80001790:	79a2                	ld	s3,40(sp)
    80001792:	7a02                	ld	s4,32(sp)
    80001794:	6ae2                	ld	s5,24(sp)
    80001796:	6b42                	ld	s6,16(sp)
    80001798:	6ba2                	ld	s7,8(sp)
    8000179a:	6c02                	ld	s8,0(sp)
    8000179c:	6161                	addi	sp,sp,80
    8000179e:	8082                	ret
    800017a0:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    800017a4:	972a                	add	a4,a4,a0
      --max;
    800017a6:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    800017aa:	01348c33          	add	s8,s1,s3
  while (got_null == 0 && max > 0) {
    800017ae:	04e58563          	beq	a1,a4,800017f8 <copyinstr+0xb8>
{
    800017b2:	8bbe                	mv	s7,a5
    va0 = PGROUNDDOWN(srcva);
    800017b4:	015c74b3          	and	s1,s8,s5
    pa0 = walkaddr(pagetable, va0);
    800017b8:	85a6                	mv	a1,s1
    800017ba:	8552                	mv	a0,s4
    800017bc:	88fff0ef          	jal	8000104a <walkaddr>
    if (pa0 == 0) {
    800017c0:	d54d                	beqz	a0,8000176a <copyinstr+0x2a>
    n = PGSIZE - (srcva - va0);
    800017c2:	41848633          	sub	a2,s1,s8
    800017c6:	964e                	add	a2,a2,s3
    if (n > max)
    800017c8:	00c97363          	bgeu	s2,a2,800017ce <copyinstr+0x8e>
    800017cc:	864a                	mv	a2,s2
    char *p = (char *)(pa0 + (srcva - va0));
    800017ce:	409c0c33          	sub	s8,s8,s1
    800017d2:	9c2a                	add	s8,s8,a0
    while (n > 0) {
    800017d4:	c605                	beqz	a2,800017fc <copyinstr+0xbc>
    800017d6:	87de                	mv	a5,s7
    800017d8:	855e                	mv	a0,s7
      if (*p == '\0') {
    800017da:	417c0733          	sub	a4,s8,s7
    while (n > 0) {
    800017de:	965e                	add	a2,a2,s7
    800017e0:	85be                	mv	a1,a5
      if (*p == '\0') {
    800017e2:	00f706b3          	add	a3,a4,a5
    800017e6:	0006c683          	lbu	a3,0(a3) # fffffffffffff000 <end+0xffffffff7ffdb980>
    800017ea:	dac9                	beqz	a3,8000177c <copyinstr+0x3c>
        *dst = *p;
    800017ec:	00d78023          	sb	a3,0(a5)
      dst++;
    800017f0:	0785                	addi	a5,a5,1
    while (n > 0) {
    800017f2:	fec797e3          	bne	a5,a2,800017e0 <copyinstr+0xa0>
    800017f6:	b76d                	j	800017a0 <copyinstr+0x60>
    800017f8:	4781                	li	a5,0
    800017fa:	b761                	j	80001782 <copyinstr+0x42>
    srcva = va0 + PGSIZE;
    800017fc:	6c05                	lui	s8,0x1
    800017fe:	9c26                	add	s8,s8,s1
    80001800:	87de                	mv	a5,s7
    80001802:	bf45                	j	800017b2 <copyinstr+0x72>
  int got_null = 0;
    80001804:	4781                	li	a5,0
  if (got_null) {
    80001806:	37fd                	addiw	a5,a5,-1
    80001808:	0007851b          	sext.w	a0,a5
}
    8000180c:	8082                	ret

000000008000180e <vtop>:
// walkpgdir()  in  vm.c  is  static, so add a helper function in  vm.c and declare it in  defs.h) and returns the 
// physical address that  va maps to (frame address plus the offset inside the page). It returns  -1 if the page is not 
// present or is not accessible from user mode (PTE_U not set). 
uint64
vtop(pagetable_t pagetable, uint64 va)
{
    8000180e:	1101                	addi	sp,sp,-32
    80001810:	ec06                	sd	ra,24(sp)
    80001812:	e822                	sd	s0,16(sp)
    80001814:	e426                	sd	s1,8(sp)
    80001816:	1000                	addi	s0,sp,32
    80001818:	84ae                	mv	s1,a1
  pte_t *pte;
  uint64 pa;

  pte = walk(pagetable, va, 0);
    8000181a:	4601                	li	a2,0
    8000181c:	f94ff0ef          	jal	80000fb0 <walk>
  if (pte == 0) {
    80001820:	c11d                	beqz	a0,80001846 <vtop+0x38>
    return -1;
  }
  if (*pte & PTE_V) {
    80001822:	611c                	ld	a5,0(a0)
    80001824:	0017f713          	andi	a4,a5,1
    pa = (*pte & ~0xfff) + (va & 0xfff);
    return pa;
  }
  return -1;
    80001828:	557d                	li	a0,-1
  if (*pte & PTE_V) {
    8000182a:	e711                	bnez	a4,80001836 <vtop+0x28>
}
    8000182c:	60e2                	ld	ra,24(sp)
    8000182e:	6442                	ld	s0,16(sp)
    80001830:	64a2                	ld	s1,8(sp)
    80001832:	6105                	addi	sp,sp,32
    80001834:	8082                	ret
    pa = (*pte & ~0xfff) + (va & 0xfff);
    80001836:	777d                	lui	a4,0xfffff
    80001838:	8ff9                	and	a5,a5,a4
    8000183a:	03449593          	slli	a1,s1,0x34
    8000183e:	91d1                	srli	a1,a1,0x34
    80001840:	00b7e533          	or	a0,a5,a1
    return pa;
    80001844:	b7e5                	j	8000182c <vtop+0x1e>
    return -1;
    80001846:	557d                	li	a0,-1
    80001848:	b7d5                	j	8000182c <vtop+0x1e>

000000008000184a <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    8000184a:	7139                	addi	sp,sp,-64
    8000184c:	fc06                	sd	ra,56(sp)
    8000184e:	f822                	sd	s0,48(sp)
    80001850:	f426                	sd	s1,40(sp)
    80001852:	f04a                	sd	s2,32(sp)
    80001854:	ec4e                	sd	s3,24(sp)
    80001856:	e852                	sd	s4,16(sp)
    80001858:	e456                	sd	s5,8(sp)
    8000185a:	e05a                	sd	s6,0(sp)
    8000185c:	0080                	addi	s0,sp,64
    8000185e:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001860:	00011497          	auipc	s1,0x11
    80001864:	04048493          	addi	s1,s1,64 # 800128a0 <proc>
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    80001868:	8b26                	mv	s6,s1
    8000186a:	04fa5937          	lui	s2,0x4fa5
    8000186e:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    80001872:	0932                	slli	s2,s2,0xc
    80001874:	fa590913          	addi	s2,s2,-91
    80001878:	0932                	slli	s2,s2,0xc
    8000187a:	fa590913          	addi	s2,s2,-91
    8000187e:	0932                	slli	s2,s2,0xc
    80001880:	fa590913          	addi	s2,s2,-91
    80001884:	040009b7          	lui	s3,0x4000
    80001888:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000188a:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    8000188c:	00017a97          	auipc	s5,0x17
    80001890:	a14a8a93          	addi	s5,s5,-1516 # 800182a0 <tickslock>
    char *pa = kalloc();
    80001894:	b00ff0ef          	jal	80000b94 <kalloc>
    80001898:	862a                	mv	a2,a0
    if (pa == 0)
    8000189a:	cd15                	beqz	a0,800018d6 <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int)(p - proc));
    8000189c:	416485b3          	sub	a1,s1,s6
    800018a0:	858d                	srai	a1,a1,0x3
    800018a2:	032585b3          	mul	a1,a1,s2
    800018a6:	2585                	addiw	a1,a1,1
    800018a8:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800018ac:	4719                	li	a4,6
    800018ae:	6685                	lui	a3,0x1
    800018b0:	40b985b3          	sub	a1,s3,a1
    800018b4:	8552                	mv	a0,s4
    800018b6:	883ff0ef          	jal	80001138 <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    800018ba:	16848493          	addi	s1,s1,360
    800018be:	fd549be3          	bne	s1,s5,80001894 <proc_mapstacks+0x4a>
  }
}
    800018c2:	70e2                	ld	ra,56(sp)
    800018c4:	7442                	ld	s0,48(sp)
    800018c6:	74a2                	ld	s1,40(sp)
    800018c8:	7902                	ld	s2,32(sp)
    800018ca:	69e2                	ld	s3,24(sp)
    800018cc:	6a42                	ld	s4,16(sp)
    800018ce:	6aa2                	ld	s5,8(sp)
    800018d0:	6b02                	ld	s6,0(sp)
    800018d2:	6121                	addi	sp,sp,64
    800018d4:	8082                	ret
      panic("kalloc");
    800018d6:	00006517          	auipc	a0,0x6
    800018da:	88250513          	addi	a0,a0,-1918 # 80007158 <etext+0x158>
    800018de:	f13fe0ef          	jal	800007f0 <panic>

00000000800018e2 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800018e2:	7139                	addi	sp,sp,-64
    800018e4:	fc06                	sd	ra,56(sp)
    800018e6:	f822                	sd	s0,48(sp)
    800018e8:	f426                	sd	s1,40(sp)
    800018ea:	f04a                	sd	s2,32(sp)
    800018ec:	ec4e                	sd	s3,24(sp)
    800018ee:	e852                	sd	s4,16(sp)
    800018f0:	e456                	sd	s5,8(sp)
    800018f2:	e05a                	sd	s6,0(sp)
    800018f4:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    800018f6:	00006597          	auipc	a1,0x6
    800018fa:	86a58593          	addi	a1,a1,-1942 # 80007160 <etext+0x160>
    800018fe:	00011517          	auipc	a0,0x11
    80001902:	b7250513          	addi	a0,a0,-1166 # 80012470 <pid_lock>
    80001906:	afaff0ef          	jal	80000c00 <initlock>
  initlock(&wait_lock, "wait_lock");
    8000190a:	00006597          	auipc	a1,0x6
    8000190e:	85e58593          	addi	a1,a1,-1954 # 80007168 <etext+0x168>
    80001912:	00011517          	auipc	a0,0x11
    80001916:	b7650513          	addi	a0,a0,-1162 # 80012488 <wait_lock>
    8000191a:	ae6ff0ef          	jal	80000c00 <initlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000191e:	00011497          	auipc	s1,0x11
    80001922:	f8248493          	addi	s1,s1,-126 # 800128a0 <proc>
    initlock(&p->lock, "proc");
    80001926:	00006b17          	auipc	s6,0x6
    8000192a:	852b0b13          	addi	s6,s6,-1966 # 80007178 <etext+0x178>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    8000192e:	8aa6                	mv	s5,s1
    80001930:	04fa5937          	lui	s2,0x4fa5
    80001934:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    80001938:	0932                	slli	s2,s2,0xc
    8000193a:	fa590913          	addi	s2,s2,-91
    8000193e:	0932                	slli	s2,s2,0xc
    80001940:	fa590913          	addi	s2,s2,-91
    80001944:	0932                	slli	s2,s2,0xc
    80001946:	fa590913          	addi	s2,s2,-91
    8000194a:	040009b7          	lui	s3,0x4000
    8000194e:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001950:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001952:	00017a17          	auipc	s4,0x17
    80001956:	94ea0a13          	addi	s4,s4,-1714 # 800182a0 <tickslock>
    initlock(&p->lock, "proc");
    8000195a:	85da                	mv	a1,s6
    8000195c:	8526                	mv	a0,s1
    8000195e:	aa2ff0ef          	jal	80000c00 <initlock>
    p->state = UNUSED;
    80001962:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    80001966:	415487b3          	sub	a5,s1,s5
    8000196a:	878d                	srai	a5,a5,0x3
    8000196c:	032787b3          	mul	a5,a5,s2
    80001970:	2785                	addiw	a5,a5,1
    80001972:	00d7979b          	slliw	a5,a5,0xd
    80001976:	40f987b3          	sub	a5,s3,a5
    8000197a:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    8000197c:	16848493          	addi	s1,s1,360
    80001980:	fd449de3          	bne	s1,s4,8000195a <procinit+0x78>
  }
}
    80001984:	70e2                	ld	ra,56(sp)
    80001986:	7442                	ld	s0,48(sp)
    80001988:	74a2                	ld	s1,40(sp)
    8000198a:	7902                	ld	s2,32(sp)
    8000198c:	69e2                	ld	s3,24(sp)
    8000198e:	6a42                	ld	s4,16(sp)
    80001990:	6aa2                	ld	s5,8(sp)
    80001992:	6b02                	ld	s6,0(sp)
    80001994:	6121                	addi	sp,sp,64
    80001996:	8082                	ret

0000000080001998 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001998:	1141                	addi	sp,sp,-16
    8000199a:	e422                	sd	s0,8(sp)
    8000199c:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    8000199e:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800019a0:	2501                	sext.w	a0,a0
    800019a2:	6422                	ld	s0,8(sp)
    800019a4:	0141                	addi	sp,sp,16
    800019a6:	8082                	ret

00000000800019a8 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    800019a8:	1141                	addi	sp,sp,-16
    800019aa:	e422                	sd	s0,8(sp)
    800019ac:	0800                	addi	s0,sp,16
    800019ae:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800019b0:	2781                	sext.w	a5,a5
    800019b2:	079e                	slli	a5,a5,0x7
  return c;
}
    800019b4:	00011517          	auipc	a0,0x11
    800019b8:	aec50513          	addi	a0,a0,-1300 # 800124a0 <cpus>
    800019bc:	953e                	add	a0,a0,a5
    800019be:	6422                	ld	s0,8(sp)
    800019c0:	0141                	addi	sp,sp,16
    800019c2:	8082                	ret

00000000800019c4 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    800019c4:	1101                	addi	sp,sp,-32
    800019c6:	ec06                	sd	ra,24(sp)
    800019c8:	e822                	sd	s0,16(sp)
    800019ca:	e426                	sd	s1,8(sp)
    800019cc:	1000                	addi	s0,sp,32
  push_off();
    800019ce:	a72ff0ef          	jal	80000c40 <push_off>
    800019d2:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800019d4:	2781                	sext.w	a5,a5
    800019d6:	079e                	slli	a5,a5,0x7
    800019d8:	00011717          	auipc	a4,0x11
    800019dc:	a9870713          	addi	a4,a4,-1384 # 80012470 <pid_lock>
    800019e0:	97ba                	add	a5,a5,a4
    800019e2:	7b84                	ld	s1,48(a5)
  pop_off();
    800019e4:	ad2ff0ef          	jal	80000cb6 <pop_off>
  return p;
}
    800019e8:	8526                	mv	a0,s1
    800019ea:	60e2                	ld	ra,24(sp)
    800019ec:	6442                	ld	s0,16(sp)
    800019ee:	64a2                	ld	s1,8(sp)
    800019f0:	6105                	addi	sp,sp,32
    800019f2:	8082                	ret

00000000800019f4 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800019f4:	7179                	addi	sp,sp,-48
    800019f6:	f406                	sd	ra,40(sp)
    800019f8:	f022                	sd	s0,32(sp)
    800019fa:	ec26                	sd	s1,24(sp)
    800019fc:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    800019fe:	fc7ff0ef          	jal	800019c4 <myproc>
    80001a02:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001a04:	afeff0ef          	jal	80000d02 <release>

  if (first) {
    80001a08:	00009797          	auipc	a5,0x9
    80001a0c:	8e87a783          	lw	a5,-1816(a5) # 8000a2f0 <first.1>
    80001a10:	cb9d                	beqz	a5,80001a46 <forkret+0x52>
    first = 0;
    80001a12:	00009797          	auipc	a5,0x9
    80001a16:	8c07af23          	sw	zero,-1826(a5) # 8000a2f0 <first.1>

    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001a1a:	4505                	li	a0,1
    80001a1c:	59f010ef          	jal	800037ba <fsinit>

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    80001a20:	00005517          	auipc	a0,0x5
    80001a24:	76050513          	addi	a0,a0,1888 # 80007180 <etext+0x180>
    80001a28:	fca43823          	sd	a0,-48(s0)
    80001a2c:	fc043c23          	sd	zero,-40(s0)
    80001a30:	fd040593          	addi	a1,s0,-48
    80001a34:	78f020ef          	jal	800049c2 <kexec>
    80001a38:	6cbc                	ld	a5,88(s1)
    80001a3a:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001a3c:	6cbc                	ld	a5,88(s1)
    80001a3e:	7bb8                	ld	a4,112(a5)
    80001a40:	57fd                	li	a5,-1
    80001a42:	02f70d63          	beq	a4,a5,80001a7c <forkret+0x88>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001a46:	2f9000ef          	jal	8000253e <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001a4a:	68a8                	ld	a0,80(s1)
    80001a4c:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001a4e:	04000737          	lui	a4,0x4000
    80001a52:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001a54:	0732                	slli	a4,a4,0xc
    80001a56:	00004797          	auipc	a5,0x4
    80001a5a:	64678793          	addi	a5,a5,1606 # 8000609c <userret>
    80001a5e:	00004697          	auipc	a3,0x4
    80001a62:	5a268693          	addi	a3,a3,1442 # 80006000 <_trampoline>
    80001a66:	8f95                	sub	a5,a5,a3
    80001a68:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001a6a:	577d                	li	a4,-1
    80001a6c:	177e                	slli	a4,a4,0x3f
    80001a6e:	8d59                	or	a0,a0,a4
    80001a70:	9782                	jalr	a5
}
    80001a72:	70a2                	ld	ra,40(sp)
    80001a74:	7402                	ld	s0,32(sp)
    80001a76:	64e2                	ld	s1,24(sp)
    80001a78:	6145                	addi	sp,sp,48
    80001a7a:	8082                	ret
      panic("exec");
    80001a7c:	00005517          	auipc	a0,0x5
    80001a80:	70c50513          	addi	a0,a0,1804 # 80007188 <etext+0x188>
    80001a84:	d6dfe0ef          	jal	800007f0 <panic>

0000000080001a88 <allocpid>:
{
    80001a88:	1101                	addi	sp,sp,-32
    80001a8a:	ec06                	sd	ra,24(sp)
    80001a8c:	e822                	sd	s0,16(sp)
    80001a8e:	e426                	sd	s1,8(sp)
    80001a90:	e04a                	sd	s2,0(sp)
    80001a92:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001a94:	00011917          	auipc	s2,0x11
    80001a98:	9dc90913          	addi	s2,s2,-1572 # 80012470 <pid_lock>
    80001a9c:	854a                	mv	a0,s2
    80001a9e:	9d8ff0ef          	jal	80000c76 <acquire>
  pid = nextpid;
    80001aa2:	00009797          	auipc	a5,0x9
    80001aa6:	85278793          	addi	a5,a5,-1966 # 8000a2f4 <nextpid>
    80001aaa:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001aac:	0014871b          	addiw	a4,s1,1
    80001ab0:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001ab2:	854a                	mv	a0,s2
    80001ab4:	a4eff0ef          	jal	80000d02 <release>
}
    80001ab8:	8526                	mv	a0,s1
    80001aba:	60e2                	ld	ra,24(sp)
    80001abc:	6442                	ld	s0,16(sp)
    80001abe:	64a2                	ld	s1,8(sp)
    80001ac0:	6902                	ld	s2,0(sp)
    80001ac2:	6105                	addi	sp,sp,32
    80001ac4:	8082                	ret

0000000080001ac6 <proc_pagetable>:
{
    80001ac6:	1101                	addi	sp,sp,-32
    80001ac8:	ec06                	sd	ra,24(sp)
    80001aca:	e822                	sd	s0,16(sp)
    80001acc:	e426                	sd	s1,8(sp)
    80001ace:	e04a                	sd	s2,0(sp)
    80001ad0:	1000                	addi	s0,sp,32
    80001ad2:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001ad4:	f5aff0ef          	jal	8000122e <uvmcreate>
    80001ad8:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001ada:	cd05                	beqz	a0,80001b12 <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    80001adc:	4729                	li	a4,10
    80001ade:	00004697          	auipc	a3,0x4
    80001ae2:	52268693          	addi	a3,a3,1314 # 80006000 <_trampoline>
    80001ae6:	6605                	lui	a2,0x1
    80001ae8:	040005b7          	lui	a1,0x4000
    80001aec:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001aee:	05b2                	slli	a1,a1,0xc
    80001af0:	d98ff0ef          	jal	80001088 <mappages>
    80001af4:	02054663          	bltz	a0,80001b20 <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    80001af8:	4719                	li	a4,6
    80001afa:	05893683          	ld	a3,88(s2)
    80001afe:	6605                	lui	a2,0x1
    80001b00:	020005b7          	lui	a1,0x2000
    80001b04:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001b06:	05b6                	slli	a1,a1,0xd
    80001b08:	8526                	mv	a0,s1
    80001b0a:	d7eff0ef          	jal	80001088 <mappages>
    80001b0e:	00054f63          	bltz	a0,80001b2c <proc_pagetable+0x66>
}
    80001b12:	8526                	mv	a0,s1
    80001b14:	60e2                	ld	ra,24(sp)
    80001b16:	6442                	ld	s0,16(sp)
    80001b18:	64a2                	ld	s1,8(sp)
    80001b1a:	6902                	ld	s2,0(sp)
    80001b1c:	6105                	addi	sp,sp,32
    80001b1e:	8082                	ret
    uvmfree(pagetable, 0);
    80001b20:	4581                	li	a1,0
    80001b22:	8526                	mv	a0,s1
    80001b24:	905ff0ef          	jal	80001428 <uvmfree>
    return 0;
    80001b28:	4481                	li	s1,0
    80001b2a:	b7e5                	j	80001b12 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001b2c:	4681                	li	a3,0
    80001b2e:	4605                	li	a2,1
    80001b30:	040005b7          	lui	a1,0x4000
    80001b34:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001b36:	05b2                	slli	a1,a1,0xc
    80001b38:	8526                	mv	a0,s1
    80001b3a:	f1aff0ef          	jal	80001254 <uvmunmap>
    uvmfree(pagetable, 0);
    80001b3e:	4581                	li	a1,0
    80001b40:	8526                	mv	a0,s1
    80001b42:	8e7ff0ef          	jal	80001428 <uvmfree>
    return 0;
    80001b46:	4481                	li	s1,0
    80001b48:	b7e9                	j	80001b12 <proc_pagetable+0x4c>

0000000080001b4a <proc_freepagetable>:
{
    80001b4a:	1101                	addi	sp,sp,-32
    80001b4c:	ec06                	sd	ra,24(sp)
    80001b4e:	e822                	sd	s0,16(sp)
    80001b50:	e426                	sd	s1,8(sp)
    80001b52:	e04a                	sd	s2,0(sp)
    80001b54:	1000                	addi	s0,sp,32
    80001b56:	84aa                	mv	s1,a0
    80001b58:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001b5a:	4681                	li	a3,0
    80001b5c:	4605                	li	a2,1
    80001b5e:	040005b7          	lui	a1,0x4000
    80001b62:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001b64:	05b2                	slli	a1,a1,0xc
    80001b66:	eeeff0ef          	jal	80001254 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001b6a:	4681                	li	a3,0
    80001b6c:	4605                	li	a2,1
    80001b6e:	020005b7          	lui	a1,0x2000
    80001b72:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001b74:	05b6                	slli	a1,a1,0xd
    80001b76:	8526                	mv	a0,s1
    80001b78:	edcff0ef          	jal	80001254 <uvmunmap>
  uvmfree(pagetable, sz);
    80001b7c:	85ca                	mv	a1,s2
    80001b7e:	8526                	mv	a0,s1
    80001b80:	8a9ff0ef          	jal	80001428 <uvmfree>
}
    80001b84:	60e2                	ld	ra,24(sp)
    80001b86:	6442                	ld	s0,16(sp)
    80001b88:	64a2                	ld	s1,8(sp)
    80001b8a:	6902                	ld	s2,0(sp)
    80001b8c:	6105                	addi	sp,sp,32
    80001b8e:	8082                	ret

0000000080001b90 <freeproc>:
{
    80001b90:	1101                	addi	sp,sp,-32
    80001b92:	ec06                	sd	ra,24(sp)
    80001b94:	e822                	sd	s0,16(sp)
    80001b96:	e426                	sd	s1,8(sp)
    80001b98:	1000                	addi	s0,sp,32
    80001b9a:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001b9c:	6d28                	ld	a0,88(a0)
    80001b9e:	c119                	beqz	a0,80001ba4 <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001ba0:	ed1fe0ef          	jal	80000a70 <kfree>
  p->trapframe = 0;
    80001ba4:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001ba8:	68a8                	ld	a0,80(s1)
    80001baa:	c501                	beqz	a0,80001bb2 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001bac:	64ac                	ld	a1,72(s1)
    80001bae:	f9dff0ef          	jal	80001b4a <proc_freepagetable>
  p->pagetable = 0;
    80001bb2:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001bb6:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001bba:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001bbe:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001bc2:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001bc6:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001bca:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001bce:	0004ac23          	sw	zero,24(s1)
}
    80001bd2:	60e2                	ld	ra,24(sp)
    80001bd4:	6442                	ld	s0,16(sp)
    80001bd6:	64a2                	ld	s1,8(sp)
    80001bd8:	6105                	addi	sp,sp,32
    80001bda:	8082                	ret

0000000080001bdc <allocproc>:
{
    80001bdc:	1101                	addi	sp,sp,-32
    80001bde:	ec06                	sd	ra,24(sp)
    80001be0:	e822                	sd	s0,16(sp)
    80001be2:	e426                	sd	s1,8(sp)
    80001be4:	e04a                	sd	s2,0(sp)
    80001be6:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001be8:	00011497          	auipc	s1,0x11
    80001bec:	cb848493          	addi	s1,s1,-840 # 800128a0 <proc>
    80001bf0:	00016917          	auipc	s2,0x16
    80001bf4:	6b090913          	addi	s2,s2,1712 # 800182a0 <tickslock>
    acquire(&p->lock);
    80001bf8:	8526                	mv	a0,s1
    80001bfa:	87cff0ef          	jal	80000c76 <acquire>
    if (p->state == UNUSED) {
    80001bfe:	4c9c                	lw	a5,24(s1)
    80001c00:	cb91                	beqz	a5,80001c14 <allocproc+0x38>
      release(&p->lock);
    80001c02:	8526                	mv	a0,s1
    80001c04:	8feff0ef          	jal	80000d02 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001c08:	16848493          	addi	s1,s1,360
    80001c0c:	ff2496e3          	bne	s1,s2,80001bf8 <allocproc+0x1c>
  return 0;
    80001c10:	4481                	li	s1,0
    80001c12:	a089                	j	80001c54 <allocproc+0x78>
  p->pid = allocpid();
    80001c14:	e75ff0ef          	jal	80001a88 <allocpid>
    80001c18:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001c1a:	4785                	li	a5,1
    80001c1c:	cc9c                	sw	a5,24(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001c1e:	f77fe0ef          	jal	80000b94 <kalloc>
    80001c22:	892a                	mv	s2,a0
    80001c24:	eca8                	sd	a0,88(s1)
    80001c26:	cd15                	beqz	a0,80001c62 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001c28:	8526                	mv	a0,s1
    80001c2a:	e9dff0ef          	jal	80001ac6 <proc_pagetable>
    80001c2e:	892a                	mv	s2,a0
    80001c30:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001c32:	c121                	beqz	a0,80001c72 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001c34:	07000613          	li	a2,112
    80001c38:	4581                	li	a1,0
    80001c3a:	06048513          	addi	a0,s1,96
    80001c3e:	8fcff0ef          	jal	80000d3a <memset>
  p->context.ra = (uint64)forkret;
    80001c42:	00000797          	auipc	a5,0x0
    80001c46:	db278793          	addi	a5,a5,-590 # 800019f4 <forkret>
    80001c4a:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001c4c:	60bc                	ld	a5,64(s1)
    80001c4e:	6705                	lui	a4,0x1
    80001c50:	97ba                	add	a5,a5,a4
    80001c52:	f4bc                	sd	a5,104(s1)
}
    80001c54:	8526                	mv	a0,s1
    80001c56:	60e2                	ld	ra,24(sp)
    80001c58:	6442                	ld	s0,16(sp)
    80001c5a:	64a2                	ld	s1,8(sp)
    80001c5c:	6902                	ld	s2,0(sp)
    80001c5e:	6105                	addi	sp,sp,32
    80001c60:	8082                	ret
    freeproc(p);
    80001c62:	8526                	mv	a0,s1
    80001c64:	f2dff0ef          	jal	80001b90 <freeproc>
    release(&p->lock);
    80001c68:	8526                	mv	a0,s1
    80001c6a:	898ff0ef          	jal	80000d02 <release>
    return 0;
    80001c6e:	84ca                	mv	s1,s2
    80001c70:	b7d5                	j	80001c54 <allocproc+0x78>
    freeproc(p);
    80001c72:	8526                	mv	a0,s1
    80001c74:	f1dff0ef          	jal	80001b90 <freeproc>
    release(&p->lock);
    80001c78:	8526                	mv	a0,s1
    80001c7a:	888ff0ef          	jal	80000d02 <release>
    return 0;
    80001c7e:	84ca                	mv	s1,s2
    80001c80:	bfd1                	j	80001c54 <allocproc+0x78>

0000000080001c82 <userinit>:
{
    80001c82:	1101                	addi	sp,sp,-32
    80001c84:	ec06                	sd	ra,24(sp)
    80001c86:	e822                	sd	s0,16(sp)
    80001c88:	e426                	sd	s1,8(sp)
    80001c8a:	1000                	addi	s0,sp,32
  p = allocproc();
    80001c8c:	f51ff0ef          	jal	80001bdc <allocproc>
    80001c90:	84aa                	mv	s1,a0
  initproc = p;
    80001c92:	00008797          	auipc	a5,0x8
    80001c96:	6aa7b723          	sd	a0,1710(a5) # 8000a340 <initproc>
  p->cwd = namei("/");
    80001c9a:	00005517          	auipc	a0,0x5
    80001c9e:	4f650513          	addi	a0,a0,1270 # 80007190 <etext+0x190>
    80001ca2:	052020ef          	jal	80003cf4 <namei>
    80001ca6:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001caa:	478d                	li	a5,3
    80001cac:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001cae:	8526                	mv	a0,s1
    80001cb0:	852ff0ef          	jal	80000d02 <release>
}
    80001cb4:	60e2                	ld	ra,24(sp)
    80001cb6:	6442                	ld	s0,16(sp)
    80001cb8:	64a2                	ld	s1,8(sp)
    80001cba:	6105                	addi	sp,sp,32
    80001cbc:	8082                	ret

0000000080001cbe <growproc>:
{
    80001cbe:	1101                	addi	sp,sp,-32
    80001cc0:	ec06                	sd	ra,24(sp)
    80001cc2:	e822                	sd	s0,16(sp)
    80001cc4:	e426                	sd	s1,8(sp)
    80001cc6:	e04a                	sd	s2,0(sp)
    80001cc8:	1000                	addi	s0,sp,32
    80001cca:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001ccc:	cf9ff0ef          	jal	800019c4 <myproc>
    80001cd0:	892a                	mv	s2,a0
  sz = p->sz;
    80001cd2:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001cd4:	02905963          	blez	s1,80001d06 <growproc+0x48>
    if (sz + n > TRAPFRAME) {
    80001cd8:	00b48633          	add	a2,s1,a1
    80001cdc:	020007b7          	lui	a5,0x2000
    80001ce0:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001ce2:	07b6                	slli	a5,a5,0xd
    80001ce4:	02c7ea63          	bltu	a5,a2,80001d18 <growproc+0x5a>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001ce8:	4691                	li	a3,4
    80001cea:	6928                	ld	a0,80(a0)
    80001cec:	e36ff0ef          	jal	80001322 <uvmalloc>
    80001cf0:	85aa                	mv	a1,a0
    80001cf2:	c50d                	beqz	a0,80001d1c <growproc+0x5e>
  p->sz = sz;
    80001cf4:	04b93423          	sd	a1,72(s2)
  return 0;
    80001cf8:	4501                	li	a0,0
}
    80001cfa:	60e2                	ld	ra,24(sp)
    80001cfc:	6442                	ld	s0,16(sp)
    80001cfe:	64a2                	ld	s1,8(sp)
    80001d00:	6902                	ld	s2,0(sp)
    80001d02:	6105                	addi	sp,sp,32
    80001d04:	8082                	ret
  } else if (n < 0) {
    80001d06:	fe04d7e3          	bgez	s1,80001cf4 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001d0a:	00b48633          	add	a2,s1,a1
    80001d0e:	6928                	ld	a0,80(a0)
    80001d10:	dceff0ef          	jal	800012de <uvmdealloc>
    80001d14:	85aa                	mv	a1,a0
    80001d16:	bff9                	j	80001cf4 <growproc+0x36>
      return -1;
    80001d18:	557d                	li	a0,-1
    80001d1a:	b7c5                	j	80001cfa <growproc+0x3c>
      return -1;
    80001d1c:	557d                	li	a0,-1
    80001d1e:	bff1                	j	80001cfa <growproc+0x3c>

0000000080001d20 <kfork>:
{
    80001d20:	7139                	addi	sp,sp,-64
    80001d22:	fc06                	sd	ra,56(sp)
    80001d24:	f822                	sd	s0,48(sp)
    80001d26:	f04a                	sd	s2,32(sp)
    80001d28:	e456                	sd	s5,8(sp)
    80001d2a:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001d2c:	c99ff0ef          	jal	800019c4 <myproc>
    80001d30:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001d32:	eabff0ef          	jal	80001bdc <allocproc>
    80001d36:	0e050a63          	beqz	a0,80001e2a <kfork+0x10a>
    80001d3a:	e852                	sd	s4,16(sp)
    80001d3c:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001d3e:	048ab603          	ld	a2,72(s5)
    80001d42:	692c                	ld	a1,80(a0)
    80001d44:	050ab503          	ld	a0,80(s5)
    80001d48:	f12ff0ef          	jal	8000145a <uvmcopy>
    80001d4c:	04054a63          	bltz	a0,80001da0 <kfork+0x80>
    80001d50:	f426                	sd	s1,40(sp)
    80001d52:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001d54:	048ab783          	ld	a5,72(s5)
    80001d58:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001d5c:	058ab683          	ld	a3,88(s5)
    80001d60:	87b6                	mv	a5,a3
    80001d62:	058a3703          	ld	a4,88(s4)
    80001d66:	12068693          	addi	a3,a3,288
    80001d6a:	0007b803          	ld	a6,0(a5)
    80001d6e:	6788                	ld	a0,8(a5)
    80001d70:	6b8c                	ld	a1,16(a5)
    80001d72:	6f90                	ld	a2,24(a5)
    80001d74:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001d78:	e708                	sd	a0,8(a4)
    80001d7a:	eb0c                	sd	a1,16(a4)
    80001d7c:	ef10                	sd	a2,24(a4)
    80001d7e:	02078793          	addi	a5,a5,32
    80001d82:	02070713          	addi	a4,a4,32
    80001d86:	fed792e3          	bne	a5,a3,80001d6a <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001d8a:	058a3783          	ld	a5,88(s4)
    80001d8e:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001d92:	0d0a8493          	addi	s1,s5,208
    80001d96:	0d0a0913          	addi	s2,s4,208
    80001d9a:	150a8993          	addi	s3,s5,336
    80001d9e:	a831                	j	80001dba <kfork+0x9a>
    freeproc(np);
    80001da0:	8552                	mv	a0,s4
    80001da2:	defff0ef          	jal	80001b90 <freeproc>
    release(&np->lock);
    80001da6:	8552                	mv	a0,s4
    80001da8:	f5bfe0ef          	jal	80000d02 <release>
    return -1;
    80001dac:	597d                	li	s2,-1
    80001dae:	6a42                	ld	s4,16(sp)
    80001db0:	a0b5                	j	80001e1c <kfork+0xfc>
  for (i = 0; i < NOFILE; i++)
    80001db2:	04a1                	addi	s1,s1,8
    80001db4:	0921                	addi	s2,s2,8
    80001db6:	01348963          	beq	s1,s3,80001dc8 <kfork+0xa8>
    if (p->ofile[i])
    80001dba:	6088                	ld	a0,0(s1)
    80001dbc:	d97d                	beqz	a0,80001db2 <kfork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001dbe:	570020ef          	jal	8000432e <filedup>
    80001dc2:	00a93023          	sd	a0,0(s2)
    80001dc6:	b7f5                	j	80001db2 <kfork+0x92>
  np->cwd = idup(p->cwd);
    80001dc8:	150ab503          	ld	a0,336(s5)
    80001dcc:	67c010ef          	jal	80003448 <idup>
    80001dd0:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001dd4:	4641                	li	a2,16
    80001dd6:	158a8593          	addi	a1,s5,344
    80001dda:	158a0513          	addi	a0,s4,344
    80001dde:	89aff0ef          	jal	80000e78 <safestrcpy>
  pid = np->pid;
    80001de2:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001de6:	8552                	mv	a0,s4
    80001de8:	f1bfe0ef          	jal	80000d02 <release>
  acquire(&wait_lock);
    80001dec:	00010497          	auipc	s1,0x10
    80001df0:	69c48493          	addi	s1,s1,1692 # 80012488 <wait_lock>
    80001df4:	8526                	mv	a0,s1
    80001df6:	e81fe0ef          	jal	80000c76 <acquire>
  np->parent = p;
    80001dfa:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001dfe:	8526                	mv	a0,s1
    80001e00:	f03fe0ef          	jal	80000d02 <release>
  acquire(&np->lock);
    80001e04:	8552                	mv	a0,s4
    80001e06:	e71fe0ef          	jal	80000c76 <acquire>
  np->state = RUNNABLE;
    80001e0a:	478d                	li	a5,3
    80001e0c:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001e10:	8552                	mv	a0,s4
    80001e12:	ef1fe0ef          	jal	80000d02 <release>
  return pid;
    80001e16:	74a2                	ld	s1,40(sp)
    80001e18:	69e2                	ld	s3,24(sp)
    80001e1a:	6a42                	ld	s4,16(sp)
}
    80001e1c:	854a                	mv	a0,s2
    80001e1e:	70e2                	ld	ra,56(sp)
    80001e20:	7442                	ld	s0,48(sp)
    80001e22:	7902                	ld	s2,32(sp)
    80001e24:	6aa2                	ld	s5,8(sp)
    80001e26:	6121                	addi	sp,sp,64
    80001e28:	8082                	ret
    return -1;
    80001e2a:	597d                	li	s2,-1
    80001e2c:	bfc5                	j	80001e1c <kfork+0xfc>

0000000080001e2e <scheduler>:
{
    80001e2e:	711d                	addi	sp,sp,-96
    80001e30:	ec86                	sd	ra,88(sp)
    80001e32:	e8a2                	sd	s0,80(sp)
    80001e34:	e4a6                	sd	s1,72(sp)
    80001e36:	e0ca                	sd	s2,64(sp)
    80001e38:	fc4e                	sd	s3,56(sp)
    80001e3a:	f852                	sd	s4,48(sp)
    80001e3c:	f456                	sd	s5,40(sp)
    80001e3e:	f05a                	sd	s6,32(sp)
    80001e40:	ec5e                	sd	s7,24(sp)
    80001e42:	e862                	sd	s8,16(sp)
    80001e44:	e466                	sd	s9,8(sp)
    80001e46:	1080                	addi	s0,sp,96
    80001e48:	8792                	mv	a5,tp
  int id = r_tp();
    80001e4a:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001e4c:	00779a93          	slli	s5,a5,0x7
    80001e50:	00010717          	auipc	a4,0x10
    80001e54:	62070713          	addi	a4,a4,1568 # 80012470 <pid_lock>
    80001e58:	9756                	add	a4,a4,s5
    80001e5a:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001e5e:	00010717          	auipc	a4,0x10
    80001e62:	64a70713          	addi	a4,a4,1610 # 800124a8 <cpus+0x8>
    80001e66:	9aba                	add	s5,s5,a4
        p->state = RUNNING;
    80001e68:	4c11                	li	s8,4
        c->proc = p;
    80001e6a:	00010b17          	auipc	s6,0x10
    80001e6e:	606b0b13          	addi	s6,s6,1542 # 80012470 <pid_lock>
    80001e72:	079e                	slli	a5,a5,0x7
    80001e74:	00fb0a33          	add	s4,s6,a5
        found = 1;
    80001e78:	4b85                	li	s7,1
    for (p = proc; p < &proc[NPROC]; p++) {
    80001e7a:	00016997          	auipc	s3,0x16
    80001e7e:	42698993          	addi	s3,s3,1062 # 800182a0 <tickslock>
    80001e82:	a0a9                	j	80001ecc <scheduler+0x9e>
      release(&p->lock);
    80001e84:	8526                	mv	a0,s1
    80001e86:	e7dfe0ef          	jal	80000d02 <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001e8a:	16848493          	addi	s1,s1,360
    80001e8e:	03348b63          	beq	s1,s3,80001ec4 <scheduler+0x96>
      acquire(&p->lock);
    80001e92:	8526                	mv	a0,s1
    80001e94:	de3fe0ef          	jal	80000c76 <acquire>
      if (p->state == RUNNABLE) {
    80001e98:	4c9c                	lw	a5,24(s1)
    80001e9a:	ff2795e3          	bne	a5,s2,80001e84 <scheduler+0x56>
        p->state = RUNNING;
    80001e9e:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001ea2:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001ea6:	06048593          	addi	a1,s1,96
    80001eaa:	8556                	mv	a0,s5
    80001eac:	5ec000ef          	jal	80002498 <swtch>
    80001eb0:	8792                	mv	a5,tp
        mycpu()->intena = 0;
    80001eb2:	2781                	sext.w	a5,a5
    80001eb4:	079e                	slli	a5,a5,0x7
    80001eb6:	97da                	add	a5,a5,s6
    80001eb8:	0a07a623          	sw	zero,172(a5)
        c->proc = 0;
    80001ebc:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001ec0:	8cde                	mv	s9,s7
    80001ec2:	b7c9                	j	80001e84 <scheduler+0x56>
    if (found == 0) {
    80001ec4:	000c9463          	bnez	s9,80001ecc <scheduler+0x9e>
      asm volatile("wfi");
    80001ec8:	10500073          	wfi
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001ecc:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001ed0:	10017073          	csrci	sstatus,2
    int found = 0;
    80001ed4:	4c81                	li	s9,0
    for (p = proc; p < &proc[NPROC]; p++) {
    80001ed6:	00011497          	auipc	s1,0x11
    80001eda:	9ca48493          	addi	s1,s1,-1590 # 800128a0 <proc>
      if (p->state == RUNNABLE) {
    80001ede:	490d                	li	s2,3
    80001ee0:	bf4d                	j	80001e92 <scheduler+0x64>

0000000080001ee2 <sched>:
{
    80001ee2:	7179                	addi	sp,sp,-48
    80001ee4:	f406                	sd	ra,40(sp)
    80001ee6:	f022                	sd	s0,32(sp)
    80001ee8:	ec26                	sd	s1,24(sp)
    80001eea:	e84a                	sd	s2,16(sp)
    80001eec:	e44e                	sd	s3,8(sp)
    80001eee:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001ef0:	ad5ff0ef          	jal	800019c4 <myproc>
    80001ef4:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001ef6:	d21fe0ef          	jal	80000c16 <holding>
    80001efa:	c92d                	beqz	a0,80001f6c <sched+0x8a>
  asm volatile("mv %0, tp" : "=r"(x));
    80001efc:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001efe:	2781                	sext.w	a5,a5
    80001f00:	079e                	slli	a5,a5,0x7
    80001f02:	00010717          	auipc	a4,0x10
    80001f06:	56e70713          	addi	a4,a4,1390 # 80012470 <pid_lock>
    80001f0a:	97ba                	add	a5,a5,a4
    80001f0c:	0a87a703          	lw	a4,168(a5)
    80001f10:	4785                	li	a5,1
    80001f12:	06f71363          	bne	a4,a5,80001f78 <sched+0x96>
  if (p->state == RUNNING)
    80001f16:	4c98                	lw	a4,24(s1)
    80001f18:	4791                	li	a5,4
    80001f1a:	06f70563          	beq	a4,a5,80001f84 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001f1e:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001f22:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001f24:	e7b5                	bnez	a5,80001f90 <sched+0xae>
  asm volatile("mv %0, tp" : "=r"(x));
    80001f26:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001f28:	00010917          	auipc	s2,0x10
    80001f2c:	54890913          	addi	s2,s2,1352 # 80012470 <pid_lock>
    80001f30:	2781                	sext.w	a5,a5
    80001f32:	079e                	slli	a5,a5,0x7
    80001f34:	97ca                	add	a5,a5,s2
    80001f36:	0ac7a983          	lw	s3,172(a5)
    80001f3a:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001f3c:	2781                	sext.w	a5,a5
    80001f3e:	079e                	slli	a5,a5,0x7
    80001f40:	00010597          	auipc	a1,0x10
    80001f44:	56858593          	addi	a1,a1,1384 # 800124a8 <cpus+0x8>
    80001f48:	95be                	add	a1,a1,a5
    80001f4a:	06048513          	addi	a0,s1,96
    80001f4e:	54a000ef          	jal	80002498 <swtch>
    80001f52:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001f54:	2781                	sext.w	a5,a5
    80001f56:	079e                	slli	a5,a5,0x7
    80001f58:	993e                	add	s2,s2,a5
    80001f5a:	0b392623          	sw	s3,172(s2)
}
    80001f5e:	70a2                	ld	ra,40(sp)
    80001f60:	7402                	ld	s0,32(sp)
    80001f62:	64e2                	ld	s1,24(sp)
    80001f64:	6942                	ld	s2,16(sp)
    80001f66:	69a2                	ld	s3,8(sp)
    80001f68:	6145                	addi	sp,sp,48
    80001f6a:	8082                	ret
    panic("sched p->lock");
    80001f6c:	00005517          	auipc	a0,0x5
    80001f70:	22c50513          	addi	a0,a0,556 # 80007198 <etext+0x198>
    80001f74:	87dfe0ef          	jal	800007f0 <panic>
    panic("sched locks");
    80001f78:	00005517          	auipc	a0,0x5
    80001f7c:	23050513          	addi	a0,a0,560 # 800071a8 <etext+0x1a8>
    80001f80:	871fe0ef          	jal	800007f0 <panic>
    panic("sched RUNNING");
    80001f84:	00005517          	auipc	a0,0x5
    80001f88:	23450513          	addi	a0,a0,564 # 800071b8 <etext+0x1b8>
    80001f8c:	865fe0ef          	jal	800007f0 <panic>
    panic("sched interruptible");
    80001f90:	00005517          	auipc	a0,0x5
    80001f94:	23850513          	addi	a0,a0,568 # 800071c8 <etext+0x1c8>
    80001f98:	859fe0ef          	jal	800007f0 <panic>

0000000080001f9c <yield>:
{
    80001f9c:	1101                	addi	sp,sp,-32
    80001f9e:	ec06                	sd	ra,24(sp)
    80001fa0:	e822                	sd	s0,16(sp)
    80001fa2:	e426                	sd	s1,8(sp)
    80001fa4:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001fa6:	a1fff0ef          	jal	800019c4 <myproc>
    80001faa:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001fac:	ccbfe0ef          	jal	80000c76 <acquire>
  p->state = RUNNABLE;
    80001fb0:	478d                	li	a5,3
    80001fb2:	cc9c                	sw	a5,24(s1)
  sched();
    80001fb4:	f2fff0ef          	jal	80001ee2 <sched>
  release(&p->lock);
    80001fb8:	8526                	mv	a0,s1
    80001fba:	d49fe0ef          	jal	80000d02 <release>
}
    80001fbe:	60e2                	ld	ra,24(sp)
    80001fc0:	6442                	ld	s0,16(sp)
    80001fc2:	64a2                	ld	s1,8(sp)
    80001fc4:	6105                	addi	sp,sp,32
    80001fc6:	8082                	ret

0000000080001fc8 <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80001fc8:	1101                	addi	sp,sp,-32
    80001fca:	ec06                	sd	ra,24(sp)
    80001fcc:	e822                	sd	s0,16(sp)
    80001fce:	e426                	sd	s1,8(sp)
    80001fd0:	e04a                	sd	s2,0(sp)
    80001fd2:	1000                	addi	s0,sp,32
    80001fd4:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001fd6:	9efff0ef          	jal	800019c4 <myproc>
    80001fda:	892a                	mv	s2,a0

  acquire(&p->lock);
    80001fdc:	c9bfe0ef          	jal	80000c76 <acquire>
  if (chan == 0)
    80001fe0:	cc81                	beqz	s1,80001ff8 <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80001fe2:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80001fe6:	854a                	mv	a0,s2
    80001fe8:	d1bfe0ef          	jal	80000d02 <release>
}
    80001fec:	60e2                	ld	ra,24(sp)
    80001fee:	6442                	ld	s0,16(sp)
    80001ff0:	64a2                	ld	s1,8(sp)
    80001ff2:	6902                	ld	s2,0(sp)
    80001ff4:	6105                	addi	sp,sp,32
    80001ff6:	8082                	ret
    panic("sleep_prepare: zero chan");
    80001ff8:	00005517          	auipc	a0,0x5
    80001ffc:	1e850513          	addi	a0,a0,488 # 800071e0 <etext+0x1e0>
    80002000:	ff0fe0ef          	jal	800007f0 <panic>

0000000080002004 <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    80002004:	1101                	addi	sp,sp,-32
    80002006:	ec06                	sd	ra,24(sp)
    80002008:	e822                	sd	s0,16(sp)
    8000200a:	e426                	sd	s1,8(sp)
    8000200c:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    8000200e:	9b7ff0ef          	jal	800019c4 <myproc>
    80002012:	84aa                	mv	s1,a0

  acquire(&p->lock);
    80002014:	c63fe0ef          	jal	80000c76 <acquire>
  if (p->chan != 0) {
    80002018:	709c                	ld	a5,32(s1)
    8000201a:	c789                	beqz	a5,80002024 <sleep+0x20>
    p->state = SLEEPING;
    8000201c:	4789                	li	a5,2
    8000201e:	cc9c                	sw	a5,24(s1)
    sched();
    80002020:	ec3ff0ef          	jal	80001ee2 <sched>
  }
  release(&p->lock);
    80002024:	8526                	mv	a0,s1
    80002026:	cddfe0ef          	jal	80000d02 <release>
}
    8000202a:	60e2                	ld	ra,24(sp)
    8000202c:	6442                	ld	s0,16(sp)
    8000202e:	64a2                	ld	s1,8(sp)
    80002030:	6105                	addi	sp,sp,32
    80002032:	8082                	ret

0000000080002034 <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    80002034:	7139                	addi	sp,sp,-64
    80002036:	fc06                	sd	ra,56(sp)
    80002038:	f822                	sd	s0,48(sp)
    8000203a:	f426                	sd	s1,40(sp)
    8000203c:	f04a                	sd	s2,32(sp)
    8000203e:	ec4e                	sd	s3,24(sp)
    80002040:	e852                	sd	s4,16(sp)
    80002042:	e456                	sd	s5,8(sp)
    80002044:	0080                	addi	s0,sp,64
    80002046:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80002048:	00011497          	auipc	s1,0x11
    8000204c:	85848493          	addi	s1,s1,-1960 # 800128a0 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80002050:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80002052:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80002054:	00016997          	auipc	s3,0x16
    80002058:	24c98993          	addi	s3,s3,588 # 800182a0 <tickslock>
    8000205c:	a801                	j	8000206c <wakeup+0x38>
      }
    }
    release(&p->lock);
    8000205e:	8526                	mv	a0,s1
    80002060:	ca3fe0ef          	jal	80000d02 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002064:	16848493          	addi	s1,s1,360
    80002068:	03348063          	beq	s1,s3,80002088 <wakeup+0x54>
    acquire(&p->lock);
    8000206c:	8526                	mv	a0,s1
    8000206e:	c09fe0ef          	jal	80000c76 <acquire>
    if (p->chan == chan) {
    80002072:	709c                	ld	a5,32(s1)
    80002074:	ff2795e3          	bne	a5,s2,8000205e <wakeup+0x2a>
      p->chan = 0;
    80002078:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    8000207c:	4c9c                	lw	a5,24(s1)
    8000207e:	ff4790e3          	bne	a5,s4,8000205e <wakeup+0x2a>
        p->state = RUNNABLE;
    80002082:	0154ac23          	sw	s5,24(s1)
    80002086:	bfe1                	j	8000205e <wakeup+0x2a>
  }
}
    80002088:	70e2                	ld	ra,56(sp)
    8000208a:	7442                	ld	s0,48(sp)
    8000208c:	74a2                	ld	s1,40(sp)
    8000208e:	7902                	ld	s2,32(sp)
    80002090:	69e2                	ld	s3,24(sp)
    80002092:	6a42                	ld	s4,16(sp)
    80002094:	6aa2                	ld	s5,8(sp)
    80002096:	6121                	addi	sp,sp,64
    80002098:	8082                	ret

000000008000209a <reparent>:
{
    8000209a:	7179                	addi	sp,sp,-48
    8000209c:	f406                	sd	ra,40(sp)
    8000209e:	f022                	sd	s0,32(sp)
    800020a0:	ec26                	sd	s1,24(sp)
    800020a2:	e84a                	sd	s2,16(sp)
    800020a4:	e44e                	sd	s3,8(sp)
    800020a6:	e052                	sd	s4,0(sp)
    800020a8:	1800                	addi	s0,sp,48
    800020aa:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    800020ac:	00010497          	auipc	s1,0x10
    800020b0:	7f448493          	addi	s1,s1,2036 # 800128a0 <proc>
      pp->parent = initproc;
    800020b4:	00008a17          	auipc	s4,0x8
    800020b8:	28ca0a13          	addi	s4,s4,652 # 8000a340 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    800020bc:	00016997          	auipc	s3,0x16
    800020c0:	1e498993          	addi	s3,s3,484 # 800182a0 <tickslock>
    800020c4:	a029                	j	800020ce <reparent+0x34>
    800020c6:	16848493          	addi	s1,s1,360
    800020ca:	01348b63          	beq	s1,s3,800020e0 <reparent+0x46>
    if (pp->parent == p) {
    800020ce:	7c9c                	ld	a5,56(s1)
    800020d0:	ff279be3          	bne	a5,s2,800020c6 <reparent+0x2c>
      pp->parent = initproc;
    800020d4:	000a3503          	ld	a0,0(s4)
    800020d8:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    800020da:	f5bff0ef          	jal	80002034 <wakeup>
    800020de:	b7e5                	j	800020c6 <reparent+0x2c>
}
    800020e0:	70a2                	ld	ra,40(sp)
    800020e2:	7402                	ld	s0,32(sp)
    800020e4:	64e2                	ld	s1,24(sp)
    800020e6:	6942                	ld	s2,16(sp)
    800020e8:	69a2                	ld	s3,8(sp)
    800020ea:	6a02                	ld	s4,0(sp)
    800020ec:	6145                	addi	sp,sp,48
    800020ee:	8082                	ret

00000000800020f0 <kexit>:
{
    800020f0:	7179                	addi	sp,sp,-48
    800020f2:	f406                	sd	ra,40(sp)
    800020f4:	f022                	sd	s0,32(sp)
    800020f6:	ec26                	sd	s1,24(sp)
    800020f8:	e84a                	sd	s2,16(sp)
    800020fa:	e44e                	sd	s3,8(sp)
    800020fc:	e052                	sd	s4,0(sp)
    800020fe:	1800                	addi	s0,sp,48
    80002100:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002102:	8c3ff0ef          	jal	800019c4 <myproc>
    80002106:	89aa                	mv	s3,a0
  if (p == initproc)
    80002108:	00008797          	auipc	a5,0x8
    8000210c:	2387b783          	ld	a5,568(a5) # 8000a340 <initproc>
    80002110:	0d050493          	addi	s1,a0,208
    80002114:	15050913          	addi	s2,a0,336
    80002118:	00a79f63          	bne	a5,a0,80002136 <kexit+0x46>
    panic("init exiting");
    8000211c:	00005517          	auipc	a0,0x5
    80002120:	0e450513          	addi	a0,a0,228 # 80007200 <etext+0x200>
    80002124:	eccfe0ef          	jal	800007f0 <panic>
      fileclose(f);
    80002128:	24c020ef          	jal	80004374 <fileclose>
      p->ofile[fd] = 0;
    8000212c:	0004b023          	sd	zero,0(s1)
  for (int fd = 0; fd < NOFILE; fd++) {
    80002130:	04a1                	addi	s1,s1,8
    80002132:	01248563          	beq	s1,s2,8000213c <kexit+0x4c>
    if (p->ofile[fd]) {
    80002136:	6088                	ld	a0,0(s1)
    80002138:	f965                	bnez	a0,80002128 <kexit+0x38>
    8000213a:	bfdd                	j	80002130 <kexit+0x40>
  begin_op();
    8000213c:	58d010ef          	jal	80003ec8 <begin_op>
  iput(p->cwd);
    80002140:	1509b503          	ld	a0,336(s3)
    80002144:	4bc010ef          	jal	80003600 <iput>
  end_op();
    80002148:	607010ef          	jal	80003f4e <end_op>
  p->cwd = 0;
    8000214c:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002150:	00010497          	auipc	s1,0x10
    80002154:	33848493          	addi	s1,s1,824 # 80012488 <wait_lock>
    80002158:	8526                	mv	a0,s1
    8000215a:	b1dfe0ef          	jal	80000c76 <acquire>
  reparent(p);
    8000215e:	854e                	mv	a0,s3
    80002160:	f3bff0ef          	jal	8000209a <reparent>
  wakeup(p->parent);
    80002164:	0389b503          	ld	a0,56(s3)
    80002168:	ecdff0ef          	jal	80002034 <wakeup>
  acquire(&p->lock);
    8000216c:	854e                	mv	a0,s3
    8000216e:	b09fe0ef          	jal	80000c76 <acquire>
  p->xstate = status;
    80002172:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002176:	4795                	li	a5,5
    80002178:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    8000217c:	8526                	mv	a0,s1
    8000217e:	b85fe0ef          	jal	80000d02 <release>
  sched();
    80002182:	d61ff0ef          	jal	80001ee2 <sched>
  panic("zombie exit");
    80002186:	00005517          	auipc	a0,0x5
    8000218a:	08a50513          	addi	a0,a0,138 # 80007210 <etext+0x210>
    8000218e:	e62fe0ef          	jal	800007f0 <panic>

0000000080002192 <kkill>:
int
kkill(int pid)
{
  struct proc *p;

  if (pid == 0)
    80002192:	c525                	beqz	a0,800021fa <kkill+0x68>
{
    80002194:	7179                	addi	sp,sp,-48
    80002196:	f406                	sd	ra,40(sp)
    80002198:	f022                	sd	s0,32(sp)
    8000219a:	ec26                	sd	s1,24(sp)
    8000219c:	e84a                	sd	s2,16(sp)
    8000219e:	e44e                	sd	s3,8(sp)
    800021a0:	1800                	addi	s0,sp,48
    800021a2:	892a                	mv	s2,a0
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    800021a4:	00010497          	auipc	s1,0x10
    800021a8:	6fc48493          	addi	s1,s1,1788 # 800128a0 <proc>
    800021ac:	00016997          	auipc	s3,0x16
    800021b0:	0f498993          	addi	s3,s3,244 # 800182a0 <tickslock>
    acquire(&p->lock);
    800021b4:	8526                	mv	a0,s1
    800021b6:	ac1fe0ef          	jal	80000c76 <acquire>
    if (p->pid == pid) {
    800021ba:	589c                	lw	a5,48(s1)
    800021bc:	01278b63          	beq	a5,s2,800021d2 <kkill+0x40>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800021c0:	8526                	mv	a0,s1
    800021c2:	b41fe0ef          	jal	80000d02 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    800021c6:	16848493          	addi	s1,s1,360
    800021ca:	ff3495e3          	bne	s1,s3,800021b4 <kkill+0x22>
  }
  return -1;
    800021ce:	557d                	li	a0,-1
    800021d0:	a819                	j	800021e6 <kkill+0x54>
      p->killed = 1;
    800021d2:	4785                	li	a5,1
    800021d4:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    800021d6:	4c98                	lw	a4,24(s1)
    800021d8:	4789                	li	a5,2
    800021da:	00f70d63          	beq	a4,a5,800021f4 <kkill+0x62>
      release(&p->lock);
    800021de:	8526                	mv	a0,s1
    800021e0:	b23fe0ef          	jal	80000d02 <release>
      return 0;
    800021e4:	4501                	li	a0,0
}
    800021e6:	70a2                	ld	ra,40(sp)
    800021e8:	7402                	ld	s0,32(sp)
    800021ea:	64e2                	ld	s1,24(sp)
    800021ec:	6942                	ld	s2,16(sp)
    800021ee:	69a2                	ld	s3,8(sp)
    800021f0:	6145                	addi	sp,sp,48
    800021f2:	8082                	ret
        p->state = RUNNABLE;
    800021f4:	478d                	li	a5,3
    800021f6:	cc9c                	sw	a5,24(s1)
    800021f8:	b7dd                	j	800021de <kkill+0x4c>
    return -1;
    800021fa:	557d                	li	a0,-1
}
    800021fc:	8082                	ret

00000000800021fe <setkilled>:

void
setkilled(struct proc *p)
{
    800021fe:	1101                	addi	sp,sp,-32
    80002200:	ec06                	sd	ra,24(sp)
    80002202:	e822                	sd	s0,16(sp)
    80002204:	e426                	sd	s1,8(sp)
    80002206:	1000                	addi	s0,sp,32
    80002208:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000220a:	a6dfe0ef          	jal	80000c76 <acquire>
  p->killed = 1;
    8000220e:	4785                	li	a5,1
    80002210:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002212:	8526                	mv	a0,s1
    80002214:	aeffe0ef          	jal	80000d02 <release>
}
    80002218:	60e2                	ld	ra,24(sp)
    8000221a:	6442                	ld	s0,16(sp)
    8000221c:	64a2                	ld	s1,8(sp)
    8000221e:	6105                	addi	sp,sp,32
    80002220:	8082                	ret

0000000080002222 <killed>:

int
killed(struct proc *p)
{
    80002222:	1101                	addi	sp,sp,-32
    80002224:	ec06                	sd	ra,24(sp)
    80002226:	e822                	sd	s0,16(sp)
    80002228:	e426                	sd	s1,8(sp)
    8000222a:	e04a                	sd	s2,0(sp)
    8000222c:	1000                	addi	s0,sp,32
    8000222e:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    80002230:	a47fe0ef          	jal	80000c76 <acquire>
  k = p->killed;
    80002234:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    80002238:	8526                	mv	a0,s1
    8000223a:	ac9fe0ef          	jal	80000d02 <release>
  return k;
}
    8000223e:	854a                	mv	a0,s2
    80002240:	60e2                	ld	ra,24(sp)
    80002242:	6442                	ld	s0,16(sp)
    80002244:	64a2                	ld	s1,8(sp)
    80002246:	6902                	ld	s2,0(sp)
    80002248:	6105                	addi	sp,sp,32
    8000224a:	8082                	ret

000000008000224c <kwait>:
{
    8000224c:	715d                	addi	sp,sp,-80
    8000224e:	e486                	sd	ra,72(sp)
    80002250:	e0a2                	sd	s0,64(sp)
    80002252:	fc26                	sd	s1,56(sp)
    80002254:	f84a                	sd	s2,48(sp)
    80002256:	f44e                	sd	s3,40(sp)
    80002258:	f052                	sd	s4,32(sp)
    8000225a:	ec56                	sd	s5,24(sp)
    8000225c:	e85a                	sd	s6,16(sp)
    8000225e:	e45e                	sd	s7,8(sp)
    80002260:	e062                	sd	s8,0(sp)
    80002262:	0880                	addi	s0,sp,80
    80002264:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80002266:	f5eff0ef          	jal	800019c4 <myproc>
    8000226a:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000226c:	00010517          	auipc	a0,0x10
    80002270:	21c50513          	addi	a0,a0,540 # 80012488 <wait_lock>
    80002274:	a03fe0ef          	jal	80000c76 <acquire>
    havekids = 0;
    80002278:	4c01                	li	s8,0
        if (pp->state == ZOMBIE) {
    8000227a:	4a15                	li	s4,5
        havekids = 1;
    8000227c:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000227e:	00016997          	auipc	s3,0x16
    80002282:	02298993          	addi	s3,s3,34 # 800182a0 <tickslock>
    release(&wait_lock);
    80002286:	00010b97          	auipc	s7,0x10
    8000228a:	202b8b93          	addi	s7,s7,514 # 80012488 <wait_lock>
    8000228e:	a84d                	j	80002340 <kwait+0xf4>
          pid = pp->pid;
    80002290:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    80002294:	000b0e63          	beqz	s6,800022b0 <kwait+0x64>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    80002298:	4711                	li	a4,4
    8000229a:	02c48693          	addi	a3,s1,44
    8000229e:	865a                	mv	a2,s6
    800022a0:	04893583          	ld	a1,72(s2)
    800022a4:	05093503          	ld	a0,80(s2)
    800022a8:	b16ff0ef          	jal	800015be <copyout>
          if (addr != 0 &&
    800022ac:	02054d63          	bltz	a0,800022e6 <kwait+0x9a>
          pp->parent = 0;
    800022b0:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    800022b4:	8526                	mv	a0,s1
    800022b6:	8dbff0ef          	jal	80001b90 <freeproc>
          release(&pp->lock);
    800022ba:	8526                	mv	a0,s1
    800022bc:	a47fe0ef          	jal	80000d02 <release>
          release(&wait_lock);
    800022c0:	00010517          	auipc	a0,0x10
    800022c4:	1c850513          	addi	a0,a0,456 # 80012488 <wait_lock>
    800022c8:	a3bfe0ef          	jal	80000d02 <release>
}
    800022cc:	854e                	mv	a0,s3
    800022ce:	60a6                	ld	ra,72(sp)
    800022d0:	6406                	ld	s0,64(sp)
    800022d2:	74e2                	ld	s1,56(sp)
    800022d4:	7942                	ld	s2,48(sp)
    800022d6:	79a2                	ld	s3,40(sp)
    800022d8:	7a02                	ld	s4,32(sp)
    800022da:	6ae2                	ld	s5,24(sp)
    800022dc:	6b42                	ld	s6,16(sp)
    800022de:	6ba2                	ld	s7,8(sp)
    800022e0:	6c02                	ld	s8,0(sp)
    800022e2:	6161                	addi	sp,sp,80
    800022e4:	8082                	ret
            release(&pp->lock);
    800022e6:	8526                	mv	a0,s1
    800022e8:	a1bfe0ef          	jal	80000d02 <release>
            release(&wait_lock);
    800022ec:	00010517          	auipc	a0,0x10
    800022f0:	19c50513          	addi	a0,a0,412 # 80012488 <wait_lock>
    800022f4:	a0ffe0ef          	jal	80000d02 <release>
            return -1;
    800022f8:	59fd                	li	s3,-1
    800022fa:	bfc9                	j	800022cc <kwait+0x80>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800022fc:	16848493          	addi	s1,s1,360
    80002300:	03348063          	beq	s1,s3,80002320 <kwait+0xd4>
      if (pp->parent == p) {
    80002304:	7c9c                	ld	a5,56(s1)
    80002306:	ff279be3          	bne	a5,s2,800022fc <kwait+0xb0>
        acquire(&pp->lock);
    8000230a:	8526                	mv	a0,s1
    8000230c:	96bfe0ef          	jal	80000c76 <acquire>
        if (pp->state == ZOMBIE) {
    80002310:	4c9c                	lw	a5,24(s1)
    80002312:	f7478fe3          	beq	a5,s4,80002290 <kwait+0x44>
        release(&pp->lock);
    80002316:	8526                	mv	a0,s1
    80002318:	9ebfe0ef          	jal	80000d02 <release>
        havekids = 1;
    8000231c:	8756                	mv	a4,s5
    8000231e:	bff9                	j	800022fc <kwait+0xb0>
    if (!havekids || killed(p)) {
    80002320:	c715                	beqz	a4,8000234c <kwait+0x100>
    80002322:	854a                	mv	a0,s2
    80002324:	effff0ef          	jal	80002222 <killed>
    80002328:	e115                	bnez	a0,8000234c <kwait+0x100>
    sleep_prepare(p); //DOC: wait-sleep
    8000232a:	854a                	mv	a0,s2
    8000232c:	c9dff0ef          	jal	80001fc8 <sleep_prepare>
    release(&wait_lock);
    80002330:	855e                	mv	a0,s7
    80002332:	9d1fe0ef          	jal	80000d02 <release>
    sleep();
    80002336:	ccfff0ef          	jal	80002004 <sleep>
    acquire(&wait_lock);
    8000233a:	855e                	mv	a0,s7
    8000233c:	93bfe0ef          	jal	80000c76 <acquire>
    havekids = 0;
    80002340:	8762                	mv	a4,s8
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002342:	00010497          	auipc	s1,0x10
    80002346:	55e48493          	addi	s1,s1,1374 # 800128a0 <proc>
    8000234a:	bf6d                	j	80002304 <kwait+0xb8>
      release(&wait_lock);
    8000234c:	00010517          	auipc	a0,0x10
    80002350:	13c50513          	addi	a0,a0,316 # 80012488 <wait_lock>
    80002354:	9affe0ef          	jal	80000d02 <release>
      return -1;
    80002358:	59fd                	li	s3,-1
    8000235a:	bf8d                	j	800022cc <kwait+0x80>

000000008000235c <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000235c:	7179                	addi	sp,sp,-48
    8000235e:	f406                	sd	ra,40(sp)
    80002360:	f022                	sd	s0,32(sp)
    80002362:	ec26                	sd	s1,24(sp)
    80002364:	e84a                	sd	s2,16(sp)
    80002366:	e44e                	sd	s3,8(sp)
    80002368:	e052                	sd	s4,0(sp)
    8000236a:	1800                	addi	s0,sp,48
    8000236c:	84aa                	mv	s1,a0
    8000236e:	892e                	mv	s2,a1
    80002370:	89b2                	mv	s3,a2
    80002372:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002374:	e50ff0ef          	jal	800019c4 <myproc>
  if (user_dst) {
    80002378:	c085                	beqz	s1,80002398 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    8000237a:	8752                	mv	a4,s4
    8000237c:	86ce                	mv	a3,s3
    8000237e:	864a                	mv	a2,s2
    80002380:	652c                	ld	a1,72(a0)
    80002382:	6928                	ld	a0,80(a0)
    80002384:	a3aff0ef          	jal	800015be <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002388:	70a2                	ld	ra,40(sp)
    8000238a:	7402                	ld	s0,32(sp)
    8000238c:	64e2                	ld	s1,24(sp)
    8000238e:	6942                	ld	s2,16(sp)
    80002390:	69a2                	ld	s3,8(sp)
    80002392:	6a02                	ld	s4,0(sp)
    80002394:	6145                	addi	sp,sp,48
    80002396:	8082                	ret
    memmove((char *)dst, src, len);
    80002398:	000a061b          	sext.w	a2,s4
    8000239c:	85ce                	mv	a1,s3
    8000239e:	854a                	mv	a0,s2
    800023a0:	9f7fe0ef          	jal	80000d96 <memmove>
    return 0;
    800023a4:	8526                	mv	a0,s1
    800023a6:	b7cd                	j	80002388 <either_copyout+0x2c>

00000000800023a8 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800023a8:	7179                	addi	sp,sp,-48
    800023aa:	f406                	sd	ra,40(sp)
    800023ac:	f022                	sd	s0,32(sp)
    800023ae:	ec26                	sd	s1,24(sp)
    800023b0:	e84a                	sd	s2,16(sp)
    800023b2:	e44e                	sd	s3,8(sp)
    800023b4:	e052                	sd	s4,0(sp)
    800023b6:	1800                	addi	s0,sp,48
    800023b8:	892a                	mv	s2,a0
    800023ba:	84ae                	mv	s1,a1
    800023bc:	89b2                	mv	s3,a2
    800023be:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800023c0:	e04ff0ef          	jal	800019c4 <myproc>
  if (user_src) {
    800023c4:	c085                	beqz	s1,800023e4 <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    800023c6:	8752                	mv	a4,s4
    800023c8:	86ce                	mv	a3,s3
    800023ca:	864a                	mv	a2,s2
    800023cc:	652c                	ld	a1,72(a0)
    800023ce:	6928                	ld	a0,80(a0)
    800023d0:	adaff0ef          	jal	800016aa <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    800023d4:	70a2                	ld	ra,40(sp)
    800023d6:	7402                	ld	s0,32(sp)
    800023d8:	64e2                	ld	s1,24(sp)
    800023da:	6942                	ld	s2,16(sp)
    800023dc:	69a2                	ld	s3,8(sp)
    800023de:	6a02                	ld	s4,0(sp)
    800023e0:	6145                	addi	sp,sp,48
    800023e2:	8082                	ret
    memmove(dst, (char *)src, len);
    800023e4:	000a061b          	sext.w	a2,s4
    800023e8:	85ce                	mv	a1,s3
    800023ea:	854a                	mv	a0,s2
    800023ec:	9abfe0ef          	jal	80000d96 <memmove>
    return 0;
    800023f0:	8526                	mv	a0,s1
    800023f2:	b7cd                	j	800023d4 <either_copyin+0x2c>

00000000800023f4 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800023f4:	715d                	addi	sp,sp,-80
    800023f6:	e486                	sd	ra,72(sp)
    800023f8:	e0a2                	sd	s0,64(sp)
    800023fa:	fc26                	sd	s1,56(sp)
    800023fc:	f84a                	sd	s2,48(sp)
    800023fe:	f44e                	sd	s3,40(sp)
    80002400:	f052                	sd	s4,32(sp)
    80002402:	ec56                	sd	s5,24(sp)
    80002404:	e85a                	sd	s6,16(sp)
    80002406:	e45e                	sd	s7,8(sp)
    80002408:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    8000240a:	00005517          	auipc	a0,0x5
    8000240e:	c6e50513          	addi	a0,a0,-914 # 80007078 <etext+0x78>
    80002412:	8f8fe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002416:	00010497          	auipc	s1,0x10
    8000241a:	5e248493          	addi	s1,s1,1506 # 800129f8 <proc+0x158>
    8000241e:	00016917          	auipc	s2,0x16
    80002422:	fda90913          	addi	s2,s2,-38 # 800183f8 <bcache+0x140>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002426:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002428:	00005997          	auipc	s3,0x5
    8000242c:	df898993          	addi	s3,s3,-520 # 80007220 <etext+0x220>
    printk("%d %s %s", p->pid, state, p->name);
    80002430:	00005a97          	auipc	s5,0x5
    80002434:	df8a8a93          	addi	s5,s5,-520 # 80007228 <etext+0x228>
    printk("\n");
    80002438:	00005a17          	auipc	s4,0x5
    8000243c:	c40a0a13          	addi	s4,s4,-960 # 80007078 <etext+0x78>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002440:	00005b97          	auipc	s7,0x5
    80002444:	308b8b93          	addi	s7,s7,776 # 80007748 <states.0>
    80002448:	a829                	j	80002462 <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    8000244a:	ed86a583          	lw	a1,-296(a3)
    8000244e:	8556                	mv	a0,s5
    80002450:	8bafe0ef          	jal	8000050a <printk>
    printk("\n");
    80002454:	8552                	mv	a0,s4
    80002456:	8b4fe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000245a:	16848493          	addi	s1,s1,360
    8000245e:	03248263          	beq	s1,s2,80002482 <procdump+0x8e>
    if (p->state == UNUSED)
    80002462:	86a6                	mv	a3,s1
    80002464:	ec04a783          	lw	a5,-320(s1)
    80002468:	dbed                	beqz	a5,8000245a <procdump+0x66>
      state = "???";
    8000246a:	864e                	mv	a2,s3
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000246c:	fcfb6fe3          	bltu	s6,a5,8000244a <procdump+0x56>
    80002470:	02079713          	slli	a4,a5,0x20
    80002474:	01d75793          	srli	a5,a4,0x1d
    80002478:	97de                	add	a5,a5,s7
    8000247a:	6390                	ld	a2,0(a5)
    8000247c:	f679                	bnez	a2,8000244a <procdump+0x56>
      state = "???";
    8000247e:	864e                	mv	a2,s3
    80002480:	b7e9                	j	8000244a <procdump+0x56>
  }
}
    80002482:	60a6                	ld	ra,72(sp)
    80002484:	6406                	ld	s0,64(sp)
    80002486:	74e2                	ld	s1,56(sp)
    80002488:	7942                	ld	s2,48(sp)
    8000248a:	79a2                	ld	s3,40(sp)
    8000248c:	7a02                	ld	s4,32(sp)
    8000248e:	6ae2                	ld	s5,24(sp)
    80002490:	6b42                	ld	s6,16(sp)
    80002492:	6ba2                	ld	s7,8(sp)
    80002494:	6161                	addi	sp,sp,80
    80002496:	8082                	ret

0000000080002498 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    80002498:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    8000249c:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800024a0:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800024a2:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800024a4:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800024a8:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800024ac:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800024b0:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800024b4:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800024b8:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800024bc:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800024c0:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800024c4:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800024c8:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800024cc:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800024d0:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800024d4:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800024d6:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    800024d8:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    800024dc:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    800024e0:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    800024e4:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    800024e8:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800024ec:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800024f0:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800024f4:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    800024f8:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    800024fc:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002500:	8082                	ret

0000000080002502 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002502:	1141                	addi	sp,sp,-16
    80002504:	e406                	sd	ra,8(sp)
    80002506:	e022                	sd	s0,0(sp)
    80002508:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    8000250a:	00005597          	auipc	a1,0x5
    8000250e:	d5e58593          	addi	a1,a1,-674 # 80007268 <etext+0x268>
    80002512:	00016517          	auipc	a0,0x16
    80002516:	d8e50513          	addi	a0,a0,-626 # 800182a0 <tickslock>
    8000251a:	ee6fe0ef          	jal	80000c00 <initlock>
}
    8000251e:	60a2                	ld	ra,8(sp)
    80002520:	6402                	ld	s0,0(sp)
    80002522:	0141                	addi	sp,sp,16
    80002524:	8082                	ret

0000000080002526 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002526:	1141                	addi	sp,sp,-16
    80002528:	e422                	sd	s0,8(sp)
    8000252a:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    8000252c:	00003797          	auipc	a5,0x3
    80002530:	29478793          	addi	a5,a5,660 # 800057c0 <kernelvec>
    80002534:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002538:	6422                	ld	s0,8(sp)
    8000253a:	0141                	addi	sp,sp,16
    8000253c:	8082                	ret

000000008000253e <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    8000253e:	1141                	addi	sp,sp,-16
    80002540:	e406                	sd	ra,8(sp)
    80002542:	e022                	sd	s0,0(sp)
    80002544:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002546:	c7eff0ef          	jal	800019c4 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    8000254a:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    8000254e:	04000737          	lui	a4,0x4000
    80002552:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80002554:	0732                	slli	a4,a4,0xc
    80002556:	00004797          	auipc	a5,0x4
    8000255a:	aaa78793          	addi	a5,a5,-1366 # 80006000 <_trampoline>
    8000255e:	00004697          	auipc	a3,0x4
    80002562:	aa268693          	addi	a3,a3,-1374 # 80006000 <_trampoline>
    80002566:	8f95                	sub	a5,a5,a3
    80002568:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    8000256a:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    8000256e:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    80002570:	18002773          	csrr	a4,satp
    80002574:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002576:	6d38                	ld	a4,88(a0)
    80002578:	613c                	ld	a5,64(a0)
    8000257a:	6685                	lui	a3,0x1
    8000257c:	97b6                	add	a5,a5,a3
    8000257e:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002580:	6d3c                	ld	a5,88(a0)
    80002582:	00000717          	auipc	a4,0x0
    80002586:	0f870713          	addi	a4,a4,248 # 8000267a <usertrap>
    8000258a:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    8000258c:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    8000258e:	8712                	mv	a4,tp
    80002590:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002592:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002596:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    8000259a:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    8000259e:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800025a2:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    800025a4:	6f9c                	ld	a5,24(a5)
    800025a6:	14179073          	csrw	sepc,a5
}
    800025aa:	60a2                	ld	ra,8(sp)
    800025ac:	6402                	ld	s0,0(sp)
    800025ae:	0141                	addi	sp,sp,16
    800025b0:	8082                	ret

00000000800025b2 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800025b2:	1101                	addi	sp,sp,-32
    800025b4:	ec06                	sd	ra,24(sp)
    800025b6:	e822                	sd	s0,16(sp)
    800025b8:	1000                	addi	s0,sp,32
  if (cpuid() == 0) {
    800025ba:	bdeff0ef          	jal	80001998 <cpuid>
    800025be:	cd11                	beqz	a0,800025da <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    800025c0:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800025c4:	000f4737          	lui	a4,0xf4
    800025c8:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800025cc:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    800025ce:	14d79073          	csrw	stimecmp,a5
}
    800025d2:	60e2                	ld	ra,24(sp)
    800025d4:	6442                	ld	s0,16(sp)
    800025d6:	6105                	addi	sp,sp,32
    800025d8:	8082                	ret
    800025da:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    800025dc:	00016497          	auipc	s1,0x16
    800025e0:	cc448493          	addi	s1,s1,-828 # 800182a0 <tickslock>
    800025e4:	8526                	mv	a0,s1
    800025e6:	e90fe0ef          	jal	80000c76 <acquire>
    ticks++;
    800025ea:	00008517          	auipc	a0,0x8
    800025ee:	d5e50513          	addi	a0,a0,-674 # 8000a348 <ticks>
    800025f2:	411c                	lw	a5,0(a0)
    800025f4:	2785                	addiw	a5,a5,1
    800025f6:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    800025f8:	a3dff0ef          	jal	80002034 <wakeup>
    release(&tickslock);
    800025fc:	8526                	mv	a0,s1
    800025fe:	f04fe0ef          	jal	80000d02 <release>
    80002602:	64a2                	ld	s1,8(sp)
    80002604:	bf75                	j	800025c0 <clockintr+0xe>

0000000080002606 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002606:	1101                	addi	sp,sp,-32
    80002608:	ec06                	sd	ra,24(sp)
    8000260a:	e822                	sd	s0,16(sp)
    8000260c:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    8000260e:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    80002612:	57fd                	li	a5,-1
    80002614:	17fe                	slli	a5,a5,0x3f
    80002616:	07a5                	addi	a5,a5,9
    80002618:	00f70c63          	beq	a4,a5,80002630 <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    8000261c:	57fd                	li	a5,-1
    8000261e:	17fe                	slli	a5,a5,0x3f
    80002620:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002622:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    80002624:	04f70763          	beq	a4,a5,80002672 <devintr+0x6c>
  }
}
    80002628:	60e2                	ld	ra,24(sp)
    8000262a:	6442                	ld	s0,16(sp)
    8000262c:	6105                	addi	sp,sp,32
    8000262e:	8082                	ret
    80002630:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002632:	23c030ef          	jal	8000586e <plic_claim>
    80002636:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    80002638:	47a9                	li	a5,10
    8000263a:	00f50963          	beq	a0,a5,8000264c <devintr+0x46>
    } else if (irq == VIRTIO0_IRQ) {
    8000263e:	4785                	li	a5,1
    80002640:	00f50963          	beq	a0,a5,80002652 <devintr+0x4c>
    return 1;
    80002644:	4505                	li	a0,1
    } else if (irq) {
    80002646:	e889                	bnez	s1,80002658 <devintr+0x52>
    80002648:	64a2                	ld	s1,8(sp)
    8000264a:	bff9                	j	80002628 <devintr+0x22>
      uartintr();
    8000264c:	b60fe0ef          	jal	800009ac <uartintr>
    if (irq)
    80002650:	a819                	j	80002666 <devintr+0x60>
      virtio_disk_intr();
    80002652:	706030ef          	jal	80005d58 <virtio_disk_intr>
    if (irq)
    80002656:	a801                	j	80002666 <devintr+0x60>
      printk("unexpected interrupt irq=%d\n", irq);
    80002658:	85a6                	mv	a1,s1
    8000265a:	00005517          	auipc	a0,0x5
    8000265e:	c1650513          	addi	a0,a0,-1002 # 80007270 <etext+0x270>
    80002662:	ea9fd0ef          	jal	8000050a <printk>
      plic_complete(irq);
    80002666:	8526                	mv	a0,s1
    80002668:	228030ef          	jal	80005890 <plic_complete>
    return 1;
    8000266c:	4505                	li	a0,1
    8000266e:	64a2                	ld	s1,8(sp)
    80002670:	bf65                	j	80002628 <devintr+0x22>
    clockintr();
    80002672:	f41ff0ef          	jal	800025b2 <clockintr>
    return 2;
    80002676:	4509                	li	a0,2
    80002678:	bf45                	j	80002628 <devintr+0x22>

000000008000267a <usertrap>:
{
    8000267a:	1101                	addi	sp,sp,-32
    8000267c:	ec06                	sd	ra,24(sp)
    8000267e:	e822                	sd	s0,16(sp)
    80002680:	e426                	sd	s1,8(sp)
    80002682:	e04a                	sd	s2,0(sp)
    80002684:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002686:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    8000268a:	1007f793          	andi	a5,a5,256
    8000268e:	eba5                	bnez	a5,800026fe <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002690:	00003797          	auipc	a5,0x3
    80002694:	13078793          	addi	a5,a5,304 # 800057c0 <kernelvec>
    80002698:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000269c:	b28ff0ef          	jal	800019c4 <myproc>
    800026a0:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800026a2:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    800026a4:	14102773          	csrr	a4,sepc
    800026a8:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    800026aa:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    800026ae:	47a1                	li	a5,8
    800026b0:	04f70d63          	beq	a4,a5,8000270a <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    800026b4:	f53ff0ef          	jal	80002606 <devintr>
    800026b8:	892a                	mv	s2,a0
    800026ba:	e54d                	bnez	a0,80002764 <usertrap+0xea>
    800026bc:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    800026c0:	47bd                	li	a5,15
    800026c2:	08f70463          	beq	a4,a5,8000274a <usertrap+0xd0>
    800026c6:	14202773          	csrr	a4,scause
    800026ca:	47b5                	li	a5,13
    800026cc:	06f70f63          	beq	a4,a5,8000274a <usertrap+0xd0>
    800026d0:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800026d4:	5890                	lw	a2,48(s1)
    800026d6:	00005517          	auipc	a0,0x5
    800026da:	bda50513          	addi	a0,a0,-1062 # 800072b0 <etext+0x2b0>
    800026de:	e2dfd0ef          	jal	8000050a <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800026e2:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800026e6:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800026ea:	00005517          	auipc	a0,0x5
    800026ee:	bf650513          	addi	a0,a0,-1034 # 800072e0 <etext+0x2e0>
    800026f2:	e19fd0ef          	jal	8000050a <printk>
    setkilled(p);
    800026f6:	8526                	mv	a0,s1
    800026f8:	b07ff0ef          	jal	800021fe <setkilled>
    800026fc:	a015                	j	80002720 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    800026fe:	00005517          	auipc	a0,0x5
    80002702:	b9250513          	addi	a0,a0,-1134 # 80007290 <etext+0x290>
    80002706:	8eafe0ef          	jal	800007f0 <panic>
    if (killed(p))
    8000270a:	b19ff0ef          	jal	80002222 <killed>
    8000270e:	e915                	bnez	a0,80002742 <usertrap+0xc8>
    p->trapframe->epc += 4;
    80002710:	6cb8                	ld	a4,88(s1)
    80002712:	6f1c                	ld	a5,24(a4)
    80002714:	0791                	addi	a5,a5,4
    80002716:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80002718:	10016073          	csrsi	sstatus,2
    syscall();
    8000271c:	24a000ef          	jal	80002966 <syscall>
  if (killed(p))
    80002720:	8526                	mv	a0,s1
    80002722:	b01ff0ef          	jal	80002222 <killed>
    80002726:	e521                	bnez	a0,8000276e <usertrap+0xf4>
  prepare_return();
    80002728:	e17ff0ef          	jal	8000253e <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    8000272c:	68a8                	ld	a0,80(s1)
    8000272e:	8131                	srli	a0,a0,0xc
    80002730:	57fd                	li	a5,-1
    80002732:	17fe                	slli	a5,a5,0x3f
    80002734:	8d5d                	or	a0,a0,a5
}
    80002736:	60e2                	ld	ra,24(sp)
    80002738:	6442                	ld	s0,16(sp)
    8000273a:	64a2                	ld	s1,8(sp)
    8000273c:	6902                	ld	s2,0(sp)
    8000273e:	6105                	addi	sp,sp,32
    80002740:	8082                	ret
      kexit(-1);
    80002742:	557d                	li	a0,-1
    80002744:	9adff0ef          	jal	800020f0 <kexit>
    80002748:	b7e1                	j	80002710 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    8000274a:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    8000274e:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    80002752:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    80002754:	0016b693          	seqz	a3,a3
    80002758:	64ac                	ld	a1,72(s1)
    8000275a:	68a8                	ld	a0,80(s1)
    8000275c:	de7fe0ef          	jal	80001542 <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002760:	f161                	bnez	a0,80002720 <usertrap+0xa6>
    80002762:	b7bd                	j	800026d0 <usertrap+0x56>
  if (killed(p))
    80002764:	8526                	mv	a0,s1
    80002766:	abdff0ef          	jal	80002222 <killed>
    8000276a:	c511                	beqz	a0,80002776 <usertrap+0xfc>
    8000276c:	a011                	j	80002770 <usertrap+0xf6>
    8000276e:	4901                	li	s2,0
    kexit(-1);
    80002770:	557d                	li	a0,-1
    80002772:	97fff0ef          	jal	800020f0 <kexit>
  if (which_dev == 2)
    80002776:	4789                	li	a5,2
    80002778:	faf918e3          	bne	s2,a5,80002728 <usertrap+0xae>
    yield();
    8000277c:	821ff0ef          	jal	80001f9c <yield>
    80002780:	b765                	j	80002728 <usertrap+0xae>

0000000080002782 <kerneltrap>:
{
    80002782:	7179                	addi	sp,sp,-48
    80002784:	f406                	sd	ra,40(sp)
    80002786:	f022                	sd	s0,32(sp)
    80002788:	ec26                	sd	s1,24(sp)
    8000278a:	e84a                	sd	s2,16(sp)
    8000278c:	e44e                	sd	s3,8(sp)
    8000278e:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002790:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002794:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    80002798:	142029f3          	csrr	s3,scause
  if ((sstatus & SSTATUS_SPP) == 0)
    8000279c:	1004f793          	andi	a5,s1,256
    800027a0:	c795                	beqz	a5,800027cc <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800027a2:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800027a6:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    800027a8:	eb85                	bnez	a5,800027d8 <kerneltrap+0x56>
  if ((which_dev = devintr()) == 0) {
    800027aa:	e5dff0ef          	jal	80002606 <devintr>
    800027ae:	c91d                	beqz	a0,800027e4 <kerneltrap+0x62>
  if (which_dev == 2 && myproc() != 0)
    800027b0:	4789                	li	a5,2
    800027b2:	04f50a63          	beq	a0,a5,80002806 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r"(x));
    800027b6:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    800027ba:	10049073          	csrw	sstatus,s1
}
    800027be:	70a2                	ld	ra,40(sp)
    800027c0:	7402                	ld	s0,32(sp)
    800027c2:	64e2                	ld	s1,24(sp)
    800027c4:	6942                	ld	s2,16(sp)
    800027c6:	69a2                	ld	s3,8(sp)
    800027c8:	6145                	addi	sp,sp,48
    800027ca:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800027cc:	00005517          	auipc	a0,0x5
    800027d0:	b3c50513          	addi	a0,a0,-1220 # 80007308 <etext+0x308>
    800027d4:	81cfe0ef          	jal	800007f0 <panic>
    panic("kerneltrap: interrupts enabled");
    800027d8:	00005517          	auipc	a0,0x5
    800027dc:	b5850513          	addi	a0,a0,-1192 # 80007330 <etext+0x330>
    800027e0:	810fe0ef          	jal	800007f0 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800027e4:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800027e8:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    800027ec:	85ce                	mv	a1,s3
    800027ee:	00005517          	auipc	a0,0x5
    800027f2:	b6250513          	addi	a0,a0,-1182 # 80007350 <etext+0x350>
    800027f6:	d15fd0ef          	jal	8000050a <printk>
    panic("kerneltrap");
    800027fa:	00005517          	auipc	a0,0x5
    800027fe:	b7e50513          	addi	a0,a0,-1154 # 80007378 <etext+0x378>
    80002802:	feffd0ef          	jal	800007f0 <panic>
  if (which_dev == 2 && myproc() != 0)
    80002806:	9beff0ef          	jal	800019c4 <myproc>
    8000280a:	d555                	beqz	a0,800027b6 <kerneltrap+0x34>
    yield();
    8000280c:	f90ff0ef          	jal	80001f9c <yield>
    80002810:	b75d                	j	800027b6 <kerneltrap+0x34>

0000000080002812 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002812:	1101                	addi	sp,sp,-32
    80002814:	ec06                	sd	ra,24(sp)
    80002816:	e822                	sd	s0,16(sp)
    80002818:	e426                	sd	s1,8(sp)
    8000281a:	1000                	addi	s0,sp,32
    8000281c:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    8000281e:	9a6ff0ef          	jal	800019c4 <myproc>
  switch (n) {
    80002822:	4795                	li	a5,5
    80002824:	0497e163          	bltu	a5,s1,80002866 <argraw+0x54>
    80002828:	048a                	slli	s1,s1,0x2
    8000282a:	00005717          	auipc	a4,0x5
    8000282e:	f4e70713          	addi	a4,a4,-178 # 80007778 <states.0+0x30>
    80002832:	94ba                	add	s1,s1,a4
    80002834:	409c                	lw	a5,0(s1)
    80002836:	97ba                	add	a5,a5,a4
    80002838:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    8000283a:	6d3c                	ld	a5,88(a0)
    8000283c:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    8000283e:	60e2                	ld	ra,24(sp)
    80002840:	6442                	ld	s0,16(sp)
    80002842:	64a2                	ld	s1,8(sp)
    80002844:	6105                	addi	sp,sp,32
    80002846:	8082                	ret
    return p->trapframe->a1;
    80002848:	6d3c                	ld	a5,88(a0)
    8000284a:	7fa8                	ld	a0,120(a5)
    8000284c:	bfcd                	j	8000283e <argraw+0x2c>
    return p->trapframe->a2;
    8000284e:	6d3c                	ld	a5,88(a0)
    80002850:	63c8                	ld	a0,128(a5)
    80002852:	b7f5                	j	8000283e <argraw+0x2c>
    return p->trapframe->a3;
    80002854:	6d3c                	ld	a5,88(a0)
    80002856:	67c8                	ld	a0,136(a5)
    80002858:	b7dd                	j	8000283e <argraw+0x2c>
    return p->trapframe->a4;
    8000285a:	6d3c                	ld	a5,88(a0)
    8000285c:	6bc8                	ld	a0,144(a5)
    8000285e:	b7c5                	j	8000283e <argraw+0x2c>
    return p->trapframe->a5;
    80002860:	6d3c                	ld	a5,88(a0)
    80002862:	6fc8                	ld	a0,152(a5)
    80002864:	bfe9                	j	8000283e <argraw+0x2c>
  panic("argraw");
    80002866:	00005517          	auipc	a0,0x5
    8000286a:	b2250513          	addi	a0,a0,-1246 # 80007388 <etext+0x388>
    8000286e:	f83fd0ef          	jal	800007f0 <panic>

0000000080002872 <fetchaddr>:
{
    80002872:	1101                	addi	sp,sp,-32
    80002874:	ec06                	sd	ra,24(sp)
    80002876:	e822                	sd	s0,16(sp)
    80002878:	e426                	sd	s1,8(sp)
    8000287a:	e04a                	sd	s2,0(sp)
    8000287c:	1000                	addi	s0,sp,32
    8000287e:	84aa                	mv	s1,a0
    80002880:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002882:	942ff0ef          	jal	800019c4 <myproc>
  if (addr >= p->sz ||
    80002886:	652c                	ld	a1,72(a0)
    80002888:	02b4f663          	bgeu	s1,a1,800028b4 <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    8000288c:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    80002890:	02f5e463          	bltu	a1,a5,800028b8 <fetchaddr+0x46>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    80002894:	4721                	li	a4,8
    80002896:	86a6                	mv	a3,s1
    80002898:	864a                	mv	a2,s2
    8000289a:	6928                	ld	a0,80(a0)
    8000289c:	e0ffe0ef          	jal	800016aa <copyin>
    800028a0:	00a03533          	snez	a0,a0
    800028a4:	40a00533          	neg	a0,a0
}
    800028a8:	60e2                	ld	ra,24(sp)
    800028aa:	6442                	ld	s0,16(sp)
    800028ac:	64a2                	ld	s1,8(sp)
    800028ae:	6902                	ld	s2,0(sp)
    800028b0:	6105                	addi	sp,sp,32
    800028b2:	8082                	ret
    return -1;
    800028b4:	557d                	li	a0,-1
    800028b6:	bfcd                	j	800028a8 <fetchaddr+0x36>
    800028b8:	557d                	li	a0,-1
    800028ba:	b7fd                	j	800028a8 <fetchaddr+0x36>

00000000800028bc <fetchstr>:
{
    800028bc:	7179                	addi	sp,sp,-48
    800028be:	f406                	sd	ra,40(sp)
    800028c0:	f022                	sd	s0,32(sp)
    800028c2:	ec26                	sd	s1,24(sp)
    800028c4:	e84a                	sd	s2,16(sp)
    800028c6:	e44e                	sd	s3,8(sp)
    800028c8:	1800                	addi	s0,sp,48
    800028ca:	892a                	mv	s2,a0
    800028cc:	84ae                	mv	s1,a1
    800028ce:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    800028d0:	8f4ff0ef          	jal	800019c4 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    800028d4:	874e                	mv	a4,s3
    800028d6:	86ca                	mv	a3,s2
    800028d8:	8626                	mv	a2,s1
    800028da:	652c                	ld	a1,72(a0)
    800028dc:	6928                	ld	a0,80(a0)
    800028de:	e63fe0ef          	jal	80001740 <copyinstr>
    800028e2:	00054c63          	bltz	a0,800028fa <fetchstr+0x3e>
  return strlen(buf);
    800028e6:	8526                	mv	a0,s1
    800028e8:	dc2fe0ef          	jal	80000eaa <strlen>
}
    800028ec:	70a2                	ld	ra,40(sp)
    800028ee:	7402                	ld	s0,32(sp)
    800028f0:	64e2                	ld	s1,24(sp)
    800028f2:	6942                	ld	s2,16(sp)
    800028f4:	69a2                	ld	s3,8(sp)
    800028f6:	6145                	addi	sp,sp,48
    800028f8:	8082                	ret
    return -1;
    800028fa:	557d                	li	a0,-1
    800028fc:	bfc5                	j	800028ec <fetchstr+0x30>

00000000800028fe <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800028fe:	1101                	addi	sp,sp,-32
    80002900:	ec06                	sd	ra,24(sp)
    80002902:	e822                	sd	s0,16(sp)
    80002904:	e426                	sd	s1,8(sp)
    80002906:	1000                	addi	s0,sp,32
    80002908:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000290a:	f09ff0ef          	jal	80002812 <argraw>
    8000290e:	c088                	sw	a0,0(s1)
}
    80002910:	60e2                	ld	ra,24(sp)
    80002912:	6442                	ld	s0,16(sp)
    80002914:	64a2                	ld	s1,8(sp)
    80002916:	6105                	addi	sp,sp,32
    80002918:	8082                	ret

000000008000291a <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    8000291a:	1101                	addi	sp,sp,-32
    8000291c:	ec06                	sd	ra,24(sp)
    8000291e:	e822                	sd	s0,16(sp)
    80002920:	e426                	sd	s1,8(sp)
    80002922:	1000                	addi	s0,sp,32
    80002924:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002926:	eedff0ef          	jal	80002812 <argraw>
    8000292a:	e088                	sd	a0,0(s1)
}
    8000292c:	60e2                	ld	ra,24(sp)
    8000292e:	6442                	ld	s0,16(sp)
    80002930:	64a2                	ld	s1,8(sp)
    80002932:	6105                	addi	sp,sp,32
    80002934:	8082                	ret

0000000080002936 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002936:	7179                	addi	sp,sp,-48
    80002938:	f406                	sd	ra,40(sp)
    8000293a:	f022                	sd	s0,32(sp)
    8000293c:	ec26                	sd	s1,24(sp)
    8000293e:	e84a                	sd	s2,16(sp)
    80002940:	1800                	addi	s0,sp,48
    80002942:	84ae                	mv	s1,a1
    80002944:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002946:	fd840593          	addi	a1,s0,-40
    8000294a:	fd1ff0ef          	jal	8000291a <argaddr>
  return fetchstr(addr, buf, max);
    8000294e:	864a                	mv	a2,s2
    80002950:	85a6                	mv	a1,s1
    80002952:	fd843503          	ld	a0,-40(s0)
    80002956:	f67ff0ef          	jal	800028bc <fetchstr>
}
    8000295a:	70a2                	ld	ra,40(sp)
    8000295c:	7402                	ld	s0,32(sp)
    8000295e:	64e2                	ld	s1,24(sp)
    80002960:	6942                	ld	s2,16(sp)
    80002962:	6145                	addi	sp,sp,48
    80002964:	8082                	ret

0000000080002966 <syscall>:
  // clang-format on
};

void
syscall(void)
{
    80002966:	1101                	addi	sp,sp,-32
    80002968:	ec06                	sd	ra,24(sp)
    8000296a:	e822                	sd	s0,16(sp)
    8000296c:	e426                	sd	s1,8(sp)
    8000296e:	e04a                	sd	s2,0(sp)
    80002970:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002972:	852ff0ef          	jal	800019c4 <myproc>
    80002976:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002978:	05853903          	ld	s2,88(a0)
    8000297c:	0a893783          	ld	a5,168(s2)
    80002980:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002984:	37fd                	addiw	a5,a5,-1
    80002986:	4765                	li	a4,25
    80002988:	00f76f63          	bltu	a4,a5,800029a6 <syscall+0x40>
    8000298c:	00369713          	slli	a4,a3,0x3
    80002990:	00005797          	auipc	a5,0x5
    80002994:	e0078793          	addi	a5,a5,-512 # 80007790 <syscalls>
    80002998:	97ba                	add	a5,a5,a4
    8000299a:	639c                	ld	a5,0(a5)
    8000299c:	c789                	beqz	a5,800029a6 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    8000299e:	9782                	jalr	a5
    800029a0:	06a93823          	sd	a0,112(s2)
    800029a4:	a829                	j	800029be <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    800029a6:	15848613          	addi	a2,s1,344
    800029aa:	588c                	lw	a1,48(s1)
    800029ac:	00005517          	auipc	a0,0x5
    800029b0:	9e450513          	addi	a0,a0,-1564 # 80007390 <etext+0x390>
    800029b4:	b57fd0ef          	jal	8000050a <printk>
    p->trapframe->a0 = -1;
    800029b8:	6cbc                	ld	a5,88(s1)
    800029ba:	577d                	li	a4,-1
    800029bc:	fbb8                	sd	a4,112(a5)
  }
}
    800029be:	60e2                	ld	ra,24(sp)
    800029c0:	6442                	ld	s0,16(sp)
    800029c2:	64a2                	ld	s1,8(sp)
    800029c4:	6902                	ld	s2,0(sp)
    800029c6:	6105                	addi	sp,sp,32
    800029c8:	8082                	ret

00000000800029ca <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    800029ca:	1101                	addi	sp,sp,-32
    800029cc:	ec06                	sd	ra,24(sp)
    800029ce:	e822                	sd	s0,16(sp)
    800029d0:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    800029d2:	fec40593          	addi	a1,s0,-20
    800029d6:	4501                	li	a0,0
    800029d8:	f27ff0ef          	jal	800028fe <argint>
  kexit(n);
    800029dc:	fec42503          	lw	a0,-20(s0)
    800029e0:	f10ff0ef          	jal	800020f0 <kexit>
  return 0; // not reached
}
    800029e4:	4501                	li	a0,0
    800029e6:	60e2                	ld	ra,24(sp)
    800029e8:	6442                	ld	s0,16(sp)
    800029ea:	6105                	addi	sp,sp,32
    800029ec:	8082                	ret

00000000800029ee <sys_getpid>:

uint64
sys_getpid(void)
{
    800029ee:	1141                	addi	sp,sp,-16
    800029f0:	e406                	sd	ra,8(sp)
    800029f2:	e022                	sd	s0,0(sp)
    800029f4:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800029f6:	fcffe0ef          	jal	800019c4 <myproc>
}
    800029fa:	5908                	lw	a0,48(a0)
    800029fc:	60a2                	ld	ra,8(sp)
    800029fe:	6402                	ld	s0,0(sp)
    80002a00:	0141                	addi	sp,sp,16
    80002a02:	8082                	ret

0000000080002a04 <sys_fork>:

uint64
sys_fork(void)
{
    80002a04:	1141                	addi	sp,sp,-16
    80002a06:	e406                	sd	ra,8(sp)
    80002a08:	e022                	sd	s0,0(sp)
    80002a0a:	0800                	addi	s0,sp,16
  return kfork();
    80002a0c:	b14ff0ef          	jal	80001d20 <kfork>
}
    80002a10:	60a2                	ld	ra,8(sp)
    80002a12:	6402                	ld	s0,0(sp)
    80002a14:	0141                	addi	sp,sp,16
    80002a16:	8082                	ret

0000000080002a18 <sys_wait>:

uint64
sys_wait(void)
{
    80002a18:	1101                	addi	sp,sp,-32
    80002a1a:	ec06                	sd	ra,24(sp)
    80002a1c:	e822                	sd	s0,16(sp)
    80002a1e:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002a20:	fe840593          	addi	a1,s0,-24
    80002a24:	4501                	li	a0,0
    80002a26:	ef5ff0ef          	jal	8000291a <argaddr>
  return kwait(p);
    80002a2a:	fe843503          	ld	a0,-24(s0)
    80002a2e:	81fff0ef          	jal	8000224c <kwait>
}
    80002a32:	60e2                	ld	ra,24(sp)
    80002a34:	6442                	ld	s0,16(sp)
    80002a36:	6105                	addi	sp,sp,32
    80002a38:	8082                	ret

0000000080002a3a <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002a3a:	7179                	addi	sp,sp,-48
    80002a3c:	f406                	sd	ra,40(sp)
    80002a3e:	f022                	sd	s0,32(sp)
    80002a40:	ec26                	sd	s1,24(sp)
    80002a42:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002a44:	fd840593          	addi	a1,s0,-40
    80002a48:	4501                	li	a0,0
    80002a4a:	eb5ff0ef          	jal	800028fe <argint>
  argint(1, &t);
    80002a4e:	fdc40593          	addi	a1,s0,-36
    80002a52:	4505                	li	a0,1
    80002a54:	eabff0ef          	jal	800028fe <argint>
  addr = myproc()->sz;
    80002a58:	f6dfe0ef          	jal	800019c4 <myproc>
    80002a5c:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    80002a5e:	fdc42703          	lw	a4,-36(s0)
    80002a62:	4785                	li	a5,1
    80002a64:	02f70763          	beq	a4,a5,80002a92 <sys_sbrk+0x58>
    80002a68:	fd842783          	lw	a5,-40(s0)
    80002a6c:	0207c363          	bltz	a5,80002a92 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    80002a70:	97a6                	add	a5,a5,s1
    80002a72:	0297ee63          	bltu	a5,s1,80002aae <sys_sbrk+0x74>
      return -1;
    if (addr + n > TRAPFRAME)
    80002a76:	02000737          	lui	a4,0x2000
    80002a7a:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    80002a7c:	0736                	slli	a4,a4,0xd
    80002a7e:	02f76a63          	bltu	a4,a5,80002ab2 <sys_sbrk+0x78>
      return -1;
    myproc()->sz += n;
    80002a82:	f43fe0ef          	jal	800019c4 <myproc>
    80002a86:	fd842703          	lw	a4,-40(s0)
    80002a8a:	653c                	ld	a5,72(a0)
    80002a8c:	97ba                	add	a5,a5,a4
    80002a8e:	e53c                	sd	a5,72(a0)
    80002a90:	a039                	j	80002a9e <sys_sbrk+0x64>
    if (growproc(n) < 0) {
    80002a92:	fd842503          	lw	a0,-40(s0)
    80002a96:	a28ff0ef          	jal	80001cbe <growproc>
    80002a9a:	00054863          	bltz	a0,80002aaa <sys_sbrk+0x70>
  }
  return addr;
}
    80002a9e:	8526                	mv	a0,s1
    80002aa0:	70a2                	ld	ra,40(sp)
    80002aa2:	7402                	ld	s0,32(sp)
    80002aa4:	64e2                	ld	s1,24(sp)
    80002aa6:	6145                	addi	sp,sp,48
    80002aa8:	8082                	ret
      return -1;
    80002aaa:	54fd                	li	s1,-1
    80002aac:	bfcd                	j	80002a9e <sys_sbrk+0x64>
      return -1;
    80002aae:	54fd                	li	s1,-1
    80002ab0:	b7fd                	j	80002a9e <sys_sbrk+0x64>
      return -1;
    80002ab2:	54fd                	li	s1,-1
    80002ab4:	b7ed                	j	80002a9e <sys_sbrk+0x64>

0000000080002ab6 <sys_pause>:

uint64
sys_pause(void)
{
    80002ab6:	7139                	addi	sp,sp,-64
    80002ab8:	fc06                	sd	ra,56(sp)
    80002aba:	f822                	sd	s0,48(sp)
    80002abc:	ec4e                	sd	s3,24(sp)
    80002abe:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002ac0:	fcc40593          	addi	a1,s0,-52
    80002ac4:	4501                	li	a0,0
    80002ac6:	e39ff0ef          	jal	800028fe <argint>
  if (n < 0)
    80002aca:	fcc42783          	lw	a5,-52(s0)
    80002ace:	0607cf63          	bltz	a5,80002b4c <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    80002ad2:	00015517          	auipc	a0,0x15
    80002ad6:	7ce50513          	addi	a0,a0,1998 # 800182a0 <tickslock>
    80002ada:	99cfe0ef          	jal	80000c76 <acquire>
  ticks0 = ticks;
    80002ade:	00008997          	auipc	s3,0x8
    80002ae2:	86a9a983          	lw	s3,-1942(s3) # 8000a348 <ticks>
  while (ticks - ticks0 < n) {
    80002ae6:	fcc42783          	lw	a5,-52(s0)
    80002aea:	c7a9                	beqz	a5,80002b34 <sys_pause+0x7e>
    80002aec:	f426                	sd	s1,40(sp)
    80002aee:	f04a                	sd	s2,32(sp)
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    80002af0:	00008917          	auipc	s2,0x8
    80002af4:	85890913          	addi	s2,s2,-1960 # 8000a348 <ticks>
    release(&tickslock);
    80002af8:	00015497          	auipc	s1,0x15
    80002afc:	7a848493          	addi	s1,s1,1960 # 800182a0 <tickslock>
    if (killed(myproc())) {
    80002b00:	ec5fe0ef          	jal	800019c4 <myproc>
    80002b04:	f1eff0ef          	jal	80002222 <killed>
    80002b08:	e529                	bnez	a0,80002b52 <sys_pause+0x9c>
    sleep_prepare(&ticks);
    80002b0a:	854a                	mv	a0,s2
    80002b0c:	cbcff0ef          	jal	80001fc8 <sleep_prepare>
    release(&tickslock);
    80002b10:	8526                	mv	a0,s1
    80002b12:	9f0fe0ef          	jal	80000d02 <release>
    sleep();
    80002b16:	ceeff0ef          	jal	80002004 <sleep>
    acquire(&tickslock);
    80002b1a:	8526                	mv	a0,s1
    80002b1c:	95afe0ef          	jal	80000c76 <acquire>
  while (ticks - ticks0 < n) {
    80002b20:	00092783          	lw	a5,0(s2)
    80002b24:	413787bb          	subw	a5,a5,s3
    80002b28:	fcc42703          	lw	a4,-52(s0)
    80002b2c:	fce7eae3          	bltu	a5,a4,80002b00 <sys_pause+0x4a>
    80002b30:	74a2                	ld	s1,40(sp)
    80002b32:	7902                	ld	s2,32(sp)
  }
  release(&tickslock);
    80002b34:	00015517          	auipc	a0,0x15
    80002b38:	76c50513          	addi	a0,a0,1900 # 800182a0 <tickslock>
    80002b3c:	9c6fe0ef          	jal	80000d02 <release>
  return 0;
    80002b40:	4501                	li	a0,0
}
    80002b42:	70e2                	ld	ra,56(sp)
    80002b44:	7442                	ld	s0,48(sp)
    80002b46:	69e2                	ld	s3,24(sp)
    80002b48:	6121                	addi	sp,sp,64
    80002b4a:	8082                	ret
    n = 0;
    80002b4c:	fc042623          	sw	zero,-52(s0)
    80002b50:	b749                	j	80002ad2 <sys_pause+0x1c>
      release(&tickslock);
    80002b52:	00015517          	auipc	a0,0x15
    80002b56:	74e50513          	addi	a0,a0,1870 # 800182a0 <tickslock>
    80002b5a:	9a8fe0ef          	jal	80000d02 <release>
      return -1;
    80002b5e:	557d                	li	a0,-1
    80002b60:	74a2                	ld	s1,40(sp)
    80002b62:	7902                	ld	s2,32(sp)
    80002b64:	bff9                	j	80002b42 <sys_pause+0x8c>

0000000080002b66 <sys_kallocstats>:
  int user;
};

uint64
sys_kallocstats(void)
{
    80002b66:	715d                	addi	sp,sp,-80
    80002b68:	e486                	sd	ra,72(sp)
    80002b6a:	e0a2                	sd	s0,64(sp)
    80002b6c:	fc26                	sd	s1,56(sp)
    80002b6e:	0880                	addi	s0,sp,80
  uint64 addr;
  struct kalloc_stats stats;

  argaddr(0, &addr);
    80002b70:	fd840593          	addi	a1,s0,-40
    80002b74:	4501                	li	a0,0
    80002b76:	da5ff0ef          	jal	8000291a <argaddr>
  kallocstats(&stats);
    80002b7a:	fb840513          	addi	a0,s0,-72
    80002b7e:	eabfd0ef          	jal	80000a28 <kallocstats>
  if (copyout(myproc()->pagetable, myproc()->sz, addr, (char *)&stats,
    80002b82:	e43fe0ef          	jal	800019c4 <myproc>
    80002b86:	6924                	ld	s1,80(a0)
    80002b88:	e3dfe0ef          	jal	800019c4 <myproc>
    80002b8c:	02000713          	li	a4,32
    80002b90:	fb840693          	addi	a3,s0,-72
    80002b94:	fd843603          	ld	a2,-40(s0)
    80002b98:	652c                	ld	a1,72(a0)
    80002b9a:	8526                	mv	a0,s1
    80002b9c:	a23fe0ef          	jal	800015be <copyout>
              sizeof(stats)) < 0)
    return -1;
  return 0;
}
    80002ba0:	957d                	srai	a0,a0,0x3f
    80002ba2:	60a6                	ld	ra,72(sp)
    80002ba4:	6406                	ld	s0,64(sp)
    80002ba6:	74e2                	ld	s1,56(sp)
    80002ba8:	6161                	addi	sp,sp,80
    80002baa:	8082                	ret

0000000080002bac <sys_vtop>:

uint64
sys_vtop(void)
{
    80002bac:	1101                	addi	sp,sp,-32
    80002bae:	ec06                	sd	ra,24(sp)
    80002bb0:	e822                	sd	s0,16(sp)
    80002bb2:	1000                	addi	s0,sp,32
  uint64 va;

  argaddr(0, &va);
    80002bb4:	fe840593          	addi	a1,s0,-24
    80002bb8:	4501                	li	a0,0
    80002bba:	d61ff0ef          	jal	8000291a <argaddr>
  return vtop(myproc()->pagetable, va);
    80002bbe:	e07fe0ef          	jal	800019c4 <myproc>
    80002bc2:	fe843583          	ld	a1,-24(s0)
    80002bc6:	6928                	ld	a0,80(a0)
    80002bc8:	c47fe0ef          	jal	8000180e <vtop>
}
    80002bcc:	60e2                	ld	ra,24(sp)
    80002bce:	6442                	ld	s0,16(sp)
    80002bd0:	6105                	addi	sp,sp,32
    80002bd2:	8082                	ret

0000000080002bd4 <sys_pageinfo>:

uint64
sys_pageinfo(void)
{
    80002bd4:	715d                	addi	sp,sp,-80
    80002bd6:	e486                	sd	ra,72(sp)
    80002bd8:	e0a2                	sd	s0,64(sp)
    80002bda:	fc26                	sd	s1,56(sp)
    80002bdc:	0880                	addi	s0,sp,80
  uint64 va;
  uint64 outaddr;
  struct pageinfo info;
  pte_t *pte;

  argaddr(0, &va);
    80002bde:	fd840593          	addi	a1,s0,-40
    80002be2:	4501                	li	a0,0
    80002be4:	d37ff0ef          	jal	8000291a <argaddr>
  argaddr(1, &outaddr);
    80002be8:	fd040593          	addi	a1,s0,-48
    80002bec:	4505                	li	a0,1
    80002bee:	d2dff0ef          	jal	8000291a <argaddr>

  info.va = va;
    80002bf2:	fd843783          	ld	a5,-40(s0)
    80002bf6:	faf43823          	sd	a5,-80(s0)
  pte = walk(myproc()->pagetable, va, 0);
    80002bfa:	dcbfe0ef          	jal	800019c4 <myproc>
    80002bfe:	4601                	li	a2,0
    80002c00:	fd843583          	ld	a1,-40(s0)
    80002c04:	6928                	ld	a0,80(a0)
    80002c06:	baafe0ef          	jal	80000fb0 <walk>
  info.present = (pte != 0 && (*pte & PTE_V) != 0);
    80002c0a:	cd39                	beqz	a0,80002c68 <sys_pageinfo+0x94>
    80002c0c:	611c                	ld	a5,0(a0)
    80002c0e:	8b85                	andi	a5,a5,1
    80002c10:	fcf42023          	sw	a5,-64(s0)
  info.writable = info.present && ((*pte & PTE_W) != 0);
    80002c14:	cfa1                	beqz	a5,80002c6c <sys_pageinfo+0x98>
    80002c16:	611c                	ld	a5,0(a0)
    80002c18:	8389                	srli	a5,a5,0x2
    80002c1a:	8b85                	andi	a5,a5,1
    80002c1c:	fcf42223          	sw	a5,-60(s0)
  info.user = info.present && ((*pte & PTE_U) != 0);
    80002c20:	611c                	ld	a5,0(a0)
    80002c22:	8391                	srli	a5,a5,0x4
    80002c24:	8b85                	andi	a5,a5,1
    80002c26:	fcf42423          	sw	a5,-56(s0)
  info.pa = info.present ? PTE2PA(*pte) + (va - PGROUNDDOWN(va)) : 0;
    80002c2a:	611c                	ld	a5,0(a0)
    80002c2c:	83a9                	srli	a5,a5,0xa
    80002c2e:	07b2                	slli	a5,a5,0xc
    80002c30:	fd843703          	ld	a4,-40(s0)
    80002c34:	1752                	slli	a4,a4,0x34
    80002c36:	9351                	srli	a4,a4,0x34
    80002c38:	97ba                	add	a5,a5,a4
    80002c3a:	faf43c23          	sd	a5,-72(s0)

  if (copyout(myproc()->pagetable, myproc()->sz, outaddr, (char *)&info,
    80002c3e:	d87fe0ef          	jal	800019c4 <myproc>
    80002c42:	6924                	ld	s1,80(a0)
    80002c44:	d81fe0ef          	jal	800019c4 <myproc>
    80002c48:	02000713          	li	a4,32
    80002c4c:	fb040693          	addi	a3,s0,-80
    80002c50:	fd043603          	ld	a2,-48(s0)
    80002c54:	652c                	ld	a1,72(a0)
    80002c56:	8526                	mv	a0,s1
    80002c58:	967fe0ef          	jal	800015be <copyout>
    80002c5c:	957d                	srai	a0,a0,0x3f
              sizeof(info)) < 0)
    return -1;
  return 0;
}
    80002c5e:	60a6                	ld	ra,72(sp)
    80002c60:	6406                	ld	s0,64(sp)
    80002c62:	74e2                	ld	s1,56(sp)
    80002c64:	6161                	addi	sp,sp,80
    80002c66:	8082                	ret
  info.present = (pte != 0 && (*pte & PTE_V) != 0);
    80002c68:	fc042023          	sw	zero,-64(s0)
  info.writable = info.present && ((*pte & PTE_W) != 0);
    80002c6c:	fc042223          	sw	zero,-60(s0)
  info.user = info.present && ((*pte & PTE_U) != 0);
    80002c70:	fc042423          	sw	zero,-56(s0)
  info.pa = info.present ? PTE2PA(*pte) + (va - PGROUNDDOWN(va)) : 0;
    80002c74:	4781                	li	a5,0
    80002c76:	b7d1                	j	80002c3a <sys_pageinfo+0x66>

0000000080002c78 <sys_setreadonly>:

uint64
sys_setreadonly(void)
{
    80002c78:	1101                	addi	sp,sp,-32
    80002c7a:	ec06                	sd	ra,24(sp)
    80002c7c:	e822                	sd	s0,16(sp)
    80002c7e:	1000                	addi	s0,sp,32
  uint64 va;
  pte_t *pte;

  argaddr(0, &va);
    80002c80:	fe840593          	addi	a1,s0,-24
    80002c84:	4501                	li	a0,0
    80002c86:	c95ff0ef          	jal	8000291a <argaddr>
  if (va >= MAXVA)
    80002c8a:	fe843703          	ld	a4,-24(s0)
    80002c8e:	57fd                	li	a5,-1
    80002c90:	83e9                	srli	a5,a5,0x1a
    return -1;
    80002c92:	557d                	li	a0,-1
  if (va >= MAXVA)
    80002c94:	02e7e863          	bltu	a5,a4,80002cc4 <sys_setreadonly+0x4c>

  pte = walk(myproc()->pagetable, va, 0);
    80002c98:	d2dfe0ef          	jal	800019c4 <myproc>
    80002c9c:	4601                	li	a2,0
    80002c9e:	fe843583          	ld	a1,-24(s0)
    80002ca2:	6928                	ld	a0,80(a0)
    80002ca4:	b0cfe0ef          	jal	80000fb0 <walk>
    80002ca8:	87aa                	mv	a5,a0
  if (pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0)
    80002caa:	c10d                	beqz	a0,80002ccc <sys_setreadonly+0x54>
    80002cac:	6118                	ld	a4,0(a0)
    80002cae:	01177613          	andi	a2,a4,17
    80002cb2:	46c5                	li	a3,17
    return -1;
    80002cb4:	557d                	li	a0,-1
  if (pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0)
    80002cb6:	00d61763          	bne	a2,a3,80002cc4 <sys_setreadonly+0x4c>

  *pte &= ~PTE_W;
    80002cba:	9b6d                	andi	a4,a4,-5
    80002cbc:	e398                	sd	a4,0(a5)
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80002cbe:	12000073          	sfence.vma
  sfence_vma();
  return 0;
    80002cc2:	4501                	li	a0,0
}
    80002cc4:	60e2                	ld	ra,24(sp)
    80002cc6:	6442                	ld	s0,16(sp)
    80002cc8:	6105                	addi	sp,sp,32
    80002cca:	8082                	ret
    return -1;
    80002ccc:	557d                	li	a0,-1
    80002cce:	bfdd                	j	80002cc4 <sys_setreadonly+0x4c>

0000000080002cd0 <sys_kill>:

uint64
sys_kill(void)
{
    80002cd0:	1101                	addi	sp,sp,-32
    80002cd2:	ec06                	sd	ra,24(sp)
    80002cd4:	e822                	sd	s0,16(sp)
    80002cd6:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002cd8:	fec40593          	addi	a1,s0,-20
    80002cdc:	4501                	li	a0,0
    80002cde:	c21ff0ef          	jal	800028fe <argint>
  return kkill(pid);
    80002ce2:	fec42503          	lw	a0,-20(s0)
    80002ce6:	cacff0ef          	jal	80002192 <kkill>
}
    80002cea:	60e2                	ld	ra,24(sp)
    80002cec:	6442                	ld	s0,16(sp)
    80002cee:	6105                	addi	sp,sp,32
    80002cf0:	8082                	ret

0000000080002cf2 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002cf2:	1101                	addi	sp,sp,-32
    80002cf4:	ec06                	sd	ra,24(sp)
    80002cf6:	e822                	sd	s0,16(sp)
    80002cf8:	e426                	sd	s1,8(sp)
    80002cfa:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002cfc:	00015517          	auipc	a0,0x15
    80002d00:	5a450513          	addi	a0,a0,1444 # 800182a0 <tickslock>
    80002d04:	f73fd0ef          	jal	80000c76 <acquire>
  xticks = ticks;
    80002d08:	00007497          	auipc	s1,0x7
    80002d0c:	6404a483          	lw	s1,1600(s1) # 8000a348 <ticks>
  release(&tickslock);
    80002d10:	00015517          	auipc	a0,0x15
    80002d14:	59050513          	addi	a0,a0,1424 # 800182a0 <tickslock>
    80002d18:	febfd0ef          	jal	80000d02 <release>
  return xticks;
}
    80002d1c:	02049513          	slli	a0,s1,0x20
    80002d20:	9101                	srli	a0,a0,0x20
    80002d22:	60e2                	ld	ra,24(sp)
    80002d24:	6442                	ld	s0,16(sp)
    80002d26:	64a2                	ld	s1,8(sp)
    80002d28:	6105                	addi	sp,sp,32
    80002d2a:	8082                	ret

0000000080002d2c <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002d2c:	7179                	addi	sp,sp,-48
    80002d2e:	f406                	sd	ra,40(sp)
    80002d30:	f022                	sd	s0,32(sp)
    80002d32:	ec26                	sd	s1,24(sp)
    80002d34:	e84a                	sd	s2,16(sp)
    80002d36:	e44e                	sd	s3,8(sp)
    80002d38:	e052                	sd	s4,0(sp)
    80002d3a:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002d3c:	00004597          	auipc	a1,0x4
    80002d40:	67458593          	addi	a1,a1,1652 # 800073b0 <etext+0x3b0>
    80002d44:	00015517          	auipc	a0,0x15
    80002d48:	57450513          	addi	a0,a0,1396 # 800182b8 <bcache>
    80002d4c:	eb5fd0ef          	jal	80000c00 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002d50:	0001d797          	auipc	a5,0x1d
    80002d54:	56878793          	addi	a5,a5,1384 # 800202b8 <bcache+0x8000>
    80002d58:	0001d717          	auipc	a4,0x1d
    80002d5c:	7c870713          	addi	a4,a4,1992 # 80020520 <bcache+0x8268>
    80002d60:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002d64:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002d68:	00015497          	auipc	s1,0x15
    80002d6c:	56848493          	addi	s1,s1,1384 # 800182d0 <bcache+0x18>
    b->next = bcache.head.next;
    80002d70:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002d72:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002d74:	00004a17          	auipc	s4,0x4
    80002d78:	644a0a13          	addi	s4,s4,1604 # 800073b8 <etext+0x3b8>
    b->next = bcache.head.next;
    80002d7c:	2b893783          	ld	a5,696(s2)
    80002d80:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002d82:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002d86:	85d2                	mv	a1,s4
    80002d88:	01048513          	addi	a0,s1,16
    80002d8c:	414010ef          	jal	800041a0 <initsleeplock>
    bcache.head.next->prev = b;
    80002d90:	2b893783          	ld	a5,696(s2)
    80002d94:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002d96:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    80002d9a:	45848493          	addi	s1,s1,1112
    80002d9e:	fd349fe3          	bne	s1,s3,80002d7c <binit+0x50>
  }
}
    80002da2:	70a2                	ld	ra,40(sp)
    80002da4:	7402                	ld	s0,32(sp)
    80002da6:	64e2                	ld	s1,24(sp)
    80002da8:	6942                	ld	s2,16(sp)
    80002daa:	69a2                	ld	s3,8(sp)
    80002dac:	6a02                	ld	s4,0(sp)
    80002dae:	6145                	addi	sp,sp,48
    80002db0:	8082                	ret

0000000080002db2 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80002db2:	7179                	addi	sp,sp,-48
    80002db4:	f406                	sd	ra,40(sp)
    80002db6:	f022                	sd	s0,32(sp)
    80002db8:	ec26                	sd	s1,24(sp)
    80002dba:	e84a                	sd	s2,16(sp)
    80002dbc:	e44e                	sd	s3,8(sp)
    80002dbe:	1800                	addi	s0,sp,48
    80002dc0:	892a                	mv	s2,a0
    80002dc2:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002dc4:	00015517          	auipc	a0,0x15
    80002dc8:	4f450513          	addi	a0,a0,1268 # 800182b8 <bcache>
    80002dcc:	eabfd0ef          	jal	80000c76 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80002dd0:	0001d497          	auipc	s1,0x1d
    80002dd4:	7a04b483          	ld	s1,1952(s1) # 80020570 <bcache+0x82b8>
    80002dd8:	0001d797          	auipc	a5,0x1d
    80002ddc:	74878793          	addi	a5,a5,1864 # 80020520 <bcache+0x8268>
    80002de0:	02f48b63          	beq	s1,a5,80002e16 <bread+0x64>
    80002de4:	873e                	mv	a4,a5
    80002de6:	a021                	j	80002dee <bread+0x3c>
    80002de8:	68a4                	ld	s1,80(s1)
    80002dea:	02e48663          	beq	s1,a4,80002e16 <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80002dee:	449c                	lw	a5,8(s1)
    80002df0:	ff279ce3          	bne	a5,s2,80002de8 <bread+0x36>
    80002df4:	44dc                	lw	a5,12(s1)
    80002df6:	ff3799e3          	bne	a5,s3,80002de8 <bread+0x36>
      b->refcnt++;
    80002dfa:	40bc                	lw	a5,64(s1)
    80002dfc:	2785                	addiw	a5,a5,1
    80002dfe:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e00:	00015517          	auipc	a0,0x15
    80002e04:	4b850513          	addi	a0,a0,1208 # 800182b8 <bcache>
    80002e08:	efbfd0ef          	jal	80000d02 <release>
      acquiresleep(&b->lock);
    80002e0c:	01048513          	addi	a0,s1,16
    80002e10:	3c6010ef          	jal	800041d6 <acquiresleep>
      return b;
    80002e14:	a889                	j	80002e66 <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002e16:	0001d497          	auipc	s1,0x1d
    80002e1a:	7524b483          	ld	s1,1874(s1) # 80020568 <bcache+0x82b0>
    80002e1e:	0001d797          	auipc	a5,0x1d
    80002e22:	70278793          	addi	a5,a5,1794 # 80020520 <bcache+0x8268>
    80002e26:	00f48863          	beq	s1,a5,80002e36 <bread+0x84>
    80002e2a:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80002e2c:	40bc                	lw	a5,64(s1)
    80002e2e:	cb91                	beqz	a5,80002e42 <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80002e30:	64a4                	ld	s1,72(s1)
    80002e32:	fee49de3          	bne	s1,a4,80002e2c <bread+0x7a>
  panic("bget: no buffers");
    80002e36:	00004517          	auipc	a0,0x4
    80002e3a:	58a50513          	addi	a0,a0,1418 # 800073c0 <etext+0x3c0>
    80002e3e:	9b3fd0ef          	jal	800007f0 <panic>
      b->dev = dev;
    80002e42:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002e46:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002e4a:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002e4e:	4785                	li	a5,1
    80002e50:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002e52:	00015517          	auipc	a0,0x15
    80002e56:	46650513          	addi	a0,a0,1126 # 800182b8 <bcache>
    80002e5a:	ea9fd0ef          	jal	80000d02 <release>
      acquiresleep(&b->lock);
    80002e5e:	01048513          	addi	a0,s1,16
    80002e62:	374010ef          	jal	800041d6 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    80002e66:	409c                	lw	a5,0(s1)
    80002e68:	cb89                	beqz	a5,80002e7a <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002e6a:	8526                	mv	a0,s1
    80002e6c:	70a2                	ld	ra,40(sp)
    80002e6e:	7402                	ld	s0,32(sp)
    80002e70:	64e2                	ld	s1,24(sp)
    80002e72:	6942                	ld	s2,16(sp)
    80002e74:	69a2                	ld	s3,8(sp)
    80002e76:	6145                	addi	sp,sp,48
    80002e78:	8082                	ret
    virtio_disk_rw(b, 0);
    80002e7a:	4581                	li	a1,0
    80002e7c:	8526                	mv	a0,s1
    80002e7e:	4ab020ef          	jal	80005b28 <virtio_disk_rw>
    b->valid = 1;
    80002e82:	4785                	li	a5,1
    80002e84:	c09c                	sw	a5,0(s1)
  return b;
    80002e86:	b7d5                	j	80002e6a <bread+0xb8>

0000000080002e88 <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80002e88:	1101                	addi	sp,sp,-32
    80002e8a:	ec06                	sd	ra,24(sp)
    80002e8c:	e822                	sd	s0,16(sp)
    80002e8e:	e426                	sd	s1,8(sp)
    80002e90:	1000                	addi	s0,sp,32
    80002e92:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002e94:	0541                	addi	a0,a0,16
    80002e96:	3cc010ef          	jal	80004262 <holdingsleep>
    80002e9a:	c911                	beqz	a0,80002eae <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002e9c:	4585                	li	a1,1
    80002e9e:	8526                	mv	a0,s1
    80002ea0:	489020ef          	jal	80005b28 <virtio_disk_rw>
}
    80002ea4:	60e2                	ld	ra,24(sp)
    80002ea6:	6442                	ld	s0,16(sp)
    80002ea8:	64a2                	ld	s1,8(sp)
    80002eaa:	6105                	addi	sp,sp,32
    80002eac:	8082                	ret
    panic("bwrite");
    80002eae:	00004517          	auipc	a0,0x4
    80002eb2:	52a50513          	addi	a0,a0,1322 # 800073d8 <etext+0x3d8>
    80002eb6:	93bfd0ef          	jal	800007f0 <panic>

0000000080002eba <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002eba:	1101                	addi	sp,sp,-32
    80002ebc:	ec06                	sd	ra,24(sp)
    80002ebe:	e822                	sd	s0,16(sp)
    80002ec0:	e426                	sd	s1,8(sp)
    80002ec2:	e04a                	sd	s2,0(sp)
    80002ec4:	1000                	addi	s0,sp,32
    80002ec6:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80002ec8:	01050913          	addi	s2,a0,16
    80002ecc:	854a                	mv	a0,s2
    80002ece:	394010ef          	jal	80004262 <holdingsleep>
    80002ed2:	c135                	beqz	a0,80002f36 <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    80002ed4:	854a                	mv	a0,s2
    80002ed6:	354010ef          	jal	8000422a <releasesleep>

  acquire(&bcache.lock);
    80002eda:	00015517          	auipc	a0,0x15
    80002ede:	3de50513          	addi	a0,a0,990 # 800182b8 <bcache>
    80002ee2:	d95fd0ef          	jal	80000c76 <acquire>
  b->refcnt--;
    80002ee6:	40bc                	lw	a5,64(s1)
    80002ee8:	37fd                	addiw	a5,a5,-1
    80002eea:	0007871b          	sext.w	a4,a5
    80002eee:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002ef0:	e71d                	bnez	a4,80002f1e <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002ef2:	68b8                	ld	a4,80(s1)
    80002ef4:	64bc                	ld	a5,72(s1)
    80002ef6:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002ef8:	68b8                	ld	a4,80(s1)
    80002efa:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002efc:	0001d797          	auipc	a5,0x1d
    80002f00:	3bc78793          	addi	a5,a5,956 # 800202b8 <bcache+0x8000>
    80002f04:	2b87b703          	ld	a4,696(a5)
    80002f08:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002f0a:	0001d717          	auipc	a4,0x1d
    80002f0e:	61670713          	addi	a4,a4,1558 # 80020520 <bcache+0x8268>
    80002f12:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002f14:	2b87b703          	ld	a4,696(a5)
    80002f18:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002f1a:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80002f1e:	00015517          	auipc	a0,0x15
    80002f22:	39a50513          	addi	a0,a0,922 # 800182b8 <bcache>
    80002f26:	dddfd0ef          	jal	80000d02 <release>
}
    80002f2a:	60e2                	ld	ra,24(sp)
    80002f2c:	6442                	ld	s0,16(sp)
    80002f2e:	64a2                	ld	s1,8(sp)
    80002f30:	6902                	ld	s2,0(sp)
    80002f32:	6105                	addi	sp,sp,32
    80002f34:	8082                	ret
    panic("brelse");
    80002f36:	00004517          	auipc	a0,0x4
    80002f3a:	4aa50513          	addi	a0,a0,1194 # 800073e0 <etext+0x3e0>
    80002f3e:	8b3fd0ef          	jal	800007f0 <panic>

0000000080002f42 <bpin>:

void
bpin(struct buf *b)
{
    80002f42:	1101                	addi	sp,sp,-32
    80002f44:	ec06                	sd	ra,24(sp)
    80002f46:	e822                	sd	s0,16(sp)
    80002f48:	e426                	sd	s1,8(sp)
    80002f4a:	1000                	addi	s0,sp,32
    80002f4c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002f4e:	00015517          	auipc	a0,0x15
    80002f52:	36a50513          	addi	a0,a0,874 # 800182b8 <bcache>
    80002f56:	d21fd0ef          	jal	80000c76 <acquire>
  b->refcnt++;
    80002f5a:	40bc                	lw	a5,64(s1)
    80002f5c:	2785                	addiw	a5,a5,1
    80002f5e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002f60:	00015517          	auipc	a0,0x15
    80002f64:	35850513          	addi	a0,a0,856 # 800182b8 <bcache>
    80002f68:	d9bfd0ef          	jal	80000d02 <release>
}
    80002f6c:	60e2                	ld	ra,24(sp)
    80002f6e:	6442                	ld	s0,16(sp)
    80002f70:	64a2                	ld	s1,8(sp)
    80002f72:	6105                	addi	sp,sp,32
    80002f74:	8082                	ret

0000000080002f76 <bunpin>:

void
bunpin(struct buf *b)
{
    80002f76:	1101                	addi	sp,sp,-32
    80002f78:	ec06                	sd	ra,24(sp)
    80002f7a:	e822                	sd	s0,16(sp)
    80002f7c:	e426                	sd	s1,8(sp)
    80002f7e:	1000                	addi	s0,sp,32
    80002f80:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002f82:	00015517          	auipc	a0,0x15
    80002f86:	33650513          	addi	a0,a0,822 # 800182b8 <bcache>
    80002f8a:	cedfd0ef          	jal	80000c76 <acquire>
  b->refcnt--;
    80002f8e:	40bc                	lw	a5,64(s1)
    80002f90:	37fd                	addiw	a5,a5,-1
    80002f92:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002f94:	00015517          	auipc	a0,0x15
    80002f98:	32450513          	addi	a0,a0,804 # 800182b8 <bcache>
    80002f9c:	d67fd0ef          	jal	80000d02 <release>
}
    80002fa0:	60e2                	ld	ra,24(sp)
    80002fa2:	6442                	ld	s0,16(sp)
    80002fa4:	64a2                	ld	s1,8(sp)
    80002fa6:	6105                	addi	sp,sp,32
    80002fa8:	8082                	ret

0000000080002faa <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002faa:	1101                	addi	sp,sp,-32
    80002fac:	ec06                	sd	ra,24(sp)
    80002fae:	e822                	sd	s0,16(sp)
    80002fb0:	e426                	sd	s1,8(sp)
    80002fb2:	e04a                	sd	s2,0(sp)
    80002fb4:	1000                	addi	s0,sp,32
    80002fb6:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002fb8:	00d5d59b          	srliw	a1,a1,0xd
    80002fbc:	0001e797          	auipc	a5,0x1e
    80002fc0:	9d87a783          	lw	a5,-1576(a5) # 80020994 <sb+0x1c>
    80002fc4:	9dbd                	addw	a1,a1,a5
    80002fc6:	dedff0ef          	jal	80002db2 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002fca:	0074f713          	andi	a4,s1,7
    80002fce:	4785                	li	a5,1
    80002fd0:	00e797bb          	sllw	a5,a5,a4
  if ((bp->data[bi / 8] & m) == 0)
    80002fd4:	14ce                	slli	s1,s1,0x33
    80002fd6:	90d9                	srli	s1,s1,0x36
    80002fd8:	00950733          	add	a4,a0,s1
    80002fdc:	05874703          	lbu	a4,88(a4)
    80002fe0:	00e7f6b3          	and	a3,a5,a4
    80002fe4:	c29d                	beqz	a3,8000300a <bfree+0x60>
    80002fe6:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80002fe8:	94aa                	add	s1,s1,a0
    80002fea:	fff7c793          	not	a5,a5
    80002fee:	8f7d                	and	a4,a4,a5
    80002ff0:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002ff4:	07a010ef          	jal	8000406e <log_write>
  brelse(bp);
    80002ff8:	854a                	mv	a0,s2
    80002ffa:	ec1ff0ef          	jal	80002eba <brelse>
}
    80002ffe:	60e2                	ld	ra,24(sp)
    80003000:	6442                	ld	s0,16(sp)
    80003002:	64a2                	ld	s1,8(sp)
    80003004:	6902                	ld	s2,0(sp)
    80003006:	6105                	addi	sp,sp,32
    80003008:	8082                	ret
    panic("freeing free block");
    8000300a:	00004517          	auipc	a0,0x4
    8000300e:	3de50513          	addi	a0,a0,990 # 800073e8 <etext+0x3e8>
    80003012:	fdefd0ef          	jal	800007f0 <panic>

0000000080003016 <balloc>:
{
    80003016:	711d                	addi	sp,sp,-96
    80003018:	ec86                	sd	ra,88(sp)
    8000301a:	e8a2                	sd	s0,80(sp)
    8000301c:	e4a6                	sd	s1,72(sp)
    8000301e:	1080                	addi	s0,sp,96
  for (b = 0; b < sb.size; b += BPB) {
    80003020:	0001e797          	auipc	a5,0x1e
    80003024:	95c7a783          	lw	a5,-1700(a5) # 8002097c <sb+0x4>
    80003028:	0e078f63          	beqz	a5,80003126 <balloc+0x110>
    8000302c:	e0ca                	sd	s2,64(sp)
    8000302e:	fc4e                	sd	s3,56(sp)
    80003030:	f852                	sd	s4,48(sp)
    80003032:	f456                	sd	s5,40(sp)
    80003034:	f05a                	sd	s6,32(sp)
    80003036:	ec5e                	sd	s7,24(sp)
    80003038:	e862                	sd	s8,16(sp)
    8000303a:	e466                	sd	s9,8(sp)
    8000303c:	8baa                	mv	s7,a0
    8000303e:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80003040:	0001eb17          	auipc	s6,0x1e
    80003044:	938b0b13          	addi	s6,s6,-1736 # 80020978 <sb>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003048:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    8000304a:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    8000304c:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    8000304e:	6c89                	lui	s9,0x2
    80003050:	a0b5                	j	800030bc <balloc+0xa6>
        bp->data[bi / 8] |= m;           // Mark block in use.
    80003052:	97ca                	add	a5,a5,s2
    80003054:	8e55                	or	a2,a2,a3
    80003056:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    8000305a:	854a                	mv	a0,s2
    8000305c:	012010ef          	jal	8000406e <log_write>
        brelse(bp);
    80003060:	854a                	mv	a0,s2
    80003062:	e59ff0ef          	jal	80002eba <brelse>
  bp = bread(dev, bno);
    80003066:	85a6                	mv	a1,s1
    80003068:	855e                	mv	a0,s7
    8000306a:	d49ff0ef          	jal	80002db2 <bread>
    8000306e:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80003070:	40000613          	li	a2,1024
    80003074:	4581                	li	a1,0
    80003076:	05850513          	addi	a0,a0,88
    8000307a:	cc1fd0ef          	jal	80000d3a <memset>
  log_write(bp);
    8000307e:	854a                	mv	a0,s2
    80003080:	7ef000ef          	jal	8000406e <log_write>
  brelse(bp);
    80003084:	854a                	mv	a0,s2
    80003086:	e35ff0ef          	jal	80002eba <brelse>
}
    8000308a:	6906                	ld	s2,64(sp)
    8000308c:	79e2                	ld	s3,56(sp)
    8000308e:	7a42                	ld	s4,48(sp)
    80003090:	7aa2                	ld	s5,40(sp)
    80003092:	7b02                	ld	s6,32(sp)
    80003094:	6be2                	ld	s7,24(sp)
    80003096:	6c42                	ld	s8,16(sp)
    80003098:	6ca2                	ld	s9,8(sp)
}
    8000309a:	8526                	mv	a0,s1
    8000309c:	60e6                	ld	ra,88(sp)
    8000309e:	6446                	ld	s0,80(sp)
    800030a0:	64a6                	ld	s1,72(sp)
    800030a2:	6125                	addi	sp,sp,96
    800030a4:	8082                	ret
    brelse(bp);
    800030a6:	854a                	mv	a0,s2
    800030a8:	e13ff0ef          	jal	80002eba <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    800030ac:	015c87bb          	addw	a5,s9,s5
    800030b0:	00078a9b          	sext.w	s5,a5
    800030b4:	004b2703          	lw	a4,4(s6)
    800030b8:	04eaff63          	bgeu	s5,a4,80003116 <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    800030bc:	41fad79b          	sraiw	a5,s5,0x1f
    800030c0:	0137d79b          	srliw	a5,a5,0x13
    800030c4:	015787bb          	addw	a5,a5,s5
    800030c8:	40d7d79b          	sraiw	a5,a5,0xd
    800030cc:	01cb2583          	lw	a1,28(s6)
    800030d0:	9dbd                	addw	a1,a1,a5
    800030d2:	855e                	mv	a0,s7
    800030d4:	cdfff0ef          	jal	80002db2 <bread>
    800030d8:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    800030da:	004b2503          	lw	a0,4(s6)
    800030de:	000a849b          	sext.w	s1,s5
    800030e2:	8762                	mv	a4,s8
    800030e4:	fca4f1e3          	bgeu	s1,a0,800030a6 <balloc+0x90>
      m = 1 << (bi % 8);
    800030e8:	00777693          	andi	a3,a4,7
    800030ec:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    800030f0:	41f7579b          	sraiw	a5,a4,0x1f
    800030f4:	01d7d79b          	srliw	a5,a5,0x1d
    800030f8:	9fb9                	addw	a5,a5,a4
    800030fa:	4037d79b          	sraiw	a5,a5,0x3
    800030fe:	00f90633          	add	a2,s2,a5
    80003102:	05864603          	lbu	a2,88(a2) # 1058 <_entry-0x7fffefa8>
    80003106:	00c6f5b3          	and	a1,a3,a2
    8000310a:	d5a1                	beqz	a1,80003052 <balloc+0x3c>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    8000310c:	2705                	addiw	a4,a4,1
    8000310e:	2485                	addiw	s1,s1,1
    80003110:	fd471ae3          	bne	a4,s4,800030e4 <balloc+0xce>
    80003114:	bf49                	j	800030a6 <balloc+0x90>
    80003116:	6906                	ld	s2,64(sp)
    80003118:	79e2                	ld	s3,56(sp)
    8000311a:	7a42                	ld	s4,48(sp)
    8000311c:	7aa2                	ld	s5,40(sp)
    8000311e:	7b02                	ld	s6,32(sp)
    80003120:	6be2                	ld	s7,24(sp)
    80003122:	6c42                	ld	s8,16(sp)
    80003124:	6ca2                	ld	s9,8(sp)
  printk("balloc: out of blocks\n");
    80003126:	00004517          	auipc	a0,0x4
    8000312a:	2da50513          	addi	a0,a0,730 # 80007400 <etext+0x400>
    8000312e:	bdcfd0ef          	jal	8000050a <printk>
  return 0;
    80003132:	4481                	li	s1,0
    80003134:	b79d                	j	8000309a <balloc+0x84>

0000000080003136 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80003136:	7179                	addi	sp,sp,-48
    80003138:	f406                	sd	ra,40(sp)
    8000313a:	f022                	sd	s0,32(sp)
    8000313c:	ec26                	sd	s1,24(sp)
    8000313e:	e84a                	sd	s2,16(sp)
    80003140:	e44e                	sd	s3,8(sp)
    80003142:	1800                	addi	s0,sp,48
    80003144:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    80003146:	47ad                	li	a5,11
    80003148:	02b7e663          	bltu	a5,a1,80003174 <bmap+0x3e>
    if ((addr = ip->addrs[bn]) == 0) {
    8000314c:	02059793          	slli	a5,a1,0x20
    80003150:	01e7d593          	srli	a1,a5,0x1e
    80003154:	00b504b3          	add	s1,a0,a1
    80003158:	0504a903          	lw	s2,80(s1)
    8000315c:	06091a63          	bnez	s2,800031d0 <bmap+0x9a>
      addr = balloc(ip->dev);
    80003160:	4108                	lw	a0,0(a0)
    80003162:	eb5ff0ef          	jal	80003016 <balloc>
    80003166:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    8000316a:	06090363          	beqz	s2,800031d0 <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    8000316e:	0524a823          	sw	s2,80(s1)
    80003172:	a8b9                	j	800031d0 <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003174:	ff45849b          	addiw	s1,a1,-12
    80003178:	0004871b          	sext.w	a4,s1

  if (bn < NINDIRECT) {
    8000317c:	0ff00793          	li	a5,255
    80003180:	06e7ee63          	bltu	a5,a4,800031fc <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    80003184:	08052903          	lw	s2,128(a0)
    80003188:	00091d63          	bnez	s2,800031a2 <bmap+0x6c>
      addr = balloc(ip->dev);
    8000318c:	4108                	lw	a0,0(a0)
    8000318e:	e89ff0ef          	jal	80003016 <balloc>
    80003192:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    80003196:	02090d63          	beqz	s2,800031d0 <bmap+0x9a>
    8000319a:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000319c:	0929a023          	sw	s2,128(s3)
    800031a0:	a011                	j	800031a4 <bmap+0x6e>
    800031a2:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    800031a4:	85ca                	mv	a1,s2
    800031a6:	0009a503          	lw	a0,0(s3)
    800031aa:	c09ff0ef          	jal	80002db2 <bread>
    800031ae:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    800031b0:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    800031b4:	02049713          	slli	a4,s1,0x20
    800031b8:	01e75593          	srli	a1,a4,0x1e
    800031bc:	00b784b3          	add	s1,a5,a1
    800031c0:	0004a903          	lw	s2,0(s1)
    800031c4:	00090e63          	beqz	s2,800031e0 <bmap+0xaa>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    800031c8:	8552                	mv	a0,s4
    800031ca:	cf1ff0ef          	jal	80002eba <brelse>
    return addr;
    800031ce:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    800031d0:	854a                	mv	a0,s2
    800031d2:	70a2                	ld	ra,40(sp)
    800031d4:	7402                	ld	s0,32(sp)
    800031d6:	64e2                	ld	s1,24(sp)
    800031d8:	6942                	ld	s2,16(sp)
    800031da:	69a2                	ld	s3,8(sp)
    800031dc:	6145                	addi	sp,sp,48
    800031de:	8082                	ret
      addr = balloc(ip->dev);
    800031e0:	0009a503          	lw	a0,0(s3)
    800031e4:	e33ff0ef          	jal	80003016 <balloc>
    800031e8:	0005091b          	sext.w	s2,a0
      if (addr) {
    800031ec:	fc090ee3          	beqz	s2,800031c8 <bmap+0x92>
        a[bn] = addr;
    800031f0:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    800031f4:	8552                	mv	a0,s4
    800031f6:	679000ef          	jal	8000406e <log_write>
    800031fa:	b7f9                	j	800031c8 <bmap+0x92>
    800031fc:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    800031fe:	00004517          	auipc	a0,0x4
    80003202:	21a50513          	addi	a0,a0,538 # 80007418 <etext+0x418>
    80003206:	deafd0ef          	jal	800007f0 <panic>

000000008000320a <iget>:
{
    8000320a:	7179                	addi	sp,sp,-48
    8000320c:	f406                	sd	ra,40(sp)
    8000320e:	f022                	sd	s0,32(sp)
    80003210:	ec26                	sd	s1,24(sp)
    80003212:	e84a                	sd	s2,16(sp)
    80003214:	e44e                	sd	s3,8(sp)
    80003216:	e052                	sd	s4,0(sp)
    80003218:	1800                	addi	s0,sp,48
    8000321a:	89aa                	mv	s3,a0
    8000321c:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000321e:	0001d517          	auipc	a0,0x1d
    80003222:	77a50513          	addi	a0,a0,1914 # 80020998 <itable>
    80003226:	a51fd0ef          	jal	80000c76 <acquire>
  empty = 0;
    8000322a:	4901                	li	s2,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    8000322c:	0001d497          	auipc	s1,0x1d
    80003230:	78448493          	addi	s1,s1,1924 # 800209b0 <itable+0x18>
    80003234:	0001f697          	auipc	a3,0x1f
    80003238:	20c68693          	addi	a3,a3,524 # 80022440 <log>
    8000323c:	a039                	j	8000324a <iget+0x40>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    8000323e:	02090963          	beqz	s2,80003270 <iget+0x66>
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80003242:	08848493          	addi	s1,s1,136
    80003246:	02d48863          	beq	s1,a3,80003276 <iget+0x6c>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    8000324a:	449c                	lw	a5,8(s1)
    8000324c:	fef059e3          	blez	a5,8000323e <iget+0x34>
    80003250:	4098                	lw	a4,0(s1)
    80003252:	ff3716e3          	bne	a4,s3,8000323e <iget+0x34>
    80003256:	40d8                	lw	a4,4(s1)
    80003258:	ff4713e3          	bne	a4,s4,8000323e <iget+0x34>
      ip->ref++;
    8000325c:	2785                	addiw	a5,a5,1
    8000325e:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003260:	0001d517          	auipc	a0,0x1d
    80003264:	73850513          	addi	a0,a0,1848 # 80020998 <itable>
    80003268:	a9bfd0ef          	jal	80000d02 <release>
      return ip;
    8000326c:	8926                	mv	s2,s1
    8000326e:	a02d                	j	80003298 <iget+0x8e>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    80003270:	fbe9                	bnez	a5,80003242 <iget+0x38>
      empty = ip;
    80003272:	8926                	mv	s2,s1
    80003274:	b7f9                	j	80003242 <iget+0x38>
  if (empty == 0)
    80003276:	02090a63          	beqz	s2,800032aa <iget+0xa0>
  ip->dev = dev;
    8000327a:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    8000327e:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003282:	4785                	li	a5,1
    80003284:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80003288:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000328c:	0001d517          	auipc	a0,0x1d
    80003290:	70c50513          	addi	a0,a0,1804 # 80020998 <itable>
    80003294:	a6ffd0ef          	jal	80000d02 <release>
}
    80003298:	854a                	mv	a0,s2
    8000329a:	70a2                	ld	ra,40(sp)
    8000329c:	7402                	ld	s0,32(sp)
    8000329e:	64e2                	ld	s1,24(sp)
    800032a0:	6942                	ld	s2,16(sp)
    800032a2:	69a2                	ld	s3,8(sp)
    800032a4:	6a02                	ld	s4,0(sp)
    800032a6:	6145                	addi	sp,sp,48
    800032a8:	8082                	ret
    panic("iget: no inodes");
    800032aa:	00004517          	auipc	a0,0x4
    800032ae:	18650513          	addi	a0,a0,390 # 80007430 <etext+0x430>
    800032b2:	d3efd0ef          	jal	800007f0 <panic>

00000000800032b6 <iinit>:
{
    800032b6:	7179                	addi	sp,sp,-48
    800032b8:	f406                	sd	ra,40(sp)
    800032ba:	f022                	sd	s0,32(sp)
    800032bc:	ec26                	sd	s1,24(sp)
    800032be:	e84a                	sd	s2,16(sp)
    800032c0:	e44e                	sd	s3,8(sp)
    800032c2:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800032c4:	00004597          	auipc	a1,0x4
    800032c8:	17c58593          	addi	a1,a1,380 # 80007440 <etext+0x440>
    800032cc:	0001d517          	auipc	a0,0x1d
    800032d0:	6cc50513          	addi	a0,a0,1740 # 80020998 <itable>
    800032d4:	92dfd0ef          	jal	80000c00 <initlock>
  for (i = 0; i < NINODE; i++) {
    800032d8:	0001d497          	auipc	s1,0x1d
    800032dc:	6e848493          	addi	s1,s1,1768 # 800209c0 <itable+0x28>
    800032e0:	0001f997          	auipc	s3,0x1f
    800032e4:	17098993          	addi	s3,s3,368 # 80022450 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800032e8:	00004917          	auipc	s2,0x4
    800032ec:	16090913          	addi	s2,s2,352 # 80007448 <etext+0x448>
    800032f0:	85ca                	mv	a1,s2
    800032f2:	8526                	mv	a0,s1
    800032f4:	6ad000ef          	jal	800041a0 <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    800032f8:	08848493          	addi	s1,s1,136
    800032fc:	ff349ae3          	bne	s1,s3,800032f0 <iinit+0x3a>
}
    80003300:	70a2                	ld	ra,40(sp)
    80003302:	7402                	ld	s0,32(sp)
    80003304:	64e2                	ld	s1,24(sp)
    80003306:	6942                	ld	s2,16(sp)
    80003308:	69a2                	ld	s3,8(sp)
    8000330a:	6145                	addi	sp,sp,48
    8000330c:	8082                	ret

000000008000330e <ialloc>:
{
    8000330e:	7139                	addi	sp,sp,-64
    80003310:	fc06                	sd	ra,56(sp)
    80003312:	f822                	sd	s0,48(sp)
    80003314:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    80003316:	0001d717          	auipc	a4,0x1d
    8000331a:	66e72703          	lw	a4,1646(a4) # 80020984 <sb+0xc>
    8000331e:	4785                	li	a5,1
    80003320:	06e7f063          	bgeu	a5,a4,80003380 <ialloc+0x72>
    80003324:	f426                	sd	s1,40(sp)
    80003326:	f04a                	sd	s2,32(sp)
    80003328:	ec4e                	sd	s3,24(sp)
    8000332a:	e852                	sd	s4,16(sp)
    8000332c:	e456                	sd	s5,8(sp)
    8000332e:	e05a                	sd	s6,0(sp)
    80003330:	8aaa                	mv	s5,a0
    80003332:	8b2e                	mv	s6,a1
    80003334:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    80003336:	0001da17          	auipc	s4,0x1d
    8000333a:	642a0a13          	addi	s4,s4,1602 # 80020978 <sb>
    8000333e:	00495593          	srli	a1,s2,0x4
    80003342:	018a2783          	lw	a5,24(s4)
    80003346:	9dbd                	addw	a1,a1,a5
    80003348:	8556                	mv	a0,s5
    8000334a:	a69ff0ef          	jal	80002db2 <bread>
    8000334e:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    80003350:	05850993          	addi	s3,a0,88
    80003354:	00f97793          	andi	a5,s2,15
    80003358:	079a                	slli	a5,a5,0x6
    8000335a:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    8000335c:	00099783          	lh	a5,0(s3)
    80003360:	cb9d                	beqz	a5,80003396 <ialloc+0x88>
    brelse(bp);
    80003362:	b59ff0ef          	jal	80002eba <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    80003366:	0905                	addi	s2,s2,1
    80003368:	00ca2703          	lw	a4,12(s4)
    8000336c:	0009079b          	sext.w	a5,s2
    80003370:	fce7e7e3          	bltu	a5,a4,8000333e <ialloc+0x30>
    80003374:	74a2                	ld	s1,40(sp)
    80003376:	7902                	ld	s2,32(sp)
    80003378:	69e2                	ld	s3,24(sp)
    8000337a:	6a42                	ld	s4,16(sp)
    8000337c:	6aa2                	ld	s5,8(sp)
    8000337e:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    80003380:	00004517          	auipc	a0,0x4
    80003384:	0d050513          	addi	a0,a0,208 # 80007450 <etext+0x450>
    80003388:	982fd0ef          	jal	8000050a <printk>
  return 0;
    8000338c:	4501                	li	a0,0
}
    8000338e:	70e2                	ld	ra,56(sp)
    80003390:	7442                	ld	s0,48(sp)
    80003392:	6121                	addi	sp,sp,64
    80003394:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003396:	04000613          	li	a2,64
    8000339a:	4581                	li	a1,0
    8000339c:	854e                	mv	a0,s3
    8000339e:	99dfd0ef          	jal	80000d3a <memset>
      dip->type = type;
    800033a2:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    800033a6:	8526                	mv	a0,s1
    800033a8:	4c7000ef          	jal	8000406e <log_write>
      brelse(bp);
    800033ac:	8526                	mv	a0,s1
    800033ae:	b0dff0ef          	jal	80002eba <brelse>
      return iget(dev, inum);
    800033b2:	0009059b          	sext.w	a1,s2
    800033b6:	8556                	mv	a0,s5
    800033b8:	e53ff0ef          	jal	8000320a <iget>
    800033bc:	74a2                	ld	s1,40(sp)
    800033be:	7902                	ld	s2,32(sp)
    800033c0:	69e2                	ld	s3,24(sp)
    800033c2:	6a42                	ld	s4,16(sp)
    800033c4:	6aa2                	ld	s5,8(sp)
    800033c6:	6b02                	ld	s6,0(sp)
    800033c8:	b7d9                	j	8000338e <ialloc+0x80>

00000000800033ca <iupdate>:
{
    800033ca:	1101                	addi	sp,sp,-32
    800033cc:	ec06                	sd	ra,24(sp)
    800033ce:	e822                	sd	s0,16(sp)
    800033d0:	e426                	sd	s1,8(sp)
    800033d2:	e04a                	sd	s2,0(sp)
    800033d4:	1000                	addi	s0,sp,32
    800033d6:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800033d8:	415c                	lw	a5,4(a0)
    800033da:	0047d79b          	srliw	a5,a5,0x4
    800033de:	0001d597          	auipc	a1,0x1d
    800033e2:	5b25a583          	lw	a1,1458(a1) # 80020990 <sb+0x18>
    800033e6:	9dbd                	addw	a1,a1,a5
    800033e8:	4108                	lw	a0,0(a0)
    800033ea:	9c9ff0ef          	jal	80002db2 <bread>
    800033ee:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    800033f0:	05850793          	addi	a5,a0,88
    800033f4:	40d8                	lw	a4,4(s1)
    800033f6:	8b3d                	andi	a4,a4,15
    800033f8:	071a                	slli	a4,a4,0x6
    800033fa:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800033fc:	04449703          	lh	a4,68(s1)
    80003400:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003404:	04649703          	lh	a4,70(s1)
    80003408:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    8000340c:	04849703          	lh	a4,72(s1)
    80003410:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003414:	04a49703          	lh	a4,74(s1)
    80003418:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    8000341c:	44f8                	lw	a4,76(s1)
    8000341e:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003420:	03400613          	li	a2,52
    80003424:	05048593          	addi	a1,s1,80
    80003428:	00c78513          	addi	a0,a5,12
    8000342c:	96bfd0ef          	jal	80000d96 <memmove>
  log_write(bp);
    80003430:	854a                	mv	a0,s2
    80003432:	43d000ef          	jal	8000406e <log_write>
  brelse(bp);
    80003436:	854a                	mv	a0,s2
    80003438:	a83ff0ef          	jal	80002eba <brelse>
}
    8000343c:	60e2                	ld	ra,24(sp)
    8000343e:	6442                	ld	s0,16(sp)
    80003440:	64a2                	ld	s1,8(sp)
    80003442:	6902                	ld	s2,0(sp)
    80003444:	6105                	addi	sp,sp,32
    80003446:	8082                	ret

0000000080003448 <idup>:
{
    80003448:	1101                	addi	sp,sp,-32
    8000344a:	ec06                	sd	ra,24(sp)
    8000344c:	e822                	sd	s0,16(sp)
    8000344e:	e426                	sd	s1,8(sp)
    80003450:	1000                	addi	s0,sp,32
    80003452:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003454:	0001d517          	auipc	a0,0x1d
    80003458:	54450513          	addi	a0,a0,1348 # 80020998 <itable>
    8000345c:	81bfd0ef          	jal	80000c76 <acquire>
  ip->ref++;
    80003460:	449c                	lw	a5,8(s1)
    80003462:	2785                	addiw	a5,a5,1
    80003464:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003466:	0001d517          	auipc	a0,0x1d
    8000346a:	53250513          	addi	a0,a0,1330 # 80020998 <itable>
    8000346e:	895fd0ef          	jal	80000d02 <release>
}
    80003472:	8526                	mv	a0,s1
    80003474:	60e2                	ld	ra,24(sp)
    80003476:	6442                	ld	s0,16(sp)
    80003478:	64a2                	ld	s1,8(sp)
    8000347a:	6105                	addi	sp,sp,32
    8000347c:	8082                	ret

000000008000347e <ilock>:
{
    8000347e:	1101                	addi	sp,sp,-32
    80003480:	ec06                	sd	ra,24(sp)
    80003482:	e822                	sd	s0,16(sp)
    80003484:	e426                	sd	s1,8(sp)
    80003486:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    80003488:	cd19                	beqz	a0,800034a6 <ilock+0x28>
    8000348a:	84aa                	mv	s1,a0
    8000348c:	451c                	lw	a5,8(a0)
    8000348e:	00f05c63          	blez	a5,800034a6 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003492:	0541                	addi	a0,a0,16
    80003494:	543000ef          	jal	800041d6 <acquiresleep>
  if (ip->valid == 0) {
    80003498:	40bc                	lw	a5,64(s1)
    8000349a:	cf89                	beqz	a5,800034b4 <ilock+0x36>
}
    8000349c:	60e2                	ld	ra,24(sp)
    8000349e:	6442                	ld	s0,16(sp)
    800034a0:	64a2                	ld	s1,8(sp)
    800034a2:	6105                	addi	sp,sp,32
    800034a4:	8082                	ret
    800034a6:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800034a8:	00004517          	auipc	a0,0x4
    800034ac:	fc050513          	addi	a0,a0,-64 # 80007468 <etext+0x468>
    800034b0:	b40fd0ef          	jal	800007f0 <panic>
    800034b4:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800034b6:	40dc                	lw	a5,4(s1)
    800034b8:	0047d79b          	srliw	a5,a5,0x4
    800034bc:	0001d597          	auipc	a1,0x1d
    800034c0:	4d45a583          	lw	a1,1236(a1) # 80020990 <sb+0x18>
    800034c4:	9dbd                	addw	a1,a1,a5
    800034c6:	4088                	lw	a0,0(s1)
    800034c8:	8ebff0ef          	jal	80002db2 <bread>
    800034cc:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    800034ce:	05850593          	addi	a1,a0,88
    800034d2:	40dc                	lw	a5,4(s1)
    800034d4:	8bbd                	andi	a5,a5,15
    800034d6:	079a                	slli	a5,a5,0x6
    800034d8:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800034da:	00059783          	lh	a5,0(a1)
    800034de:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800034e2:	00259783          	lh	a5,2(a1)
    800034e6:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800034ea:	00459783          	lh	a5,4(a1)
    800034ee:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800034f2:	00659783          	lh	a5,6(a1)
    800034f6:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800034fa:	459c                	lw	a5,8(a1)
    800034fc:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800034fe:	03400613          	li	a2,52
    80003502:	05b1                	addi	a1,a1,12
    80003504:	05048513          	addi	a0,s1,80
    80003508:	88ffd0ef          	jal	80000d96 <memmove>
    brelse(bp);
    8000350c:	854a                	mv	a0,s2
    8000350e:	9adff0ef          	jal	80002eba <brelse>
    ip->valid = 1;
    80003512:	4785                	li	a5,1
    80003514:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    80003516:	04449783          	lh	a5,68(s1)
    8000351a:	c399                	beqz	a5,80003520 <ilock+0xa2>
    8000351c:	6902                	ld	s2,0(sp)
    8000351e:	bfbd                	j	8000349c <ilock+0x1e>
      panic("ilock: no type");
    80003520:	00004517          	auipc	a0,0x4
    80003524:	f5050513          	addi	a0,a0,-176 # 80007470 <etext+0x470>
    80003528:	ac8fd0ef          	jal	800007f0 <panic>

000000008000352c <iunlock>:
{
    8000352c:	1101                	addi	sp,sp,-32
    8000352e:	ec06                	sd	ra,24(sp)
    80003530:	e822                	sd	s0,16(sp)
    80003532:	e426                	sd	s1,8(sp)
    80003534:	e04a                	sd	s2,0(sp)
    80003536:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003538:	c505                	beqz	a0,80003560 <iunlock+0x34>
    8000353a:	84aa                	mv	s1,a0
    8000353c:	01050913          	addi	s2,a0,16
    80003540:	854a                	mv	a0,s2
    80003542:	521000ef          	jal	80004262 <holdingsleep>
    80003546:	cd09                	beqz	a0,80003560 <iunlock+0x34>
    80003548:	449c                	lw	a5,8(s1)
    8000354a:	00f05b63          	blez	a5,80003560 <iunlock+0x34>
  releasesleep(&ip->lock);
    8000354e:	854a                	mv	a0,s2
    80003550:	4db000ef          	jal	8000422a <releasesleep>
}
    80003554:	60e2                	ld	ra,24(sp)
    80003556:	6442                	ld	s0,16(sp)
    80003558:	64a2                	ld	s1,8(sp)
    8000355a:	6902                	ld	s2,0(sp)
    8000355c:	6105                	addi	sp,sp,32
    8000355e:	8082                	ret
    panic("iunlock");
    80003560:	00004517          	auipc	a0,0x4
    80003564:	f2050513          	addi	a0,a0,-224 # 80007480 <etext+0x480>
    80003568:	a88fd0ef          	jal	800007f0 <panic>

000000008000356c <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000356c:	7179                	addi	sp,sp,-48
    8000356e:	f406                	sd	ra,40(sp)
    80003570:	f022                	sd	s0,32(sp)
    80003572:	ec26                	sd	s1,24(sp)
    80003574:	e84a                	sd	s2,16(sp)
    80003576:	e44e                	sd	s3,8(sp)
    80003578:	1800                	addi	s0,sp,48
    8000357a:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    8000357c:	05050493          	addi	s1,a0,80
    80003580:	08050913          	addi	s2,a0,128
    80003584:	a021                	j	8000358c <itrunc+0x20>
    80003586:	0491                	addi	s1,s1,4
    80003588:	01248b63          	beq	s1,s2,8000359e <itrunc+0x32>
    if (ip->addrs[i]) {
    8000358c:	408c                	lw	a1,0(s1)
    8000358e:	dde5                	beqz	a1,80003586 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80003590:	0009a503          	lw	a0,0(s3)
    80003594:	a17ff0ef          	jal	80002faa <bfree>
      ip->addrs[i] = 0;
    80003598:	0004a023          	sw	zero,0(s1)
    8000359c:	b7ed                	j	80003586 <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    8000359e:	0809a583          	lw	a1,128(s3)
    800035a2:	ed89                	bnez	a1,800035bc <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800035a4:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800035a8:	854e                	mv	a0,s3
    800035aa:	e21ff0ef          	jal	800033ca <iupdate>
}
    800035ae:	70a2                	ld	ra,40(sp)
    800035b0:	7402                	ld	s0,32(sp)
    800035b2:	64e2                	ld	s1,24(sp)
    800035b4:	6942                	ld	s2,16(sp)
    800035b6:	69a2                	ld	s3,8(sp)
    800035b8:	6145                	addi	sp,sp,48
    800035ba:	8082                	ret
    800035bc:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800035be:	0009a503          	lw	a0,0(s3)
    800035c2:	ff0ff0ef          	jal	80002db2 <bread>
    800035c6:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    800035c8:	05850493          	addi	s1,a0,88
    800035cc:	45850913          	addi	s2,a0,1112
    800035d0:	a021                	j	800035d8 <itrunc+0x6c>
    800035d2:	0491                	addi	s1,s1,4
    800035d4:	01248963          	beq	s1,s2,800035e6 <itrunc+0x7a>
      if (a[j])
    800035d8:	408c                	lw	a1,0(s1)
    800035da:	dde5                	beqz	a1,800035d2 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800035dc:	0009a503          	lw	a0,0(s3)
    800035e0:	9cbff0ef          	jal	80002faa <bfree>
    800035e4:	b7fd                	j	800035d2 <itrunc+0x66>
    brelse(bp);
    800035e6:	8552                	mv	a0,s4
    800035e8:	8d3ff0ef          	jal	80002eba <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800035ec:	0809a583          	lw	a1,128(s3)
    800035f0:	0009a503          	lw	a0,0(s3)
    800035f4:	9b7ff0ef          	jal	80002faa <bfree>
    ip->addrs[NDIRECT] = 0;
    800035f8:	0809a023          	sw	zero,128(s3)
    800035fc:	6a02                	ld	s4,0(sp)
    800035fe:	b75d                	j	800035a4 <itrunc+0x38>

0000000080003600 <iput>:
{
    80003600:	7179                	addi	sp,sp,-48
    80003602:	f406                	sd	ra,40(sp)
    80003604:	f022                	sd	s0,32(sp)
    80003606:	ec26                	sd	s1,24(sp)
    80003608:	1800                	addi	s0,sp,48
    8000360a:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000360c:	0001d517          	auipc	a0,0x1d
    80003610:	38c50513          	addi	a0,a0,908 # 80020998 <itable>
    80003614:	e62fd0ef          	jal	80000c76 <acquire>
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    80003618:	449c                	lw	a5,8(s1)
    8000361a:	4705                	li	a4,1
    8000361c:	00e78f63          	beq	a5,a4,8000363a <iput+0x3a>
  ip->ref--;
    80003620:	37fd                	addiw	a5,a5,-1
    80003622:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003624:	0001d517          	auipc	a0,0x1d
    80003628:	37450513          	addi	a0,a0,884 # 80020998 <itable>
    8000362c:	ed6fd0ef          	jal	80000d02 <release>
}
    80003630:	70a2                	ld	ra,40(sp)
    80003632:	7402                	ld	s0,32(sp)
    80003634:	64e2                	ld	s1,24(sp)
    80003636:	6145                	addi	sp,sp,48
    80003638:	8082                	ret
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    8000363a:	40b8                	lw	a4,64(s1)
    8000363c:	d375                	beqz	a4,80003620 <iput+0x20>
    8000363e:	e84a                	sd	s2,16(sp)
    80003640:	e052                	sd	s4,0(sp)
  uint dev = ip->dev, inum = ip->inum;
    80003642:	0004aa03          	lw	s4,0(s1)
    80003646:	0044a903          	lw	s2,4(s1)
  if (last) {
    8000364a:	04a49703          	lh	a4,74(s1)
    8000364e:	ef35                	bnez	a4,800036ca <iput+0xca>
    80003650:	e44e                	sd	s3,8(sp)
    acquiresleep(&ip->lock);
    80003652:	01048993          	addi	s3,s1,16
    80003656:	854e                	mv	a0,s3
    80003658:	37f000ef          	jal	800041d6 <acquiresleep>
    release(&itable.lock);
    8000365c:	0001d517          	auipc	a0,0x1d
    80003660:	33c50513          	addi	a0,a0,828 # 80020998 <itable>
    80003664:	e9efd0ef          	jal	80000d02 <release>
    itrunc(ip); // free the data blocks (type stays nonzero on disk)
    80003668:	8526                	mv	a0,s1
    8000366a:	f03ff0ef          	jal	8000356c <itrunc>
    ip->valid = 0;
    8000366e:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003672:	854e                	mv	a0,s3
    80003674:	3b7000ef          	jal	8000422a <releasesleep>
    acquire(&itable.lock);
    80003678:	0001d517          	auipc	a0,0x1d
    8000367c:	32050513          	addi	a0,a0,800 # 80020998 <itable>
    80003680:	df6fd0ef          	jal	80000c76 <acquire>
  ip->ref--;
    80003684:	449c                	lw	a5,8(s1)
    80003686:	37fd                	addiw	a5,a5,-1
    80003688:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000368a:	0001d517          	auipc	a0,0x1d
    8000368e:	30e50513          	addi	a0,a0,782 # 80020998 <itable>
    80003692:	e70fd0ef          	jal	80000d02 <release>
  struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003696:	0049559b          	srliw	a1,s2,0x4
    8000369a:	0001d797          	auipc	a5,0x1d
    8000369e:	2f67a783          	lw	a5,758(a5) # 80020990 <sb+0x18>
    800036a2:	9dbd                	addw	a1,a1,a5
    800036a4:	8552                	mv	a0,s4
    800036a6:	f0cff0ef          	jal	80002db2 <bread>
    800036aa:	84aa                	mv	s1,a0
  struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800036ac:	00f97913          	andi	s2,s2,15
  dip->type = 0;
    800036b0:	091a                	slli	s2,s2,0x6
    800036b2:	992a                	add	s2,s2,a0
    800036b4:	04091c23          	sh	zero,88(s2)
  log_write(bp);
    800036b8:	1b7000ef          	jal	8000406e <log_write>
  brelse(bp);
    800036bc:	8526                	mv	a0,s1
    800036be:	ffcff0ef          	jal	80002eba <brelse>
}
    800036c2:	6942                	ld	s2,16(sp)
    800036c4:	69a2                	ld	s3,8(sp)
    800036c6:	6a02                	ld	s4,0(sp)
    800036c8:	b7a5                	j	80003630 <iput+0x30>
    800036ca:	6942                	ld	s2,16(sp)
    800036cc:	6a02                	ld	s4,0(sp)
    800036ce:	bf89                	j	80003620 <iput+0x20>

00000000800036d0 <iunlockput>:
{
    800036d0:	1101                	addi	sp,sp,-32
    800036d2:	ec06                	sd	ra,24(sp)
    800036d4:	e822                	sd	s0,16(sp)
    800036d6:	e426                	sd	s1,8(sp)
    800036d8:	1000                	addi	s0,sp,32
    800036da:	84aa                	mv	s1,a0
  iunlock(ip);
    800036dc:	e51ff0ef          	jal	8000352c <iunlock>
  iput(ip);
    800036e0:	8526                	mv	a0,s1
    800036e2:	f1fff0ef          	jal	80003600 <iput>
}
    800036e6:	60e2                	ld	ra,24(sp)
    800036e8:	6442                	ld	s0,16(sp)
    800036ea:	64a2                	ld	s1,8(sp)
    800036ec:	6105                	addi	sp,sp,32
    800036ee:	8082                	ret

00000000800036f0 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800036f0:	0001d717          	auipc	a4,0x1d
    800036f4:	29472703          	lw	a4,660(a4) # 80020984 <sb+0xc>
    800036f8:	4785                	li	a5,1
    800036fa:	0ae7ff63          	bgeu	a5,a4,800037b8 <ireclaim+0xc8>
{
    800036fe:	7139                	addi	sp,sp,-64
    80003700:	fc06                	sd	ra,56(sp)
    80003702:	f822                	sd	s0,48(sp)
    80003704:	f426                	sd	s1,40(sp)
    80003706:	f04a                	sd	s2,32(sp)
    80003708:	ec4e                	sd	s3,24(sp)
    8000370a:	e852                	sd	s4,16(sp)
    8000370c:	e456                	sd	s5,8(sp)
    8000370e:	e05a                	sd	s6,0(sp)
    80003710:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003712:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003714:	00050a1b          	sext.w	s4,a0
    80003718:	0001da97          	auipc	s5,0x1d
    8000371c:	260a8a93          	addi	s5,s5,608 # 80020978 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    80003720:	00004b17          	auipc	s6,0x4
    80003724:	d68b0b13          	addi	s6,s6,-664 # 80007488 <etext+0x488>
    80003728:	a099                	j	8000376e <ireclaim+0x7e>
    8000372a:	85ce                	mv	a1,s3
    8000372c:	855a                	mv	a0,s6
    8000372e:	dddfc0ef          	jal	8000050a <printk>
      ip = iget(dev, inum);
    80003732:	85ce                	mv	a1,s3
    80003734:	8552                	mv	a0,s4
    80003736:	ad5ff0ef          	jal	8000320a <iget>
    8000373a:	89aa                	mv	s3,a0
    brelse(bp);
    8000373c:	854a                	mv	a0,s2
    8000373e:	f7cff0ef          	jal	80002eba <brelse>
    if (ip) {
    80003742:	00098f63          	beqz	s3,80003760 <ireclaim+0x70>
      begin_op();
    80003746:	782000ef          	jal	80003ec8 <begin_op>
      ilock(ip);
    8000374a:	854e                	mv	a0,s3
    8000374c:	d33ff0ef          	jal	8000347e <ilock>
      iunlock(ip);
    80003750:	854e                	mv	a0,s3
    80003752:	ddbff0ef          	jal	8000352c <iunlock>
      iput(ip);
    80003756:	854e                	mv	a0,s3
    80003758:	ea9ff0ef          	jal	80003600 <iput>
      end_op();
    8000375c:	7f2000ef          	jal	80003f4e <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003760:	0485                	addi	s1,s1,1
    80003762:	00caa703          	lw	a4,12(s5)
    80003766:	0004879b          	sext.w	a5,s1
    8000376a:	02e7fd63          	bgeu	a5,a4,800037a4 <ireclaim+0xb4>
    8000376e:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003772:	0044d593          	srli	a1,s1,0x4
    80003776:	018aa783          	lw	a5,24(s5)
    8000377a:	9dbd                	addw	a1,a1,a5
    8000377c:	8552                	mv	a0,s4
    8000377e:	e34ff0ef          	jal	80002db2 <bread>
    80003782:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003784:	05850793          	addi	a5,a0,88
    80003788:	00f9f713          	andi	a4,s3,15
    8000378c:	071a                	slli	a4,a4,0x6
    8000378e:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    80003790:	00079703          	lh	a4,0(a5)
    80003794:	c701                	beqz	a4,8000379c <ireclaim+0xac>
    80003796:	00679783          	lh	a5,6(a5)
    8000379a:	dbc1                	beqz	a5,8000372a <ireclaim+0x3a>
    brelse(bp);
    8000379c:	854a                	mv	a0,s2
    8000379e:	f1cff0ef          	jal	80002eba <brelse>
    if (ip) {
    800037a2:	bf7d                	j	80003760 <ireclaim+0x70>
}
    800037a4:	70e2                	ld	ra,56(sp)
    800037a6:	7442                	ld	s0,48(sp)
    800037a8:	74a2                	ld	s1,40(sp)
    800037aa:	7902                	ld	s2,32(sp)
    800037ac:	69e2                	ld	s3,24(sp)
    800037ae:	6a42                	ld	s4,16(sp)
    800037b0:	6aa2                	ld	s5,8(sp)
    800037b2:	6b02                	ld	s6,0(sp)
    800037b4:	6121                	addi	sp,sp,64
    800037b6:	8082                	ret
    800037b8:	8082                	ret

00000000800037ba <fsinit>:
{
    800037ba:	7179                	addi	sp,sp,-48
    800037bc:	f406                	sd	ra,40(sp)
    800037be:	f022                	sd	s0,32(sp)
    800037c0:	ec26                	sd	s1,24(sp)
    800037c2:	e84a                	sd	s2,16(sp)
    800037c4:	e44e                	sd	s3,8(sp)
    800037c6:	1800                	addi	s0,sp,48
    800037c8:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    800037ca:	4585                	li	a1,1
    800037cc:	de6ff0ef          	jal	80002db2 <bread>
    800037d0:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    800037d2:	0001d997          	auipc	s3,0x1d
    800037d6:	1a698993          	addi	s3,s3,422 # 80020978 <sb>
    800037da:	02000613          	li	a2,32
    800037de:	05850593          	addi	a1,a0,88
    800037e2:	854e                	mv	a0,s3
    800037e4:	db2fd0ef          	jal	80000d96 <memmove>
  brelse(bp);
    800037e8:	854a                	mv	a0,s2
    800037ea:	ed0ff0ef          	jal	80002eba <brelse>
  if (sb.magic != FSMAGIC)
    800037ee:	0009a703          	lw	a4,0(s3)
    800037f2:	102037b7          	lui	a5,0x10203
    800037f6:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    800037fa:	02f71363          	bne	a4,a5,80003820 <fsinit+0x66>
  initlog(dev, &sb);
    800037fe:	0001d597          	auipc	a1,0x1d
    80003802:	17a58593          	addi	a1,a1,378 # 80020978 <sb>
    80003806:	8526                	mv	a0,s1
    80003808:	642000ef          	jal	80003e4a <initlog>
  ireclaim(dev);
    8000380c:	8526                	mv	a0,s1
    8000380e:	ee3ff0ef          	jal	800036f0 <ireclaim>
}
    80003812:	70a2                	ld	ra,40(sp)
    80003814:	7402                	ld	s0,32(sp)
    80003816:	64e2                	ld	s1,24(sp)
    80003818:	6942                	ld	s2,16(sp)
    8000381a:	69a2                	ld	s3,8(sp)
    8000381c:	6145                	addi	sp,sp,48
    8000381e:	8082                	ret
    panic("invalid file system");
    80003820:	00004517          	auipc	a0,0x4
    80003824:	c8850513          	addi	a0,a0,-888 # 800074a8 <etext+0x4a8>
    80003828:	fc9fc0ef          	jal	800007f0 <panic>

000000008000382c <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    8000382c:	1141                	addi	sp,sp,-16
    8000382e:	e422                	sd	s0,8(sp)
    80003830:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003832:	411c                	lw	a5,0(a0)
    80003834:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003836:	415c                	lw	a5,4(a0)
    80003838:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    8000383a:	04451783          	lh	a5,68(a0)
    8000383e:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003842:	04a51783          	lh	a5,74(a0)
    80003846:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    8000384a:	04c56783          	lwu	a5,76(a0)
    8000384e:	e99c                	sd	a5,16(a1)
}
    80003850:	6422                	ld	s0,8(sp)
    80003852:	0141                	addi	sp,sp,16
    80003854:	8082                	ret

0000000080003856 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003856:	457c                	lw	a5,76(a0)
    80003858:	0ed7eb63          	bltu	a5,a3,8000394e <readi+0xf8>
{
    8000385c:	7159                	addi	sp,sp,-112
    8000385e:	f486                	sd	ra,104(sp)
    80003860:	f0a2                	sd	s0,96(sp)
    80003862:	eca6                	sd	s1,88(sp)
    80003864:	e0d2                	sd	s4,64(sp)
    80003866:	fc56                	sd	s5,56(sp)
    80003868:	f85a                	sd	s6,48(sp)
    8000386a:	f45e                	sd	s7,40(sp)
    8000386c:	1880                	addi	s0,sp,112
    8000386e:	8b2a                	mv	s6,a0
    80003870:	8bae                	mv	s7,a1
    80003872:	8a32                	mv	s4,a2
    80003874:	84b6                	mv	s1,a3
    80003876:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003878:	9f35                	addw	a4,a4,a3
    return 0;
    8000387a:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    8000387c:	0cd76063          	bltu	a4,a3,8000393c <readi+0xe6>
    80003880:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    80003882:	00e7f463          	bgeu	a5,a4,8000388a <readi+0x34>
    n = ip->size - off;
    80003886:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    8000388a:	080a8f63          	beqz	s5,80003928 <readi+0xd2>
    8000388e:	e8ca                	sd	s2,80(sp)
    80003890:	f062                	sd	s8,32(sp)
    80003892:	ec66                	sd	s9,24(sp)
    80003894:	e86a                	sd	s10,16(sp)
    80003896:	e46e                	sd	s11,8(sp)
    80003898:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    8000389a:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000389e:	5c7d                	li	s8,-1
    800038a0:	a80d                	j	800038d2 <readi+0x7c>
    800038a2:	020d1d93          	slli	s11,s10,0x20
    800038a6:	020ddd93          	srli	s11,s11,0x20
    800038aa:	05890613          	addi	a2,s2,88
    800038ae:	86ee                	mv	a3,s11
    800038b0:	963a                	add	a2,a2,a4
    800038b2:	85d2                	mv	a1,s4
    800038b4:	855e                	mv	a0,s7
    800038b6:	aa7fe0ef          	jal	8000235c <either_copyout>
    800038ba:	05850763          	beq	a0,s8,80003908 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800038be:	854a                	mv	a0,s2
    800038c0:	dfaff0ef          	jal	80002eba <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    800038c4:	013d09bb          	addw	s3,s10,s3
    800038c8:	009d04bb          	addw	s1,s10,s1
    800038cc:	9a6e                	add	s4,s4,s11
    800038ce:	0559f763          	bgeu	s3,s5,8000391c <readi+0xc6>
    uint addr = bmap(ip, off / BSIZE);
    800038d2:	00a4d59b          	srliw	a1,s1,0xa
    800038d6:	855a                	mv	a0,s6
    800038d8:	85fff0ef          	jal	80003136 <bmap>
    800038dc:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    800038e0:	c5b1                	beqz	a1,8000392c <readi+0xd6>
    bp = bread(ip->dev, addr);
    800038e2:	000b2503          	lw	a0,0(s6)
    800038e6:	cccff0ef          	jal	80002db2 <bread>
    800038ea:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800038ec:	3ff4f713          	andi	a4,s1,1023
    800038f0:	40ec87bb          	subw	a5,s9,a4
    800038f4:	413a86bb          	subw	a3,s5,s3
    800038f8:	8d3e                	mv	s10,a5
    800038fa:	2781                	sext.w	a5,a5
    800038fc:	0006861b          	sext.w	a2,a3
    80003900:	faf671e3          	bgeu	a2,a5,800038a2 <readi+0x4c>
    80003904:	8d36                	mv	s10,a3
    80003906:	bf71                	j	800038a2 <readi+0x4c>
      brelse(bp);
    80003908:	854a                	mv	a0,s2
    8000390a:	db0ff0ef          	jal	80002eba <brelse>
      tot = -1;
    8000390e:	59fd                	li	s3,-1
      break;
    80003910:	6946                	ld	s2,80(sp)
    80003912:	7c02                	ld	s8,32(sp)
    80003914:	6ce2                	ld	s9,24(sp)
    80003916:	6d42                	ld	s10,16(sp)
    80003918:	6da2                	ld	s11,8(sp)
    8000391a:	a831                	j	80003936 <readi+0xe0>
    8000391c:	6946                	ld	s2,80(sp)
    8000391e:	7c02                	ld	s8,32(sp)
    80003920:	6ce2                	ld	s9,24(sp)
    80003922:	6d42                	ld	s10,16(sp)
    80003924:	6da2                	ld	s11,8(sp)
    80003926:	a801                	j	80003936 <readi+0xe0>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003928:	89d6                	mv	s3,s5
    8000392a:	a031                	j	80003936 <readi+0xe0>
    8000392c:	6946                	ld	s2,80(sp)
    8000392e:	7c02                	ld	s8,32(sp)
    80003930:	6ce2                	ld	s9,24(sp)
    80003932:	6d42                	ld	s10,16(sp)
    80003934:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003936:	0009851b          	sext.w	a0,s3
    8000393a:	69a6                	ld	s3,72(sp)
}
    8000393c:	70a6                	ld	ra,104(sp)
    8000393e:	7406                	ld	s0,96(sp)
    80003940:	64e6                	ld	s1,88(sp)
    80003942:	6a06                	ld	s4,64(sp)
    80003944:	7ae2                	ld	s5,56(sp)
    80003946:	7b42                	ld	s6,48(sp)
    80003948:	7ba2                	ld	s7,40(sp)
    8000394a:	6165                	addi	sp,sp,112
    8000394c:	8082                	ret
    return 0;
    8000394e:	4501                	li	a0,0
}
    80003950:	8082                	ret

0000000080003952 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003952:	457c                	lw	a5,76(a0)
    80003954:	10d7e363          	bltu	a5,a3,80003a5a <writei+0x108>
{
    80003958:	7159                	addi	sp,sp,-112
    8000395a:	f486                	sd	ra,104(sp)
    8000395c:	f0a2                	sd	s0,96(sp)
    8000395e:	e8ca                	sd	s2,80(sp)
    80003960:	e0d2                	sd	s4,64(sp)
    80003962:	fc56                	sd	s5,56(sp)
    80003964:	f85a                	sd	s6,48(sp)
    80003966:	f45e                	sd	s7,40(sp)
    80003968:	1880                	addi	s0,sp,112
    8000396a:	8aaa                	mv	s5,a0
    8000396c:	8bae                	mv	s7,a1
    8000396e:	8a32                	mv	s4,a2
    80003970:	8936                	mv	s2,a3
    80003972:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    80003974:	00e687bb          	addw	a5,a3,a4
    80003978:	0ed7e363          	bltu	a5,a3,80003a5e <writei+0x10c>
    return -1;
  if (off + n > MAXFILE * BSIZE)
    8000397c:	00043737          	lui	a4,0x43
    80003980:	0ef76163          	bltu	a4,a5,80003a62 <writei+0x110>
    80003984:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003986:	0c0b0263          	beqz	s6,80003a4a <writei+0xf8>
    8000398a:	eca6                	sd	s1,88(sp)
    8000398c:	f062                	sd	s8,32(sp)
    8000398e:	ec66                	sd	s9,24(sp)
    80003990:	e86a                	sd	s10,16(sp)
    80003992:	e46e                	sd	s11,8(sp)
    80003994:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003996:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000399a:	5c7d                	li	s8,-1
    8000399c:	a825                	j	800039d4 <writei+0x82>
    8000399e:	020d1d93          	slli	s11,s10,0x20
    800039a2:	020ddd93          	srli	s11,s11,0x20
    800039a6:	05848513          	addi	a0,s1,88
    800039aa:	86ee                	mv	a3,s11
    800039ac:	8652                	mv	a2,s4
    800039ae:	85de                	mv	a1,s7
    800039b0:	953a                	add	a0,a0,a4
    800039b2:	9f7fe0ef          	jal	800023a8 <either_copyin>
    800039b6:	05850a63          	beq	a0,s8,80003a0a <writei+0xb8>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    800039ba:	8526                	mv	a0,s1
    800039bc:	6b2000ef          	jal	8000406e <log_write>
    brelse(bp);
    800039c0:	8526                	mv	a0,s1
    800039c2:	cf8ff0ef          	jal	80002eba <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    800039c6:	013d09bb          	addw	s3,s10,s3
    800039ca:	012d093b          	addw	s2,s10,s2
    800039ce:	9a6e                	add	s4,s4,s11
    800039d0:	0569f363          	bgeu	s3,s6,80003a16 <writei+0xc4>
    uint addr = bmap(ip, off / BSIZE);
    800039d4:	00a9559b          	srliw	a1,s2,0xa
    800039d8:	8556                	mv	a0,s5
    800039da:	f5cff0ef          	jal	80003136 <bmap>
    800039de:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    800039e2:	c995                	beqz	a1,80003a16 <writei+0xc4>
    bp = bread(ip->dev, addr);
    800039e4:	000aa503          	lw	a0,0(s5)
    800039e8:	bcaff0ef          	jal	80002db2 <bread>
    800039ec:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    800039ee:	3ff97713          	andi	a4,s2,1023
    800039f2:	40ec87bb          	subw	a5,s9,a4
    800039f6:	413b06bb          	subw	a3,s6,s3
    800039fa:	8d3e                	mv	s10,a5
    800039fc:	2781                	sext.w	a5,a5
    800039fe:	0006861b          	sext.w	a2,a3
    80003a02:	f8f67ee3          	bgeu	a2,a5,8000399e <writei+0x4c>
    80003a06:	8d36                	mv	s10,a3
    80003a08:	bf59                	j	8000399e <writei+0x4c>
      log_write(bp);
    80003a0a:	8526                	mv	a0,s1
    80003a0c:	662000ef          	jal	8000406e <log_write>
      brelse(bp);
    80003a10:	8526                	mv	a0,s1
    80003a12:	ca8ff0ef          	jal	80002eba <brelse>
  }

  if (off > ip->size)
    80003a16:	04caa783          	lw	a5,76(s5)
    80003a1a:	0327fa63          	bgeu	a5,s2,80003a4e <writei+0xfc>
    ip->size = off;
    80003a1e:	052aa623          	sw	s2,76(s5)
    80003a22:	64e6                	ld	s1,88(sp)
    80003a24:	7c02                	ld	s8,32(sp)
    80003a26:	6ce2                	ld	s9,24(sp)
    80003a28:	6d42                	ld	s10,16(sp)
    80003a2a:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003a2c:	8556                	mv	a0,s5
    80003a2e:	99dff0ef          	jal	800033ca <iupdate>

  return tot;
    80003a32:	0009851b          	sext.w	a0,s3
    80003a36:	69a6                	ld	s3,72(sp)
}
    80003a38:	70a6                	ld	ra,104(sp)
    80003a3a:	7406                	ld	s0,96(sp)
    80003a3c:	6946                	ld	s2,80(sp)
    80003a3e:	6a06                	ld	s4,64(sp)
    80003a40:	7ae2                	ld	s5,56(sp)
    80003a42:	7b42                	ld	s6,48(sp)
    80003a44:	7ba2                	ld	s7,40(sp)
    80003a46:	6165                	addi	sp,sp,112
    80003a48:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003a4a:	89da                	mv	s3,s6
    80003a4c:	b7c5                	j	80003a2c <writei+0xda>
    80003a4e:	64e6                	ld	s1,88(sp)
    80003a50:	7c02                	ld	s8,32(sp)
    80003a52:	6ce2                	ld	s9,24(sp)
    80003a54:	6d42                	ld	s10,16(sp)
    80003a56:	6da2                	ld	s11,8(sp)
    80003a58:	bfd1                	j	80003a2c <writei+0xda>
    return -1;
    80003a5a:	557d                	li	a0,-1
}
    80003a5c:	8082                	ret
    return -1;
    80003a5e:	557d                	li	a0,-1
    80003a60:	bfe1                	j	80003a38 <writei+0xe6>
    return -1;
    80003a62:	557d                	li	a0,-1
    80003a64:	bfd1                	j	80003a38 <writei+0xe6>

0000000080003a66 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003a66:	1141                	addi	sp,sp,-16
    80003a68:	e406                	sd	ra,8(sp)
    80003a6a:	e022                	sd	s0,0(sp)
    80003a6c:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003a6e:	4639                	li	a2,14
    80003a70:	b96fd0ef          	jal	80000e06 <strncmp>
}
    80003a74:	60a2                	ld	ra,8(sp)
    80003a76:	6402                	ld	s0,0(sp)
    80003a78:	0141                	addi	sp,sp,16
    80003a7a:	8082                	ret

0000000080003a7c <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003a7c:	7139                	addi	sp,sp,-64
    80003a7e:	fc06                	sd	ra,56(sp)
    80003a80:	f822                	sd	s0,48(sp)
    80003a82:	f426                	sd	s1,40(sp)
    80003a84:	f04a                	sd	s2,32(sp)
    80003a86:	ec4e                	sd	s3,24(sp)
    80003a88:	e852                	sd	s4,16(sp)
    80003a8a:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    80003a8c:	04451703          	lh	a4,68(a0)
    80003a90:	4785                	li	a5,1
    80003a92:	00f71a63          	bne	a4,a5,80003aa6 <dirlookup+0x2a>
    80003a96:	892a                	mv	s2,a0
    80003a98:	89ae                	mv	s3,a1
    80003a9a:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003a9c:	457c                	lw	a5,76(a0)
    80003a9e:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003aa0:	4501                	li	a0,0
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003aa2:	e39d                	bnez	a5,80003ac8 <dirlookup+0x4c>
    80003aa4:	a095                	j	80003b08 <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003aa6:	00004517          	auipc	a0,0x4
    80003aaa:	a1a50513          	addi	a0,a0,-1510 # 800074c0 <etext+0x4c0>
    80003aae:	d43fc0ef          	jal	800007f0 <panic>
      panic("dirlookup read");
    80003ab2:	00004517          	auipc	a0,0x4
    80003ab6:	a2650513          	addi	a0,a0,-1498 # 800074d8 <etext+0x4d8>
    80003aba:	d37fc0ef          	jal	800007f0 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003abe:	24c1                	addiw	s1,s1,16
    80003ac0:	04c92783          	lw	a5,76(s2)
    80003ac4:	04f4f163          	bgeu	s1,a5,80003b06 <dirlookup+0x8a>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003ac8:	4741                	li	a4,16
    80003aca:	86a6                	mv	a3,s1
    80003acc:	fc040613          	addi	a2,s0,-64
    80003ad0:	4581                	li	a1,0
    80003ad2:	854a                	mv	a0,s2
    80003ad4:	d83ff0ef          	jal	80003856 <readi>
    80003ad8:	47c1                	li	a5,16
    80003ada:	fcf51ce3          	bne	a0,a5,80003ab2 <dirlookup+0x36>
    if (de.inum == 0)
    80003ade:	fc045783          	lhu	a5,-64(s0)
    80003ae2:	dff1                	beqz	a5,80003abe <dirlookup+0x42>
    if (namecmp(name, de.name) == 0) {
    80003ae4:	fc240593          	addi	a1,s0,-62
    80003ae8:	854e                	mv	a0,s3
    80003aea:	f7dff0ef          	jal	80003a66 <namecmp>
    80003aee:	f961                	bnez	a0,80003abe <dirlookup+0x42>
      if (poff)
    80003af0:	000a0463          	beqz	s4,80003af8 <dirlookup+0x7c>
        *poff = off;
    80003af4:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003af8:	fc045583          	lhu	a1,-64(s0)
    80003afc:	00092503          	lw	a0,0(s2)
    80003b00:	f0aff0ef          	jal	8000320a <iget>
    80003b04:	a011                	j	80003b08 <dirlookup+0x8c>
  return 0;
    80003b06:	4501                	li	a0,0
}
    80003b08:	70e2                	ld	ra,56(sp)
    80003b0a:	7442                	ld	s0,48(sp)
    80003b0c:	74a2                	ld	s1,40(sp)
    80003b0e:	7902                	ld	s2,32(sp)
    80003b10:	69e2                	ld	s3,24(sp)
    80003b12:	6a42                	ld	s4,16(sp)
    80003b14:	6121                	addi	sp,sp,64
    80003b16:	8082                	ret

0000000080003b18 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    80003b18:	711d                	addi	sp,sp,-96
    80003b1a:	ec86                	sd	ra,88(sp)
    80003b1c:	e8a2                	sd	s0,80(sp)
    80003b1e:	e4a6                	sd	s1,72(sp)
    80003b20:	e0ca                	sd	s2,64(sp)
    80003b22:	fc4e                	sd	s3,56(sp)
    80003b24:	f852                	sd	s4,48(sp)
    80003b26:	f456                	sd	s5,40(sp)
    80003b28:	f05a                	sd	s6,32(sp)
    80003b2a:	ec5e                	sd	s7,24(sp)
    80003b2c:	e862                	sd	s8,16(sp)
    80003b2e:	e466                	sd	s9,8(sp)
    80003b30:	1080                	addi	s0,sp,96
    80003b32:	84aa                	mv	s1,a0
    80003b34:	8b2e                	mv	s6,a1
    80003b36:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    80003b38:	00054703          	lbu	a4,0(a0)
    80003b3c:	02f00793          	li	a5,47
    80003b40:	00f70e63          	beq	a4,a5,80003b5c <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003b44:	e81fd0ef          	jal	800019c4 <myproc>
    80003b48:	15053503          	ld	a0,336(a0)
    80003b4c:	8fdff0ef          	jal	80003448 <idup>
    80003b50:	8a2a                	mv	s4,a0
  while (*path == '/')
    80003b52:	02f00913          	li	s2,47
  if (len >= DIRSIZ)
    80003b56:	4c35                	li	s8,13

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    80003b58:	4b85                	li	s7,1
    80003b5a:	a075                	j	80003c06 <namex+0xee>
    ip = iget(ROOTDEV, ROOTINO);
    80003b5c:	4585                	li	a1,1
    80003b5e:	4505                	li	a0,1
    80003b60:	eaaff0ef          	jal	8000320a <iget>
    80003b64:	8a2a                	mv	s4,a0
    80003b66:	b7f5                	j	80003b52 <namex+0x3a>
      iunlockput(ip);
    80003b68:	8552                	mv	a0,s4
    80003b6a:	b67ff0ef          	jal	800036d0 <iunlockput>
      return 0;
    80003b6e:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003b70:	8552                	mv	a0,s4
    80003b72:	60e6                	ld	ra,88(sp)
    80003b74:	6446                	ld	s0,80(sp)
    80003b76:	64a6                	ld	s1,72(sp)
    80003b78:	6906                	ld	s2,64(sp)
    80003b7a:	79e2                	ld	s3,56(sp)
    80003b7c:	7a42                	ld	s4,48(sp)
    80003b7e:	7aa2                	ld	s5,40(sp)
    80003b80:	7b02                	ld	s6,32(sp)
    80003b82:	6be2                	ld	s7,24(sp)
    80003b84:	6c42                	ld	s8,16(sp)
    80003b86:	6ca2                	ld	s9,8(sp)
    80003b88:	6125                	addi	sp,sp,96
    80003b8a:	8082                	ret
      iunlockput(ip);
    80003b8c:	8552                	mv	a0,s4
    80003b8e:	b43ff0ef          	jal	800036d0 <iunlockput>
      return 0;
    80003b92:	4a01                	li	s4,0
    80003b94:	bff1                	j	80003b70 <namex+0x58>
      iunlock(ip);
    80003b96:	8552                	mv	a0,s4
    80003b98:	995ff0ef          	jal	8000352c <iunlock>
      return ip;
    80003b9c:	bfd1                	j	80003b70 <namex+0x58>
      iunlockput(ip);
    80003b9e:	8552                	mv	a0,s4
    80003ba0:	b31ff0ef          	jal	800036d0 <iunlockput>
      return 0;
    80003ba4:	8a4e                	mv	s4,s3
    80003ba6:	b7e9                	j	80003b70 <namex+0x58>
  len = path - s;
    80003ba8:	40998633          	sub	a2,s3,s1
    80003bac:	00060c9b          	sext.w	s9,a2
  if (len >= DIRSIZ)
    80003bb0:	099c5363          	bge	s8,s9,80003c36 <namex+0x11e>
    memmove(name, s, DIRSIZ);
    80003bb4:	4639                	li	a2,14
    80003bb6:	85a6                	mv	a1,s1
    80003bb8:	8556                	mv	a0,s5
    80003bba:	9dcfd0ef          	jal	80000d96 <memmove>
    80003bbe:	84ce                	mv	s1,s3
  while (*path == '/')
    80003bc0:	0004c783          	lbu	a5,0(s1)
    80003bc4:	09279363          	bne	a5,s2,80003c4a <namex+0x132>
    path++;
    80003bc8:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003bca:	0004c783          	lbu	a5,0(s1)
    80003bce:	ff278de3          	beq	a5,s2,80003bc8 <namex+0xb0>
    ilock(ip);
    80003bd2:	8552                	mv	a0,s4
    80003bd4:	8abff0ef          	jal	8000347e <ilock>
    if (ip->type != T_DIR) {
    80003bd8:	044a1783          	lh	a5,68(s4)
    80003bdc:	f97796e3          	bne	a5,s7,80003b68 <namex+0x50>
    if (ip->nlink == 0) {
    80003be0:	04aa1783          	lh	a5,74(s4)
    80003be4:	d7c5                	beqz	a5,80003b8c <namex+0x74>
    if (nameiparent && *path == '\0') {
    80003be6:	000b0563          	beqz	s6,80003bf0 <namex+0xd8>
    80003bea:	0004c783          	lbu	a5,0(s1)
    80003bee:	d7c5                	beqz	a5,80003b96 <namex+0x7e>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    80003bf0:	4601                	li	a2,0
    80003bf2:	85d6                	mv	a1,s5
    80003bf4:	8552                	mv	a0,s4
    80003bf6:	e87ff0ef          	jal	80003a7c <dirlookup>
    80003bfa:	89aa                	mv	s3,a0
    80003bfc:	d14d                	beqz	a0,80003b9e <namex+0x86>
    iunlockput(ip);
    80003bfe:	8552                	mv	a0,s4
    80003c00:	ad1ff0ef          	jal	800036d0 <iunlockput>
    ip = next;
    80003c04:	8a4e                	mv	s4,s3
  while (*path == '/')
    80003c06:	0004c783          	lbu	a5,0(s1)
    80003c0a:	01279763          	bne	a5,s2,80003c18 <namex+0x100>
    path++;
    80003c0e:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003c10:	0004c783          	lbu	a5,0(s1)
    80003c14:	ff278de3          	beq	a5,s2,80003c0e <namex+0xf6>
  if (*path == 0)
    80003c18:	cb95                	beqz	a5,80003c4c <namex+0x134>
  while (*path != '/' && *path != 0)
    80003c1a:	0004c783          	lbu	a5,0(s1)
    80003c1e:	89a6                	mv	s3,s1
  len = path - s;
    80003c20:	4c81                	li	s9,0
    80003c22:	4601                	li	a2,0
  while (*path != '/' && *path != 0)
    80003c24:	01278963          	beq	a5,s2,80003c36 <namex+0x11e>
    80003c28:	d3c1                	beqz	a5,80003ba8 <namex+0x90>
    path++;
    80003c2a:	0985                	addi	s3,s3,1
  while (*path != '/' && *path != 0)
    80003c2c:	0009c783          	lbu	a5,0(s3)
    80003c30:	ff279ce3          	bne	a5,s2,80003c28 <namex+0x110>
    80003c34:	bf95                	j	80003ba8 <namex+0x90>
    memmove(name, s, len);
    80003c36:	2601                	sext.w	a2,a2
    80003c38:	85a6                	mv	a1,s1
    80003c3a:	8556                	mv	a0,s5
    80003c3c:	95afd0ef          	jal	80000d96 <memmove>
    name[len] = 0;
    80003c40:	9cd6                	add	s9,s9,s5
    80003c42:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003c46:	84ce                	mv	s1,s3
    80003c48:	bfa5                	j	80003bc0 <namex+0xa8>
  while ((path = skipelem(path, name)) != 0) {
    80003c4a:	f4c1                	bnez	s1,80003bd2 <namex+0xba>
  if (nameiparent) {
    80003c4c:	f20b02e3          	beqz	s6,80003b70 <namex+0x58>
    iput(ip);
    80003c50:	8552                	mv	a0,s4
    80003c52:	9afff0ef          	jal	80003600 <iput>
    return 0;
    80003c56:	4a01                	li	s4,0
    80003c58:	bf21                	j	80003b70 <namex+0x58>

0000000080003c5a <dirlink>:
{
    80003c5a:	7139                	addi	sp,sp,-64
    80003c5c:	fc06                	sd	ra,56(sp)
    80003c5e:	f822                	sd	s0,48(sp)
    80003c60:	f04a                	sd	s2,32(sp)
    80003c62:	ec4e                	sd	s3,24(sp)
    80003c64:	e852                	sd	s4,16(sp)
    80003c66:	0080                	addi	s0,sp,64
    80003c68:	892a                	mv	s2,a0
    80003c6a:	8a2e                	mv	s4,a1
    80003c6c:	89b2                	mv	s3,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003c6e:	4601                	li	a2,0
    80003c70:	e0dff0ef          	jal	80003a7c <dirlookup>
    80003c74:	e535                	bnez	a0,80003ce0 <dirlink+0x86>
    80003c76:	f426                	sd	s1,40(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003c78:	04c92483          	lw	s1,76(s2)
    80003c7c:	c48d                	beqz	s1,80003ca6 <dirlink+0x4c>
    80003c7e:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003c80:	4741                	li	a4,16
    80003c82:	86a6                	mv	a3,s1
    80003c84:	fc040613          	addi	a2,s0,-64
    80003c88:	4581                	li	a1,0
    80003c8a:	854a                	mv	a0,s2
    80003c8c:	bcbff0ef          	jal	80003856 <readi>
    80003c90:	47c1                	li	a5,16
    80003c92:	04f51b63          	bne	a0,a5,80003ce8 <dirlink+0x8e>
    if (de.inum == 0)
    80003c96:	fc045783          	lhu	a5,-64(s0)
    80003c9a:	c791                	beqz	a5,80003ca6 <dirlink+0x4c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003c9c:	24c1                	addiw	s1,s1,16
    80003c9e:	04c92783          	lw	a5,76(s2)
    80003ca2:	fcf4efe3          	bltu	s1,a5,80003c80 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003ca6:	4639                	li	a2,14
    80003ca8:	85d2                	mv	a1,s4
    80003caa:	fc240513          	addi	a0,s0,-62
    80003cae:	98efd0ef          	jal	80000e3c <strncpy>
  de.inum = inum;
    80003cb2:	fd341023          	sh	s3,-64(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003cb6:	4741                	li	a4,16
    80003cb8:	86a6                	mv	a3,s1
    80003cba:	fc040613          	addi	a2,s0,-64
    80003cbe:	4581                	li	a1,0
    80003cc0:	854a                	mv	a0,s2
    80003cc2:	c91ff0ef          	jal	80003952 <writei>
    80003cc6:	1541                	addi	a0,a0,-16
    80003cc8:	00a03533          	snez	a0,a0
    80003ccc:	40a00533          	neg	a0,a0
    80003cd0:	74a2                	ld	s1,40(sp)
}
    80003cd2:	70e2                	ld	ra,56(sp)
    80003cd4:	7442                	ld	s0,48(sp)
    80003cd6:	7902                	ld	s2,32(sp)
    80003cd8:	69e2                	ld	s3,24(sp)
    80003cda:	6a42                	ld	s4,16(sp)
    80003cdc:	6121                	addi	sp,sp,64
    80003cde:	8082                	ret
    iput(ip);
    80003ce0:	921ff0ef          	jal	80003600 <iput>
    return -1;
    80003ce4:	557d                	li	a0,-1
    80003ce6:	b7f5                	j	80003cd2 <dirlink+0x78>
      panic("dirlink read");
    80003ce8:	00004517          	auipc	a0,0x4
    80003cec:	80050513          	addi	a0,a0,-2048 # 800074e8 <etext+0x4e8>
    80003cf0:	b01fc0ef          	jal	800007f0 <panic>

0000000080003cf4 <namei>:

struct inode *
namei(char *path)
{
    80003cf4:	1101                	addi	sp,sp,-32
    80003cf6:	ec06                	sd	ra,24(sp)
    80003cf8:	e822                	sd	s0,16(sp)
    80003cfa:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003cfc:	fe040613          	addi	a2,s0,-32
    80003d00:	4581                	li	a1,0
    80003d02:	e17ff0ef          	jal	80003b18 <namex>
}
    80003d06:	60e2                	ld	ra,24(sp)
    80003d08:	6442                	ld	s0,16(sp)
    80003d0a:	6105                	addi	sp,sp,32
    80003d0c:	8082                	ret

0000000080003d0e <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80003d0e:	1141                	addi	sp,sp,-16
    80003d10:	e406                	sd	ra,8(sp)
    80003d12:	e022                	sd	s0,0(sp)
    80003d14:	0800                	addi	s0,sp,16
    80003d16:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003d18:	4585                	li	a1,1
    80003d1a:	dffff0ef          	jal	80003b18 <namex>
}
    80003d1e:	60a2                	ld	ra,8(sp)
    80003d20:	6402                	ld	s0,0(sp)
    80003d22:	0141                	addi	sp,sp,16
    80003d24:	8082                	ret

0000000080003d26 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003d26:	1101                	addi	sp,sp,-32
    80003d28:	ec06                	sd	ra,24(sp)
    80003d2a:	e822                	sd	s0,16(sp)
    80003d2c:	e426                	sd	s1,8(sp)
    80003d2e:	e04a                	sd	s2,0(sp)
    80003d30:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003d32:	0001e917          	auipc	s2,0x1e
    80003d36:	70e90913          	addi	s2,s2,1806 # 80022440 <log>
    80003d3a:	01892583          	lw	a1,24(s2)
    80003d3e:	02492503          	lw	a0,36(s2)
    80003d42:	870ff0ef          	jal	80002db2 <bread>
    80003d46:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80003d48:	02c92603          	lw	a2,44(s2)
    80003d4c:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003d4e:	00c05f63          	blez	a2,80003d6c <write_head+0x46>
    80003d52:	0001e717          	auipc	a4,0x1e
    80003d56:	71e70713          	addi	a4,a4,1822 # 80022470 <log+0x30>
    80003d5a:	87aa                	mv	a5,a0
    80003d5c:	060a                	slli	a2,a2,0x2
    80003d5e:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003d60:	4314                	lw	a3,0(a4)
    80003d62:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003d64:	0711                	addi	a4,a4,4
    80003d66:	0791                	addi	a5,a5,4
    80003d68:	fec79ce3          	bne	a5,a2,80003d60 <write_head+0x3a>
  }
  bwrite(buf);
    80003d6c:	8526                	mv	a0,s1
    80003d6e:	91aff0ef          	jal	80002e88 <bwrite>
  brelse(buf);
    80003d72:	8526                	mv	a0,s1
    80003d74:	946ff0ef          	jal	80002eba <brelse>
}
    80003d78:	60e2                	ld	ra,24(sp)
    80003d7a:	6442                	ld	s0,16(sp)
    80003d7c:	64a2                	ld	s1,8(sp)
    80003d7e:	6902                	ld	s2,0(sp)
    80003d80:	6105                	addi	sp,sp,32
    80003d82:	8082                	ret

0000000080003d84 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d84:	0001e797          	auipc	a5,0x1e
    80003d88:	6e87a783          	lw	a5,1768(a5) # 8002246c <log+0x2c>
    80003d8c:	0af05e63          	blez	a5,80003e48 <install_trans+0xc4>
{
    80003d90:	715d                	addi	sp,sp,-80
    80003d92:	e486                	sd	ra,72(sp)
    80003d94:	e0a2                	sd	s0,64(sp)
    80003d96:	fc26                	sd	s1,56(sp)
    80003d98:	f84a                	sd	s2,48(sp)
    80003d9a:	f44e                	sd	s3,40(sp)
    80003d9c:	f052                	sd	s4,32(sp)
    80003d9e:	ec56                	sd	s5,24(sp)
    80003da0:	e85a                	sd	s6,16(sp)
    80003da2:	e45e                	sd	s7,8(sp)
    80003da4:	0880                	addi	s0,sp,80
    80003da6:	8b2a                	mv	s6,a0
    80003da8:	0001ea97          	auipc	s5,0x1e
    80003dac:	6c8a8a93          	addi	s5,s5,1736 # 80022470 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003db0:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003db2:	00003b97          	auipc	s7,0x3
    80003db6:	746b8b93          	addi	s7,s7,1862 # 800074f8 <etext+0x4f8>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003dba:	0001ea17          	auipc	s4,0x1e
    80003dbe:	686a0a13          	addi	s4,s4,1670 # 80022440 <log>
    80003dc2:	a025                	j	80003dea <install_trans+0x66>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003dc4:	000aa603          	lw	a2,0(s5)
    80003dc8:	85ce                	mv	a1,s3
    80003dca:	855e                	mv	a0,s7
    80003dcc:	f3efc0ef          	jal	8000050a <printk>
    80003dd0:	a839                	j	80003dee <install_trans+0x6a>
    brelse(lbuf);
    80003dd2:	854a                	mv	a0,s2
    80003dd4:	8e6ff0ef          	jal	80002eba <brelse>
    brelse(dbuf);
    80003dd8:	8526                	mv	a0,s1
    80003dda:	8e0ff0ef          	jal	80002eba <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003dde:	2985                	addiw	s3,s3,1
    80003de0:	0a91                	addi	s5,s5,4
    80003de2:	02ca2783          	lw	a5,44(s4)
    80003de6:	04f9d663          	bge	s3,a5,80003e32 <install_trans+0xae>
    if (recovering) {
    80003dea:	fc0b1de3          	bnez	s6,80003dc4 <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80003dee:	018a2583          	lw	a1,24(s4)
    80003df2:	013585bb          	addw	a1,a1,s3
    80003df6:	2585                	addiw	a1,a1,1
    80003df8:	024a2503          	lw	a0,36(s4)
    80003dfc:	fb7fe0ef          	jal	80002db2 <bread>
    80003e00:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80003e02:	000aa583          	lw	a1,0(s5)
    80003e06:	024a2503          	lw	a0,36(s4)
    80003e0a:	fa9fe0ef          	jal	80002db2 <bread>
    80003e0e:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80003e10:	40000613          	li	a2,1024
    80003e14:	05890593          	addi	a1,s2,88
    80003e18:	05850513          	addi	a0,a0,88
    80003e1c:	f7bfc0ef          	jal	80000d96 <memmove>
    bwrite(dbuf);                           // write dst to disk
    80003e20:	8526                	mv	a0,s1
    80003e22:	866ff0ef          	jal	80002e88 <bwrite>
    if (recovering == 0)
    80003e26:	fa0b16e3          	bnez	s6,80003dd2 <install_trans+0x4e>
      bunpin(dbuf);
    80003e2a:	8526                	mv	a0,s1
    80003e2c:	94aff0ef          	jal	80002f76 <bunpin>
    80003e30:	b74d                	j	80003dd2 <install_trans+0x4e>
}
    80003e32:	60a6                	ld	ra,72(sp)
    80003e34:	6406                	ld	s0,64(sp)
    80003e36:	74e2                	ld	s1,56(sp)
    80003e38:	7942                	ld	s2,48(sp)
    80003e3a:	79a2                	ld	s3,40(sp)
    80003e3c:	7a02                	ld	s4,32(sp)
    80003e3e:	6ae2                	ld	s5,24(sp)
    80003e40:	6b42                	ld	s6,16(sp)
    80003e42:	6ba2                	ld	s7,8(sp)
    80003e44:	6161                	addi	sp,sp,80
    80003e46:	8082                	ret
    80003e48:	8082                	ret

0000000080003e4a <initlog>:
{
    80003e4a:	7179                	addi	sp,sp,-48
    80003e4c:	f406                	sd	ra,40(sp)
    80003e4e:	f022                	sd	s0,32(sp)
    80003e50:	ec26                	sd	s1,24(sp)
    80003e52:	e84a                	sd	s2,16(sp)
    80003e54:	e44e                	sd	s3,8(sp)
    80003e56:	1800                	addi	s0,sp,48
    80003e58:	892a                	mv	s2,a0
    80003e5a:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003e5c:	0001e497          	auipc	s1,0x1e
    80003e60:	5e448493          	addi	s1,s1,1508 # 80022440 <log>
    80003e64:	00003597          	auipc	a1,0x3
    80003e68:	6b458593          	addi	a1,a1,1716 # 80007518 <etext+0x518>
    80003e6c:	8526                	mv	a0,s1
    80003e6e:	d93fc0ef          	jal	80000c00 <initlock>
  log.start = sb->logstart;
    80003e72:	0149a583          	lw	a1,20(s3)
    80003e76:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    80003e78:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003e7c:	854a                	mv	a0,s2
    80003e7e:	f35fe0ef          	jal	80002db2 <bread>
  log.lh.n = lh->n;
    80003e82:	4d30                	lw	a2,88(a0)
    80003e84:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003e86:	00c05f63          	blez	a2,80003ea4 <initlog+0x5a>
    80003e8a:	87aa                	mv	a5,a0
    80003e8c:	0001e717          	auipc	a4,0x1e
    80003e90:	5e470713          	addi	a4,a4,1508 # 80022470 <log+0x30>
    80003e94:	060a                	slli	a2,a2,0x2
    80003e96:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003e98:	4ff4                	lw	a3,92(a5)
    80003e9a:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003e9c:	0791                	addi	a5,a5,4
    80003e9e:	0711                	addi	a4,a4,4
    80003ea0:	fec79ce3          	bne	a5,a2,80003e98 <initlog+0x4e>
  brelse(buf);
    80003ea4:	816ff0ef          	jal	80002eba <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003ea8:	4505                	li	a0,1
    80003eaa:	edbff0ef          	jal	80003d84 <install_trans>
  log.lh.n = 0;
    80003eae:	0001e797          	auipc	a5,0x1e
    80003eb2:	5a07af23          	sw	zero,1470(a5) # 8002246c <log+0x2c>
  write_head(); // clear the log
    80003eb6:	e71ff0ef          	jal	80003d26 <write_head>
}
    80003eba:	70a2                	ld	ra,40(sp)
    80003ebc:	7402                	ld	s0,32(sp)
    80003ebe:	64e2                	ld	s1,24(sp)
    80003ec0:	6942                	ld	s2,16(sp)
    80003ec2:	69a2                	ld	s3,8(sp)
    80003ec4:	6145                	addi	sp,sp,48
    80003ec6:	8082                	ret

0000000080003ec8 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003ec8:	1101                	addi	sp,sp,-32
    80003eca:	ec06                	sd	ra,24(sp)
    80003ecc:	e822                	sd	s0,16(sp)
    80003ece:	e426                	sd	s1,8(sp)
    80003ed0:	e04a                	sd	s2,0(sp)
    80003ed2:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003ed4:	0001e517          	auipc	a0,0x1e
    80003ed8:	56c50513          	addi	a0,a0,1388 # 80022440 <log>
    80003edc:	d9bfc0ef          	jal	80000c76 <acquire>
  while (1) {
    if (log.committing) {
    80003ee0:	0001e497          	auipc	s1,0x1e
    80003ee4:	56048493          	addi	s1,s1,1376 # 80022440 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003ee8:	4979                	li	s2,30
    80003eea:	a821                	j	80003f02 <begin_op+0x3a>
      sleep_prepare(&log);
    80003eec:	8526                	mv	a0,s1
    80003eee:	8dafe0ef          	jal	80001fc8 <sleep_prepare>
      release(&log.lock);
    80003ef2:	8526                	mv	a0,s1
    80003ef4:	e0ffc0ef          	jal	80000d02 <release>
      sleep();
    80003ef8:	90cfe0ef          	jal	80002004 <sleep>
      acquire(&log.lock);
    80003efc:	8526                	mv	a0,s1
    80003efe:	d79fc0ef          	jal	80000c76 <acquire>
    if (log.committing) {
    80003f02:	509c                	lw	a5,32(s1)
    80003f04:	f7e5                	bnez	a5,80003eec <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    80003f06:	4cd8                	lw	a4,28(s1)
    80003f08:	2705                	addiw	a4,a4,1
    80003f0a:	0027179b          	slliw	a5,a4,0x2
    80003f0e:	9fb9                	addw	a5,a5,a4
    80003f10:	0017979b          	slliw	a5,a5,0x1
    80003f14:	54d4                	lw	a3,44(s1)
    80003f16:	9fb5                	addw	a5,a5,a3
    80003f18:	00f95e63          	bge	s2,a5,80003f34 <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80003f1c:	8526                	mv	a0,s1
    80003f1e:	8aafe0ef          	jal	80001fc8 <sleep_prepare>
      release(&log.lock);
    80003f22:	8526                	mv	a0,s1
    80003f24:	ddffc0ef          	jal	80000d02 <release>
      sleep();
    80003f28:	8dcfe0ef          	jal	80002004 <sleep>
      acquire(&log.lock);
    80003f2c:	8526                	mv	a0,s1
    80003f2e:	d49fc0ef          	jal	80000c76 <acquire>
    80003f32:	bfc1                	j	80003f02 <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    80003f34:	0001e517          	auipc	a0,0x1e
    80003f38:	50c50513          	addi	a0,a0,1292 # 80022440 <log>
    80003f3c:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    80003f3e:	dc5fc0ef          	jal	80000d02 <release>
      break;
    }
  }
}
    80003f42:	60e2                	ld	ra,24(sp)
    80003f44:	6442                	ld	s0,16(sp)
    80003f46:	64a2                	ld	s1,8(sp)
    80003f48:	6902                	ld	s2,0(sp)
    80003f4a:	6105                	addi	sp,sp,32
    80003f4c:	8082                	ret

0000000080003f4e <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003f4e:	7139                	addi	sp,sp,-64
    80003f50:	fc06                	sd	ra,56(sp)
    80003f52:	f822                	sd	s0,48(sp)
    80003f54:	f426                	sd	s1,40(sp)
    80003f56:	f04a                	sd	s2,32(sp)
    80003f58:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003f5a:	0001e497          	auipc	s1,0x1e
    80003f5e:	4e648493          	addi	s1,s1,1254 # 80022440 <log>
    80003f62:	8526                	mv	a0,s1
    80003f64:	d13fc0ef          	jal	80000c76 <acquire>
  log.outstanding -= 1;
    80003f68:	4cdc                	lw	a5,28(s1)
    80003f6a:	37fd                	addiw	a5,a5,-1
    80003f6c:	0007891b          	sext.w	s2,a5
    80003f70:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    80003f72:	509c                	lw	a5,32(s1)
    80003f74:	e3b1                	bnez	a5,80003fb8 <end_op+0x6a>
    panic("log.committing");
  if (log.outstanding == 0) {
    80003f76:	04091a63          	bnez	s2,80003fca <end_op+0x7c>
    do_commit = 1;
    log.committing = 1;
    80003f7a:	0001e497          	auipc	s1,0x1e
    80003f7e:	4c648493          	addi	s1,s1,1222 # 80022440 <log>
    80003f82:	4785                	li	a5,1
    80003f84:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003f86:	8526                	mv	a0,s1
    80003f88:	d7bfc0ef          	jal	80000d02 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003f8c:	54dc                	lw	a5,44(s1)
    80003f8e:	04f04e63          	bgtz	a5,80003fea <end_op+0x9c>
    acquire(&log.lock);
    80003f92:	0001e497          	auipc	s1,0x1e
    80003f96:	4ae48493          	addi	s1,s1,1198 # 80022440 <log>
    80003f9a:	8526                	mv	a0,s1
    80003f9c:	cdbfc0ef          	jal	80000c76 <acquire>
    log.committing = 0;
    80003fa0:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    80003fa4:	549c                	lw	a5,40(s1)
    80003fa6:	2785                	addiw	a5,a5,1
    80003fa8:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    80003faa:	8526                	mv	a0,s1
    80003fac:	888fe0ef          	jal	80002034 <wakeup>
    release(&log.lock);
    80003fb0:	8526                	mv	a0,s1
    80003fb2:	d51fc0ef          	jal	80000d02 <release>
}
    80003fb6:	a025                	j	80003fde <end_op+0x90>
    80003fb8:	ec4e                	sd	s3,24(sp)
    80003fba:	e852                	sd	s4,16(sp)
    80003fbc:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003fbe:	00003517          	auipc	a0,0x3
    80003fc2:	56250513          	addi	a0,a0,1378 # 80007520 <etext+0x520>
    80003fc6:	82bfc0ef          	jal	800007f0 <panic>
    wakeup(&log);
    80003fca:	0001e497          	auipc	s1,0x1e
    80003fce:	47648493          	addi	s1,s1,1142 # 80022440 <log>
    80003fd2:	8526                	mv	a0,s1
    80003fd4:	860fe0ef          	jal	80002034 <wakeup>
  release(&log.lock);
    80003fd8:	8526                	mv	a0,s1
    80003fda:	d29fc0ef          	jal	80000d02 <release>
}
    80003fde:	70e2                	ld	ra,56(sp)
    80003fe0:	7442                	ld	s0,48(sp)
    80003fe2:	74a2                	ld	s1,40(sp)
    80003fe4:	7902                	ld	s2,32(sp)
    80003fe6:	6121                	addi	sp,sp,64
    80003fe8:	8082                	ret
    80003fea:	ec4e                	sd	s3,24(sp)
    80003fec:	e852                	sd	s4,16(sp)
    80003fee:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ff0:	0001ea97          	auipc	s5,0x1e
    80003ff4:	480a8a93          	addi	s5,s5,1152 # 80022470 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80003ff8:	0001ea17          	auipc	s4,0x1e
    80003ffc:	448a0a13          	addi	s4,s4,1096 # 80022440 <log>
    80004000:	018a2583          	lw	a1,24(s4)
    80004004:	012585bb          	addw	a1,a1,s2
    80004008:	2585                	addiw	a1,a1,1
    8000400a:	024a2503          	lw	a0,36(s4)
    8000400e:	da5fe0ef          	jal	80002db2 <bread>
    80004012:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80004014:	000aa583          	lw	a1,0(s5)
    80004018:	024a2503          	lw	a0,36(s4)
    8000401c:	d97fe0ef          	jal	80002db2 <bread>
    80004020:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80004022:	40000613          	li	a2,1024
    80004026:	05850593          	addi	a1,a0,88
    8000402a:	05848513          	addi	a0,s1,88
    8000402e:	d69fc0ef          	jal	80000d96 <memmove>
    bwrite(to); // write the log
    80004032:	8526                	mv	a0,s1
    80004034:	e55fe0ef          	jal	80002e88 <bwrite>
    brelse(from);
    80004038:	854e                	mv	a0,s3
    8000403a:	e81fe0ef          	jal	80002eba <brelse>
    brelse(to);
    8000403e:	8526                	mv	a0,s1
    80004040:	e7bfe0ef          	jal	80002eba <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004044:	2905                	addiw	s2,s2,1
    80004046:	0a91                	addi	s5,s5,4
    80004048:	02ca2783          	lw	a5,44(s4)
    8000404c:	faf94ae3          	blt	s2,a5,80004000 <end_op+0xb2>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80004050:	cd7ff0ef          	jal	80003d26 <write_head>
    install_trans(0); // Now install writes to home locations
    80004054:	4501                	li	a0,0
    80004056:	d2fff0ef          	jal	80003d84 <install_trans>
    log.lh.n = 0;
    8000405a:	0001e797          	auipc	a5,0x1e
    8000405e:	4007a923          	sw	zero,1042(a5) # 8002246c <log+0x2c>
    write_head(); // Erase the transaction from the log
    80004062:	cc5ff0ef          	jal	80003d26 <write_head>
    80004066:	69e2                	ld	s3,24(sp)
    80004068:	6a42                	ld	s4,16(sp)
    8000406a:	6aa2                	ld	s5,8(sp)
    8000406c:	b71d                	j	80003f92 <end_op+0x44>

000000008000406e <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000406e:	1101                	addi	sp,sp,-32
    80004070:	ec06                	sd	ra,24(sp)
    80004072:	e822                	sd	s0,16(sp)
    80004074:	e426                	sd	s1,8(sp)
    80004076:	e04a                	sd	s2,0(sp)
    80004078:	1000                	addi	s0,sp,32
    8000407a:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    8000407c:	0001e917          	auipc	s2,0x1e
    80004080:	3c490913          	addi	s2,s2,964 # 80022440 <log>
    80004084:	854a                	mv	a0,s2
    80004086:	bf1fc0ef          	jal	80000c76 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    8000408a:	02c92603          	lw	a2,44(s2)
    8000408e:	47f5                	li	a5,29
    80004090:	04c7cc63          	blt	a5,a2,800040e8 <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80004094:	0001e797          	auipc	a5,0x1e
    80004098:	3c87a783          	lw	a5,968(a5) # 8002245c <log+0x1c>
    8000409c:	04f05c63          	blez	a5,800040f4 <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800040a0:	4781                	li	a5,0
    800040a2:	04c05f63          	blez	a2,80004100 <log_write+0x92>
    if (log.lh.block[i] == b->blockno) // log absorption
    800040a6:	44cc                	lw	a1,12(s1)
    800040a8:	0001e717          	auipc	a4,0x1e
    800040ac:	3c870713          	addi	a4,a4,968 # 80022470 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800040b0:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    800040b2:	4314                	lw	a3,0(a4)
    800040b4:	04b68663          	beq	a3,a1,80004100 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    800040b8:	2785                	addiw	a5,a5,1
    800040ba:	0711                	addi	a4,a4,4
    800040bc:	fef61be3          	bne	a2,a5,800040b2 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    800040c0:	0621                	addi	a2,a2,8
    800040c2:	060a                	slli	a2,a2,0x2
    800040c4:	0001e797          	auipc	a5,0x1e
    800040c8:	37c78793          	addi	a5,a5,892 # 80022440 <log>
    800040cc:	97b2                	add	a5,a5,a2
    800040ce:	44d8                	lw	a4,12(s1)
    800040d0:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    800040d2:	8526                	mv	a0,s1
    800040d4:	e6ffe0ef          	jal	80002f42 <bpin>
    log.lh.n++;
    800040d8:	0001e717          	auipc	a4,0x1e
    800040dc:	36870713          	addi	a4,a4,872 # 80022440 <log>
    800040e0:	575c                	lw	a5,44(a4)
    800040e2:	2785                	addiw	a5,a5,1
    800040e4:	d75c                	sw	a5,44(a4)
    800040e6:	a80d                	j	80004118 <log_write+0xaa>
    panic("too big a transaction");
    800040e8:	00003517          	auipc	a0,0x3
    800040ec:	44850513          	addi	a0,a0,1096 # 80007530 <etext+0x530>
    800040f0:	f00fc0ef          	jal	800007f0 <panic>
    panic("log_write outside of trans");
    800040f4:	00003517          	auipc	a0,0x3
    800040f8:	45450513          	addi	a0,a0,1108 # 80007548 <etext+0x548>
    800040fc:	ef4fc0ef          	jal	800007f0 <panic>
  log.lh.block[i] = b->blockno;
    80004100:	00878693          	addi	a3,a5,8
    80004104:	068a                	slli	a3,a3,0x2
    80004106:	0001e717          	auipc	a4,0x1e
    8000410a:	33a70713          	addi	a4,a4,826 # 80022440 <log>
    8000410e:	9736                	add	a4,a4,a3
    80004110:	44d4                	lw	a3,12(s1)
    80004112:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    80004114:	faf60fe3          	beq	a2,a5,800040d2 <log_write+0x64>
  }
  release(&log.lock);
    80004118:	0001e517          	auipc	a0,0x1e
    8000411c:	32850513          	addi	a0,a0,808 # 80022440 <log>
    80004120:	be3fc0ef          	jal	80000d02 <release>
}
    80004124:	60e2                	ld	ra,24(sp)
    80004126:	6442                	ld	s0,16(sp)
    80004128:	64a2                	ld	s1,8(sp)
    8000412a:	6902                	ld	s2,0(sp)
    8000412c:	6105                	addi	sp,sp,32
    8000412e:	8082                	ret

0000000080004130 <sys_sync>:

uint64
sys_sync(void)
{
    80004130:	1101                	addi	sp,sp,-32
    80004132:	ec06                	sd	ra,24(sp)
    80004134:	e822                	sd	s0,16(sp)
    80004136:	e426                	sd	s1,8(sp)
    80004138:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000413a:	0001e497          	auipc	s1,0x1e
    8000413e:	30648493          	addi	s1,s1,774 # 80022440 <log>
    80004142:	8526                	mv	a0,s1
    80004144:	b33fc0ef          	jal	80000c76 <acquire>
  if (log.committing || log.outstanding > 0) {
    80004148:	509c                	lw	a5,32(s1)
    8000414a:	e799                	bnez	a5,80004158 <sys_sync+0x28>
    8000414c:	0001e797          	auipc	a5,0x1e
    80004150:	3107a783          	lw	a5,784(a5) # 8002245c <log+0x1c>
    80004154:	02f05a63          	blez	a5,80004188 <sys_sync+0x58>
    80004158:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    8000415a:	0001e917          	auipc	s2,0x1e
    8000415e:	30e92903          	lw	s2,782(s2) # 80022468 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    80004162:	0001e497          	auipc	s1,0x1e
    80004166:	2de48493          	addi	s1,s1,734 # 80022440 <log>
    8000416a:	8526                	mv	a0,s1
    8000416c:	e5dfd0ef          	jal	80001fc8 <sleep_prepare>
      release(&log.lock);
    80004170:	8526                	mv	a0,s1
    80004172:	b91fc0ef          	jal	80000d02 <release>
      sleep();
    80004176:	e8ffd0ef          	jal	80002004 <sleep>
      acquire(&log.lock);
    8000417a:	8526                	mv	a0,s1
    8000417c:	afbfc0ef          	jal	80000c76 <acquire>
    while (log.ncommit < n) {
    80004180:	549c                	lw	a5,40(s1)
    80004182:	fef954e3          	bge	s2,a5,8000416a <sys_sync+0x3a>
    80004186:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    80004188:	0001e517          	auipc	a0,0x1e
    8000418c:	2b850513          	addi	a0,a0,696 # 80022440 <log>
    80004190:	b73fc0ef          	jal	80000d02 <release>
  return 0;
}
    80004194:	4501                	li	a0,0
    80004196:	60e2                	ld	ra,24(sp)
    80004198:	6442                	ld	s0,16(sp)
    8000419a:	64a2                	ld	s1,8(sp)
    8000419c:	6105                	addi	sp,sp,32
    8000419e:	8082                	ret

00000000800041a0 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800041a0:	1101                	addi	sp,sp,-32
    800041a2:	ec06                	sd	ra,24(sp)
    800041a4:	e822                	sd	s0,16(sp)
    800041a6:	e426                	sd	s1,8(sp)
    800041a8:	e04a                	sd	s2,0(sp)
    800041aa:	1000                	addi	s0,sp,32
    800041ac:	84aa                	mv	s1,a0
    800041ae:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800041b0:	00003597          	auipc	a1,0x3
    800041b4:	3b858593          	addi	a1,a1,952 # 80007568 <etext+0x568>
    800041b8:	0521                	addi	a0,a0,8
    800041ba:	a47fc0ef          	jal	80000c00 <initlock>
  lk->name = name;
    800041be:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800041c2:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800041c6:	0204a423          	sw	zero,40(s1)
}
    800041ca:	60e2                	ld	ra,24(sp)
    800041cc:	6442                	ld	s0,16(sp)
    800041ce:	64a2                	ld	s1,8(sp)
    800041d0:	6902                	ld	s2,0(sp)
    800041d2:	6105                	addi	sp,sp,32
    800041d4:	8082                	ret

00000000800041d6 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    800041d6:	1101                	addi	sp,sp,-32
    800041d8:	ec06                	sd	ra,24(sp)
    800041da:	e822                	sd	s0,16(sp)
    800041dc:	e426                	sd	s1,8(sp)
    800041de:	e04a                	sd	s2,0(sp)
    800041e0:	1000                	addi	s0,sp,32
    800041e2:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800041e4:	00850913          	addi	s2,a0,8
    800041e8:	854a                	mv	a0,s2
    800041ea:	a8dfc0ef          	jal	80000c76 <acquire>
  while (lk->locked) {
    800041ee:	409c                	lw	a5,0(s1)
    800041f0:	cf91                	beqz	a5,8000420c <acquiresleep+0x36>
    sleep_prepare(lk);
    800041f2:	8526                	mv	a0,s1
    800041f4:	dd5fd0ef          	jal	80001fc8 <sleep_prepare>
    release(&lk->lk);
    800041f8:	854a                	mv	a0,s2
    800041fa:	b09fc0ef          	jal	80000d02 <release>
    sleep();
    800041fe:	e07fd0ef          	jal	80002004 <sleep>
    acquire(&lk->lk);
    80004202:	854a                	mv	a0,s2
    80004204:	a73fc0ef          	jal	80000c76 <acquire>
  while (lk->locked) {
    80004208:	409c                	lw	a5,0(s1)
    8000420a:	f7e5                	bnez	a5,800041f2 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000420c:	4785                	li	a5,1
    8000420e:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004210:	fb4fd0ef          	jal	800019c4 <myproc>
    80004214:	591c                	lw	a5,48(a0)
    80004216:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004218:	854a                	mv	a0,s2
    8000421a:	ae9fc0ef          	jal	80000d02 <release>
}
    8000421e:	60e2                	ld	ra,24(sp)
    80004220:	6442                	ld	s0,16(sp)
    80004222:	64a2                	ld	s1,8(sp)
    80004224:	6902                	ld	s2,0(sp)
    80004226:	6105                	addi	sp,sp,32
    80004228:	8082                	ret

000000008000422a <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    8000422a:	1101                	addi	sp,sp,-32
    8000422c:	ec06                	sd	ra,24(sp)
    8000422e:	e822                	sd	s0,16(sp)
    80004230:	e426                	sd	s1,8(sp)
    80004232:	e04a                	sd	s2,0(sp)
    80004234:	1000                	addi	s0,sp,32
    80004236:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004238:	00850913          	addi	s2,a0,8
    8000423c:	854a                	mv	a0,s2
    8000423e:	a39fc0ef          	jal	80000c76 <acquire>
  lk->locked = 0;
    80004242:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004246:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000424a:	8526                	mv	a0,s1
    8000424c:	de9fd0ef          	jal	80002034 <wakeup>
  release(&lk->lk);
    80004250:	854a                	mv	a0,s2
    80004252:	ab1fc0ef          	jal	80000d02 <release>
}
    80004256:	60e2                	ld	ra,24(sp)
    80004258:	6442                	ld	s0,16(sp)
    8000425a:	64a2                	ld	s1,8(sp)
    8000425c:	6902                	ld	s2,0(sp)
    8000425e:	6105                	addi	sp,sp,32
    80004260:	8082                	ret

0000000080004262 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80004262:	7179                	addi	sp,sp,-48
    80004264:	f406                	sd	ra,40(sp)
    80004266:	f022                	sd	s0,32(sp)
    80004268:	ec26                	sd	s1,24(sp)
    8000426a:	e84a                	sd	s2,16(sp)
    8000426c:	1800                	addi	s0,sp,48
    8000426e:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    80004270:	00850913          	addi	s2,a0,8
    80004274:	854a                	mv	a0,s2
    80004276:	a01fc0ef          	jal	80000c76 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000427a:	409c                	lw	a5,0(s1)
    8000427c:	ef81                	bnez	a5,80004294 <holdingsleep+0x32>
    8000427e:	4481                	li	s1,0
  release(&lk->lk);
    80004280:	854a                	mv	a0,s2
    80004282:	a81fc0ef          	jal	80000d02 <release>
  return r;
}
    80004286:	8526                	mv	a0,s1
    80004288:	70a2                	ld	ra,40(sp)
    8000428a:	7402                	ld	s0,32(sp)
    8000428c:	64e2                	ld	s1,24(sp)
    8000428e:	6942                	ld	s2,16(sp)
    80004290:	6145                	addi	sp,sp,48
    80004292:	8082                	ret
    80004294:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80004296:	0284a983          	lw	s3,40(s1)
    8000429a:	f2afd0ef          	jal	800019c4 <myproc>
    8000429e:	5904                	lw	s1,48(a0)
    800042a0:	413484b3          	sub	s1,s1,s3
    800042a4:	0014b493          	seqz	s1,s1
    800042a8:	69a2                	ld	s3,8(sp)
    800042aa:	bfd9                	j	80004280 <holdingsleep+0x1e>

00000000800042ac <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800042ac:	1141                	addi	sp,sp,-16
    800042ae:	e406                	sd	ra,8(sp)
    800042b0:	e022                	sd	s0,0(sp)
    800042b2:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800042b4:	00003597          	auipc	a1,0x3
    800042b8:	2c458593          	addi	a1,a1,708 # 80007578 <etext+0x578>
    800042bc:	0001e517          	auipc	a0,0x1e
    800042c0:	2cc50513          	addi	a0,a0,716 # 80022588 <ftable>
    800042c4:	93dfc0ef          	jal	80000c00 <initlock>
}
    800042c8:	60a2                	ld	ra,8(sp)
    800042ca:	6402                	ld	s0,0(sp)
    800042cc:	0141                	addi	sp,sp,16
    800042ce:	8082                	ret

00000000800042d0 <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    800042d0:	1101                	addi	sp,sp,-32
    800042d2:	ec06                	sd	ra,24(sp)
    800042d4:	e822                	sd	s0,16(sp)
    800042d6:	e426                	sd	s1,8(sp)
    800042d8:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800042da:	0001e517          	auipc	a0,0x1e
    800042de:	2ae50513          	addi	a0,a0,686 # 80022588 <ftable>
    800042e2:	995fc0ef          	jal	80000c76 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800042e6:	0001e497          	auipc	s1,0x1e
    800042ea:	2ba48493          	addi	s1,s1,698 # 800225a0 <ftable+0x18>
    800042ee:	0001f717          	auipc	a4,0x1f
    800042f2:	25270713          	addi	a4,a4,594 # 80023540 <disk>
    if (f->ref == 0) {
    800042f6:	40dc                	lw	a5,4(s1)
    800042f8:	cf89                	beqz	a5,80004312 <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    800042fa:	02848493          	addi	s1,s1,40
    800042fe:	fee49ce3          	bne	s1,a4,800042f6 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004302:	0001e517          	auipc	a0,0x1e
    80004306:	28650513          	addi	a0,a0,646 # 80022588 <ftable>
    8000430a:	9f9fc0ef          	jal	80000d02 <release>
  return 0;
    8000430e:	4481                	li	s1,0
    80004310:	a809                	j	80004322 <filealloc+0x52>
      f->ref = 1;
    80004312:	4785                	li	a5,1
    80004314:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004316:	0001e517          	auipc	a0,0x1e
    8000431a:	27250513          	addi	a0,a0,626 # 80022588 <ftable>
    8000431e:	9e5fc0ef          	jal	80000d02 <release>
}
    80004322:	8526                	mv	a0,s1
    80004324:	60e2                	ld	ra,24(sp)
    80004326:	6442                	ld	s0,16(sp)
    80004328:	64a2                	ld	s1,8(sp)
    8000432a:	6105                	addi	sp,sp,32
    8000432c:	8082                	ret

000000008000432e <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    8000432e:	1101                	addi	sp,sp,-32
    80004330:	ec06                	sd	ra,24(sp)
    80004332:	e822                	sd	s0,16(sp)
    80004334:	e426                	sd	s1,8(sp)
    80004336:	1000                	addi	s0,sp,32
    80004338:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000433a:	0001e517          	auipc	a0,0x1e
    8000433e:	24e50513          	addi	a0,a0,590 # 80022588 <ftable>
    80004342:	935fc0ef          	jal	80000c76 <acquire>
  if (f->ref < 1)
    80004346:	40dc                	lw	a5,4(s1)
    80004348:	02f05063          	blez	a5,80004368 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000434c:	2785                	addiw	a5,a5,1
    8000434e:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004350:	0001e517          	auipc	a0,0x1e
    80004354:	23850513          	addi	a0,a0,568 # 80022588 <ftable>
    80004358:	9abfc0ef          	jal	80000d02 <release>
  return f;
}
    8000435c:	8526                	mv	a0,s1
    8000435e:	60e2                	ld	ra,24(sp)
    80004360:	6442                	ld	s0,16(sp)
    80004362:	64a2                	ld	s1,8(sp)
    80004364:	6105                	addi	sp,sp,32
    80004366:	8082                	ret
    panic("filedup");
    80004368:	00003517          	auipc	a0,0x3
    8000436c:	21850513          	addi	a0,a0,536 # 80007580 <etext+0x580>
    80004370:	c80fc0ef          	jal	800007f0 <panic>

0000000080004374 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004374:	7139                	addi	sp,sp,-64
    80004376:	fc06                	sd	ra,56(sp)
    80004378:	f822                	sd	s0,48(sp)
    8000437a:	f426                	sd	s1,40(sp)
    8000437c:	0080                	addi	s0,sp,64
    8000437e:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004380:	0001e517          	auipc	a0,0x1e
    80004384:	20850513          	addi	a0,a0,520 # 80022588 <ftable>
    80004388:	8effc0ef          	jal	80000c76 <acquire>
  if (f->ref < 1)
    8000438c:	40dc                	lw	a5,4(s1)
    8000438e:	04f05a63          	blez	a5,800043e2 <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    80004392:	37fd                	addiw	a5,a5,-1
    80004394:	0007871b          	sext.w	a4,a5
    80004398:	c0dc                	sw	a5,4(s1)
    8000439a:	04e04e63          	bgtz	a4,800043f6 <fileclose+0x82>
    8000439e:	f04a                	sd	s2,32(sp)
    800043a0:	ec4e                	sd	s3,24(sp)
    800043a2:	e852                	sd	s4,16(sp)
    800043a4:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800043a6:	0004a903          	lw	s2,0(s1)
    800043aa:	0094ca83          	lbu	s5,9(s1)
    800043ae:	0104ba03          	ld	s4,16(s1)
    800043b2:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    800043b6:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800043ba:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800043be:	0001e517          	auipc	a0,0x1e
    800043c2:	1ca50513          	addi	a0,a0,458 # 80022588 <ftable>
    800043c6:	93dfc0ef          	jal	80000d02 <release>

  if (ff.type == FD_PIPE) {
    800043ca:	4785                	li	a5,1
    800043cc:	04f90063          	beq	s2,a5,8000440c <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    800043d0:	3979                	addiw	s2,s2,-2
    800043d2:	4785                	li	a5,1
    800043d4:	0527f563          	bgeu	a5,s2,8000441e <fileclose+0xaa>
    800043d8:	7902                	ld	s2,32(sp)
    800043da:	69e2                	ld	s3,24(sp)
    800043dc:	6a42                	ld	s4,16(sp)
    800043de:	6aa2                	ld	s5,8(sp)
    800043e0:	a00d                	j	80004402 <fileclose+0x8e>
    800043e2:	f04a                	sd	s2,32(sp)
    800043e4:	ec4e                	sd	s3,24(sp)
    800043e6:	e852                	sd	s4,16(sp)
    800043e8:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800043ea:	00003517          	auipc	a0,0x3
    800043ee:	19e50513          	addi	a0,a0,414 # 80007588 <etext+0x588>
    800043f2:	bfefc0ef          	jal	800007f0 <panic>
    release(&ftable.lock);
    800043f6:	0001e517          	auipc	a0,0x1e
    800043fa:	19250513          	addi	a0,a0,402 # 80022588 <ftable>
    800043fe:	905fc0ef          	jal	80000d02 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80004402:	70e2                	ld	ra,56(sp)
    80004404:	7442                	ld	s0,48(sp)
    80004406:	74a2                	ld	s1,40(sp)
    80004408:	6121                	addi	sp,sp,64
    8000440a:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    8000440c:	85d6                	mv	a1,s5
    8000440e:	8552                	mv	a0,s4
    80004410:	358000ef          	jal	80004768 <pipeclose>
    80004414:	7902                	ld	s2,32(sp)
    80004416:	69e2                	ld	s3,24(sp)
    80004418:	6a42                	ld	s4,16(sp)
    8000441a:	6aa2                	ld	s5,8(sp)
    8000441c:	b7dd                	j	80004402 <fileclose+0x8e>
    begin_op();
    8000441e:	aabff0ef          	jal	80003ec8 <begin_op>
    iput(ff.ip);
    80004422:	854e                	mv	a0,s3
    80004424:	9dcff0ef          	jal	80003600 <iput>
    end_op();
    80004428:	b27ff0ef          	jal	80003f4e <end_op>
    8000442c:	7902                	ld	s2,32(sp)
    8000442e:	69e2                	ld	s3,24(sp)
    80004430:	6a42                	ld	s4,16(sp)
    80004432:	6aa2                	ld	s5,8(sp)
    80004434:	b7f9                	j	80004402 <fileclose+0x8e>

0000000080004436 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004436:	715d                	addi	sp,sp,-80
    80004438:	e486                	sd	ra,72(sp)
    8000443a:	e0a2                	sd	s0,64(sp)
    8000443c:	fc26                	sd	s1,56(sp)
    8000443e:	f44e                	sd	s3,40(sp)
    80004440:	0880                	addi	s0,sp,80
    80004442:	84aa                	mv	s1,a0
    80004444:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    80004446:	d7efd0ef          	jal	800019c4 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    8000444a:	409c                	lw	a5,0(s1)
    8000444c:	37f9                	addiw	a5,a5,-2
    8000444e:	4705                	li	a4,1
    80004450:	04f76863          	bltu	a4,a5,800044a0 <filestat+0x6a>
    80004454:	f84a                	sd	s2,48(sp)
    80004456:	892a                	mv	s2,a0
    memset(&st, 0, sizeof(st));
    80004458:	4661                	li	a2,24
    8000445a:	4581                	li	a1,0
    8000445c:	fb840513          	addi	a0,s0,-72
    80004460:	8dbfc0ef          	jal	80000d3a <memset>
    ilock(f->ip);
    80004464:	6c88                	ld	a0,24(s1)
    80004466:	818ff0ef          	jal	8000347e <ilock>
    stati(f->ip, &st);
    8000446a:	fb840593          	addi	a1,s0,-72
    8000446e:	6c88                	ld	a0,24(s1)
    80004470:	bbcff0ef          	jal	8000382c <stati>
    iunlock(f->ip);
    80004474:	6c88                	ld	a0,24(s1)
    80004476:	8b6ff0ef          	jal	8000352c <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    8000447a:	4761                	li	a4,24
    8000447c:	fb840693          	addi	a3,s0,-72
    80004480:	864e                	mv	a2,s3
    80004482:	04893583          	ld	a1,72(s2)
    80004486:	05093503          	ld	a0,80(s2)
    8000448a:	934fd0ef          	jal	800015be <copyout>
    8000448e:	41f5551b          	sraiw	a0,a0,0x1f
    80004492:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004494:	60a6                	ld	ra,72(sp)
    80004496:	6406                	ld	s0,64(sp)
    80004498:	74e2                	ld	s1,56(sp)
    8000449a:	79a2                	ld	s3,40(sp)
    8000449c:	6161                	addi	sp,sp,80
    8000449e:	8082                	ret
  return -1;
    800044a0:	557d                	li	a0,-1
    800044a2:	bfcd                	j	80004494 <filestat+0x5e>

00000000800044a4 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800044a4:	7179                	addi	sp,sp,-48
    800044a6:	f406                	sd	ra,40(sp)
    800044a8:	f022                	sd	s0,32(sp)
    800044aa:	e84a                	sd	s2,16(sp)
    800044ac:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0 || n < 0)
    800044ae:	00854783          	lbu	a5,8(a0)
    800044b2:	c3c5                	beqz	a5,80004552 <fileread+0xae>
    800044b4:	ec26                	sd	s1,24(sp)
    800044b6:	e44e                	sd	s3,8(sp)
    800044b8:	84aa                	mv	s1,a0
    800044ba:	89ae                	mv	s3,a1
    800044bc:	8932                	mv	s2,a2
    800044be:	08064c63          	bltz	a2,80004556 <fileread+0xb2>
    return -1;

  if (f->type == FD_PIPE) {
    800044c2:	411c                	lw	a5,0(a0)
    800044c4:	4705                	li	a4,1
    800044c6:	04e78363          	beq	a5,a4,8000450c <fileread+0x68>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    800044ca:	470d                	li	a4,3
    800044cc:	04e78763          	beq	a5,a4,8000451a <fileread+0x76>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    800044d0:	4709                	li	a4,2
    800044d2:	06e79a63          	bne	a5,a4,80004546 <fileread+0xa2>
    ilock(f->ip);
    800044d6:	6d08                	ld	a0,24(a0)
    800044d8:	fa7fe0ef          	jal	8000347e <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800044dc:	874a                	mv	a4,s2
    800044de:	5094                	lw	a3,32(s1)
    800044e0:	864e                	mv	a2,s3
    800044e2:	4585                	li	a1,1
    800044e4:	6c88                	ld	a0,24(s1)
    800044e6:	b70ff0ef          	jal	80003856 <readi>
    800044ea:	892a                	mv	s2,a0
    800044ec:	00a05563          	blez	a0,800044f6 <fileread+0x52>
      f->off += r;
    800044f0:	509c                	lw	a5,32(s1)
    800044f2:	9fa9                	addw	a5,a5,a0
    800044f4:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800044f6:	6c88                	ld	a0,24(s1)
    800044f8:	834ff0ef          	jal	8000352c <iunlock>
    800044fc:	64e2                	ld	s1,24(sp)
    800044fe:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004500:	854a                	mv	a0,s2
    80004502:	70a2                	ld	ra,40(sp)
    80004504:	7402                	ld	s0,32(sp)
    80004506:	6942                	ld	s2,16(sp)
    80004508:	6145                	addi	sp,sp,48
    8000450a:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000450c:	6908                	ld	a0,16(a0)
    8000450e:	3b6000ef          	jal	800048c4 <piperead>
    80004512:	892a                	mv	s2,a0
    80004514:	64e2                	ld	s1,24(sp)
    80004516:	69a2                	ld	s3,8(sp)
    80004518:	b7e5                	j	80004500 <fileread+0x5c>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000451a:	02451783          	lh	a5,36(a0)
    8000451e:	03079693          	slli	a3,a5,0x30
    80004522:	92c1                	srli	a3,a3,0x30
    80004524:	4725                	li	a4,9
    80004526:	02d76c63          	bltu	a4,a3,8000455e <fileread+0xba>
    8000452a:	0792                	slli	a5,a5,0x4
    8000452c:	0001e717          	auipc	a4,0x1e
    80004530:	fbc70713          	addi	a4,a4,-68 # 800224e8 <devsw>
    80004534:	97ba                	add	a5,a5,a4
    80004536:	639c                	ld	a5,0(a5)
    80004538:	c79d                	beqz	a5,80004566 <fileread+0xc2>
    r = devsw[f->major].read(1, addr, n);
    8000453a:	4505                	li	a0,1
    8000453c:	9782                	jalr	a5
    8000453e:	892a                	mv	s2,a0
    80004540:	64e2                	ld	s1,24(sp)
    80004542:	69a2                	ld	s3,8(sp)
    80004544:	bf75                	j	80004500 <fileread+0x5c>
    panic("fileread");
    80004546:	00003517          	auipc	a0,0x3
    8000454a:	05250513          	addi	a0,a0,82 # 80007598 <etext+0x598>
    8000454e:	aa2fc0ef          	jal	800007f0 <panic>
    return -1;
    80004552:	597d                	li	s2,-1
    80004554:	b775                	j	80004500 <fileread+0x5c>
    80004556:	597d                	li	s2,-1
    80004558:	64e2                	ld	s1,24(sp)
    8000455a:	69a2                	ld	s3,8(sp)
    8000455c:	b755                	j	80004500 <fileread+0x5c>
      return -1;
    8000455e:	597d                	li	s2,-1
    80004560:	64e2                	ld	s1,24(sp)
    80004562:	69a2                	ld	s3,8(sp)
    80004564:	bf71                	j	80004500 <fileread+0x5c>
    80004566:	597d                	li	s2,-1
    80004568:	64e2                	ld	s1,24(sp)
    8000456a:	69a2                	ld	s3,8(sp)
    8000456c:	bf51                	j	80004500 <fileread+0x5c>

000000008000456e <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0 || n < 0)
    8000456e:	00954783          	lbu	a5,9(a0)
    80004572:	10078663          	beqz	a5,8000467e <filewrite+0x110>
{
    80004576:	715d                	addi	sp,sp,-80
    80004578:	e486                	sd	ra,72(sp)
    8000457a:	e0a2                	sd	s0,64(sp)
    8000457c:	f84a                	sd	s2,48(sp)
    8000457e:	f052                	sd	s4,32(sp)
    80004580:	e85a                	sd	s6,16(sp)
    80004582:	0880                	addi	s0,sp,80
    80004584:	892a                	mv	s2,a0
    80004586:	8b2e                	mv	s6,a1
    80004588:	8a32                	mv	s4,a2
  if (f->writable == 0 || n < 0)
    8000458a:	0e064c63          	bltz	a2,80004682 <filewrite+0x114>
    return -1;

  if (f->type == FD_PIPE) {
    8000458e:	411c                	lw	a5,0(a0)
    80004590:	4705                	li	a4,1
    80004592:	02e78763          	beq	a5,a4,800045c0 <filewrite+0x52>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004596:	470d                	li	a4,3
    80004598:	02e78863          	beq	a5,a4,800045c8 <filewrite+0x5a>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    8000459c:	4709                	li	a4,2
    8000459e:	0ce79563          	bne	a5,a4,80004668 <filewrite+0xfa>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    800045a2:	0ec05663          	blez	a2,8000468e <filewrite+0x120>
    800045a6:	fc26                	sd	s1,56(sp)
    800045a8:	f44e                	sd	s3,40(sp)
    800045aa:	ec56                	sd	s5,24(sp)
    800045ac:	e45e                	sd	s7,8(sp)
    800045ae:	e062                	sd	s8,0(sp)
    int i = 0;
    800045b0:	4981                	li	s3,0
      int n1 = n - i;
      if (n1 > max)
    800045b2:	6b85                	lui	s7,0x1
    800045b4:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800045b8:	6c05                	lui	s8,0x1
    800045ba:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    800045be:	a8b5                	j	8000463a <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800045c0:	6908                	ld	a0,16(a0)
    800045c2:	1fe000ef          	jal	800047c0 <pipewrite>
    800045c6:	a851                	j	8000465a <filewrite+0xec>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800045c8:	02451783          	lh	a5,36(a0)
    800045cc:	03079693          	slli	a3,a5,0x30
    800045d0:	92c1                	srli	a3,a3,0x30
    800045d2:	4725                	li	a4,9
    800045d4:	0ad76963          	bltu	a4,a3,80004686 <filewrite+0x118>
    800045d8:	0792                	slli	a5,a5,0x4
    800045da:	0001e717          	auipc	a4,0x1e
    800045de:	f0e70713          	addi	a4,a4,-242 # 800224e8 <devsw>
    800045e2:	97ba                	add	a5,a5,a4
    800045e4:	679c                	ld	a5,8(a5)
    800045e6:	c3d5                	beqz	a5,8000468a <filewrite+0x11c>
    ret = devsw[f->major].write(1, addr, n);
    800045e8:	4505                	li	a0,1
    800045ea:	9782                	jalr	a5
    800045ec:	a0bd                	j	8000465a <filewrite+0xec>
      if (n1 > max)
    800045ee:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    800045f2:	8d7ff0ef          	jal	80003ec8 <begin_op>
      ilock(f->ip);
    800045f6:	01893503          	ld	a0,24(s2)
    800045fa:	e85fe0ef          	jal	8000347e <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800045fe:	8756                	mv	a4,s5
    80004600:	02092683          	lw	a3,32(s2)
    80004604:	01698633          	add	a2,s3,s6
    80004608:	4585                	li	a1,1
    8000460a:	01893503          	ld	a0,24(s2)
    8000460e:	b44ff0ef          	jal	80003952 <writei>
    80004612:	84aa                	mv	s1,a0
    80004614:	00a05763          	blez	a0,80004622 <filewrite+0xb4>
        f->off += r;
    80004618:	02092783          	lw	a5,32(s2)
    8000461c:	9fa9                	addw	a5,a5,a0
    8000461e:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004622:	01893503          	ld	a0,24(s2)
    80004626:	f07fe0ef          	jal	8000352c <iunlock>
      end_op();
    8000462a:	925ff0ef          	jal	80003f4e <end_op>

      if (r != n1) {
    8000462e:	009a9e63          	bne	s5,s1,8000464a <filewrite+0xdc>
        // error from writei
        break;
      }
      i += r;
    80004632:	013489bb          	addw	s3,s1,s3
    while (i < n) {
    80004636:	0149da63          	bge	s3,s4,8000464a <filewrite+0xdc>
      int n1 = n - i;
    8000463a:	413a04bb          	subw	s1,s4,s3
      if (n1 > max)
    8000463e:	0004879b          	sext.w	a5,s1
    80004642:	fafbd6e3          	bge	s7,a5,800045ee <filewrite+0x80>
    80004646:	84e2                	mv	s1,s8
    80004648:	b75d                	j	800045ee <filewrite+0x80>
    }
    ret = (i == n ? n : -1);
    8000464a:	053a1463          	bne	s4,s3,80004692 <filewrite+0x124>
    8000464e:	8552                	mv	a0,s4
    80004650:	74e2                	ld	s1,56(sp)
    80004652:	79a2                	ld	s3,40(sp)
    80004654:	6ae2                	ld	s5,24(sp)
    80004656:	6ba2                	ld	s7,8(sp)
    80004658:	6c02                	ld	s8,0(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000465a:	60a6                	ld	ra,72(sp)
    8000465c:	6406                	ld	s0,64(sp)
    8000465e:	7942                	ld	s2,48(sp)
    80004660:	7a02                	ld	s4,32(sp)
    80004662:	6b42                	ld	s6,16(sp)
    80004664:	6161                	addi	sp,sp,80
    80004666:	8082                	ret
    80004668:	fc26                	sd	s1,56(sp)
    8000466a:	f44e                	sd	s3,40(sp)
    8000466c:	ec56                	sd	s5,24(sp)
    8000466e:	e45e                	sd	s7,8(sp)
    80004670:	e062                	sd	s8,0(sp)
    panic("filewrite");
    80004672:	00003517          	auipc	a0,0x3
    80004676:	f3650513          	addi	a0,a0,-202 # 800075a8 <etext+0x5a8>
    8000467a:	976fc0ef          	jal	800007f0 <panic>
    return -1;
    8000467e:	557d                	li	a0,-1
}
    80004680:	8082                	ret
    return -1;
    80004682:	557d                	li	a0,-1
    80004684:	bfd9                	j	8000465a <filewrite+0xec>
      return -1;
    80004686:	557d                	li	a0,-1
    80004688:	bfc9                	j	8000465a <filewrite+0xec>
    8000468a:	557d                	li	a0,-1
    8000468c:	b7f9                	j	8000465a <filewrite+0xec>
    ret = (i == n ? n : -1);
    8000468e:	8532                	mv	a0,a2
    80004690:	b7e9                	j	8000465a <filewrite+0xec>
    80004692:	557d                	li	a0,-1
    80004694:	74e2                	ld	s1,56(sp)
    80004696:	79a2                	ld	s3,40(sp)
    80004698:	6ae2                	ld	s5,24(sp)
    8000469a:	6ba2                	ld	s7,8(sp)
    8000469c:	6c02                	ld	s8,0(sp)
    8000469e:	bf75                	j	8000465a <filewrite+0xec>

00000000800046a0 <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800046a0:	7179                	addi	sp,sp,-48
    800046a2:	f406                	sd	ra,40(sp)
    800046a4:	f022                	sd	s0,32(sp)
    800046a6:	ec26                	sd	s1,24(sp)
    800046a8:	e052                	sd	s4,0(sp)
    800046aa:	1800                	addi	s0,sp,48
    800046ac:	84aa                	mv	s1,a0
    800046ae:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800046b0:	0005b023          	sd	zero,0(a1)
    800046b4:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800046b8:	c19ff0ef          	jal	800042d0 <filealloc>
    800046bc:	e088                	sd	a0,0(s1)
    800046be:	c549                	beqz	a0,80004748 <pipealloc+0xa8>
    800046c0:	c11ff0ef          	jal	800042d0 <filealloc>
    800046c4:	00aa3023          	sd	a0,0(s4)
    800046c8:	cd25                	beqz	a0,80004740 <pipealloc+0xa0>
    800046ca:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    800046cc:	cc8fc0ef          	jal	80000b94 <kalloc>
    800046d0:	892a                	mv	s2,a0
    800046d2:	c12d                	beqz	a0,80004734 <pipealloc+0x94>
    800046d4:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800046d6:	4985                	li	s3,1
    800046d8:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800046dc:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800046e0:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800046e4:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800046e8:	00003597          	auipc	a1,0x3
    800046ec:	ed058593          	addi	a1,a1,-304 # 800075b8 <etext+0x5b8>
    800046f0:	d10fc0ef          	jal	80000c00 <initlock>
  (*f0)->type = FD_PIPE;
    800046f4:	609c                	ld	a5,0(s1)
    800046f6:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800046fa:	609c                	ld	a5,0(s1)
    800046fc:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004700:	609c                	ld	a5,0(s1)
    80004702:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004706:	609c                	ld	a5,0(s1)
    80004708:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    8000470c:	000a3783          	ld	a5,0(s4)
    80004710:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004714:	000a3783          	ld	a5,0(s4)
    80004718:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    8000471c:	000a3783          	ld	a5,0(s4)
    80004720:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004724:	000a3783          	ld	a5,0(s4)
    80004728:	0127b823          	sd	s2,16(a5)
  return 0;
    8000472c:	4501                	li	a0,0
    8000472e:	6942                	ld	s2,16(sp)
    80004730:	69a2                	ld	s3,8(sp)
    80004732:	a01d                	j	80004758 <pipealloc+0xb8>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    80004734:	6088                	ld	a0,0(s1)
    80004736:	c119                	beqz	a0,8000473c <pipealloc+0x9c>
    80004738:	6942                	ld	s2,16(sp)
    8000473a:	a029                	j	80004744 <pipealloc+0xa4>
    8000473c:	6942                	ld	s2,16(sp)
    8000473e:	a029                	j	80004748 <pipealloc+0xa8>
    80004740:	6088                	ld	a0,0(s1)
    80004742:	c10d                	beqz	a0,80004764 <pipealloc+0xc4>
    fileclose(*f0);
    80004744:	c31ff0ef          	jal	80004374 <fileclose>
  if (*f1)
    80004748:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    8000474c:	557d                	li	a0,-1
  if (*f1)
    8000474e:	c789                	beqz	a5,80004758 <pipealloc+0xb8>
    fileclose(*f1);
    80004750:	853e                	mv	a0,a5
    80004752:	c23ff0ef          	jal	80004374 <fileclose>
  return -1;
    80004756:	557d                	li	a0,-1
}
    80004758:	70a2                	ld	ra,40(sp)
    8000475a:	7402                	ld	s0,32(sp)
    8000475c:	64e2                	ld	s1,24(sp)
    8000475e:	6a02                	ld	s4,0(sp)
    80004760:	6145                	addi	sp,sp,48
    80004762:	8082                	ret
  return -1;
    80004764:	557d                	li	a0,-1
    80004766:	bfcd                	j	80004758 <pipealloc+0xb8>

0000000080004768 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004768:	1101                	addi	sp,sp,-32
    8000476a:	ec06                	sd	ra,24(sp)
    8000476c:	e822                	sd	s0,16(sp)
    8000476e:	e426                	sd	s1,8(sp)
    80004770:	e04a                	sd	s2,0(sp)
    80004772:	1000                	addi	s0,sp,32
    80004774:	84aa                	mv	s1,a0
    80004776:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004778:	cfefc0ef          	jal	80000c76 <acquire>
  if (writable) {
    8000477c:	02090763          	beqz	s2,800047aa <pipeclose+0x42>
    pi->writeopen = 0;
    80004780:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004784:	21848513          	addi	a0,s1,536
    80004788:	8adfd0ef          	jal	80002034 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    8000478c:	2204b783          	ld	a5,544(s1)
    80004790:	e785                	bnez	a5,800047b8 <pipeclose+0x50>
    release(&pi->lock);
    80004792:	8526                	mv	a0,s1
    80004794:	d6efc0ef          	jal	80000d02 <release>
    kfree((char *)pi);
    80004798:	8526                	mv	a0,s1
    8000479a:	ad6fc0ef          	jal	80000a70 <kfree>
  } else
    release(&pi->lock);
}
    8000479e:	60e2                	ld	ra,24(sp)
    800047a0:	6442                	ld	s0,16(sp)
    800047a2:	64a2                	ld	s1,8(sp)
    800047a4:	6902                	ld	s2,0(sp)
    800047a6:	6105                	addi	sp,sp,32
    800047a8:	8082                	ret
    pi->readopen = 0;
    800047aa:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800047ae:	21c48513          	addi	a0,s1,540
    800047b2:	883fd0ef          	jal	80002034 <wakeup>
    800047b6:	bfd9                	j	8000478c <pipeclose+0x24>
    release(&pi->lock);
    800047b8:	8526                	mv	a0,s1
    800047ba:	d48fc0ef          	jal	80000d02 <release>
}
    800047be:	b7c5                	j	8000479e <pipeclose+0x36>

00000000800047c0 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800047c0:	711d                	addi	sp,sp,-96
    800047c2:	ec86                	sd	ra,88(sp)
    800047c4:	e8a2                	sd	s0,80(sp)
    800047c6:	e4a6                	sd	s1,72(sp)
    800047c8:	e0ca                	sd	s2,64(sp)
    800047ca:	fc4e                	sd	s3,56(sp)
    800047cc:	f852                	sd	s4,48(sp)
    800047ce:	f456                	sd	s5,40(sp)
    800047d0:	1080                	addi	s0,sp,96
    800047d2:	84aa                	mv	s1,a0
    800047d4:	8aae                	mv	s5,a1
    800047d6:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800047d8:	9ecfd0ef          	jal	800019c4 <myproc>
    800047dc:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800047de:	8526                	mv	a0,s1
    800047e0:	c96fc0ef          	jal	80000c76 <acquire>
  while (i < n) {
    800047e4:	0d405e63          	blez	s4,800048c0 <pipewrite+0x100>
    800047e8:	f05a                	sd	s6,32(sp)
    800047ea:	ec5e                	sd	s7,24(sp)
    800047ec:	e862                	sd	s8,16(sp)
  int i = 0;
    800047ee:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    800047f0:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800047f2:	21848c13          	addi	s8,s1,536
      sleep_prepare(&pi->nwrite);
    800047f6:	21c48b93          	addi	s7,s1,540
    800047fa:	a091                	j	8000483e <pipewrite+0x7e>
      release(&pi->lock);
    800047fc:	8526                	mv	a0,s1
    800047fe:	d04fc0ef          	jal	80000d02 <release>
      return -1;
    80004802:	597d                	li	s2,-1
    80004804:	7b02                	ld	s6,32(sp)
    80004806:	6be2                	ld	s7,24(sp)
    80004808:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000480a:	854a                	mv	a0,s2
    8000480c:	60e6                	ld	ra,88(sp)
    8000480e:	6446                	ld	s0,80(sp)
    80004810:	64a6                	ld	s1,72(sp)
    80004812:	6906                	ld	s2,64(sp)
    80004814:	79e2                	ld	s3,56(sp)
    80004816:	7a42                	ld	s4,48(sp)
    80004818:	7aa2                	ld	s5,40(sp)
    8000481a:	6125                	addi	sp,sp,96
    8000481c:	8082                	ret
      wakeup(&pi->nread);
    8000481e:	8562                	mv	a0,s8
    80004820:	815fd0ef          	jal	80002034 <wakeup>
      sleep_prepare(&pi->nwrite);
    80004824:	855e                	mv	a0,s7
    80004826:	fa2fd0ef          	jal	80001fc8 <sleep_prepare>
      release(&pi->lock);
    8000482a:	8526                	mv	a0,s1
    8000482c:	cd6fc0ef          	jal	80000d02 <release>
      sleep();
    80004830:	fd4fd0ef          	jal	80002004 <sleep>
      acquire(&pi->lock);
    80004834:	8526                	mv	a0,s1
    80004836:	c40fc0ef          	jal	80000c76 <acquire>
  while (i < n) {
    8000483a:	07495863          	bge	s2,s4,800048aa <pipewrite+0xea>
    if (pi->readopen == 0 || killed(pr)) {
    8000483e:	2204a783          	lw	a5,544(s1)
    80004842:	dfcd                	beqz	a5,800047fc <pipewrite+0x3c>
    80004844:	854e                	mv	a0,s3
    80004846:	9ddfd0ef          	jal	80002222 <killed>
    8000484a:	f94d                	bnez	a0,800047fc <pipewrite+0x3c>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    8000484c:	2184a783          	lw	a5,536(s1)
    80004850:	21c4a703          	lw	a4,540(s1)
    80004854:	2007879b          	addiw	a5,a5,512
    80004858:	fcf703e3          	beq	a4,a5,8000481e <pipewrite+0x5e>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    8000485c:	4705                	li	a4,1
    8000485e:	015906b3          	add	a3,s2,s5
    80004862:	faf40613          	addi	a2,s0,-81
    80004866:	0489b583          	ld	a1,72(s3)
    8000486a:	0509b503          	ld	a0,80(s3)
    8000486e:	e3dfc0ef          	jal	800016aa <copyin>
    80004872:	03650163          	beq	a0,s6,80004894 <pipewrite+0xd4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004876:	21c4a783          	lw	a5,540(s1)
    8000487a:	0017871b          	addiw	a4,a5,1
    8000487e:	20e4ae23          	sw	a4,540(s1)
    80004882:	1ff7f793          	andi	a5,a5,511
    80004886:	97a6                	add	a5,a5,s1
    80004888:	faf44703          	lbu	a4,-81(s0)
    8000488c:	00e78c23          	sb	a4,24(a5)
      i++;
    80004890:	2905                	addiw	s2,s2,1
    80004892:	b765                	j	8000483a <pipewrite+0x7a>
        if (i == 0)
    80004894:	00090663          	beqz	s2,800048a0 <pipewrite+0xe0>
    80004898:	7b02                	ld	s6,32(sp)
    8000489a:	6be2                	ld	s7,24(sp)
    8000489c:	6c42                	ld	s8,16(sp)
    8000489e:	a809                	j	800048b0 <pipewrite+0xf0>
          i = -1;
    800048a0:	892a                	mv	s2,a0
        break;
    800048a2:	7b02                	ld	s6,32(sp)
    800048a4:	6be2                	ld	s7,24(sp)
    800048a6:	6c42                	ld	s8,16(sp)
    800048a8:	a021                	j	800048b0 <pipewrite+0xf0>
    800048aa:	7b02                	ld	s6,32(sp)
    800048ac:	6be2                	ld	s7,24(sp)
    800048ae:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    800048b0:	21848513          	addi	a0,s1,536
    800048b4:	f80fd0ef          	jal	80002034 <wakeup>
  release(&pi->lock);
    800048b8:	8526                	mv	a0,s1
    800048ba:	c48fc0ef          	jal	80000d02 <release>
  return i;
    800048be:	b7b1                	j	8000480a <pipewrite+0x4a>
  int i = 0;
    800048c0:	4901                	li	s2,0
    800048c2:	b7fd                	j	800048b0 <pipewrite+0xf0>

00000000800048c4 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800048c4:	715d                	addi	sp,sp,-80
    800048c6:	e486                	sd	ra,72(sp)
    800048c8:	e0a2                	sd	s0,64(sp)
    800048ca:	fc26                	sd	s1,56(sp)
    800048cc:	f84a                	sd	s2,48(sp)
    800048ce:	f44e                	sd	s3,40(sp)
    800048d0:	f052                	sd	s4,32(sp)
    800048d2:	ec56                	sd	s5,24(sp)
    800048d4:	e85a                	sd	s6,16(sp)
    800048d6:	0880                	addi	s0,sp,80
    800048d8:	84aa                	mv	s1,a0
    800048da:	8a2e                	mv	s4,a1
    800048dc:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800048de:	8e6fd0ef          	jal	800019c4 <myproc>
    800048e2:	89aa                	mv	s3,a0
  char ch;

  acquire(&pi->lock);
    800048e4:	8526                	mv	a0,s1
    800048e6:	b90fc0ef          	jal	80000c76 <acquire>
  while (n > 0 && pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    800048ea:	21848b13          	addi	s6,s1,536
  while (n > 0 && pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    800048ee:	4901                	li	s2,0
    800048f0:	09505663          	blez	s5,8000497c <piperead+0xb8>
    800048f4:	2184a703          	lw	a4,536(s1)
    800048f8:	21c4a783          	lw	a5,540(s1)
    800048fc:	02f71b63          	bne	a4,a5,80004932 <piperead+0x6e>
    80004900:	2244a903          	lw	s2,548(s1)
    80004904:	02090863          	beqz	s2,80004934 <piperead+0x70>
    if (killed(pr)) {
    80004908:	854e                	mv	a0,s3
    8000490a:	919fd0ef          	jal	80002222 <killed>
    8000490e:	ed09                	bnez	a0,80004928 <piperead+0x64>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004910:	855a                	mv	a0,s6
    80004912:	eb6fd0ef          	jal	80001fc8 <sleep_prepare>
    release(&pi->lock);
    80004916:	8526                	mv	a0,s1
    80004918:	beafc0ef          	jal	80000d02 <release>
    sleep();
    8000491c:	ee8fd0ef          	jal	80002004 <sleep>
    acquire(&pi->lock);
    80004920:	8526                	mv	a0,s1
    80004922:	b54fc0ef          	jal	80000c76 <acquire>
  while (n > 0 && pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004926:	b7f9                	j	800048f4 <piperead+0x30>
      release(&pi->lock);
    80004928:	8526                	mv	a0,s1
    8000492a:	bd8fc0ef          	jal	80000d02 <release>
      return -1;
    8000492e:	597d                	li	s2,-1
    80004930:	a8a9                	j	8000498a <piperead+0xc6>
    80004932:	4901                	li	s2,0
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004934:	5b7d                	li	s6,-1
    if (pi->nread == pi->nwrite)
    80004936:	2184a783          	lw	a5,536(s1)
    8000493a:	21c4a703          	lw	a4,540(s1)
    8000493e:	02f70f63          	beq	a4,a5,8000497c <piperead+0xb8>
    ch = pi->data[pi->nread % PIPESIZE];
    80004942:	1ff7f793          	andi	a5,a5,511
    80004946:	97a6                	add	a5,a5,s1
    80004948:	0187c783          	lbu	a5,24(a5)
    8000494c:	faf40fa3          	sb	a5,-65(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004950:	4705                	li	a4,1
    80004952:	fbf40693          	addi	a3,s0,-65
    80004956:	8652                	mv	a2,s4
    80004958:	0489b583          	ld	a1,72(s3)
    8000495c:	0509b503          	ld	a0,80(s3)
    80004960:	c5ffc0ef          	jal	800015be <copyout>
    80004964:	03650e63          	beq	a0,s6,800049a0 <piperead+0xdc>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004968:	2184a783          	lw	a5,536(s1)
    8000496c:	2785                	addiw	a5,a5,1
    8000496e:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004972:	2905                	addiw	s2,s2,1
    80004974:	0a05                	addi	s4,s4,1
    80004976:	fd2a90e3          	bne	s5,s2,80004936 <piperead+0x72>
    8000497a:	8956                	mv	s2,s5
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    8000497c:	21c48513          	addi	a0,s1,540
    80004980:	eb4fd0ef          	jal	80002034 <wakeup>
  release(&pi->lock);
    80004984:	8526                	mv	a0,s1
    80004986:	b7cfc0ef          	jal	80000d02 <release>
  return i;
}
    8000498a:	854a                	mv	a0,s2
    8000498c:	60a6                	ld	ra,72(sp)
    8000498e:	6406                	ld	s0,64(sp)
    80004990:	74e2                	ld	s1,56(sp)
    80004992:	7942                	ld	s2,48(sp)
    80004994:	79a2                	ld	s3,40(sp)
    80004996:	7a02                	ld	s4,32(sp)
    80004998:	6ae2                	ld	s5,24(sp)
    8000499a:	6b42                	ld	s6,16(sp)
    8000499c:	6161                	addi	sp,sp,80
    8000499e:	8082                	ret
      if (i == 0)
    800049a0:	fc091ee3          	bnez	s2,8000497c <piperead+0xb8>
        i = -1;
    800049a4:	892a                	mv	s2,a0
    800049a6:	bfd9                	j	8000497c <piperead+0xb8>

00000000800049a8 <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    800049a8:	1141                	addi	sp,sp,-16
    800049aa:	e422                	sd	s0,8(sp)
    800049ac:	0800                	addi	s0,sp,16
    800049ae:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    800049b0:	8905                	andi	a0,a0,1
    800049b2:	050e                	slli	a0,a0,0x3
    perm = PTE_X;
  if (flags & 0x2)
    800049b4:	8b89                	andi	a5,a5,2
    800049b6:	c399                	beqz	a5,800049bc <flags2perm+0x14>
    perm |= PTE_W;
    800049b8:	00456513          	ori	a0,a0,4
  return perm;
}
    800049bc:	6422                	ld	s0,8(sp)
    800049be:	0141                	addi	sp,sp,16
    800049c0:	8082                	ret

00000000800049c2 <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800049c2:	df010113          	addi	sp,sp,-528
    800049c6:	20113423          	sd	ra,520(sp)
    800049ca:	20813023          	sd	s0,512(sp)
    800049ce:	ffa6                	sd	s1,504(sp)
    800049d0:	fbca                	sd	s2,496(sp)
    800049d2:	0c00                	addi	s0,sp,528
    800049d4:	892a                	mv	s2,a0
    800049d6:	dea43c23          	sd	a0,-520(s0)
    800049da:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800049de:	fe7fc0ef          	jal	800019c4 <myproc>
    800049e2:	84aa                	mv	s1,a0

  begin_op();
    800049e4:	ce4ff0ef          	jal	80003ec8 <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    800049e8:	854a                	mv	a0,s2
    800049ea:	b0aff0ef          	jal	80003cf4 <namei>
    800049ee:	c931                	beqz	a0,80004a42 <kexec+0x80>
    800049f0:	f3d2                	sd	s4,480(sp)
    800049f2:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    800049f4:	a8bfe0ef          	jal	8000347e <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    800049f8:	04000713          	li	a4,64
    800049fc:	4681                	li	a3,0
    800049fe:	e5040613          	addi	a2,s0,-432
    80004a02:	4581                	li	a1,0
    80004a04:	8552                	mv	a0,s4
    80004a06:	e51fe0ef          	jal	80003856 <readi>
    80004a0a:	04000793          	li	a5,64
    80004a0e:	00f51a63          	bne	a0,a5,80004a22 <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    80004a12:	e5042703          	lw	a4,-432(s0)
    80004a16:	464c47b7          	lui	a5,0x464c4
    80004a1a:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004a1e:	02f70663          	beq	a4,a5,80004a4a <kexec+0x88>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    80004a22:	8552                	mv	a0,s4
    80004a24:	cadfe0ef          	jal	800036d0 <iunlockput>
    end_op();
    80004a28:	d26ff0ef          	jal	80003f4e <end_op>
  }
  return -1;
    80004a2c:	557d                	li	a0,-1
    80004a2e:	7a1e                	ld	s4,480(sp)
}
    80004a30:	20813083          	ld	ra,520(sp)
    80004a34:	20013403          	ld	s0,512(sp)
    80004a38:	74fe                	ld	s1,504(sp)
    80004a3a:	795e                	ld	s2,496(sp)
    80004a3c:	21010113          	addi	sp,sp,528
    80004a40:	8082                	ret
    end_op();
    80004a42:	d0cff0ef          	jal	80003f4e <end_op>
    return -1;
    80004a46:	557d                	li	a0,-1
    80004a48:	b7e5                	j	80004a30 <kexec+0x6e>
    80004a4a:	ebda                	sd	s6,464(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    80004a4c:	8526                	mv	a0,s1
    80004a4e:	878fd0ef          	jal	80001ac6 <proc_pagetable>
    80004a52:	8b2a                	mv	s6,a0
    80004a54:	2c050963          	beqz	a0,80004d26 <kexec+0x364>
    80004a58:	f7ce                	sd	s3,488(sp)
    80004a5a:	efd6                	sd	s5,472(sp)
    80004a5c:	e7de                	sd	s7,456(sp)
    80004a5e:	e3e2                	sd	s8,448(sp)
    80004a60:	ff66                	sd	s9,440(sp)
    80004a62:	fb6a                	sd	s10,432(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004a64:	e7042d03          	lw	s10,-400(s0)
    80004a68:	e8845783          	lhu	a5,-376(s0)
    80004a6c:	12078863          	beqz	a5,80004b9c <kexec+0x1da>
    80004a70:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004a72:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004a74:	4d81                	li	s11,0
    if (ph.vaddr % PGSIZE != 0)
    80004a76:	6c85                	lui	s9,0x1
    80004a78:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004a7c:	def43823          	sd	a5,-528(s0)

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    80004a80:	6a85                	lui	s5,0x1
    80004a82:	a085                	j	80004ae2 <kexec+0x120>
      panic("loadseg: address should exist");
    80004a84:	00003517          	auipc	a0,0x3
    80004a88:	b3c50513          	addi	a0,a0,-1220 # 800075c0 <etext+0x5c0>
    80004a8c:	d65fb0ef          	jal	800007f0 <panic>
    if (sz - i < PGSIZE)
    80004a90:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    80004a92:	8726                	mv	a4,s1
    80004a94:	012c06bb          	addw	a3,s8,s2
    80004a98:	4581                	li	a1,0
    80004a9a:	8552                	mv	a0,s4
    80004a9c:	dbbfe0ef          	jal	80003856 <readi>
    80004aa0:	2501                	sext.w	a0,a0
    80004aa2:	24a49863          	bne	s1,a0,80004cf2 <kexec+0x330>
  for (i = 0; i < sz; i += PGSIZE) {
    80004aa6:	012a893b          	addw	s2,s5,s2
    80004aaa:	03397363          	bgeu	s2,s3,80004ad0 <kexec+0x10e>
    pa = walkaddr(pagetable, va + i);
    80004aae:	02091593          	slli	a1,s2,0x20
    80004ab2:	9181                	srli	a1,a1,0x20
    80004ab4:	95de                	add	a1,a1,s7
    80004ab6:	855a                	mv	a0,s6
    80004ab8:	d92fc0ef          	jal	8000104a <walkaddr>
    80004abc:	862a                	mv	a2,a0
    if (pa == 0)
    80004abe:	d179                	beqz	a0,80004a84 <kexec+0xc2>
    if (sz - i < PGSIZE)
    80004ac0:	412984bb          	subw	s1,s3,s2
    80004ac4:	0004879b          	sext.w	a5,s1
    80004ac8:	fcfcf4e3          	bgeu	s9,a5,80004a90 <kexec+0xce>
    80004acc:	84d6                	mv	s1,s5
    80004ace:	b7c9                	j	80004a90 <kexec+0xce>
    sz = sz1;
    80004ad0:	e0843903          	ld	s2,-504(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004ad4:	2d85                	addiw	s11,s11,1
    80004ad6:	038d0d1b          	addiw	s10,s10,56 # 1038 <_entry-0x7fffefc8>
    80004ada:	e8845783          	lhu	a5,-376(s0)
    80004ade:	08fdd063          	bge	s11,a5,80004b5e <kexec+0x19c>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004ae2:	2d01                	sext.w	s10,s10
    80004ae4:	03800713          	li	a4,56
    80004ae8:	86ea                	mv	a3,s10
    80004aea:	e1840613          	addi	a2,s0,-488
    80004aee:	4581                	li	a1,0
    80004af0:	8552                	mv	a0,s4
    80004af2:	d65fe0ef          	jal	80003856 <readi>
    80004af6:	03800793          	li	a5,56
    80004afa:	1cf51463          	bne	a0,a5,80004cc2 <kexec+0x300>
    if (ph.type != ELF_PROG_LOAD)
    80004afe:	e1842783          	lw	a5,-488(s0)
    80004b02:	4705                	li	a4,1
    80004b04:	fce798e3          	bne	a5,a4,80004ad4 <kexec+0x112>
    if (ph.memsz < ph.filesz)
    80004b08:	e4043483          	ld	s1,-448(s0)
    80004b0c:	e3843783          	ld	a5,-456(s0)
    80004b10:	1af4ed63          	bltu	s1,a5,80004cca <kexec+0x308>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    80004b14:	e2843783          	ld	a5,-472(s0)
    80004b18:	94be                	add	s1,s1,a5
    80004b1a:	1af4ec63          	bltu	s1,a5,80004cd2 <kexec+0x310>
    if (ph.vaddr % PGSIZE != 0)
    80004b1e:	df043703          	ld	a4,-528(s0)
    80004b22:	8ff9                	and	a5,a5,a4
    80004b24:	1a079b63          	bnez	a5,80004cda <kexec+0x318>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    80004b28:	e1c42503          	lw	a0,-484(s0)
    80004b2c:	e7dff0ef          	jal	800049a8 <flags2perm>
    80004b30:	86aa                	mv	a3,a0
    80004b32:	8626                	mv	a2,s1
    80004b34:	85ca                	mv	a1,s2
    80004b36:	855a                	mv	a0,s6
    80004b38:	feafc0ef          	jal	80001322 <uvmalloc>
    80004b3c:	e0a43423          	sd	a0,-504(s0)
    80004b40:	1a050163          	beqz	a0,80004ce2 <kexec+0x320>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004b44:	e2843b83          	ld	s7,-472(s0)
    80004b48:	e2042c03          	lw	s8,-480(s0)
    80004b4c:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004b50:	00098463          	beqz	s3,80004b58 <kexec+0x196>
    80004b54:	4901                	li	s2,0
    80004b56:	bfa1                	j	80004aae <kexec+0xec>
    sz = sz1;
    80004b58:	e0843903          	ld	s2,-504(s0)
    80004b5c:	bfa5                	j	80004ad4 <kexec+0x112>
    80004b5e:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004b60:	8552                	mv	a0,s4
    80004b62:	b6ffe0ef          	jal	800036d0 <iunlockput>
  end_op();
    80004b66:	be8ff0ef          	jal	80003f4e <end_op>
  p = myproc();
    80004b6a:	e5bfc0ef          	jal	800019c4 <myproc>
    80004b6e:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004b70:	04853a03          	ld	s4,72(a0)
  sz = PGROUNDUP(sz);
    80004b74:	6b85                	lui	s7,0x1
    80004b76:	1bfd                	addi	s7,s7,-1 # fff <_entry-0x7ffff001>
    80004b78:	9bca                	add	s7,s7,s2
    80004b7a:	77fd                	lui	a5,0xfffff
    80004b7c:	00fbfbb3          	and	s7,s7,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    80004b80:	4691                	li	a3,4
    80004b82:	6609                	lui	a2,0x2
    80004b84:	965e                	add	a2,a2,s7
    80004b86:	85de                	mv	a1,s7
    80004b88:	855a                	mv	a0,s6
    80004b8a:	f98fc0ef          	jal	80001322 <uvmalloc>
    80004b8e:	e0a43423          	sd	a0,-504(s0)
    80004b92:	e519                	bnez	a0,80004ba0 <kexec+0x1de>
  if (pagetable)
    80004b94:	e1743423          	sd	s7,-504(s0)
    80004b98:	4a01                	li	s4,0
    80004b9a:	aaa9                	j	80004cf4 <kexec+0x332>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004b9c:	4901                	li	s2,0
    80004b9e:	b7c9                	j	80004b60 <kexec+0x19e>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004ba0:	75f9                	lui	a1,0xffffe
    80004ba2:	8baa                	mv	s7,a0
    80004ba4:	95aa                	add	a1,a1,a0
    80004ba6:	855a                	mv	a0,s6
    80004ba8:	951fc0ef          	jal	800014f8 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004bac:	7afd                	lui	s5,0xfffff
    80004bae:	9ade                	add	s5,s5,s7
  for (argc = 0; argv[argc]; argc++) {
    80004bb0:	e0043783          	ld	a5,-512(s0)
    80004bb4:	6388                	ld	a0,0(a5)
    80004bb6:	c15d                	beqz	a0,80004c5c <kexec+0x29a>
    80004bb8:	e9040913          	addi	s2,s0,-368
    80004bbc:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004bbe:	aecfc0ef          	jal	80000eaa <strlen>
    80004bc2:	0015079b          	addiw	a5,a0,1
    80004bc6:	40fb87b3          	sub	a5,s7,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004bca:	ff07fb93          	andi	s7,a5,-16
    if (sp < stackbase)
    80004bce:	115bee63          	bltu	s7,s5,80004cea <kexec+0x328>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004bd2:	e0043c83          	ld	s9,-512(s0)
    80004bd6:	000cbc03          	ld	s8,0(s9)
    80004bda:	8562                	mv	a0,s8
    80004bdc:	acefc0ef          	jal	80000eaa <strlen>
    80004be0:	0015071b          	addiw	a4,a0,1
    80004be4:	86e2                	mv	a3,s8
    80004be6:	865e                	mv	a2,s7
    80004be8:	e0843583          	ld	a1,-504(s0)
    80004bec:	855a                	mv	a0,s6
    80004bee:	9d1fc0ef          	jal	800015be <copyout>
    80004bf2:	0e054e63          	bltz	a0,80004cee <kexec+0x32c>
    ustack[argc] = sp;
    80004bf6:	01793023          	sd	s7,0(s2)
  for (argc = 0; argv[argc]; argc++) {
    80004bfa:	0485                	addi	s1,s1,1
    80004bfc:	008c8793          	addi	a5,s9,8
    80004c00:	e0f43023          	sd	a5,-512(s0)
    80004c04:	008cb503          	ld	a0,8(s9)
    80004c08:	0921                	addi	s2,s2,8
    80004c0a:	f955                	bnez	a0,80004bbe <kexec+0x1fc>
  ustack[argc] = 0;
    80004c0c:	00349793          	slli	a5,s1,0x3
    80004c10:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffdb910>
    80004c14:	97a2                	add	a5,a5,s0
    80004c16:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004c1a:	00148713          	addi	a4,s1,1
    80004c1e:	070e                	slli	a4,a4,0x3
    80004c20:	40eb8933          	sub	s2,s7,a4
  sp -= sp % 16;
    80004c24:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004c28:	e0843583          	ld	a1,-504(s0)
    80004c2c:	8bae                	mv	s7,a1
  if (sp < stackbase)
    80004c2e:	f75963e3          	bltu	s2,s5,80004b94 <kexec+0x1d2>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004c32:	e9040693          	addi	a3,s0,-368
    80004c36:	864a                	mv	a2,s2
    80004c38:	855a                	mv	a0,s6
    80004c3a:	985fc0ef          	jal	800015be <copyout>
    80004c3e:	0e054663          	bltz	a0,80004d2a <kexec+0x368>
  p->trapframe->a1 = sp;
    80004c42:	0589b783          	ld	a5,88(s3)
    80004c46:	0727bc23          	sd	s2,120(a5)
  for (last = s = path; *s; s++)
    80004c4a:	df843783          	ld	a5,-520(s0)
    80004c4e:	0007c703          	lbu	a4,0(a5)
    80004c52:	c315                	beqz	a4,80004c76 <kexec+0x2b4>
    80004c54:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004c56:	02f00693          	li	a3,47
    80004c5a:	a809                	j	80004c6c <kexec+0x2aa>
  sp = sz;
    80004c5c:	e0843b83          	ld	s7,-504(s0)
  for (argc = 0; argv[argc]; argc++) {
    80004c60:	4481                	li	s1,0
    80004c62:	b76d                	j	80004c0c <kexec+0x24a>
  for (last = s = path; *s; s++)
    80004c64:	0785                	addi	a5,a5,1
    80004c66:	fff7c703          	lbu	a4,-1(a5)
    80004c6a:	c711                	beqz	a4,80004c76 <kexec+0x2b4>
    if (*s == '/')
    80004c6c:	fed71ce3          	bne	a4,a3,80004c64 <kexec+0x2a2>
      last = s + 1;
    80004c70:	def43c23          	sd	a5,-520(s0)
    80004c74:	bfc5                	j	80004c64 <kexec+0x2a2>
  safestrcpy(p->name, last, sizeof(p->name));
    80004c76:	4641                	li	a2,16
    80004c78:	df843583          	ld	a1,-520(s0)
    80004c7c:	15898513          	addi	a0,s3,344
    80004c80:	9f8fc0ef          	jal	80000e78 <safestrcpy>
  oldpagetable = p->pagetable;
    80004c84:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004c88:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004c8c:	e0843783          	ld	a5,-504(s0)
    80004c90:	04f9b423          	sd	a5,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004c94:	0589b783          	ld	a5,88(s3)
    80004c98:	e6843703          	ld	a4,-408(s0)
    80004c9c:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004c9e:	0589b783          	ld	a5,88(s3)
    80004ca2:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004ca6:	85d2                	mv	a1,s4
    80004ca8:	ea3fc0ef          	jal	80001b4a <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004cac:	0004851b          	sext.w	a0,s1
    80004cb0:	79be                	ld	s3,488(sp)
    80004cb2:	7a1e                	ld	s4,480(sp)
    80004cb4:	6afe                	ld	s5,472(sp)
    80004cb6:	6b5e                	ld	s6,464(sp)
    80004cb8:	6bbe                	ld	s7,456(sp)
    80004cba:	6c1e                	ld	s8,448(sp)
    80004cbc:	7cfa                	ld	s9,440(sp)
    80004cbe:	7d5a                	ld	s10,432(sp)
    80004cc0:	bb85                	j	80004a30 <kexec+0x6e>
    80004cc2:	e1243423          	sd	s2,-504(s0)
    80004cc6:	7dba                	ld	s11,424(sp)
    80004cc8:	a035                	j	80004cf4 <kexec+0x332>
    80004cca:	e1243423          	sd	s2,-504(s0)
    80004cce:	7dba                	ld	s11,424(sp)
    80004cd0:	a015                	j	80004cf4 <kexec+0x332>
    80004cd2:	e1243423          	sd	s2,-504(s0)
    80004cd6:	7dba                	ld	s11,424(sp)
    80004cd8:	a831                	j	80004cf4 <kexec+0x332>
    80004cda:	e1243423          	sd	s2,-504(s0)
    80004cde:	7dba                	ld	s11,424(sp)
    80004ce0:	a811                	j	80004cf4 <kexec+0x332>
    80004ce2:	e1243423          	sd	s2,-504(s0)
    80004ce6:	7dba                	ld	s11,424(sp)
    80004ce8:	a031                	j	80004cf4 <kexec+0x332>
  ip = 0;
    80004cea:	4a01                	li	s4,0
    80004cec:	a021                	j	80004cf4 <kexec+0x332>
    80004cee:	4a01                	li	s4,0
  if (pagetable)
    80004cf0:	a011                	j	80004cf4 <kexec+0x332>
    80004cf2:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    80004cf4:	e0843583          	ld	a1,-504(s0)
    80004cf8:	855a                	mv	a0,s6
    80004cfa:	e51fc0ef          	jal	80001b4a <proc_freepagetable>
  return -1;
    80004cfe:	557d                	li	a0,-1
  if (ip) {
    80004d00:	000a1b63          	bnez	s4,80004d16 <kexec+0x354>
    80004d04:	79be                	ld	s3,488(sp)
    80004d06:	7a1e                	ld	s4,480(sp)
    80004d08:	6afe                	ld	s5,472(sp)
    80004d0a:	6b5e                	ld	s6,464(sp)
    80004d0c:	6bbe                	ld	s7,456(sp)
    80004d0e:	6c1e                	ld	s8,448(sp)
    80004d10:	7cfa                	ld	s9,440(sp)
    80004d12:	7d5a                	ld	s10,432(sp)
    80004d14:	bb31                	j	80004a30 <kexec+0x6e>
    80004d16:	79be                	ld	s3,488(sp)
    80004d18:	6afe                	ld	s5,472(sp)
    80004d1a:	6b5e                	ld	s6,464(sp)
    80004d1c:	6bbe                	ld	s7,456(sp)
    80004d1e:	6c1e                	ld	s8,448(sp)
    80004d20:	7cfa                	ld	s9,440(sp)
    80004d22:	7d5a                	ld	s10,432(sp)
    80004d24:	b9fd                	j	80004a22 <kexec+0x60>
    80004d26:	6b5e                	ld	s6,464(sp)
    80004d28:	b9ed                	j	80004a22 <kexec+0x60>
  sz = sz1;
    80004d2a:	e0843b83          	ld	s7,-504(s0)
    80004d2e:	b59d                	j	80004b94 <kexec+0x1d2>

0000000080004d30 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004d30:	7179                	addi	sp,sp,-48
    80004d32:	f406                	sd	ra,40(sp)
    80004d34:	f022                	sd	s0,32(sp)
    80004d36:	ec26                	sd	s1,24(sp)
    80004d38:	e84a                	sd	s2,16(sp)
    80004d3a:	1800                	addi	s0,sp,48
    80004d3c:	892e                	mv	s2,a1
    80004d3e:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004d40:	fdc40593          	addi	a1,s0,-36
    80004d44:	bbbfd0ef          	jal	800028fe <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80004d48:	fdc42703          	lw	a4,-36(s0)
    80004d4c:	47bd                	li	a5,15
    80004d4e:	02e7e963          	bltu	a5,a4,80004d80 <argfd+0x50>
    80004d52:	c73fc0ef          	jal	800019c4 <myproc>
    80004d56:	fdc42703          	lw	a4,-36(s0)
    80004d5a:	01a70793          	addi	a5,a4,26
    80004d5e:	078e                	slli	a5,a5,0x3
    80004d60:	953e                	add	a0,a0,a5
    80004d62:	611c                	ld	a5,0(a0)
    80004d64:	c385                	beqz	a5,80004d84 <argfd+0x54>
    return -1;
  if (pfd)
    80004d66:	00090463          	beqz	s2,80004d6e <argfd+0x3e>
    *pfd = fd;
    80004d6a:	00e92023          	sw	a4,0(s2)
  if (pf)
    *pf = f;
  return 0;
    80004d6e:	4501                	li	a0,0
  if (pf)
    80004d70:	c091                	beqz	s1,80004d74 <argfd+0x44>
    *pf = f;
    80004d72:	e09c                	sd	a5,0(s1)
}
    80004d74:	70a2                	ld	ra,40(sp)
    80004d76:	7402                	ld	s0,32(sp)
    80004d78:	64e2                	ld	s1,24(sp)
    80004d7a:	6942                	ld	s2,16(sp)
    80004d7c:	6145                	addi	sp,sp,48
    80004d7e:	8082                	ret
    return -1;
    80004d80:	557d                	li	a0,-1
    80004d82:	bfcd                	j	80004d74 <argfd+0x44>
    80004d84:	557d                	li	a0,-1
    80004d86:	b7fd                	j	80004d74 <argfd+0x44>

0000000080004d88 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004d88:	1101                	addi	sp,sp,-32
    80004d8a:	ec06                	sd	ra,24(sp)
    80004d8c:	e822                	sd	s0,16(sp)
    80004d8e:	e426                	sd	s1,8(sp)
    80004d90:	1000                	addi	s0,sp,32
    80004d92:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004d94:	c31fc0ef          	jal	800019c4 <myproc>
    80004d98:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    80004d9a:	0d050793          	addi	a5,a0,208
    80004d9e:	4501                	li	a0,0
    80004da0:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    80004da2:	6398                	ld	a4,0(a5)
    80004da4:	cb19                	beqz	a4,80004dba <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    80004da6:	2505                	addiw	a0,a0,1
    80004da8:	07a1                	addi	a5,a5,8
    80004daa:	fed51ce3          	bne	a0,a3,80004da2 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004dae:	557d                	li	a0,-1
}
    80004db0:	60e2                	ld	ra,24(sp)
    80004db2:	6442                	ld	s0,16(sp)
    80004db4:	64a2                	ld	s1,8(sp)
    80004db6:	6105                	addi	sp,sp,32
    80004db8:	8082                	ret
      p->ofile[fd] = f;
    80004dba:	01a50793          	addi	a5,a0,26
    80004dbe:	078e                	slli	a5,a5,0x3
    80004dc0:	963e                	add	a2,a2,a5
    80004dc2:	e204                	sd	s1,0(a2)
      return fd;
    80004dc4:	b7f5                	j	80004db0 <fdalloc+0x28>

0000000080004dc6 <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80004dc6:	715d                	addi	sp,sp,-80
    80004dc8:	e486                	sd	ra,72(sp)
    80004dca:	e0a2                	sd	s0,64(sp)
    80004dcc:	fc26                	sd	s1,56(sp)
    80004dce:	f84a                	sd	s2,48(sp)
    80004dd0:	f44e                	sd	s3,40(sp)
    80004dd2:	f052                	sd	s4,32(sp)
    80004dd4:	ec56                	sd	s5,24(sp)
    80004dd6:	0880                	addi	s0,sp,80
    80004dd8:	892e                	mv	s2,a1
    80004dda:	89b2                	mv	s3,a2
    80004ddc:	8a36                	mv	s4,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80004dde:	fb040593          	addi	a1,s0,-80
    80004de2:	f2dfe0ef          	jal	80003d0e <nameiparent>
    80004de6:	8aaa                	mv	s5,a0
    80004de8:	cd45                	beqz	a0,80004ea0 <create+0xda>
    return 0;

  ilock(dp);
    80004dea:	e94fe0ef          	jal	8000347e <ilock>

  if (dp->nlink == 0) {
    80004dee:	04aa9783          	lh	a5,74(s5) # fffffffffffff04a <end+0xffffffff7ffdb9ca>
    80004df2:	cf8d                	beqz	a5,80004e2c <create+0x66>
    iunlockput(dp);
    return 0;
  }

  // a new directory's ".." would push dp->nlink past its maximum
  if (type == T_DIR && dp->nlink >= NLINK_MAX) {
    80004df4:	4705                	li	a4,1
    80004df6:	04e91563          	bne	s2,a4,80004e40 <create+0x7a>
    80004dfa:	6721                	lui	a4,0x8
    80004dfc:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80004dfe:	02e78c63          	beq	a5,a4,80004e36 <create+0x70>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004e02:	4601                	li	a2,0
    80004e04:	fb040593          	addi	a1,s0,-80
    80004e08:	8556                	mv	a0,s5
    80004e0a:	c73fe0ef          	jal	80003a7c <dirlookup>
    80004e0e:	84aa                	mv	s1,a0
    80004e10:	e951                	bnez	a0,80004ea4 <create+0xde>
      return ip;
    iunlockput(ip);
    return 0;
  }

  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004e12:	85ca                	mv	a1,s2
    80004e14:	000aa503          	lw	a0,0(s5)
    80004e18:	cf6fe0ef          	jal	8000330e <ialloc>
    80004e1c:	84aa                	mv	s1,a0
    80004e1e:	0c051e63          	bnez	a0,80004efa <create+0x134>
    iunlockput(dp);
    80004e22:	8556                	mv	a0,s5
    80004e24:	8adfe0ef          	jal	800036d0 <iunlockput>
    return 0;
    80004e28:	4481                	li	s1,0
    80004e2a:	a0a1                	j	80004e72 <create+0xac>
    iunlockput(dp);
    80004e2c:	8556                	mv	a0,s5
    80004e2e:	8a3fe0ef          	jal	800036d0 <iunlockput>
    return 0;
    80004e32:	4481                	li	s1,0
    80004e34:	a83d                	j	80004e72 <create+0xac>
    iunlockput(dp);
    80004e36:	8556                	mv	a0,s5
    80004e38:	899fe0ef          	jal	800036d0 <iunlockput>
    return 0;
    80004e3c:	4481                	li	s1,0
    80004e3e:	a815                	j	80004e72 <create+0xac>
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004e40:	4601                	li	a2,0
    80004e42:	fb040593          	addi	a1,s0,-80
    80004e46:	8556                	mv	a0,s5
    80004e48:	c35fe0ef          	jal	80003a7c <dirlookup>
    80004e4c:	84aa                	mv	s1,a0
    80004e4e:	c535                	beqz	a0,80004eba <create+0xf4>
    iunlockput(dp);
    80004e50:	8556                	mv	a0,s5
    80004e52:	87ffe0ef          	jal	800036d0 <iunlockput>
    ilock(ip);
    80004e56:	8526                	mv	a0,s1
    80004e58:	e26fe0ef          	jal	8000347e <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004e5c:	4789                	li	a5,2
    80004e5e:	04f91963          	bne	s2,a5,80004eb0 <create+0xea>
    80004e62:	0444d783          	lhu	a5,68(s1)
    80004e66:	37f9                	addiw	a5,a5,-2
    80004e68:	17c2                	slli	a5,a5,0x30
    80004e6a:	93c1                	srli	a5,a5,0x30
    80004e6c:	4705                	li	a4,1
    80004e6e:	04f76163          	bltu	a4,a5,80004eb0 <create+0xea>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004e72:	8526                	mv	a0,s1
    80004e74:	60a6                	ld	ra,72(sp)
    80004e76:	6406                	ld	s0,64(sp)
    80004e78:	74e2                	ld	s1,56(sp)
    80004e7a:	7942                	ld	s2,48(sp)
    80004e7c:	79a2                	ld	s3,40(sp)
    80004e7e:	7a02                	ld	s4,32(sp)
    80004e80:	6ae2                	ld	s5,24(sp)
    80004e82:	6161                	addi	sp,sp,80
    80004e84:	8082                	ret
  ip->nlink = 0;
    80004e86:	04049523          	sh	zero,74(s1)
  iupdate(ip);
    80004e8a:	8526                	mv	a0,s1
    80004e8c:	d3efe0ef          	jal	800033ca <iupdate>
  iunlockput(ip);
    80004e90:	8526                	mv	a0,s1
    80004e92:	83ffe0ef          	jal	800036d0 <iunlockput>
  iunlockput(dp);
    80004e96:	8556                	mv	a0,s5
    80004e98:	839fe0ef          	jal	800036d0 <iunlockput>
  return 0;
    80004e9c:	4481                	li	s1,0
    80004e9e:	bfd1                	j	80004e72 <create+0xac>
    return 0;
    80004ea0:	84aa                	mv	s1,a0
    80004ea2:	bfc1                	j	80004e72 <create+0xac>
    iunlockput(dp);
    80004ea4:	8556                	mv	a0,s5
    80004ea6:	82bfe0ef          	jal	800036d0 <iunlockput>
    ilock(ip);
    80004eaa:	8526                	mv	a0,s1
    80004eac:	dd2fe0ef          	jal	8000347e <ilock>
    iunlockput(ip);
    80004eb0:	8526                	mv	a0,s1
    80004eb2:	81ffe0ef          	jal	800036d0 <iunlockput>
    return 0;
    80004eb6:	4481                	li	s1,0
    80004eb8:	bf6d                	j	80004e72 <create+0xac>
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80004eba:	85ca                	mv	a1,s2
    80004ebc:	000aa503          	lw	a0,0(s5)
    80004ec0:	c4efe0ef          	jal	8000330e <ialloc>
    80004ec4:	84aa                	mv	s1,a0
    80004ec6:	dd31                	beqz	a0,80004e22 <create+0x5c>
  ilock(ip);
    80004ec8:	8526                	mv	a0,s1
    80004eca:	db4fe0ef          	jal	8000347e <ilock>
  ip->major = major;
    80004ece:	05349323          	sh	s3,70(s1)
  ip->minor = minor;
    80004ed2:	05449423          	sh	s4,72(s1)
  ip->nlink = 1;
    80004ed6:	4785                	li	a5,1
    80004ed8:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004edc:	8526                	mv	a0,s1
    80004ede:	cecfe0ef          	jal	800033ca <iupdate>
  if (dirlink(dp, name, ip->inum) < 0)
    80004ee2:	40d0                	lw	a2,4(s1)
    80004ee4:	fb040593          	addi	a1,s0,-80
    80004ee8:	8556                	mv	a0,s5
    80004eea:	d71fe0ef          	jal	80003c5a <dirlink>
    80004eee:	f8054ce3          	bltz	a0,80004e86 <create+0xc0>
  iunlockput(dp);
    80004ef2:	8556                	mv	a0,s5
    80004ef4:	fdcfe0ef          	jal	800036d0 <iunlockput>
  return ip;
    80004ef8:	bfad                	j	80004e72 <create+0xac>
  ilock(ip);
    80004efa:	8526                	mv	a0,s1
    80004efc:	d82fe0ef          	jal	8000347e <ilock>
  ip->major = major;
    80004f00:	05349323          	sh	s3,70(s1)
  ip->minor = minor;
    80004f04:	05449423          	sh	s4,72(s1)
  ip->nlink = 1;
    80004f08:	4785                	li	a5,1
    80004f0a:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004f0e:	8526                	mv	a0,s1
    80004f10:	cbafe0ef          	jal	800033ca <iupdate>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004f14:	40d0                	lw	a2,4(s1)
    80004f16:	00002597          	auipc	a1,0x2
    80004f1a:	6d258593          	addi	a1,a1,1746 # 800075e8 <etext+0x5e8>
    80004f1e:	8526                	mv	a0,s1
    80004f20:	d3bfe0ef          	jal	80003c5a <dirlink>
    80004f24:	f60541e3          	bltz	a0,80004e86 <create+0xc0>
    80004f28:	004aa603          	lw	a2,4(s5)
    80004f2c:	00002597          	auipc	a1,0x2
    80004f30:	6b458593          	addi	a1,a1,1716 # 800075e0 <etext+0x5e0>
    80004f34:	8526                	mv	a0,s1
    80004f36:	d25fe0ef          	jal	80003c5a <dirlink>
    80004f3a:	f40546e3          	bltz	a0,80004e86 <create+0xc0>
  if (dirlink(dp, name, ip->inum) < 0)
    80004f3e:	40d0                	lw	a2,4(s1)
    80004f40:	fb040593          	addi	a1,s0,-80
    80004f44:	8556                	mv	a0,s5
    80004f46:	d15fe0ef          	jal	80003c5a <dirlink>
    80004f4a:	f2054ee3          	bltz	a0,80004e86 <create+0xc0>
    dp->nlink++; // for ".."
    80004f4e:	04aad783          	lhu	a5,74(s5)
    80004f52:	2785                	addiw	a5,a5,1
    80004f54:	04fa9523          	sh	a5,74(s5)
    iupdate(dp);
    80004f58:	8556                	mv	a0,s5
    80004f5a:	c70fe0ef          	jal	800033ca <iupdate>
    80004f5e:	bf51                	j	80004ef2 <create+0x12c>

0000000080004f60 <sys_dup>:
{
    80004f60:	7179                	addi	sp,sp,-48
    80004f62:	f406                	sd	ra,40(sp)
    80004f64:	f022                	sd	s0,32(sp)
    80004f66:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80004f68:	fd840613          	addi	a2,s0,-40
    80004f6c:	4581                	li	a1,0
    80004f6e:	4501                	li	a0,0
    80004f70:	dc1ff0ef          	jal	80004d30 <argfd>
    return -1;
    80004f74:	57fd                	li	a5,-1
  if (argfd(0, 0, &f) < 0)
    80004f76:	02054363          	bltz	a0,80004f9c <sys_dup+0x3c>
    80004f7a:	ec26                	sd	s1,24(sp)
    80004f7c:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    80004f7e:	fd843903          	ld	s2,-40(s0)
    80004f82:	854a                	mv	a0,s2
    80004f84:	e05ff0ef          	jal	80004d88 <fdalloc>
    80004f88:	84aa                	mv	s1,a0
    return -1;
    80004f8a:	57fd                	li	a5,-1
  if ((fd = fdalloc(f)) < 0)
    80004f8c:	00054d63          	bltz	a0,80004fa6 <sys_dup+0x46>
  filedup(f);
    80004f90:	854a                	mv	a0,s2
    80004f92:	b9cff0ef          	jal	8000432e <filedup>
  return fd;
    80004f96:	87a6                	mv	a5,s1
    80004f98:	64e2                	ld	s1,24(sp)
    80004f9a:	6942                	ld	s2,16(sp)
}
    80004f9c:	853e                	mv	a0,a5
    80004f9e:	70a2                	ld	ra,40(sp)
    80004fa0:	7402                	ld	s0,32(sp)
    80004fa2:	6145                	addi	sp,sp,48
    80004fa4:	8082                	ret
    80004fa6:	64e2                	ld	s1,24(sp)
    80004fa8:	6942                	ld	s2,16(sp)
    80004faa:	bfcd                	j	80004f9c <sys_dup+0x3c>

0000000080004fac <sys_read>:
{
    80004fac:	7179                	addi	sp,sp,-48
    80004fae:	f406                	sd	ra,40(sp)
    80004fb0:	f022                	sd	s0,32(sp)
    80004fb2:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004fb4:	fd840593          	addi	a1,s0,-40
    80004fb8:	4505                	li	a0,1
    80004fba:	961fd0ef          	jal	8000291a <argaddr>
  argint(2, &n);
    80004fbe:	fe440593          	addi	a1,s0,-28
    80004fc2:	4509                	li	a0,2
    80004fc4:	93bfd0ef          	jal	800028fe <argint>
  if (argfd(0, 0, &f) < 0)
    80004fc8:	fe840613          	addi	a2,s0,-24
    80004fcc:	4581                	li	a1,0
    80004fce:	4501                	li	a0,0
    80004fd0:	d61ff0ef          	jal	80004d30 <argfd>
    80004fd4:	87aa                	mv	a5,a0
    return -1;
    80004fd6:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80004fd8:	0007ca63          	bltz	a5,80004fec <sys_read+0x40>
  return fileread(f, p, n);
    80004fdc:	fe442603          	lw	a2,-28(s0)
    80004fe0:	fd843583          	ld	a1,-40(s0)
    80004fe4:	fe843503          	ld	a0,-24(s0)
    80004fe8:	cbcff0ef          	jal	800044a4 <fileread>
}
    80004fec:	70a2                	ld	ra,40(sp)
    80004fee:	7402                	ld	s0,32(sp)
    80004ff0:	6145                	addi	sp,sp,48
    80004ff2:	8082                	ret

0000000080004ff4 <sys_write>:
{
    80004ff4:	7179                	addi	sp,sp,-48
    80004ff6:	f406                	sd	ra,40(sp)
    80004ff8:	f022                	sd	s0,32(sp)
    80004ffa:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004ffc:	fd840593          	addi	a1,s0,-40
    80005000:	4505                	li	a0,1
    80005002:	919fd0ef          	jal	8000291a <argaddr>
  argint(2, &n);
    80005006:	fe440593          	addi	a1,s0,-28
    8000500a:	4509                	li	a0,2
    8000500c:	8f3fd0ef          	jal	800028fe <argint>
  if (argfd(0, 0, &f) < 0)
    80005010:	fe840613          	addi	a2,s0,-24
    80005014:	4581                	li	a1,0
    80005016:	4501                	li	a0,0
    80005018:	d19ff0ef          	jal	80004d30 <argfd>
    8000501c:	87aa                	mv	a5,a0
    return -1;
    8000501e:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80005020:	0007ca63          	bltz	a5,80005034 <sys_write+0x40>
  return filewrite(f, p, n);
    80005024:	fe442603          	lw	a2,-28(s0)
    80005028:	fd843583          	ld	a1,-40(s0)
    8000502c:	fe843503          	ld	a0,-24(s0)
    80005030:	d3eff0ef          	jal	8000456e <filewrite>
}
    80005034:	70a2                	ld	ra,40(sp)
    80005036:	7402                	ld	s0,32(sp)
    80005038:	6145                	addi	sp,sp,48
    8000503a:	8082                	ret

000000008000503c <sys_close>:
{
    8000503c:	1101                	addi	sp,sp,-32
    8000503e:	ec06                	sd	ra,24(sp)
    80005040:	e822                	sd	s0,16(sp)
    80005042:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80005044:	fe040613          	addi	a2,s0,-32
    80005048:	fec40593          	addi	a1,s0,-20
    8000504c:	4501                	li	a0,0
    8000504e:	ce3ff0ef          	jal	80004d30 <argfd>
    return -1;
    80005052:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80005054:	02054063          	bltz	a0,80005074 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80005058:	96dfc0ef          	jal	800019c4 <myproc>
    8000505c:	fec42783          	lw	a5,-20(s0)
    80005060:	07e9                	addi	a5,a5,26
    80005062:	078e                	slli	a5,a5,0x3
    80005064:	953e                	add	a0,a0,a5
    80005066:	00053023          	sd	zero,0(a0)
  fileclose(f);
    8000506a:	fe043503          	ld	a0,-32(s0)
    8000506e:	b06ff0ef          	jal	80004374 <fileclose>
  return 0;
    80005072:	4781                	li	a5,0
}
    80005074:	853e                	mv	a0,a5
    80005076:	60e2                	ld	ra,24(sp)
    80005078:	6442                	ld	s0,16(sp)
    8000507a:	6105                	addi	sp,sp,32
    8000507c:	8082                	ret

000000008000507e <sys_fstat>:
{
    8000507e:	1101                	addi	sp,sp,-32
    80005080:	ec06                	sd	ra,24(sp)
    80005082:	e822                	sd	s0,16(sp)
    80005084:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80005086:	fe040593          	addi	a1,s0,-32
    8000508a:	4505                	li	a0,1
    8000508c:	88ffd0ef          	jal	8000291a <argaddr>
  if (argfd(0, 0, &f) < 0)
    80005090:	fe840613          	addi	a2,s0,-24
    80005094:	4581                	li	a1,0
    80005096:	4501                	li	a0,0
    80005098:	c99ff0ef          	jal	80004d30 <argfd>
    8000509c:	87aa                	mv	a5,a0
    return -1;
    8000509e:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    800050a0:	0007c863          	bltz	a5,800050b0 <sys_fstat+0x32>
  return filestat(f, st);
    800050a4:	fe043583          	ld	a1,-32(s0)
    800050a8:	fe843503          	ld	a0,-24(s0)
    800050ac:	b8aff0ef          	jal	80004436 <filestat>
}
    800050b0:	60e2                	ld	ra,24(sp)
    800050b2:	6442                	ld	s0,16(sp)
    800050b4:	6105                	addi	sp,sp,32
    800050b6:	8082                	ret

00000000800050b8 <sys_link>:
{
    800050b8:	7169                	addi	sp,sp,-304
    800050ba:	f606                	sd	ra,296(sp)
    800050bc:	f222                	sd	s0,288(sp)
    800050be:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800050c0:	08000613          	li	a2,128
    800050c4:	ed040593          	addi	a1,s0,-304
    800050c8:	4501                	li	a0,0
    800050ca:	86dfd0ef          	jal	80002936 <argstr>
    return -1;
    800050ce:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800050d0:	10054163          	bltz	a0,800051d2 <sys_link+0x11a>
    800050d4:	08000613          	li	a2,128
    800050d8:	f5040593          	addi	a1,s0,-176
    800050dc:	4505                	li	a0,1
    800050de:	859fd0ef          	jal	80002936 <argstr>
    return -1;
    800050e2:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800050e4:	0e054763          	bltz	a0,800051d2 <sys_link+0x11a>
    800050e8:	ee26                	sd	s1,280(sp)
  begin_op();
    800050ea:	ddffe0ef          	jal	80003ec8 <begin_op>
  if ((ip = namei(old)) == 0) {
    800050ee:	ed040513          	addi	a0,s0,-304
    800050f2:	c03fe0ef          	jal	80003cf4 <namei>
    800050f6:	84aa                	mv	s1,a0
    800050f8:	cd35                	beqz	a0,80005174 <sys_link+0xbc>
  ilock(ip);
    800050fa:	b84fe0ef          	jal	8000347e <ilock>
  if (ip->type == T_DIR) {
    800050fe:	04449703          	lh	a4,68(s1)
    80005102:	4785                	li	a5,1
    80005104:	06f70d63          	beq	a4,a5,8000517e <sys_link+0xc6>
  if (ip->nlink >= NLINK_MAX) {
    80005108:	04a49783          	lh	a5,74(s1)
    8000510c:	6721                	lui	a4,0x8
    8000510e:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80005110:	06e78f63          	beq	a5,a4,8000518e <sys_link+0xd6>
    80005114:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80005116:	2785                	addiw	a5,a5,1
    80005118:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    8000511c:	8526                	mv	a0,s1
    8000511e:	aacfe0ef          	jal	800033ca <iupdate>
  iunlock(ip);
    80005122:	8526                	mv	a0,s1
    80005124:	c08fe0ef          	jal	8000352c <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    80005128:	fd040593          	addi	a1,s0,-48
    8000512c:	f5040513          	addi	a0,s0,-176
    80005130:	bdffe0ef          	jal	80003d0e <nameiparent>
    80005134:	892a                	mv	s2,a0
    80005136:	c93d                	beqz	a0,800051ac <sys_link+0xf4>
  ilock(dp);
    80005138:	b46fe0ef          	jal	8000347e <ilock>
  if (dp->nlink == 0) {
    8000513c:	04a91783          	lh	a5,74(s2)
    80005140:	cfb9                	beqz	a5,8000519e <sys_link+0xe6>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80005142:	00092703          	lw	a4,0(s2)
    80005146:	409c                	lw	a5,0(s1)
    80005148:	04f71f63          	bne	a4,a5,800051a6 <sys_link+0xee>
    8000514c:	40d0                	lw	a2,4(s1)
    8000514e:	fd040593          	addi	a1,s0,-48
    80005152:	854a                	mv	a0,s2
    80005154:	b07fe0ef          	jal	80003c5a <dirlink>
    80005158:	04054763          	bltz	a0,800051a6 <sys_link+0xee>
  iunlockput(dp);
    8000515c:	854a                	mv	a0,s2
    8000515e:	d72fe0ef          	jal	800036d0 <iunlockput>
  iput(ip);
    80005162:	8526                	mv	a0,s1
    80005164:	c9cfe0ef          	jal	80003600 <iput>
  end_op();
    80005168:	de7fe0ef          	jal	80003f4e <end_op>
  return 0;
    8000516c:	4781                	li	a5,0
    8000516e:	64f2                	ld	s1,280(sp)
    80005170:	6952                	ld	s2,272(sp)
    80005172:	a085                	j	800051d2 <sys_link+0x11a>
    end_op();
    80005174:	ddbfe0ef          	jal	80003f4e <end_op>
    return -1;
    80005178:	57fd                	li	a5,-1
    8000517a:	64f2                	ld	s1,280(sp)
    8000517c:	a899                	j	800051d2 <sys_link+0x11a>
    iunlockput(ip);
    8000517e:	8526                	mv	a0,s1
    80005180:	d50fe0ef          	jal	800036d0 <iunlockput>
    end_op();
    80005184:	dcbfe0ef          	jal	80003f4e <end_op>
    return -1;
    80005188:	57fd                	li	a5,-1
    8000518a:	64f2                	ld	s1,280(sp)
    8000518c:	a099                	j	800051d2 <sys_link+0x11a>
    iunlockput(ip);
    8000518e:	8526                	mv	a0,s1
    80005190:	d40fe0ef          	jal	800036d0 <iunlockput>
    end_op();
    80005194:	dbbfe0ef          	jal	80003f4e <end_op>
    return -1;
    80005198:	57fd                	li	a5,-1
    8000519a:	64f2                	ld	s1,280(sp)
    8000519c:	a81d                	j	800051d2 <sys_link+0x11a>
    iunlockput(dp);
    8000519e:	854a                	mv	a0,s2
    800051a0:	d30fe0ef          	jal	800036d0 <iunlockput>
    goto bad;
    800051a4:	a021                	j	800051ac <sys_link+0xf4>
    iunlockput(dp);
    800051a6:	854a                	mv	a0,s2
    800051a8:	d28fe0ef          	jal	800036d0 <iunlockput>
  ilock(ip);
    800051ac:	8526                	mv	a0,s1
    800051ae:	ad0fe0ef          	jal	8000347e <ilock>
  ip->nlink--;
    800051b2:	04a4d783          	lhu	a5,74(s1)
    800051b6:	37fd                	addiw	a5,a5,-1
    800051b8:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800051bc:	8526                	mv	a0,s1
    800051be:	a0cfe0ef          	jal	800033ca <iupdate>
  iunlockput(ip);
    800051c2:	8526                	mv	a0,s1
    800051c4:	d0cfe0ef          	jal	800036d0 <iunlockput>
  end_op();
    800051c8:	d87fe0ef          	jal	80003f4e <end_op>
  return -1;
    800051cc:	57fd                	li	a5,-1
    800051ce:	64f2                	ld	s1,280(sp)
    800051d0:	6952                	ld	s2,272(sp)
}
    800051d2:	853e                	mv	a0,a5
    800051d4:	70b2                	ld	ra,296(sp)
    800051d6:	7412                	ld	s0,288(sp)
    800051d8:	6155                	addi	sp,sp,304
    800051da:	8082                	ret

00000000800051dc <sys_unlink>:
{
    800051dc:	7151                	addi	sp,sp,-240
    800051de:	f586                	sd	ra,232(sp)
    800051e0:	f1a2                	sd	s0,224(sp)
    800051e2:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    800051e4:	08000613          	li	a2,128
    800051e8:	f3040593          	addi	a1,s0,-208
    800051ec:	4501                	li	a0,0
    800051ee:	f48fd0ef          	jal	80002936 <argstr>
    800051f2:	16054063          	bltz	a0,80005352 <sys_unlink+0x176>
    800051f6:	eda6                	sd	s1,216(sp)
  begin_op();
    800051f8:	cd1fe0ef          	jal	80003ec8 <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    800051fc:	fb040593          	addi	a1,s0,-80
    80005200:	f3040513          	addi	a0,s0,-208
    80005204:	b0bfe0ef          	jal	80003d0e <nameiparent>
    80005208:	84aa                	mv	s1,a0
    8000520a:	c945                	beqz	a0,800052ba <sys_unlink+0xde>
  ilock(dp);
    8000520c:	a72fe0ef          	jal	8000347e <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005210:	00002597          	auipc	a1,0x2
    80005214:	3d858593          	addi	a1,a1,984 # 800075e8 <etext+0x5e8>
    80005218:	fb040513          	addi	a0,s0,-80
    8000521c:	84bfe0ef          	jal	80003a66 <namecmp>
    80005220:	10050e63          	beqz	a0,8000533c <sys_unlink+0x160>
    80005224:	00002597          	auipc	a1,0x2
    80005228:	3bc58593          	addi	a1,a1,956 # 800075e0 <etext+0x5e0>
    8000522c:	fb040513          	addi	a0,s0,-80
    80005230:	837fe0ef          	jal	80003a66 <namecmp>
    80005234:	10050463          	beqz	a0,8000533c <sys_unlink+0x160>
    80005238:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    8000523a:	f2c40613          	addi	a2,s0,-212
    8000523e:	fb040593          	addi	a1,s0,-80
    80005242:	8526                	mv	a0,s1
    80005244:	839fe0ef          	jal	80003a7c <dirlookup>
    80005248:	892a                	mv	s2,a0
    8000524a:	0e050863          	beqz	a0,8000533a <sys_unlink+0x15e>
  ilock(ip);
    8000524e:	a30fe0ef          	jal	8000347e <ilock>
  if (ip->nlink < 1)
    80005252:	04a91783          	lh	a5,74(s2)
    80005256:	06f05763          	blez	a5,800052c4 <sys_unlink+0xe8>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    8000525a:	04491703          	lh	a4,68(s2)
    8000525e:	4785                	li	a5,1
    80005260:	06f70963          	beq	a4,a5,800052d2 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80005264:	4641                	li	a2,16
    80005266:	4581                	li	a1,0
    80005268:	fc040513          	addi	a0,s0,-64
    8000526c:	acffb0ef          	jal	80000d3a <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005270:	4741                	li	a4,16
    80005272:	f2c42683          	lw	a3,-212(s0)
    80005276:	fc040613          	addi	a2,s0,-64
    8000527a:	4581                	li	a1,0
    8000527c:	8526                	mv	a0,s1
    8000527e:	ed4fe0ef          	jal	80003952 <writei>
    80005282:	47c1                	li	a5,16
    80005284:	08f51b63          	bne	a0,a5,8000531a <sys_unlink+0x13e>
  if (ip->type == T_DIR) {
    80005288:	04491703          	lh	a4,68(s2)
    8000528c:	4785                	li	a5,1
    8000528e:	08f70d63          	beq	a4,a5,80005328 <sys_unlink+0x14c>
  iunlockput(dp);
    80005292:	8526                	mv	a0,s1
    80005294:	c3cfe0ef          	jal	800036d0 <iunlockput>
  ip->nlink--;
    80005298:	04a95783          	lhu	a5,74(s2)
    8000529c:	37fd                	addiw	a5,a5,-1
    8000529e:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800052a2:	854a                	mv	a0,s2
    800052a4:	926fe0ef          	jal	800033ca <iupdate>
  iunlockput(ip);
    800052a8:	854a                	mv	a0,s2
    800052aa:	c26fe0ef          	jal	800036d0 <iunlockput>
  end_op();
    800052ae:	ca1fe0ef          	jal	80003f4e <end_op>
  return 0;
    800052b2:	4501                	li	a0,0
    800052b4:	64ee                	ld	s1,216(sp)
    800052b6:	694e                	ld	s2,208(sp)
    800052b8:	a849                	j	8000534a <sys_unlink+0x16e>
    end_op();
    800052ba:	c95fe0ef          	jal	80003f4e <end_op>
    return -1;
    800052be:	557d                	li	a0,-1
    800052c0:	64ee                	ld	s1,216(sp)
    800052c2:	a061                	j	8000534a <sys_unlink+0x16e>
    800052c4:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    800052c6:	00002517          	auipc	a0,0x2
    800052ca:	32a50513          	addi	a0,a0,810 # 800075f0 <etext+0x5f0>
    800052ce:	d22fb0ef          	jal	800007f0 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800052d2:	04c92703          	lw	a4,76(s2)
    800052d6:	02000793          	li	a5,32
    800052da:	f8e7f5e3          	bgeu	a5,a4,80005264 <sys_unlink+0x88>
    800052de:	e5ce                	sd	s3,200(sp)
    800052e0:	02000993          	li	s3,32
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800052e4:	4741                	li	a4,16
    800052e6:	86ce                	mv	a3,s3
    800052e8:	f1840613          	addi	a2,s0,-232
    800052ec:	4581                	li	a1,0
    800052ee:	854a                	mv	a0,s2
    800052f0:	d66fe0ef          	jal	80003856 <readi>
    800052f4:	47c1                	li	a5,16
    800052f6:	00f51c63          	bne	a0,a5,8000530e <sys_unlink+0x132>
    if (de.inum != 0)
    800052fa:	f1845783          	lhu	a5,-232(s0)
    800052fe:	efa1                	bnez	a5,80005356 <sys_unlink+0x17a>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80005300:	29c1                	addiw	s3,s3,16
    80005302:	04c92783          	lw	a5,76(s2)
    80005306:	fcf9efe3          	bltu	s3,a5,800052e4 <sys_unlink+0x108>
    8000530a:	69ae                	ld	s3,200(sp)
    8000530c:	bfa1                	j	80005264 <sys_unlink+0x88>
      panic("isdirempty: readi");
    8000530e:	00002517          	auipc	a0,0x2
    80005312:	2fa50513          	addi	a0,a0,762 # 80007608 <etext+0x608>
    80005316:	cdafb0ef          	jal	800007f0 <panic>
    8000531a:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    8000531c:	00002517          	auipc	a0,0x2
    80005320:	30450513          	addi	a0,a0,772 # 80007620 <etext+0x620>
    80005324:	cccfb0ef          	jal	800007f0 <panic>
    dp->nlink--;
    80005328:	04a4d783          	lhu	a5,74(s1)
    8000532c:	37fd                	addiw	a5,a5,-1
    8000532e:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005332:	8526                	mv	a0,s1
    80005334:	896fe0ef          	jal	800033ca <iupdate>
    80005338:	bfa9                	j	80005292 <sys_unlink+0xb6>
    8000533a:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    8000533c:	8526                	mv	a0,s1
    8000533e:	b92fe0ef          	jal	800036d0 <iunlockput>
  end_op();
    80005342:	c0dfe0ef          	jal	80003f4e <end_op>
  return -1;
    80005346:	557d                	li	a0,-1
    80005348:	64ee                	ld	s1,216(sp)
}
    8000534a:	70ae                	ld	ra,232(sp)
    8000534c:	740e                	ld	s0,224(sp)
    8000534e:	616d                	addi	sp,sp,240
    80005350:	8082                	ret
    return -1;
    80005352:	557d                	li	a0,-1
    80005354:	bfdd                	j	8000534a <sys_unlink+0x16e>
    iunlockput(ip);
    80005356:	854a                	mv	a0,s2
    80005358:	b78fe0ef          	jal	800036d0 <iunlockput>
    goto bad;
    8000535c:	694e                	ld	s2,208(sp)
    8000535e:	69ae                	ld	s3,200(sp)
    80005360:	bff1                	j	8000533c <sys_unlink+0x160>

0000000080005362 <sys_open>:

uint64
sys_open(void)
{
    80005362:	7131                	addi	sp,sp,-192
    80005364:	fd06                	sd	ra,184(sp)
    80005366:	f922                	sd	s0,176(sp)
    80005368:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    8000536a:	f4c40593          	addi	a1,s0,-180
    8000536e:	4505                	li	a0,1
    80005370:	d8efd0ef          	jal	800028fe <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005374:	08000613          	li	a2,128
    80005378:	f5040593          	addi	a1,s0,-176
    8000537c:	4501                	li	a0,0
    8000537e:	db8fd0ef          	jal	80002936 <argstr>
    80005382:	87aa                	mv	a5,a0
    return -1;
    80005384:	557d                	li	a0,-1
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005386:	0a07c263          	bltz	a5,8000542a <sys_open+0xc8>
    8000538a:	f526                	sd	s1,168(sp)

  begin_op();
    8000538c:	b3dfe0ef          	jal	80003ec8 <begin_op>

  if (omode & O_CREATE) {
    80005390:	f4c42783          	lw	a5,-180(s0)
    80005394:	2007f793          	andi	a5,a5,512
    80005398:	c3d5                	beqz	a5,8000543c <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    8000539a:	4681                	li	a3,0
    8000539c:	4601                	li	a2,0
    8000539e:	4589                	li	a1,2
    800053a0:	f5040513          	addi	a0,s0,-176
    800053a4:	a23ff0ef          	jal	80004dc6 <create>
    800053a8:	84aa                	mv	s1,a0
    if (ip == 0) {
    800053aa:	c541                	beqz	a0,80005432 <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    800053ac:	04449703          	lh	a4,68(s1)
    800053b0:	478d                	li	a5,3
    800053b2:	00f71763          	bne	a4,a5,800053c0 <sys_open+0x5e>
    800053b6:	0464d703          	lhu	a4,70(s1)
    800053ba:	47a5                	li	a5,9
    800053bc:	0ae7ed63          	bltu	a5,a4,80005476 <sys_open+0x114>
    800053c0:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    800053c2:	f0ffe0ef          	jal	800042d0 <filealloc>
    800053c6:	892a                	mv	s2,a0
    800053c8:	c179                	beqz	a0,8000548e <sys_open+0x12c>
    800053ca:	ed4e                	sd	s3,152(sp)
    800053cc:	9bdff0ef          	jal	80004d88 <fdalloc>
    800053d0:	89aa                	mv	s3,a0
    800053d2:	0a054a63          	bltz	a0,80005486 <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    800053d6:	04449703          	lh	a4,68(s1)
    800053da:	478d                	li	a5,3
    800053dc:	0cf70263          	beq	a4,a5,800054a0 <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    800053e0:	4789                	li	a5,2
    800053e2:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800053e6:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800053ea:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    800053ee:	f4c42783          	lw	a5,-180(s0)
    800053f2:	0017c713          	xori	a4,a5,1
    800053f6:	8b05                	andi	a4,a4,1
    800053f8:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800053fc:	0037f713          	andi	a4,a5,3
    80005400:	00e03733          	snez	a4,a4
    80005404:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    80005408:	4007f793          	andi	a5,a5,1024
    8000540c:	c791                	beqz	a5,80005418 <sys_open+0xb6>
    8000540e:	04449703          	lh	a4,68(s1)
    80005412:	4789                	li	a5,2
    80005414:	08f70d63          	beq	a4,a5,800054ae <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    80005418:	8526                	mv	a0,s1
    8000541a:	912fe0ef          	jal	8000352c <iunlock>
  end_op();
    8000541e:	b31fe0ef          	jal	80003f4e <end_op>

  return fd;
    80005422:	854e                	mv	a0,s3
    80005424:	74aa                	ld	s1,168(sp)
    80005426:	790a                	ld	s2,160(sp)
    80005428:	69ea                	ld	s3,152(sp)
}
    8000542a:	70ea                	ld	ra,184(sp)
    8000542c:	744a                	ld	s0,176(sp)
    8000542e:	6129                	addi	sp,sp,192
    80005430:	8082                	ret
      end_op();
    80005432:	b1dfe0ef          	jal	80003f4e <end_op>
      return -1;
    80005436:	557d                	li	a0,-1
    80005438:	74aa                	ld	s1,168(sp)
    8000543a:	bfc5                	j	8000542a <sys_open+0xc8>
    if ((ip = namei(path)) == 0) {
    8000543c:	f5040513          	addi	a0,s0,-176
    80005440:	8b5fe0ef          	jal	80003cf4 <namei>
    80005444:	84aa                	mv	s1,a0
    80005446:	c11d                	beqz	a0,8000546c <sys_open+0x10a>
    ilock(ip);
    80005448:	836fe0ef          	jal	8000347e <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    8000544c:	04449703          	lh	a4,68(s1)
    80005450:	4785                	li	a5,1
    80005452:	f4f71de3          	bne	a4,a5,800053ac <sys_open+0x4a>
    80005456:	f4c42783          	lw	a5,-180(s0)
    8000545a:	d3bd                	beqz	a5,800053c0 <sys_open+0x5e>
      iunlockput(ip);
    8000545c:	8526                	mv	a0,s1
    8000545e:	a72fe0ef          	jal	800036d0 <iunlockput>
      end_op();
    80005462:	aedfe0ef          	jal	80003f4e <end_op>
      return -1;
    80005466:	557d                	li	a0,-1
    80005468:	74aa                	ld	s1,168(sp)
    8000546a:	b7c1                	j	8000542a <sys_open+0xc8>
      end_op();
    8000546c:	ae3fe0ef          	jal	80003f4e <end_op>
      return -1;
    80005470:	557d                	li	a0,-1
    80005472:	74aa                	ld	s1,168(sp)
    80005474:	bf5d                	j	8000542a <sys_open+0xc8>
    iunlockput(ip);
    80005476:	8526                	mv	a0,s1
    80005478:	a58fe0ef          	jal	800036d0 <iunlockput>
    end_op();
    8000547c:	ad3fe0ef          	jal	80003f4e <end_op>
    return -1;
    80005480:	557d                	li	a0,-1
    80005482:	74aa                	ld	s1,168(sp)
    80005484:	b75d                	j	8000542a <sys_open+0xc8>
      fileclose(f);
    80005486:	854a                	mv	a0,s2
    80005488:	eedfe0ef          	jal	80004374 <fileclose>
    8000548c:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    8000548e:	8526                	mv	a0,s1
    80005490:	a40fe0ef          	jal	800036d0 <iunlockput>
    end_op();
    80005494:	abbfe0ef          	jal	80003f4e <end_op>
    return -1;
    80005498:	557d                	li	a0,-1
    8000549a:	74aa                	ld	s1,168(sp)
    8000549c:	790a                	ld	s2,160(sp)
    8000549e:	b771                	j	8000542a <sys_open+0xc8>
    f->type = FD_DEVICE;
    800054a0:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    800054a4:	04649783          	lh	a5,70(s1)
    800054a8:	02f91223          	sh	a5,36(s2)
    800054ac:	bf3d                	j	800053ea <sys_open+0x88>
    itrunc(ip);
    800054ae:	8526                	mv	a0,s1
    800054b0:	8bcfe0ef          	jal	8000356c <itrunc>
    800054b4:	b795                	j	80005418 <sys_open+0xb6>

00000000800054b6 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800054b6:	7175                	addi	sp,sp,-144
    800054b8:	e506                	sd	ra,136(sp)
    800054ba:	e122                	sd	s0,128(sp)
    800054bc:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800054be:	a0bfe0ef          	jal	80003ec8 <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    800054c2:	08000613          	li	a2,128
    800054c6:	f7040593          	addi	a1,s0,-144
    800054ca:	4501                	li	a0,0
    800054cc:	c6afd0ef          	jal	80002936 <argstr>
    800054d0:	02054363          	bltz	a0,800054f6 <sys_mkdir+0x40>
    800054d4:	4681                	li	a3,0
    800054d6:	4601                	li	a2,0
    800054d8:	4585                	li	a1,1
    800054da:	f7040513          	addi	a0,s0,-144
    800054de:	8e9ff0ef          	jal	80004dc6 <create>
    800054e2:	c911                	beqz	a0,800054f6 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800054e4:	9ecfe0ef          	jal	800036d0 <iunlockput>
  end_op();
    800054e8:	a67fe0ef          	jal	80003f4e <end_op>
  return 0;
    800054ec:	4501                	li	a0,0
}
    800054ee:	60aa                	ld	ra,136(sp)
    800054f0:	640a                	ld	s0,128(sp)
    800054f2:	6149                	addi	sp,sp,144
    800054f4:	8082                	ret
    end_op();
    800054f6:	a59fe0ef          	jal	80003f4e <end_op>
    return -1;
    800054fa:	557d                	li	a0,-1
    800054fc:	bfcd                	j	800054ee <sys_mkdir+0x38>

00000000800054fe <sys_mknod>:

uint64
sys_mknod(void)
{
    800054fe:	7135                	addi	sp,sp,-160
    80005500:	ed06                	sd	ra,152(sp)
    80005502:	e922                	sd	s0,144(sp)
    80005504:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005506:	9c3fe0ef          	jal	80003ec8 <begin_op>
  argint(1, &major);
    8000550a:	f6c40593          	addi	a1,s0,-148
    8000550e:	4505                	li	a0,1
    80005510:	beefd0ef          	jal	800028fe <argint>
  argint(2, &minor);
    80005514:	f6840593          	addi	a1,s0,-152
    80005518:	4509                	li	a0,2
    8000551a:	be4fd0ef          	jal	800028fe <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    8000551e:	08000613          	li	a2,128
    80005522:	f7040593          	addi	a1,s0,-144
    80005526:	4501                	li	a0,0
    80005528:	c0efd0ef          	jal	80002936 <argstr>
    8000552c:	02054563          	bltz	a0,80005556 <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    80005530:	f6841683          	lh	a3,-152(s0)
    80005534:	f6c41603          	lh	a2,-148(s0)
    80005538:	458d                	li	a1,3
    8000553a:	f7040513          	addi	a0,s0,-144
    8000553e:	889ff0ef          	jal	80004dc6 <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005542:	c911                	beqz	a0,80005556 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005544:	98cfe0ef          	jal	800036d0 <iunlockput>
  end_op();
    80005548:	a07fe0ef          	jal	80003f4e <end_op>
  return 0;
    8000554c:	4501                	li	a0,0
}
    8000554e:	60ea                	ld	ra,152(sp)
    80005550:	644a                	ld	s0,144(sp)
    80005552:	610d                	addi	sp,sp,160
    80005554:	8082                	ret
    end_op();
    80005556:	9f9fe0ef          	jal	80003f4e <end_op>
    return -1;
    8000555a:	557d                	li	a0,-1
    8000555c:	bfcd                	j	8000554e <sys_mknod+0x50>

000000008000555e <sys_chdir>:

uint64
sys_chdir(void)
{
    8000555e:	7135                	addi	sp,sp,-160
    80005560:	ed06                	sd	ra,152(sp)
    80005562:	e922                	sd	s0,144(sp)
    80005564:	e14a                	sd	s2,128(sp)
    80005566:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005568:	c5cfc0ef          	jal	800019c4 <myproc>
    8000556c:	892a                	mv	s2,a0

  begin_op();
    8000556e:	95bfe0ef          	jal	80003ec8 <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    80005572:	08000613          	li	a2,128
    80005576:	f6040593          	addi	a1,s0,-160
    8000557a:	4501                	li	a0,0
    8000557c:	bbafd0ef          	jal	80002936 <argstr>
    80005580:	04054363          	bltz	a0,800055c6 <sys_chdir+0x68>
    80005584:	e526                	sd	s1,136(sp)
    80005586:	f6040513          	addi	a0,s0,-160
    8000558a:	f6afe0ef          	jal	80003cf4 <namei>
    8000558e:	84aa                	mv	s1,a0
    80005590:	c915                	beqz	a0,800055c4 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005592:	eedfd0ef          	jal	8000347e <ilock>
  if (ip->type != T_DIR) {
    80005596:	04449703          	lh	a4,68(s1)
    8000559a:	4785                	li	a5,1
    8000559c:	02f71963          	bne	a4,a5,800055ce <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800055a0:	8526                	mv	a0,s1
    800055a2:	f8bfd0ef          	jal	8000352c <iunlock>
  iput(p->cwd);
    800055a6:	15093503          	ld	a0,336(s2)
    800055aa:	856fe0ef          	jal	80003600 <iput>
  end_op();
    800055ae:	9a1fe0ef          	jal	80003f4e <end_op>
  p->cwd = ip;
    800055b2:	14993823          	sd	s1,336(s2)
  return 0;
    800055b6:	4501                	li	a0,0
    800055b8:	64aa                	ld	s1,136(sp)
}
    800055ba:	60ea                	ld	ra,152(sp)
    800055bc:	644a                	ld	s0,144(sp)
    800055be:	690a                	ld	s2,128(sp)
    800055c0:	610d                	addi	sp,sp,160
    800055c2:	8082                	ret
    800055c4:	64aa                	ld	s1,136(sp)
    end_op();
    800055c6:	989fe0ef          	jal	80003f4e <end_op>
    return -1;
    800055ca:	557d                	li	a0,-1
    800055cc:	b7fd                	j	800055ba <sys_chdir+0x5c>
    iunlockput(ip);
    800055ce:	8526                	mv	a0,s1
    800055d0:	900fe0ef          	jal	800036d0 <iunlockput>
    end_op();
    800055d4:	97bfe0ef          	jal	80003f4e <end_op>
    return -1;
    800055d8:	557d                	li	a0,-1
    800055da:	64aa                	ld	s1,136(sp)
    800055dc:	bff9                	j	800055ba <sys_chdir+0x5c>

00000000800055de <sys_exec>:

uint64
sys_exec(void)
{
    800055de:	7121                	addi	sp,sp,-448
    800055e0:	ff06                	sd	ra,440(sp)
    800055e2:	fb22                	sd	s0,432(sp)
    800055e4:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    800055e6:	e4840593          	addi	a1,s0,-440
    800055ea:	4505                	li	a0,1
    800055ec:	b2efd0ef          	jal	8000291a <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    800055f0:	08000613          	li	a2,128
    800055f4:	f5040593          	addi	a1,s0,-176
    800055f8:	4501                	li	a0,0
    800055fa:	b3cfd0ef          	jal	80002936 <argstr>
    800055fe:	87aa                	mv	a5,a0
    return -1;
    80005600:	557d                	li	a0,-1
  if (argstr(0, path, MAXPATH) < 0) {
    80005602:	0c07c463          	bltz	a5,800056ca <sys_exec+0xec>
    80005606:	f726                	sd	s1,424(sp)
    80005608:	f34a                	sd	s2,416(sp)
    8000560a:	ef4e                	sd	s3,408(sp)
    8000560c:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    8000560e:	10000613          	li	a2,256
    80005612:	4581                	li	a1,0
    80005614:	e5040513          	addi	a0,s0,-432
    80005618:	f22fb0ef          	jal	80000d3a <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    8000561c:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    80005620:	89a6                	mv	s3,s1
    80005622:	4901                	li	s2,0
    if (i >= NELEM(argv)) {
    80005624:	02000a13          	li	s4,32
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    80005628:	00391513          	slli	a0,s2,0x3
    8000562c:	e4040593          	addi	a1,s0,-448
    80005630:	e4843783          	ld	a5,-440(s0)
    80005634:	953e                	add	a0,a0,a5
    80005636:	a3cfd0ef          	jal	80002872 <fetchaddr>
    8000563a:	02054663          	bltz	a0,80005666 <sys_exec+0x88>
      goto bad;
    }
    if (uarg == 0) {
    8000563e:	e4043783          	ld	a5,-448(s0)
    80005642:	c3a9                	beqz	a5,80005684 <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005644:	d50fb0ef          	jal	80000b94 <kalloc>
    80005648:	85aa                	mv	a1,a0
    8000564a:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    8000564e:	cd01                	beqz	a0,80005666 <sys_exec+0x88>
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005650:	6605                	lui	a2,0x1
    80005652:	e4043503          	ld	a0,-448(s0)
    80005656:	a66fd0ef          	jal	800028bc <fetchstr>
    8000565a:	00054663          	bltz	a0,80005666 <sys_exec+0x88>
    if (i >= NELEM(argv)) {
    8000565e:	0905                	addi	s2,s2,1
    80005660:	09a1                	addi	s3,s3,8
    80005662:	fd4913e3          	bne	s2,s4,80005628 <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005666:	f5040913          	addi	s2,s0,-176
    8000566a:	6088                	ld	a0,0(s1)
    8000566c:	c931                	beqz	a0,800056c0 <sys_exec+0xe2>
    kfree(argv[i]);
    8000566e:	c02fb0ef          	jal	80000a70 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005672:	04a1                	addi	s1,s1,8
    80005674:	ff249be3          	bne	s1,s2,8000566a <sys_exec+0x8c>
  return -1;
    80005678:	557d                	li	a0,-1
    8000567a:	74ba                	ld	s1,424(sp)
    8000567c:	791a                	ld	s2,416(sp)
    8000567e:	69fa                	ld	s3,408(sp)
    80005680:	6a5a                	ld	s4,400(sp)
    80005682:	a0a1                	j	800056ca <sys_exec+0xec>
      argv[i] = 0;
    80005684:	0009079b          	sext.w	a5,s2
    80005688:	078e                	slli	a5,a5,0x3
    8000568a:	fd078793          	addi	a5,a5,-48
    8000568e:	97a2                	add	a5,a5,s0
    80005690:	e807b023          	sd	zero,-384(a5)
  int ret = kexec(path, argv);
    80005694:	e5040593          	addi	a1,s0,-432
    80005698:	f5040513          	addi	a0,s0,-176
    8000569c:	b26ff0ef          	jal	800049c2 <kexec>
    800056a0:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056a2:	f5040993          	addi	s3,s0,-176
    800056a6:	6088                	ld	a0,0(s1)
    800056a8:	c511                	beqz	a0,800056b4 <sys_exec+0xd6>
    kfree(argv[i]);
    800056aa:	bc6fb0ef          	jal	80000a70 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056ae:	04a1                	addi	s1,s1,8
    800056b0:	ff349be3          	bne	s1,s3,800056a6 <sys_exec+0xc8>
  return ret;
    800056b4:	854a                	mv	a0,s2
    800056b6:	74ba                	ld	s1,424(sp)
    800056b8:	791a                	ld	s2,416(sp)
    800056ba:	69fa                	ld	s3,408(sp)
    800056bc:	6a5a                	ld	s4,400(sp)
    800056be:	a031                	j	800056ca <sys_exec+0xec>
  return -1;
    800056c0:	557d                	li	a0,-1
    800056c2:	74ba                	ld	s1,424(sp)
    800056c4:	791a                	ld	s2,416(sp)
    800056c6:	69fa                	ld	s3,408(sp)
    800056c8:	6a5a                	ld	s4,400(sp)
}
    800056ca:	70fa                	ld	ra,440(sp)
    800056cc:	745a                	ld	s0,432(sp)
    800056ce:	6139                	addi	sp,sp,448
    800056d0:	8082                	ret

00000000800056d2 <sys_pipe>:

uint64
sys_pipe(void)
{
    800056d2:	7139                	addi	sp,sp,-64
    800056d4:	fc06                	sd	ra,56(sp)
    800056d6:	f822                	sd	s0,48(sp)
    800056d8:	f426                	sd	s1,40(sp)
    800056da:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800056dc:	ae8fc0ef          	jal	800019c4 <myproc>
    800056e0:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800056e2:	fd840593          	addi	a1,s0,-40
    800056e6:	4501                	li	a0,0
    800056e8:	a32fd0ef          	jal	8000291a <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    800056ec:	fc840593          	addi	a1,s0,-56
    800056f0:	fd040513          	addi	a0,s0,-48
    800056f4:	fadfe0ef          	jal	800046a0 <pipealloc>
    return -1;
    800056f8:	57fd                	li	a5,-1
  if (pipealloc(&rf, &wf) < 0)
    800056fa:	0a054663          	bltz	a0,800057a6 <sys_pipe+0xd4>
  fd0 = -1;
    800056fe:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    80005702:	fd043503          	ld	a0,-48(s0)
    80005706:	e82ff0ef          	jal	80004d88 <fdalloc>
    8000570a:	fca42223          	sw	a0,-60(s0)
    8000570e:	08054363          	bltz	a0,80005794 <sys_pipe+0xc2>
    80005712:	fc843503          	ld	a0,-56(s0)
    80005716:	e72ff0ef          	jal	80004d88 <fdalloc>
    8000571a:	fca42023          	sw	a0,-64(s0)
    8000571e:	06054263          	bltz	a0,80005782 <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80005722:	4711                	li	a4,4
    80005724:	fc440693          	addi	a3,s0,-60
    80005728:	fd843603          	ld	a2,-40(s0)
    8000572c:	64ac                	ld	a1,72(s1)
    8000572e:	68a8                	ld	a0,80(s1)
    80005730:	e8ffb0ef          	jal	800015be <copyout>
    80005734:	00054f63          	bltz	a0,80005752 <sys_pipe+0x80>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    80005738:	4711                	li	a4,4
    8000573a:	fc040693          	addi	a3,s0,-64
    8000573e:	fd843603          	ld	a2,-40(s0)
    80005742:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005744:	64ac                	ld	a1,72(s1)
    80005746:	68a8                	ld	a0,80(s1)
    80005748:	e77fb0ef          	jal	800015be <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    8000574c:	4781                	li	a5,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    8000574e:	04055c63          	bgez	a0,800057a6 <sys_pipe+0xd4>
    p->ofile[fd0] = 0;
    80005752:	fc442783          	lw	a5,-60(s0)
    80005756:	07e9                	addi	a5,a5,26
    80005758:	078e                	slli	a5,a5,0x3
    8000575a:	97a6                	add	a5,a5,s1
    8000575c:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005760:	fc042783          	lw	a5,-64(s0)
    80005764:	07e9                	addi	a5,a5,26
    80005766:	078e                	slli	a5,a5,0x3
    80005768:	94be                	add	s1,s1,a5
    8000576a:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000576e:	fd043503          	ld	a0,-48(s0)
    80005772:	c03fe0ef          	jal	80004374 <fileclose>
    fileclose(wf);
    80005776:	fc843503          	ld	a0,-56(s0)
    8000577a:	bfbfe0ef          	jal	80004374 <fileclose>
    return -1;
    8000577e:	57fd                	li	a5,-1
    80005780:	a01d                	j	800057a6 <sys_pipe+0xd4>
    if (fd0 >= 0)
    80005782:	fc442783          	lw	a5,-60(s0)
    80005786:	0007c763          	bltz	a5,80005794 <sys_pipe+0xc2>
      p->ofile[fd0] = 0;
    8000578a:	07e9                	addi	a5,a5,26
    8000578c:	078e                	slli	a5,a5,0x3
    8000578e:	97a6                	add	a5,a5,s1
    80005790:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005794:	fd043503          	ld	a0,-48(s0)
    80005798:	bddfe0ef          	jal	80004374 <fileclose>
    fileclose(wf);
    8000579c:	fc843503          	ld	a0,-56(s0)
    800057a0:	bd5fe0ef          	jal	80004374 <fileclose>
    return -1;
    800057a4:	57fd                	li	a5,-1
}
    800057a6:	853e                	mv	a0,a5
    800057a8:	70e2                	ld	ra,56(sp)
    800057aa:	7442                	ld	s0,48(sp)
    800057ac:	74a2                	ld	s1,40(sp)
    800057ae:	6121                	addi	sp,sp,64
    800057b0:	8082                	ret
	...

00000000800057c0 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    800057c0:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    800057c2:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    800057c4:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    800057c6:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    800057c8:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    800057ca:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    800057cc:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    800057ce:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    800057d0:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    800057d2:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    800057d4:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    800057d6:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    800057d8:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    800057da:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    800057dc:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    800057de:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    800057e0:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    800057e2:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    800057e4:	f9ffc0ef          	jal	80002782 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    800057e8:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    800057ea:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    800057ec:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    800057ee:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800057f0:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800057f2:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800057f4:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800057f6:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800057f8:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800057fa:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800057fc:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    800057fe:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005800:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005802:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005804:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005806:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    80005808:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000580a:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000580c:	10200073          	sret
	...

000000008000581e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000581e:	1141                	addi	sp,sp,-16
    80005820:	e422                	sd	s0,8(sp)
    80005822:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(volatile uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    80005824:	0c0007b7          	lui	a5,0xc000
    80005828:	4705                	li	a4,1
    8000582a:	d798                	sw	a4,40(a5)
  *(volatile uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    8000582c:	0c0007b7          	lui	a5,0xc000
    80005830:	c3d8                	sw	a4,4(a5)
}
    80005832:	6422                	ld	s0,8(sp)
    80005834:	0141                	addi	sp,sp,16
    80005836:	8082                	ret

0000000080005838 <plicinithart>:

void
plicinithart(void)
{
    80005838:	1141                	addi	sp,sp,-16
    8000583a:	e406                	sd	ra,8(sp)
    8000583c:	e022                	sd	s0,0(sp)
    8000583e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005840:	958fc0ef          	jal	80001998 <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(volatile uint32 *)PLIC_SENABLE(hart) =
    80005844:	0085179b          	slliw	a5,a0,0x8
    80005848:	0c002737          	lui	a4,0xc002
    8000584c:	08070713          	addi	a4,a4,128 # c002080 <_entry-0x73ffdf80>
    80005850:	97ba                	add	a5,a5,a4
    80005852:	40200713          	li	a4,1026
    80005856:	c398                	sw	a4,0(a5)
    (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);

  // set this hart's S-mode priority threshold to 0.
  *(volatile uint32 *)PLIC_SPRIORITY(hart) = 0;
    80005858:	00d5151b          	slliw	a0,a0,0xd
    8000585c:	0c2017b7          	lui	a5,0xc201
    80005860:	953e                	add	a0,a0,a5
    80005862:	00052023          	sw	zero,0(a0)
}
    80005866:	60a2                	ld	ra,8(sp)
    80005868:	6402                	ld	s0,0(sp)
    8000586a:	0141                	addi	sp,sp,16
    8000586c:	8082                	ret

000000008000586e <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000586e:	1141                	addi	sp,sp,-16
    80005870:	e406                	sd	ra,8(sp)
    80005872:	e022                	sd	s0,0(sp)
    80005874:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005876:	922fc0ef          	jal	80001998 <cpuid>
  int irq = *(volatile uint32 *)PLIC_SCLAIM(hart);
    8000587a:	00d5151b          	slliw	a0,a0,0xd
    8000587e:	0c2017b7          	lui	a5,0xc201
    80005882:	0791                	addi	a5,a5,4 # c201004 <_entry-0x73dfeffc>
    80005884:	953e                	add	a0,a0,a5
    80005886:	4108                	lw	a0,0(a0)
  return irq;
}
    80005888:	60a2                	ld	ra,8(sp)
    8000588a:	6402                	ld	s0,0(sp)
    8000588c:	0141                	addi	sp,sp,16
    8000588e:	8082                	ret

0000000080005890 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005890:	1101                	addi	sp,sp,-32
    80005892:	ec06                	sd	ra,24(sp)
    80005894:	e822                	sd	s0,16(sp)
    80005896:	e426                	sd	s1,8(sp)
    80005898:	1000                	addi	s0,sp,32
    8000589a:	84aa                	mv	s1,a0
  int hart = cpuid();
    8000589c:	8fcfc0ef          	jal	80001998 <cpuid>
  *(volatile uint32 *)PLIC_SCLAIM(hart) = irq;
    800058a0:	00d5179b          	slliw	a5,a0,0xd
    800058a4:	0c201737          	lui	a4,0xc201
    800058a8:	0711                	addi	a4,a4,4 # c201004 <_entry-0x73dfeffc>
    800058aa:	97ba                	add	a5,a5,a4
    800058ac:	2481                	sext.w	s1,s1
    800058ae:	c384                	sw	s1,0(a5)
}
    800058b0:	60e2                	ld	ra,24(sp)
    800058b2:	6442                	ld	s0,16(sp)
    800058b4:	64a2                	ld	s1,8(sp)
    800058b6:	6105                	addi	sp,sp,32
    800058b8:	8082                	ret

00000000800058ba <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800058ba:	1141                	addi	sp,sp,-16
    800058bc:	e406                	sd	ra,8(sp)
    800058be:	e022                	sd	s0,0(sp)
    800058c0:	0800                	addi	s0,sp,16
  if (i >= NUM)
    800058c2:	479d                	li	a5,7
    800058c4:	04a7ca63          	blt	a5,a0,80005918 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    800058c8:	0001e797          	auipc	a5,0x1e
    800058cc:	c7878793          	addi	a5,a5,-904 # 80023540 <disk>
    800058d0:	97aa                	add	a5,a5,a0
    800058d2:	0187c783          	lbu	a5,24(a5)
    800058d6:	e7b9                	bnez	a5,80005924 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    800058d8:	00451693          	slli	a3,a0,0x4
    800058dc:	0001e797          	auipc	a5,0x1e
    800058e0:	c6478793          	addi	a5,a5,-924 # 80023540 <disk>
    800058e4:	6398                	ld	a4,0(a5)
    800058e6:	9736                	add	a4,a4,a3
    800058e8:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    800058ec:	6398                	ld	a4,0(a5)
    800058ee:	9736                	add	a4,a4,a3
    800058f0:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800058f4:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800058f8:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800058fc:	97aa                	add	a5,a5,a0
    800058fe:	4705                	li	a4,1
    80005900:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005904:	0001e517          	auipc	a0,0x1e
    80005908:	c5450513          	addi	a0,a0,-940 # 80023558 <disk+0x18>
    8000590c:	f28fc0ef          	jal	80002034 <wakeup>
}
    80005910:	60a2                	ld	ra,8(sp)
    80005912:	6402                	ld	s0,0(sp)
    80005914:	0141                	addi	sp,sp,16
    80005916:	8082                	ret
    panic("free_desc 1");
    80005918:	00002517          	auipc	a0,0x2
    8000591c:	d1850513          	addi	a0,a0,-744 # 80007630 <etext+0x630>
    80005920:	ed1fa0ef          	jal	800007f0 <panic>
    panic("free_desc 2");
    80005924:	00002517          	auipc	a0,0x2
    80005928:	d1c50513          	addi	a0,a0,-740 # 80007640 <etext+0x640>
    8000592c:	ec5fa0ef          	jal	800007f0 <panic>

0000000080005930 <virtio_disk_init>:
{
    80005930:	1101                	addi	sp,sp,-32
    80005932:	ec06                	sd	ra,24(sp)
    80005934:	e822                	sd	s0,16(sp)
    80005936:	e426                	sd	s1,8(sp)
    80005938:	e04a                	sd	s2,0(sp)
    8000593a:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    8000593c:	00002597          	auipc	a1,0x2
    80005940:	d1458593          	addi	a1,a1,-748 # 80007650 <etext+0x650>
    80005944:	0001e517          	auipc	a0,0x1e
    80005948:	d2450513          	addi	a0,a0,-732 # 80023668 <disk+0x128>
    8000594c:	ab4fb0ef          	jal	80000c00 <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005950:	100017b7          	lui	a5,0x10001
    80005954:	4398                	lw	a4,0(a5)
    80005956:	2701                	sext.w	a4,a4
    80005958:	747277b7          	lui	a5,0x74727
    8000595c:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005960:	18f71063          	bne	a4,a5,80005ae0 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005964:	100017b7          	lui	a5,0x10001
    80005968:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    8000596a:	439c                	lw	a5,0(a5)
    8000596c:	2781                	sext.w	a5,a5
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    8000596e:	4709                	li	a4,2
    80005970:	16e79863          	bne	a5,a4,80005ae0 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005974:	100017b7          	lui	a5,0x10001
    80005978:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    8000597a:	439c                	lw	a5,0(a5)
    8000597c:	2781                	sext.w	a5,a5
    8000597e:	16e79163          	bne	a5,a4,80005ae0 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    80005982:	100017b7          	lui	a5,0x10001
    80005986:	47d8                	lw	a4,12(a5)
    80005988:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000598a:	554d47b7          	lui	a5,0x554d4
    8000598e:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005992:	14f71763          	bne	a4,a5,80005ae0 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005996:	100017b7          	lui	a5,0x10001
    8000599a:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000599e:	4705                	li	a4,1
    800059a0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800059a2:	470d                	li	a4,3
    800059a4:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800059a6:	10001737          	lui	a4,0x10001
    800059aa:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    800059ac:	c7ffe737          	lui	a4,0xc7ffe
    800059b0:	55f70713          	addi	a4,a4,1375 # ffffffffc7ffe55f <end+0xffffffff47fdaedf>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800059b4:	8ef9                	and	a3,a3,a4
    800059b6:	10001737          	lui	a4,0x10001
    800059ba:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    800059bc:	472d                	li	a4,11
    800059be:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800059c0:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    800059c4:	439c                	lw	a5,0(a5)
    800059c6:	0007891b          	sext.w	s2,a5
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800059ca:	8ba1                	andi	a5,a5,8
    800059cc:	12078063          	beqz	a5,80005aec <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800059d0:	100017b7          	lui	a5,0x10001
    800059d4:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    800059d8:	100017b7          	lui	a5,0x10001
    800059dc:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    800059e0:	439c                	lw	a5,0(a5)
    800059e2:	2781                	sext.w	a5,a5
    800059e4:	10079a63          	bnez	a5,80005af8 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800059e8:	100017b7          	lui	a5,0x10001
    800059ec:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    800059f0:	439c                	lw	a5,0(a5)
    800059f2:	2781                	sext.w	a5,a5
  if (max == 0)
    800059f4:	10078863          	beqz	a5,80005b04 <virtio_disk_init+0x1d4>
  if (max < NUM)
    800059f8:	471d                	li	a4,7
    800059fa:	10f77b63          	bgeu	a4,a5,80005b10 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    800059fe:	996fb0ef          	jal	80000b94 <kalloc>
    80005a02:	0001e497          	auipc	s1,0x1e
    80005a06:	b3e48493          	addi	s1,s1,-1218 # 80023540 <disk>
    80005a0a:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005a0c:	988fb0ef          	jal	80000b94 <kalloc>
    80005a10:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005a12:	982fb0ef          	jal	80000b94 <kalloc>
    80005a16:	87aa                	mv	a5,a0
    80005a18:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    80005a1a:	6088                	ld	a0,0(s1)
    80005a1c:	10050063          	beqz	a0,80005b1c <virtio_disk_init+0x1ec>
    80005a20:	0001e717          	auipc	a4,0x1e
    80005a24:	b2873703          	ld	a4,-1240(a4) # 80023548 <disk+0x8>
    80005a28:	0e070a63          	beqz	a4,80005b1c <virtio_disk_init+0x1ec>
    80005a2c:	0e078863          	beqz	a5,80005b1c <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    80005a30:	6605                	lui	a2,0x1
    80005a32:	4581                	li	a1,0
    80005a34:	b06fb0ef          	jal	80000d3a <memset>
  memset(disk.avail, 0, PGSIZE);
    80005a38:	0001e497          	auipc	s1,0x1e
    80005a3c:	b0848493          	addi	s1,s1,-1272 # 80023540 <disk>
    80005a40:	6605                	lui	a2,0x1
    80005a42:	4581                	li	a1,0
    80005a44:	6488                	ld	a0,8(s1)
    80005a46:	af4fb0ef          	jal	80000d3a <memset>
  memset(disk.used, 0, PGSIZE);
    80005a4a:	6605                	lui	a2,0x1
    80005a4c:	4581                	li	a1,0
    80005a4e:	6888                	ld	a0,16(s1)
    80005a50:	aeafb0ef          	jal	80000d3a <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005a54:	100017b7          	lui	a5,0x10001
    80005a58:	4721                	li	a4,8
    80005a5a:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005a5c:	4098                	lw	a4,0(s1)
    80005a5e:	100017b7          	lui	a5,0x10001
    80005a62:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005a66:	40d8                	lw	a4,4(s1)
    80005a68:	100017b7          	lui	a5,0x10001
    80005a6c:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005a70:	649c                	ld	a5,8(s1)
    80005a72:	0007869b          	sext.w	a3,a5
    80005a76:	10001737          	lui	a4,0x10001
    80005a7a:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005a7e:	9781                	srai	a5,a5,0x20
    80005a80:	10001737          	lui	a4,0x10001
    80005a84:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005a88:	689c                	ld	a5,16(s1)
    80005a8a:	0007869b          	sext.w	a3,a5
    80005a8e:	10001737          	lui	a4,0x10001
    80005a92:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005a96:	9781                	srai	a5,a5,0x20
    80005a98:	10001737          	lui	a4,0x10001
    80005a9c:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005aa0:	10001737          	lui	a4,0x10001
    80005aa4:	4785                	li	a5,1
    80005aa6:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005aa8:	00f48c23          	sb	a5,24(s1)
    80005aac:	00f48ca3          	sb	a5,25(s1)
    80005ab0:	00f48d23          	sb	a5,26(s1)
    80005ab4:	00f48da3          	sb	a5,27(s1)
    80005ab8:	00f48e23          	sb	a5,28(s1)
    80005abc:	00f48ea3          	sb	a5,29(s1)
    80005ac0:	00f48f23          	sb	a5,30(s1)
    80005ac4:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005ac8:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005acc:	100017b7          	lui	a5,0x10001
    80005ad0:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    80005ad4:	60e2                	ld	ra,24(sp)
    80005ad6:	6442                	ld	s0,16(sp)
    80005ad8:	64a2                	ld	s1,8(sp)
    80005ada:	6902                	ld	s2,0(sp)
    80005adc:	6105                	addi	sp,sp,32
    80005ade:	8082                	ret
    panic("could not find virtio disk");
    80005ae0:	00002517          	auipc	a0,0x2
    80005ae4:	b8050513          	addi	a0,a0,-1152 # 80007660 <etext+0x660>
    80005ae8:	d09fa0ef          	jal	800007f0 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005aec:	00002517          	auipc	a0,0x2
    80005af0:	b9450513          	addi	a0,a0,-1132 # 80007680 <etext+0x680>
    80005af4:	cfdfa0ef          	jal	800007f0 <panic>
    panic("virtio disk should not be ready");
    80005af8:	00002517          	auipc	a0,0x2
    80005afc:	ba850513          	addi	a0,a0,-1112 # 800076a0 <etext+0x6a0>
    80005b00:	cf1fa0ef          	jal	800007f0 <panic>
    panic("virtio disk has no queue 0");
    80005b04:	00002517          	auipc	a0,0x2
    80005b08:	bbc50513          	addi	a0,a0,-1092 # 800076c0 <etext+0x6c0>
    80005b0c:	ce5fa0ef          	jal	800007f0 <panic>
    panic("virtio disk max queue too short");
    80005b10:	00002517          	auipc	a0,0x2
    80005b14:	bd050513          	addi	a0,a0,-1072 # 800076e0 <etext+0x6e0>
    80005b18:	cd9fa0ef          	jal	800007f0 <panic>
    panic("virtio disk kalloc");
    80005b1c:	00002517          	auipc	a0,0x2
    80005b20:	be450513          	addi	a0,a0,-1052 # 80007700 <etext+0x700>
    80005b24:	ccdfa0ef          	jal	800007f0 <panic>

0000000080005b28 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005b28:	7159                	addi	sp,sp,-112
    80005b2a:	f486                	sd	ra,104(sp)
    80005b2c:	f0a2                	sd	s0,96(sp)
    80005b2e:	eca6                	sd	s1,88(sp)
    80005b30:	e8ca                	sd	s2,80(sp)
    80005b32:	e4ce                	sd	s3,72(sp)
    80005b34:	e0d2                	sd	s4,64(sp)
    80005b36:	fc56                	sd	s5,56(sp)
    80005b38:	f85a                	sd	s6,48(sp)
    80005b3a:	f45e                	sd	s7,40(sp)
    80005b3c:	f062                	sd	s8,32(sp)
    80005b3e:	ec66                	sd	s9,24(sp)
    80005b40:	1880                	addi	s0,sp,112
    80005b42:	8a2a                	mv	s4,a0
    80005b44:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005b46:	00c52c83          	lw	s9,12(a0)
    80005b4a:	001c9c9b          	slliw	s9,s9,0x1
    80005b4e:	1c82                	slli	s9,s9,0x20
    80005b50:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    80005b54:	0001e517          	auipc	a0,0x1e
    80005b58:	b1450513          	addi	a0,a0,-1260 # 80023668 <disk+0x128>
    80005b5c:	91afb0ef          	jal	80000c76 <acquire>
  for (int i = 0; i < 3; i++) {
    80005b60:	4981                	li	s3,0
  for (int i = 0; i < NUM; i++) {
    80005b62:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005b64:	0001eb17          	auipc	s6,0x1e
    80005b68:	9dcb0b13          	addi	s6,s6,-1572 # 80023540 <disk>
  for (int i = 0; i < 3; i++) {
    80005b6c:	4a8d                	li	s5,3
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80005b6e:	0001ec17          	auipc	s8,0x1e
    80005b72:	9eac0c13          	addi	s8,s8,-1558 # 80023558 <disk+0x18>
    80005b76:	a0bd                	j	80005be4 <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    80005b78:	00fb0733          	add	a4,s6,a5
    80005b7c:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005b80:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    80005b82:	0207c563          	bltz	a5,80005bac <virtio_disk_rw+0x84>
  for (int i = 0; i < 3; i++) {
    80005b86:	2905                	addiw	s2,s2,1
    80005b88:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005b8a:	07590163          	beq	s2,s5,80005bec <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    80005b8e:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    80005b90:	0001e717          	auipc	a4,0x1e
    80005b94:	9b070713          	addi	a4,a4,-1616 # 80023540 <disk>
    80005b98:	87ce                	mv	a5,s3
    if (disk.free[i]) {
    80005b9a:	01874683          	lbu	a3,24(a4)
    80005b9e:	fee9                	bnez	a3,80005b78 <virtio_disk_rw+0x50>
  for (int i = 0; i < NUM; i++) {
    80005ba0:	2785                	addiw	a5,a5,1
    80005ba2:	0705                	addi	a4,a4,1
    80005ba4:	fe979be3          	bne	a5,s1,80005b9a <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005ba8:	57fd                	li	a5,-1
    80005baa:	c19c                	sw	a5,0(a1)
      for (int j = 0; j < i; j++)
    80005bac:	01205d63          	blez	s2,80005bc6 <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005bb0:	f9042503          	lw	a0,-112(s0)
    80005bb4:	d07ff0ef          	jal	800058ba <free_desc>
      for (int j = 0; j < i; j++)
    80005bb8:	4785                	li	a5,1
    80005bba:	0127d663          	bge	a5,s2,80005bc6 <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005bbe:	f9442503          	lw	a0,-108(s0)
    80005bc2:	cf9ff0ef          	jal	800058ba <free_desc>
    sleep_prepare(&disk.free[0]);
    80005bc6:	8562                	mv	a0,s8
    80005bc8:	c00fc0ef          	jal	80001fc8 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005bcc:	0001e917          	auipc	s2,0x1e
    80005bd0:	a9c90913          	addi	s2,s2,-1380 # 80023668 <disk+0x128>
    80005bd4:	854a                	mv	a0,s2
    80005bd6:	92cfb0ef          	jal	80000d02 <release>
    sleep();
    80005bda:	c2afc0ef          	jal	80002004 <sleep>
    acquire(&disk.vdisk_lock);
    80005bde:	854a                	mv	a0,s2
    80005be0:	896fb0ef          	jal	80000c76 <acquire>
  for (int i = 0; i < 3; i++) {
    80005be4:	f9040613          	addi	a2,s0,-112
    80005be8:	894e                	mv	s2,s3
    80005bea:	b755                	j	80005b8e <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005bec:	f9042503          	lw	a0,-112(s0)
    80005bf0:	00451693          	slli	a3,a0,0x4

  if (write)
    80005bf4:	0001e797          	auipc	a5,0x1e
    80005bf8:	94c78793          	addi	a5,a5,-1716 # 80023540 <disk>
    80005bfc:	00a50713          	addi	a4,a0,10
    80005c00:	0712                	slli	a4,a4,0x4
    80005c02:	973e                	add	a4,a4,a5
    80005c04:	01703633          	snez	a2,s7
    80005c08:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005c0a:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005c0e:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    80005c12:	6398                	ld	a4,0(a5)
    80005c14:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005c16:	0a868613          	addi	a2,a3,168
    80005c1a:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005c1c:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005c1e:	6390                	ld	a2,0(a5)
    80005c20:	00d605b3          	add	a1,a2,a3
    80005c24:	4741                	li	a4,16
    80005c26:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005c28:	4805                	li	a6,1
    80005c2a:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005c2e:	f9442703          	lw	a4,-108(s0)
    80005c32:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80005c36:	0712                	slli	a4,a4,0x4
    80005c38:	963a                	add	a2,a2,a4
    80005c3a:	058a0593          	addi	a1,s4,88
    80005c3e:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005c40:	0007b883          	ld	a7,0(a5)
    80005c44:	9746                	add	a4,a4,a7
    80005c46:	40000613          	li	a2,1024
    80005c4a:	c710                	sw	a2,8(a4)
  if (write)
    80005c4c:	001bb613          	seqz	a2,s7
    80005c50:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005c54:	00166613          	ori	a2,a2,1
    80005c58:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005c5c:	f9842583          	lw	a1,-104(s0)
    80005c60:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005c64:	00250613          	addi	a2,a0,2
    80005c68:	0612                	slli	a2,a2,0x4
    80005c6a:	963e                	add	a2,a2,a5
    80005c6c:	577d                	li	a4,-1
    80005c6e:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80005c72:	0592                	slli	a1,a1,0x4
    80005c74:	98ae                	add	a7,a7,a1
    80005c76:	03068713          	addi	a4,a3,48
    80005c7a:	973e                	add	a4,a4,a5
    80005c7c:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005c80:	6398                	ld	a4,0(a5)
    80005c82:	972e                	add	a4,a4,a1
    80005c84:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005c88:	4689                	li	a3,2
    80005c8a:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005c8e:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005c92:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    80005c96:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005c9a:	6794                	ld	a3,8(a5)
    80005c9c:	0026d703          	lhu	a4,2(a3)
    80005ca0:	8b1d                	andi	a4,a4,7
    80005ca2:	0706                	slli	a4,a4,0x1
    80005ca4:	96ba                	add	a3,a3,a4
    80005ca6:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005caa:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005cae:	6798                	ld	a4,8(a5)
    80005cb0:	00275783          	lhu	a5,2(a4)
    80005cb4:	2785                	addiw	a5,a5,1
    80005cb6:	00f71123          	sh	a5,2(a4)
    80005cba:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005cbe:	100017b7          	lui	a5,0x10001
    80005cc2:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80005cc6:	004a2783          	lw	a5,4(s4)
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    80005cca:	0001e497          	auipc	s1,0x1e
    80005cce:	99e48493          	addi	s1,s1,-1634 # 80023668 <disk+0x128>
  while (b->disk == 1) {
    80005cd2:	4905                	li	s2,1
    80005cd4:	03079163          	bne	a5,a6,80005cf6 <virtio_disk_rw+0x1ce>
    sleep_prepare(b);
    80005cd8:	8552                	mv	a0,s4
    80005cda:	aeefc0ef          	jal	80001fc8 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005cde:	8526                	mv	a0,s1
    80005ce0:	822fb0ef          	jal	80000d02 <release>
    sleep();
    80005ce4:	b20fc0ef          	jal	80002004 <sleep>
    acquire(&disk.vdisk_lock);
    80005ce8:	8526                	mv	a0,s1
    80005cea:	f8dfa0ef          	jal	80000c76 <acquire>
  while (b->disk == 1) {
    80005cee:	004a2783          	lw	a5,4(s4)
    80005cf2:	ff2783e3          	beq	a5,s2,80005cd8 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    80005cf6:	f9042903          	lw	s2,-112(s0)
    80005cfa:	00290713          	addi	a4,s2,2
    80005cfe:	0712                	slli	a4,a4,0x4
    80005d00:	0001e797          	auipc	a5,0x1e
    80005d04:	84078793          	addi	a5,a5,-1984 # 80023540 <disk>
    80005d08:	97ba                	add	a5,a5,a4
    80005d0a:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005d0e:	0001e997          	auipc	s3,0x1e
    80005d12:	83298993          	addi	s3,s3,-1998 # 80023540 <disk>
    80005d16:	00491713          	slli	a4,s2,0x4
    80005d1a:	0009b783          	ld	a5,0(s3)
    80005d1e:	97ba                	add	a5,a5,a4
    80005d20:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005d24:	854a                	mv	a0,s2
    80005d26:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005d2a:	b91ff0ef          	jal	800058ba <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    80005d2e:	8885                	andi	s1,s1,1
    80005d30:	f0fd                	bnez	s1,80005d16 <virtio_disk_rw+0x1ee>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005d32:	0001e517          	auipc	a0,0x1e
    80005d36:	93650513          	addi	a0,a0,-1738 # 80023668 <disk+0x128>
    80005d3a:	fc9fa0ef          	jal	80000d02 <release>
}
    80005d3e:	70a6                	ld	ra,104(sp)
    80005d40:	7406                	ld	s0,96(sp)
    80005d42:	64e6                	ld	s1,88(sp)
    80005d44:	6946                	ld	s2,80(sp)
    80005d46:	69a6                	ld	s3,72(sp)
    80005d48:	6a06                	ld	s4,64(sp)
    80005d4a:	7ae2                	ld	s5,56(sp)
    80005d4c:	7b42                	ld	s6,48(sp)
    80005d4e:	7ba2                	ld	s7,40(sp)
    80005d50:	7c02                	ld	s8,32(sp)
    80005d52:	6ce2                	ld	s9,24(sp)
    80005d54:	6165                	addi	sp,sp,112
    80005d56:	8082                	ret

0000000080005d58 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005d58:	1101                	addi	sp,sp,-32
    80005d5a:	ec06                	sd	ra,24(sp)
    80005d5c:	e822                	sd	s0,16(sp)
    80005d5e:	e426                	sd	s1,8(sp)
    80005d60:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005d62:	0001d497          	auipc	s1,0x1d
    80005d66:	7de48493          	addi	s1,s1,2014 # 80023540 <disk>
    80005d6a:	0001e517          	auipc	a0,0x1e
    80005d6e:	8fe50513          	addi	a0,a0,-1794 # 80023668 <disk+0x128>
    80005d72:	f05fa0ef          	jal	80000c76 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005d76:	100017b7          	lui	a5,0x10001
    80005d7a:	53b8                	lw	a4,96(a5)
    80005d7c:	8b0d                	andi	a4,a4,3
    80005d7e:	100017b7          	lui	a5,0x10001
    80005d82:	d3f8                	sw	a4,100(a5)
    80005d84:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80005d88:	689c                	ld	a5,16(s1)
    80005d8a:	0204d703          	lhu	a4,32(s1)
    80005d8e:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    80005d92:	04f70663          	beq	a4,a5,80005dde <virtio_disk_intr+0x86>
    80005d96:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005d9a:	6898                	ld	a4,16(s1)
    80005d9c:	0204d783          	lhu	a5,32(s1)
    80005da0:	8b9d                	andi	a5,a5,7
    80005da2:	078e                	slli	a5,a5,0x3
    80005da4:	97ba                	add	a5,a5,a4
    80005da6:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80005da8:	00278713          	addi	a4,a5,2
    80005dac:	0712                	slli	a4,a4,0x4
    80005dae:	9726                	add	a4,a4,s1
    80005db0:	01074703          	lbu	a4,16(a4)
    80005db4:	e321                	bnez	a4,80005df4 <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005db6:	0789                	addi	a5,a5,2
    80005db8:	0792                	slli	a5,a5,0x4
    80005dba:	97a6                	add	a5,a5,s1
    80005dbc:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    80005dbe:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005dc2:	a72fc0ef          	jal	80002034 <wakeup>

    disk.used_idx += 1;
    80005dc6:	0204d783          	lhu	a5,32(s1)
    80005dca:	2785                	addiw	a5,a5,1
    80005dcc:	17c2                	slli	a5,a5,0x30
    80005dce:	93c1                	srli	a5,a5,0x30
    80005dd0:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80005dd4:	6898                	ld	a4,16(s1)
    80005dd6:	00275703          	lhu	a4,2(a4)
    80005dda:	faf71ee3          	bne	a4,a5,80005d96 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005dde:	0001e517          	auipc	a0,0x1e
    80005de2:	88a50513          	addi	a0,a0,-1910 # 80023668 <disk+0x128>
    80005de6:	f1dfa0ef          	jal	80000d02 <release>
}
    80005dea:	60e2                	ld	ra,24(sp)
    80005dec:	6442                	ld	s0,16(sp)
    80005dee:	64a2                	ld	s1,8(sp)
    80005df0:	6105                	addi	sp,sp,32
    80005df2:	8082                	ret
      panic("virtio_disk_intr status");
    80005df4:	00002517          	auipc	a0,0x2
    80005df8:	92450513          	addi	a0,a0,-1756 # 80007718 <etext+0x718>
    80005dfc:	9f5fa0ef          	jal	800007f0 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	0000100f          	fence.i
    800060a0:	12000073          	sfence.vma
    800060a4:	18051073          	csrw	satp,a0
    800060a8:	12000073          	sfence.vma
    800060ac:	02000537          	lui	a0,0x2000
    800060b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060b2:	0536                	slli	a0,a0,0xd
    800060b4:	02853083          	ld	ra,40(a0)
    800060b8:	03053103          	ld	sp,48(a0)
    800060bc:	03853183          	ld	gp,56(a0)
    800060c0:	04053203          	ld	tp,64(a0)
    800060c4:	04853283          	ld	t0,72(a0)
    800060c8:	05053303          	ld	t1,80(a0)
    800060cc:	05853383          	ld	t2,88(a0)
    800060d0:	7120                	ld	s0,96(a0)
    800060d2:	7524                	ld	s1,104(a0)
    800060d4:	7d2c                	ld	a1,120(a0)
    800060d6:	6150                	ld	a2,128(a0)
    800060d8:	6554                	ld	a3,136(a0)
    800060da:	6958                	ld	a4,144(a0)
    800060dc:	6d5c                	ld	a5,152(a0)
    800060de:	0a053803          	ld	a6,160(a0)
    800060e2:	0a853883          	ld	a7,168(a0)
    800060e6:	0b053903          	ld	s2,176(a0)
    800060ea:	0b853983          	ld	s3,184(a0)
    800060ee:	0c053a03          	ld	s4,192(a0)
    800060f2:	0c853a83          	ld	s5,200(a0)
    800060f6:	0d053b03          	ld	s6,208(a0)
    800060fa:	0d853b83          	ld	s7,216(a0)
    800060fe:	0e053c03          	ld	s8,224(a0)
    80006102:	0e853c83          	ld	s9,232(a0)
    80006106:	0f053d03          	ld	s10,240(a0)
    8000610a:	0f853d83          	ld	s11,248(a0)
    8000610e:	10053e03          	ld	t3,256(a0)
    80006112:	10853e83          	ld	t4,264(a0)
    80006116:	11053f03          	ld	t5,272(a0)
    8000611a:	11853f83          	ld	t6,280(a0)
    8000611e:	7928                	ld	a0,112(a0)
    80006120:	10200073          	sret
	...
