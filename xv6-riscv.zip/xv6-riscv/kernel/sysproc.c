#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  kexit(n);
  return 0; // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return kfork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return kwait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
  argint(1, &t);
  addr = myproc()->sz;

  if (t == SBRK_EAGER || n < 0) {
    if (growproc(n) < 0) {
      return -1;
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
      return -1;
    if (addr + n > TRAPFRAME)
      return -1;
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_pause(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if (n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    release(&tickslock);
    sleep();
    acquire(&tickslock);
  }
  release(&tickslock);
  return 0;
}

struct pageinfo {
  uint64 va;
  uint64 pa;
  int present;
  int writable;
  int user;
};

uint64
sys_kallocstats(void)
{
  uint64 addr;
  struct kalloc_stats stats;

  argaddr(0, &addr);
  kallocstats(&stats);
  if (copyout(myproc()->pagetable, myproc()->sz, addr, (char *)&stats,
              sizeof(stats)) < 0)
    return -1;
  return 0;
}

uint64
sys_vtop(void)
{
  uint64 va;

  argaddr(0, &va);
  return vtop(myproc()->pagetable, va);
}

uint64
sys_pageinfo(void)
{
  uint64 va;
  uint64 outaddr;
  struct pageinfo info;
  pte_t *pte;

  argaddr(0, &va);
  argaddr(1, &outaddr);

  info.va = va;
  pte = walk(myproc()->pagetable, va, 0);
  info.present = (pte != 0 && (*pte & PTE_V) != 0);
  info.writable = info.present && ((*pte & PTE_W) != 0);
  info.user = info.present && ((*pte & PTE_U) != 0);
  info.pa = info.present ? PTE2PA(*pte) + (va - PGROUNDDOWN(va)) : 0;

  if (copyout(myproc()->pagetable, myproc()->sz, outaddr, (char *)&info,
              sizeof(info)) < 0)
    return -1;
  return 0;
}

uint64
sys_setreadonly(void)
{
  uint64 va;
  pte_t *pte;

  argaddr(0, &va);
  if (va >= MAXVA)
    return -1;

  pte = walk(myproc()->pagetable, va, 0);
  if (pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0)
    return -1;

  *pte &= ~PTE_W;
  sfence_vma();
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kkill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
